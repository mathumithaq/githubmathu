<?php get_header(); ?>

<main id="primary" class="site-main default-page-main">
	<h1><?php single_post_title(); ?></h1>
	<?php
	if ( have_posts() ) :
		while ( have_posts() ) :
			the_post();
			the_content();
		endwhile;
	else :
		echo '<p>No content found.</p>';
	endif;
	?>
</main><!-- #main -->

<?php get_footer(); ?>
