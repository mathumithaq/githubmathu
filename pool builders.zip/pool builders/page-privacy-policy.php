<?php
/**
 * Template for Privacy Policy Page
 */
get_header(); ?>

<main class="legal-page-main" style="background-image: url('<?php echo get_template_directory_uri(); ?>/assets/images/pool-footer-bg.webp');">
    <!-- Dark overlay -->
    <div class="legal-page-overlay"></div>
    
    <!-- White content box -->
    <div class="kd-container legal-content-box">
        <h1 class="legal-page-title">Privacy Policy</h1>
        
        <div class="legal-content">
            <p><strong>Effective Date:</strong> 19/03/2025</p>
            <p><strong>Last Updated:</strong> 19/03/2025</p>
            <p>KD Pool Builders is committed to protecting your privacy and personal data. This Privacy Policy outlines how we collect, use, and protect your information in compliance with applicable U.S. data privacy laws, including the California Consumer Privacy Act (CCPA), the New York SHIELD Act, and other relevant state and federal regulations. For users based in the European Union (EU) or European Economic Area (EEA), we also adhere to the General Data Protection Regulation (GDPR) where applicable.</p>
            <p>This notice provides you with the necessary information regarding your rights, our obligations, and explains why, when, and how we process your personal data.</p>
            <h2>The Information That We Collect From You</h2>
            <p>We process your personal information to meet our legal, contractual, and business obligations. We will never collect unnecessary personal data or process your information in ways other than those specified in this notice.</p>
            <p>The personal data we collect includes:</p>
            <ul>
            <li>Name</li>
            <li>Address</li>
            <li>Email</li>
            <li>Telephone Number</li>
            <li>Mobile Telephone Number</li>
            <li>Contact person(s) contact information</li>
            <li>Our correspondence and communications with you</li>
            </ul>
            <h2>How Your Personal Data May Be Used</h2>
            <p>KD Pool Builders respects your privacy and will never disclose, share, or sell your data without your consent, unless required to do so by law. We retain your data only for as long as is necessary for the purposes specified in this notice.</p>
            <p>We use your personal data to:</p>
            <ul>
            <li>Provide services and ensure that all requirements are completed</li>
            <li>Occasionally send marketing information when beneficial and of interest to you as a customer, processed under legitimate interests</li>
            <li>Share necessary information with independent contractors or subcontractors for performing services related to our business</li>
            </ul>
            <p>Providing your personal information is voluntary; however, without it, we may not be able to offer some or all of our services.</p>
            <h2>SMS Opt-In Information</h2>
            <p>By providing your mobile phone number, you may opt in to receive SMS messages from KD Pool Builders regarding promotions, updates, or important information. By opting in, you agree to receive text messages at the number provided. Message and data rates may apply.</p>
            <p>You can opt out at any time by replying “STOP” to any message received, or by contacting us directly via sales@kdpoolbuilders.com or (716) 300-2773. Opting out will not affect your ability to receive other forms of communication from us if you consent.</p>
            <h2>Your Rights In Relation to Your Information</h2>
            <p>Depending on your location, you have certain rights regarding your personal information:</p>
            <p><strong>Under U.S. State Laws (e.g., CCPA):</strong></p>
            <ul>
            <li>The right to know what personal data we collect and why</li>
            <li>The right to request access to your data</li>
            <li>The right to request deletion of your data (subject to certain legal exceptions)</li>
            <li>The right to opt out of the sale of personal data (if applicable)</li>
            </ul>
            <p><strong>Under GDPR (for EU/EEA users):</strong></p>
            <ul>
            <li>The right to access your personal data</li>
            <li>The right to rectify or delete your data</li>
            <li>The right to restrict processing or object to its use</li>
            <li>The right to data portability</li>
            </ul>
            <p>If you wish to exercise any of these rights, we may ask you to verify your identity to ensure your data is protected and secure.</p>
            <h2>Sharing and Disclosing Your Personal Information</h2>
            <p>We do not share or disclose your personal information without your consent, except for the purposes specified in this notice or as required by law. We may use third-party service providers, but they process your data only under our instructions and comply fully with this Privacy Policy and applicable laws.</p>
            <h2>Safeguarding Measures</h2>
            <p>We take every reasonable measure to protect your personal data from unauthorized access, alteration, disclosure, or destruction.</p>
            <h2>Transfers Outside the U.S. or EU</h2>
            <p>If your data is transferred outside the U.S. or EU, we ensure it is protected by appropriate safeguards in compliance with applicable laws.</p>
            <h2>How Long We Keep Your Data</h2>
            <p>We retain personal information only as long as necessary for the purposes outlined in this Privacy Policy. If you consent to receive marketing communications, we retain your data until you withdraw your consent.</p>
            <h2>Use of Cookies</h2>
            <p>This website uses cookies to enhance your experience. The cookies used on this site do not store personal data but instead collect anonymous tracking information.</p>
            <h2>Grievance</h2>
            <p>We process your personal information in compliance with this Privacy Policy and applicable laws. If you have any concerns or wish to lodge a complaint, you may contact us directly. For unresolved complaints, you can contact the New York Attorney General’s Office or other relevant regulatory authorities in your jurisdiction.</p>
            <p>For EU/EEA users, complaints can be directed to the Information Commissioner’s Office (ICO):</p>
            <p>1496 Main St, Buffalo, NY 14209, United States.<br>
            (716) 300-2773<br>
            sales@kdpoolbuilders.com</p>
            <h2>Linking to Other Sites from Our Website</h2>
            <p>Our website contains links to other sites not managed by KD Pool Builders. We are not responsible for the privacy practices of these sites. We encourage users to read the privacy statements of all linked websites.</p>
        </div>
    </div>
</main>

<?php get_footer(); ?>
