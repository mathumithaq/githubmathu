<?php
/**
 * Template Name: Blog List
 * 
 * The template for displaying the blog list on the /blog/ page.
 */

get_header(); 
get_template_part('template-parts/header/inner-hero');
?>
<main id="primary" class="site-main blog-list-main">
    <div class="kd-container">
        <div class="blog-list-wrapper">
            <?php 
            $paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
            $blog_query = new WP_Query( array(
                'post_type' => 'post',
                'posts_per_page' => 4,
                'paged' => $paged
            ) );

            if ( $blog_query->have_posts() ) : ?>
                <div class="blog-list-container">
                    <?php 
                    $post_count = 0;
                    while ( $blog_query->have_posts() ) : $blog_query->the_post(); 
                        $post_count++;
                        // Alternate the class based on odd/even
                        $alt_class = ($post_count % 2 == 0) ? 'alt-layout' : '';
                    ?>
                        
                        <article id="post-<?php the_ID(); ?>" <?php post_class('blog-list-card ' . $alt_class); ?>>
                            
                            <!-- CONTENT SIDE -->
                            <div class="blog-list-content">
                                <div class="blog-list-meta">
                                    <span class="meta-date">
                                        <i class="far fa-clock"></i>
                                        <?php echo get_the_modified_date(); ?>
                                    </span>
                                    <span class="meta-category">
                                        <i class="far fa-folder"></i>
                                        <?php the_category(', '); ?>
                                    </span>
                                    <span class="meta-author">
                                        <i class="far fa-user"></i>
                                        by: <?php the_author(); ?>
                                    </span>
                                </div>
                                
                                <h2 class="blog-list-title">
                                    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                </h2>
                                
                                <div class="blog-list-footer">
                                    <a href="<?php the_permalink(); ?>" class="blog-list-read-more">
                                        Read More <span class="read-more-icon"><?php echo kdpool_get_icon('arrow-right'); ?></span>
                                    </a>
                                </div>
                            </div>

                            <!-- IMAGE SIDE -->
                            <?php if ( has_post_thumbnail() ) : ?>
                                <div class="blog-list-image">
                                    <a href="<?php the_permalink(); ?>">
                                        <?php the_post_thumbnail( 'large', array( 'class' => 'img-responsive', 'loading' => 'lazy', 'decoding' => 'async' ) ); ?>
                                    </a>
                                </div>
                            <?php else : ?>
                                <!-- Fallback image if no featured image -->
                                <div class="blog-list-image">
                                    <a href="<?php the_permalink(); ?>">
                                        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/placeholder.webp" alt="No image" class="img-responsive"<?php echo kdpool_get_image_attrs('placeholder.webp'); ?>>
                                    </a>
                                </div>
                            <?php endif; ?>
                            
                        </article>

                    <?php endwhile; ?>
                </div>

                <!-- Pagination -->
                <div class="blog-pagination">
                    <?php 
                    echo paginate_links( array(
                        'base'         => str_replace( 999999999, '%#%', esc_url( get_pagenum_link( 999999999 ) ) ),
                        'total'        => $blog_query->max_num_pages,
                        'current'      => max( 1, get_query_var( 'paged' ) ),
                        'format'       => '?paged=%#%',
                        'show_all'     => false,
                        'type'         => 'plain',
                        'end_size'     => 2,
                        'mid_size'     => 1,
                        'prev_next'    => true,
                        'prev_text'    => '<i class="fas fa-arrow-left"></i> Prev',
                        'next_text'    => 'Next <i class="fas fa-arrow-right"></i>',
                    ) );
                    ?>
                </div>

                <?php wp_reset_postdata(); ?>

            <?php else : ?>
                <p class="no-posts-found">No blog posts found. Try publishing some posts from your WordPress dashboard!</p>
            <?php endif; ?>
        </div>
    </div>
</main>

<?php get_footer(); ?>
