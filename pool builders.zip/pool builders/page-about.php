<?php
/**
 * Template Name: About Page
 */

get_header();
get_template_part('template-parts/header/inner-hero');
?>

<!-- Add a wrapper for the common background -->
<div class="about-page-wrapper">
	<!-- Common Background Overlay -->
	<div class="about-common-bg"></div>

	<!-- SECTION 1: INTRO (Split Layout) -->
	<section class="about-intro-split animate-section bg-dark-section">
		<div class="kd-container">
			<div class="intro-split-wrapper">

				<!-- Left Image Column -->
				<div class="intro-split-image">
					<div class="image-bg-shape"></div>
					<img src="<?php echo get_template_directory_uri(); ?>/assets/images/about1.webp"
						alt="KD Pool Builders Team"<?php echo kdpool_get_image_attrs('about1.webp'); ?>>
				</div>

				<!-- Right Content Column -->
				<div class="intro-split-content">
					<div class="section-subtitle">
						<?php echo kdpool_get_icon('swimming-pool'); ?>
						<span>Welcome to KD Pool Builders</span>
					</div>
					<h2 class="section-title">
						Your Trusted Partner in Pool Care and Transformation</h2>
					<p>KD Pool Builders is a leading pool construction company based in Buffalo, New York. With 10 years
						of industry expertise, we are committed to providing the best, highest quality swimming pools
						that will transform the look and feel of your home or business.</p>

					<p>At KD Pool Builders, we provide a range of pool services designed to meet the diverse needs of
						residential and commercial clients. From renovating your existing pool, professional
						inspections, and safety certifications to building a brand-new pool, our team at KD Pool
						Builders brings expertise, reliability, and a personal touch to every project.</p>

					<p>Our team is driven by a commitment to making your vision a reality. At KD Pool Builders, we
						Always believe that a well-maintained pool is more than just water; it’s your daily escape with
						friends and family.</p>

					<a href="https://kdpoolbuilders.com/wp-content/uploads/2025/01/kd-pool-developer.pdf"
						target="_blank" rel="noopener noreferrer" class="btn btn-primary intro-download-btn">
						Download Brochure
						<?php echo kdpool_get_icon('download'); ?>
					</a>
				</div>

			</div>
		</div>
	</section>

	<!-- SECTION 2: VISION & MISSION (3-COLUMN CARD) -->
	<section class="about-vision-mission animate-section bg-light-section">
		<div class="kd-container">
			<div class="vm-header">
				<div class="section-subtitle">
					<?php echo kdpool_get_icon('swimming-pool'); ?>
					<span>VISION & MISSION</span>
				</div>
				<h2 class="section-title">Driven by Purpose</h2>
			</div>
			<div class="vm-3col-card">

				<!-- Column 1: Image -->
				<div class="vm-col-image">

				</div>

				<!-- Column 2: Our Mission -->
				<div class="vm-col-mission">
					<!-- Watermark icon behind text -->
					<div class="vm-watermark">
						<?php echo kdpool_get_icon('diamond'); ?>
					</div>

					<div class="vm-icon-box">
						<?php echo kdpool_get_icon('info'); ?>
					</div>

					<h3 class="vm-col-title">Our Mission</h3>
					<div class="vm-col-divider"></div>

					<p>At KD Pool Builders, our mission is to be the most trusted and reliable swimming pool service
						provider in the region. We strive to create and maintain pools that not only look stunning but
						also offer a safe and enjoyable swimming experience for our valued customers. We understand that
						a well-maintained pool is not just a luxury; it's a place where memories are made and cherished.
					</p>
				</div>

				<!-- Column 3: Our Vision -->
				<div class="vm-col-vision">
					<!-- Watermark icon behind text -->
					<div class="vm-watermark">
						<?php echo kdpool_get_icon('target-lg'); ?>
					</div>

					<div class="vm-icon-box">
						<?php echo kdpool_get_icon('target'); ?>
					</div>

					<h3 class="vm-col-title">Our Vision</h3>
					<div class="vm-col-divider"></div>

					<p>Our vision is to build a community of happy and satisfied customers who trust us to keep their
						pools in pristine condition. We envision a world where every pool owner can relax and cherish
						their pool moments without worrying about maintenance and repairs. By offering personalized
						services, we aim to create lasting relationships with our clients and become their preferred
						choice for all their swimming pool needs.</p>
				</div>

			</div>
		</div>
	</section>

	<!-- SECTION 3: WHAT WE DO (TIMELINE) -->
	<section class="about-what-we-do animate-section bg-dark-section">
		<div class="kd-container">

			<!-- Header -->
			<div class="wwd-header">
				<div class="wwd-header-left">
					<div class="section-subtitle">
						<?php echo kdpool_get_icon('swimming-pool'); ?>
						<span>WHAT WE DO</span>
					</div>
					<h2 class="section-title text-white">Our Services</h2>
					<p>We offer a comprehensive range of services to meet all your pool needs:</p>
				</div>
				<div class="wwd-header-right">
					<a href="<?php echo esc_url(home_url('/products/')); ?>" class="btn btn-primary wwd-btn">
						OUR SERVICES
						<?php echo kdpool_get_icon('arrow-right-circle'); ?>
					</a>
				</div>
			</div>

			<!-- Timeline Area -->
			<!-- Carousel Area -->
			<div class="wwd-carousel-wrapper">
				<div class="wwd-carousel">

					<!-- Original Set (5 items) -->
					<!-- Item 1 -->
					<div class="wwd-card">
						<div class="wwd-card-image">
							<img src="<?php echo get_template_directory_uri(); ?>/assets/images/about1.webp"
								alt="Pool Cleaning"<?php echo kdpool_get_image_attrs('about1.webp'); ?>>
							<div class="wwd-card-overlay">
								<p>You can now keep your pool clean and safe with our professional cleaning services. We
									ensure your pool is free of debris, algae, and contaminants while balancing water
									chemistry for optimal safety.</p>

							</div>
						</div>
						<div class="wwd-card-bottom">
							<h4>Pool Cleaning</h4>
							<div class="wwd-card-icon">
								<?php echo kdpool_get_icon('sun'); ?>
							</div>
						</div>
					</div>

					<!-- Item 2 -->
					<div class="wwd-card">
						<div class="wwd-card-image">
							<img src="<?php echo get_template_directory_uri(); ?>/assets/images/about2.webp"
								alt="Pool Repair Services"<?php echo kdpool_get_image_attrs('about2.webp'); ?>>
							<div class="wwd-card-overlay">
								<p>We have expert technicians who can successfully diagnose and repair any pool
									equipment problem, from clogged pumps to malfunctioning heaters and leaks. We use
									high-quality parts.</p>

							</div>
						</div>
						<div class="wwd-card-bottom">
							<h4>Pool Repair Services</h4>
							<div class="wwd-card-icon">
								<?php echo kdpool_get_icon('wrench'); ?>
							</div>
						</div>
					</div>

					<!-- Item 3 -->
					<div class="wwd-card">
						<div class="wwd-card-image">
							<img src="<?php echo get_template_directory_uri(); ?>/assets/images/about3.webp"
								alt="Pool Remodeling"<?php echo kdpool_get_image_attrs('about3.webp'); ?>>
							<div class="wwd-card-overlay">
								<p>If you are looking to transform your pool into modernity, we are here for you with
									our remodeling services, including resurfacing, retiling, and deck upgrades. We
									deliver high-quality results.</p>

							</div>
						</div>
						<div class="wwd-card-bottom">
							<h4>Pool Remodeling</h4>
							<div class="wwd-card-icon">
								<?php echo kdpool_get_icon('layers'); ?>
							</div>
						</div>
					</div>

					<!-- Item 4 -->
					<div class="wwd-card">
						<div class="wwd-card-image">
							<img src="<?php echo get_template_directory_uri(); ?>/assets/images/about4.webp"
								alt="Pool Inspections"<?php echo kdpool_get_image_attrs('about4.webp'); ?>>
							<div class="wwd-card-overlay">
								<p>We provide professional pool inspection services to ensure the safety, efficiency,
									and compliance of your pool. The structural integrity, equipment performance, and
									water quality will be assessed.</p>

							</div>
						</div>
						<div class="wwd-card-bottom">
							<h4>Pool Inspections</h4>
							<div class="wwd-card-icon">
								<?php echo kdpool_get_icon('camera'); ?>
							</div>
						</div>
					</div>

					<!-- Item 5 -->
					<div class="wwd-card">
						<div class="wwd-card-image">
							<img src="<?php echo get_template_directory_uri(); ?>/assets/images/about3.webp"
								alt="Commercial Pool Services"<?php echo kdpool_get_image_attrs('about3.webp'); ?>>
							<div class="wwd-card-overlay">
								<p>Our commercial pool services cater to high-usage facilities, ensuring compliance with
									regulations and maintaining top-notch quality. We provide proactive maintenance and
									water quality management.</p>

							</div>
						</div>
						<div class="wwd-card-bottom">
							<h4>Commercial Pool</h4>
							<div class="wwd-card-icon">
								<?php echo kdpool_get_icon('building'); ?>
							</div>
						</div>
					</div>

					<!-- Duplicate Set for Auto Scroll (Items 1-5 again) -->
					<div class="wwd-card" aria-hidden="true">
						<div class="wwd-card-image">
							<img src="<?php echo get_template_directory_uri(); ?>/assets/images/about1.webp"
								alt="Pool Cleaning"<?php echo kdpool_get_image_attrs('about1.webp'); ?>>
							<div class="wwd-card-overlay">
								<p>You can now keep your pool clean and safe with our professional cleaning services. We
									ensure your pool is free of debris, algae, and contaminants while balancing water
									chemistry for optimal safety.</p>

							</div>
						</div>
						<div class="wwd-card-bottom">
							<h4>Pool Cleaning</h4>
							<div class="wwd-card-icon">
								<?php echo kdpool_get_icon('sun'); ?>
							</div>
						</div>
					</div>

					<div class="wwd-card" aria-hidden="true">
						<div class="wwd-card-image">
							<img src="<?php echo get_template_directory_uri(); ?>/assets/images/about2.webp"
								alt="Pool Repair Services"<?php echo kdpool_get_image_attrs('about2.webp'); ?>>
							<div class="wwd-card-overlay">
								<p>We have expert technicians who can successfully diagnose and repair any pool
									equipment problem, from clogged pumps to malfunctioning heaters and leaks. We use
									high-quality parts.</p>

							</div>
						</div>
						<div class="wwd-card-bottom">
							<h4>Pool Repair Services</h4>
							<div class="wwd-card-icon">
								<?php echo kdpool_get_icon('wrench'); ?>
							</div>
						</div>
					</div>

					<div class="wwd-card" aria-hidden="true">
						<div class="wwd-card-image">
							<img src="<?php echo get_template_directory_uri(); ?>/assets/images/about3.webp"
								alt="Pool Remodeling"<?php echo kdpool_get_image_attrs('about3.webp'); ?>>
							<div class="wwd-card-overlay">
								<p>If you are looking to transform your pool into modernity, we are here for you with
									our remodeling services, including resurfacing, retiling, and deck upgrades. We
									deliver high-quality results.</p>

							</div>
						</div>
						<div class="wwd-card-bottom">
							<h4>Pool Remodeling</h4>
							<div class="wwd-card-icon">
								<?php echo kdpool_get_icon('layers'); ?>
							</div>
						</div>
					</div>

					<div class="wwd-card" aria-hidden="true">
						<div class="wwd-card-image">
							<img src="<?php echo get_template_directory_uri(); ?>/assets/images/about4.webp"
								alt="Pool Inspections"<?php echo kdpool_get_image_attrs('about4.webp'); ?>>
							<div class="wwd-card-overlay">
								<p>We provide professional pool inspection services to ensure the safety, efficiency,
									and compliance of your pool. The structural integrity, equipment performance, and
									water quality will be assessed.</p>

							</div>
						</div>
						<div class="wwd-card-bottom">
							<h4>Pool Inspections</h4>
							<div class="wwd-card-icon">
								<?php echo kdpool_get_icon('camera'); ?>
							</div>
						</div>
					</div>

					<div class="wwd-card" aria-hidden="true">
						<div class="wwd-card-image">
							<img src="<?php echo get_template_directory_uri(); ?>/assets/images/about3.webp"
								alt="Commercial Pool Services"<?php echo kdpool_get_image_attrs('about3.webp'); ?>>
							<div class="wwd-card-overlay">
								<p>Our commercial pool services cater to high-usage facilities, ensuring compliance with
									regulations and maintaining top-notch quality. We provide proactive maintenance and
									water quality management.</p>

							</div>
						</div>
						<div class="wwd-card-bottom">
							<h4>Commercial Pool</h4>
							<div class="wwd-card-icon">
								<?php echo kdpool_get_icon('building'); ?>
							</div>
						</div>
					</div>

				</div>
			</div>

		</div>
	</section>

	<!-- SECTION 4: WHY CHOOSE US (Landi Style) -->
	<?php get_template_part('template-parts/sections/about-why-choose-us'); ?>
	<!-- SECTION 5: FAQ -->
	<?php get_template_part('template-parts/sections/faq'); ?>

	<!-- SECTION 6: REVIEWS -->
	<section class="reviews-section bg-dark-section">
		<div class="kd-container">
			<div class="reviews-grid">

				<!-- Left Column: Content & Slider -->
				<div class="reviews-left">
					<div class="reviews-header">
						<div class="section-subtitle">
							<?php echo kdpool_get_icon('swimming-pool'); ?>
							<span>TESTIMONIALS</span>
						</div>
						<h2>Stories from Our</h2>
						<h2 class="section-title text-white">Happy Customers</h2>
						<p>With years of experience and a customer-first approach, here's how we've made impact in our
							customers' lives:</p>
					</div>

					<div class="reviews-slider-box">
						<?php
						$about_reviews = [
							[
								'img' => 'review1.webp',
								'name' => 'Jay Theja',
								'title' => '',
								'text' => 'KD Pool Builders were great, as promised. The project was completed on time, which was beyond my expectations. I am really impressed with how they explained and described estimations. My family and kids loved their service. They have used high-quality materials and are armed with an efficient and skilled installation team. They maintained clear communication throughout the project and always made sure to respond to our concerns.  I am truly grateful for their work. Thank you, KD Pool Builders.',
							],
							[
								'img' => 'review2.webp',
								'name' => 'Tom H',
								'title' => 'Tech Entrepreneur',
								'text' => 'I am very happy to have chosen KD Pool Builders for my home pool renovation. The transformation was incredible; they resurfaced the pool, retiled it, and even upgraded the deck. This team is very professional, always efficient, and completes the job on time. I highly recommend their services.',
							],
							[
								'img' => 'review3.webp',
								'name' => 'Susan K',
								'title' => 'Facility Manager',
								'text' => 'We have been working with KD Pool Builders for our commercial pool maintenance for the past year, and their service has been excellent. From regular cleanings to inspections and ensuring compliance with regulations, they have taken care of everything. Our guests love the quality of the pool, and this team always makes sure to keep it in top condition while protecting the customer\'s trust.',
							],
							[
								'img' => 'review4.webp',
								'name' => 'Kumto Warming',
								'title' => 'Shop Owner',
								'text' => 'I recently hired KD Pool Builders for a pool inspection at my home, and I was amazed at their attention to detail. The technician thoroughly inspected everything, from the equipment to the water quality. The report they provided was clear and helpful, and they gave us lots of tips to improve the life of the pool. Thanks to KD Pool Builders, I now feel much more confident in the safety and efficiency of our pool.',
							]
						];
						?>

						<!-- Slider Track -->
						<div class="reviews-slider-track">
							<?php foreach ($about_reviews as $index => $review): ?>
								<div class="review-slide <?php echo $index === 0 ? 'active' : ''; ?>">
									<p class="review-text">"<?php echo esc_html($review['text']); ?>"</p>
									<div class="review-meta">
										<div class="reviewer-avatar">
											<img src="<?php echo get_template_directory_uri(); ?>/assets/images/<?php echo esc_attr($review['img']); ?>"
												alt="<?php echo esc_attr($review['name']); ?>"<?php echo kdpool_get_image_attrs($review['img']); ?>>
										</div>
										<div class="reviewer-info">
											<h3><?php echo esc_html($review['name']); ?></h3>
											<?php if (!empty($review['title'])): ?>
												<span><?php echo esc_html($review['title']); ?></span>
											<?php endif; ?>
											<div class="stars">
												<?php for ($i = 0; $i < 5; $i++)
													echo kdpool_get_icon('star'); ?>
											</div>
										</div>
									</div>
									<div class="quote-icon">
										<?php echo kdpool_get_icon('quote'); ?>
									</div>
								</div>
							<?php endforeach; ?>
						</div>

						<!-- Dots Navigation -->
						<div class="reviews-slider-dots">
							<?php foreach ($about_reviews as $index => $review): ?>
								<span class="dot <?php echo $index === 0 ? 'active' : ''; ?>"
									data-slide="<?php echo $index; ?>"></span>
							<?php endforeach; ?>
						</div>
					</div>
				</div>

				<!-- Right Column: Image -->
				<div class="reviews-right">
					<div class="reviews-image-wrapper">
						<img src="<?php echo get_template_directory_uri(); ?>/assets/images/review.webp"
							alt="KD Pool Builders Satisfied Customer"<?php echo kdpool_get_image_attrs('review.webp'); ?>>
					</div>
				</div>

			</div>
		</div>
	</section>


	<!-- SECTION 7: CONTACT FORM -->
	<?php get_template_part('template-parts/forms/about-contact-form'); ?>

</div>

<?php
get_footer();

