<?php
/**
 * Template Name: Legal Page
 * 
 * Custom template for Privacy Policy and Terms & Conditions with dark overlay background.
 */
get_header(); ?>

<main class="legal-page-main" style="background-image: url('<?php echo get_template_directory_uri(); ?>/assets/images/pool-footer-bg.webp');">
    
    <!-- Dark overlay -->
    <div class="legal-page-overlay"></div>
    
    <!-- White content box -->
    <div class="kd-container legal-content-box">
        
        <h1 class="legal-page-title">
            <?php the_title(); ?>
        </h1>
        
        <div class="legal-content">
            <?php 
            while ( have_posts() ) : the_post();
                the_content();
            endwhile; 
            ?>
        </div>
        
    </div>
</main>

<?php get_footer(); ?>
