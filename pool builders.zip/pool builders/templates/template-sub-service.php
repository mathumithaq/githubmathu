<?php
/**
 * Template Name: Sub Service Page
 */

get_header();

echo '<div class="kd-sub-services-page">';
get_template_part('template-parts/sub-services/sub-hero');
get_template_part('template-parts/sub-services/content');
get_template_part('template-parts/sub-services/intro');
get_template_part('template-parts/sub-services/process');
get_template_part('template-parts/sub-services/journey');
get_template_part('template-parts/sub-services/testimonial');
get_template_part('template-parts/sub-services/cta');
echo '</div>';

get_footer();