<?php
/* page.php - Default Page Template */
get_header(); ?>

<main id="primary" class="site-main">
    <?php get_template_part('template-parts/header/inner-hero'); ?>
    
    <div class="kd-container page-content-area">
        <?php
        while ( have_posts() ) :
            the_post(); ?>
            <?php the_content(); ?>
        <?php endwhile; ?>
    </div>
</main>

<?php get_footer(); ?>