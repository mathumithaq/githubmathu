<?php
/**
 * Template Name: Product Page
 */

get_header();
get_template_part('template-parts/header/inner-hero');
?>

<!-- Range of Products Section -->
<?php get_template_part('template-parts/sections/range-of-products', null, ['class' => 'bg-dark-section']); ?>

<!-- FAQ Section -->
<?php get_template_part('template-parts/sections/faq'); ?>

<!-- Contact Form Section -->
<?php get_template_part('template-parts/forms/about-contact-form'); ?>

<?php
get_footer();
