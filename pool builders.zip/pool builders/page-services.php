<?php
/**
 * Template Name: Services Page
 *
 * This template displays the main services page with a unique hero 
 * and a Leafix-inspired services grid.
 */

get_header(); 

// Ensure mainservice.css is enqueued via functions.php (it checks is_page_template('page-services.php'))

// The content array based on the live site's text
$pool_services = [
    [
        'title' => 'Pool Cleaning',
        'desc'  => 'We guarantee that your pool will be sparkling, safe, and inviting every day of the year.',
        'full_content' => 'Regular pool cleaning is essential to maintain water clarity, hygiene, and the longevity of your pool equipment. Our comprehensive cleaning service includes skimming the surface, vacuuming the floor, brushing the walls, emptying skimmer and pump baskets, and balancing the water chemistry. Enjoy a crystal clear pool without lifting a finger!',
        'link'  => home_url('/pool-cleaning/'),
        'image' => get_template_directory_uri() . '/assets/images/pool-1.webp'
    ],
    [
        'title' => 'Pool Repair Services',
        'desc'  => 'Our skilled pool repair team restores complete function, safety, and lasting quality efficiently.',
        'full_content' => 'From a leaking pump to a malfunctioning heater, our expert technicians can diagnose and repair any pool issue quickly. We use high-quality replacement parts and industry-leading techniques to ensure your pool operates safely and efficiently. Don\'t let a broken component ruin your summer!',
        'link'  => home_url('/pool-repair/'),
        'image' => get_template_directory_uri() . '/assets/images/pool-2.webp'
    ],
    [
        'title' => 'Pool Remodeling',
        'desc'  => 'Revamp your pool\'s layout, features, and finish to create a fresh new look.',
        'full_content' => 'Transform your outdated pool into a modern backyard oasis. Our remodeling services include resurfacing, adding custom water features (like waterfalls or fountains), upgrading to energy-efficient equipment, installing new LED lighting, and replacing old tile and coping. Bring your vision to life!',
        'link'  => home_url('/pool-remodeling/'),
        'image' => get_template_directory_uri() . '/assets/images/pool-3.webp'
    ],
    [
        'title' => 'Pool Inspections',
        'desc'  => 'Thorough inspections check your pool\'s structure, systems, and equipment to ensure everything functions.',
        'full_content' => 'Whether you are buying a new home or just want peace of mind, our detailed pool inspections cover everything from the structural integrity of the shell to the functionality of the pumps, filters, and electrical systems. We provide a comprehensive report outlining any current or potential issues.',
        'link'  => home_url('/pool-inspections/'),
        'image' => get_template_directory_uri() . '/assets/images/pool-1.webp'
    ],
    [
        'title' => 'Commercial Pool Services',
        'desc'  => 'We handle commercial pools with care, keeping them clean, safe, and perfectly maintained.',
        'full_content' => 'Managing a commercial pool requires strict adherence to health and safety regulations. We offer customized maintenance plans for hotels, apartment complexes, community centers, and gyms. Our reliable service ensures your pool remains open, safe, and pristine for all your guests.',
        'link'  => home_url('/commercial-pool/'),
        'image' => get_template_directory_uri() . '/assets/images/pool-2.webp'
    ],
    [
        'title' => 'New Pool Construction',
        'desc'  => 'Each new pool construction project is crafted with care, durable materials, and timeless beauty.',
        'full_content' => 'Building a new pool is a major investment, and our team is here to guide you through every step of the process. From the initial 3D design and permits to excavation, plumbing, and the final finish, we build stunning custom pools that perfectly complement your home and lifestyle.',
        'link'  => home_url('/new-pool-construction/'),
        'image' => get_template_directory_uri() . '/assets/images/pool-3.webp'
    ],
    [
        'title' => 'New Pool Installation',
        'desc'  => 'An expert new pool installation makes sure everything is perfectly set up from the start.',
        'full_content' => 'We specialize in the precise installation of fiberglass and vinyl liner pools. Our experienced crew ensures proper grading, secure placement, and flawless plumbing connections. Get ready to dive into your new pool faster with our efficient and professional installation services.',
        'link'  => home_url('/new-pool-installation/'),
        'image' => get_template_directory_uri() . '/assets/images/pool-1.webp'
    ]
];
?>

<main id="primary" class="site-main">

	<?php get_template_part('template-parts/header/inner-hero'); ?>

	<!-- Section 1: Intro (Image & Tabs) -->
	<?php get_template_part('template-parts/sections/services-intro'); ?>

    <!-- Section 2: Leafix Style Services Grid -->
    <section class="main-svc-section bg-dark-section">
        <div class="kd-container">
            <div class="section-header">
                <div class="section-subtitle">
                    <?php echo kdpool_get_icon('swimming-pool'); ?>
                    <span>OUR SERVICES</span>
                </div>
                <h2 class="section-title">Comprehensive Pool Services<br>For Every Need</h2>
                <p>With routine cleaning or full pool transformations, we make sure your pool looks its best. From skilled pool repairs, pool remodeling, and careful pool inspections, we handle every part of your pool with hands-on attention. We take pride in the work we do on pool construction, new pool installation, and reliable commercial pool services. Every project receives personal care and attention, ensuring your pool stays beautiful, enjoyable, and well-maintained all year long.</p>
            </div>
            <div class="main-svc-grid">
                <?php foreach ($pool_services as $index => $service) : ?>
                    <a href="<?php echo esc_url($service['link']); ?>" class="main-svc-card" style="text-decoration: none;">
                        <img class="main-svc-card-bg" src="<?php echo esc_url($service['image']); ?>" alt="<?php echo esc_attr($service['title']); ?>"<?php echo kdpool_get_image_attrs($service['image']); ?>>
                        
                        <div class="main-svc-card-content">
                            <h3><?php echo esc_html($service['title']); ?></h3>
                            <p><?php echo esc_html($service['desc']); ?></p>
                        </div>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
<!-- Why Choose Us Section -->
	<?php get_template_part('template-parts/sections/about-why-choose-us'); ?>
<!-- Testimonial Section -->
	<?php get_template_part('template-parts/sub-services/testimonial'); ?>

	<!-- FAQ Section -->
	<?php get_template_part('template-parts/sections/faq'); ?>
</main>

<?php 
get_footer();