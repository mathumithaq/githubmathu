<header id="masthead" class="site-header">
	<div class="header-inner">

		<!-- Logo -->
		<div class="site-branding">
			<?php if ( has_custom_logo() ) : ?>
				<?php the_custom_logo(); ?>
			<?php else : ?>
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home" class="custom-logo-link">
					<img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo-kd-pool-builders-trans.webp" alt="<?php bloginfo( 'name' ); ?>" class="custom-logo"<?php echo kdpool_get_image_attrs('logo-kd-pool-builders-trans.webp', 'eager'); ?> />
				</a>
			<?php endif; ?>
		</div>

		<!-- Navigation -->
		<nav id="site-navigation" class="main-navigation">
			<div class="menu-container">
				<?php
				wp_nav_menu( array(
					'theme_location' => 'primary',
					'menu_id'        => 'primary-menu',
					'container'      => false,
					'menu_class'     => 'primary-menu-list',
					'fallback_cb'    => function() {
						?>
						<ul id="primary-menu" class="primary-menu-list">
							<li class="menu-item"><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a></li>
							<li class="menu-item"><a href="<?php echo esc_url( home_url( '/about/' ) ); ?>">About</a></li>
							<li class="menu-item"><a href="<?php echo esc_url( home_url( '/products/' ) ); ?>">Products</a></li>
							<li class="menu-item menu-item-has-children">
								<a href="<?php echo esc_url( home_url( '/services/' ) ); ?>">Service</a>
								<ul class="sub-menu">
									<li class="menu-item"><a href="<?php echo esc_url( home_url( '/pool-cleaning/' ) ); ?>">Pool Cleaning Buffalo NY</a></li>
									<li class="menu-item"><a href="<?php echo esc_url( home_url( '/pool-repair/' ) ); ?>">Pool Repair Buffalo NY</a></li>
									<li class="menu-item"><a href="<?php echo esc_url( home_url( '/pool-remodeling/' ) ); ?>">Pool Remodeling Buffalo NY</a></li>
									<li class="menu-item"><a href="<?php echo esc_url( home_url( '/pool-inspections/' ) ); ?>">Pool Inspections Buffalo NY</a></li>
									<li class="menu-item"><a href="<?php echo esc_url( home_url( '/commercial-pool/' ) ); ?>">Commercial Pool Services Buffalo NY</a></li>
									<li class="menu-item"><a href="<?php echo esc_url( home_url( '/new-pool-construction/' ) ); ?>">New Pool Construction Buffalo NY</a></li>
									<li class="menu-item"><a href="<?php echo esc_url( home_url( '/new-pool-installation/' ) ); ?>">New Pool Installation Buffalo NY</a></li>
								</ul>
							</li>
							<li class="menu-item"><a href="<?php echo esc_url( home_url( '/faq/' ) ); ?>">FAQs</a></li>
							<li class="menu-item"><a href="<?php echo esc_url( home_url( '/blog/' ) ); ?>">Blog</a></li>
							<li class="menu-item"><a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>">Contact</a></li>
						</ul>
						<?php
					}
				) );
				?>
			</div>
		</nav>

		<!-- Right Action Area -->
		<div class="header-action">
			<?php 
				$phone = get_theme_mod( 'header_phone', '(716) 300-2773' ); 
				$phone_url = 'tel:+17163002773';
			?>
			<a href="<?php echo esc_attr( $phone_url ); ?>" class="header-btn">
				<?php echo kdpool_get_icon('phone', 'header-call-icon'); ?>
				<span class="header-btn-text">Call <?php echo esc_html( $phone ); ?></span>
			</a>
			<button class="menu-toggle" aria-controls="primary-menu" aria-expanded="false" aria-label="Toggle navigation menu">
				<span class="hamburger-bar"></span>
				<span class="hamburger-bar"></span>
				<span class="hamburger-bar"></span>
			</button>
		</div>

	</div>
</header>

<!-- Mobile Menu Overlay -->
<div class="mobile-menu-overlay"></div>
