<?php
/**
 * Inner Page Hero Banner
 */
$page_title = '';
if ( is_home() && get_option('page_for_posts') ) {
    $page_title = get_the_title( get_option('page_for_posts') );
} else {
    $page_title = get_the_title();
}
?>
<section class="inner-hero-section">
	<div class="inner-hero-bg-slider">
		<div class="slide inslide1"></div>
		<div class="slide inslide2"></div>
		<div class="slide inslide3"></div>
		<div class="slide inslide4"></div>
		<div class="slide inslide5"></div>
	</div>

	<!-- Glassy Overlay -->
	<div class="inner-hero-overlay"></div>

	<!-- Content -->
	<div class="kd-container inner-hero-content">
		<div class="breadcrumbs">
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>">
				<?php echo kdpool_get_icon('home', 'home-icon'); ?>
				Home
			</a>
			<span class="separator">/</span>
			<span class="current-page"><?php echo esc_html($page_title); ?></span>
		</div>
		
		<h1 class="inner-hero-title"><?php echo esc_html($page_title); ?></h1>
	</div>

	<!-- Bubbly Bottom Shape -->
	<div class="inner-hero-bottom-shape">
		<?php echo kdpool_get_icon('divider-wave-line'); ?>
	</div>
</section>

