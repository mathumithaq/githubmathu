<section class="products-section <?php echo isset($args['class']) ? esc_attr($args['class']) : ''; ?>">
	<div class="kd-container">

		<div class="products-header">
			<div class="products-header-left">
				<div class="section-subtitle">
					<?php echo kdpool_get_icon('swimming-pool'); ?>
					<span>Our Products</span>
				</div>
				<h2 class="section-title">Discover Our Range of Products</h2>
				<p>Wondering what kind of pool would work for your yard? Contact us today and we will guide you to the
					option that is best for you!</p>
			</div>
			<div class="products-header-right">
				<a href="<?php echo esc_url(home_url('/products/')); ?>" class="btn btn-primary">VIEW MORE</a>
			</div>
		</div>

		<div class="products-carousel-wrap">
			<div class="products-carousel">

				<!-- Original Set -->
				<a href="<?php echo esc_url(home_url('/product/tampa-pool/')); ?>" class="product-card">
					<div class="product-image">
						<img src="<?php echo get_template_directory_uri(); ?>/assets/images/tampa.webp"
							alt="Tampa pool"<?php echo kdpool_get_image_attrs('tampa.webp'); ?>>
					</div>
					<div class="product-info">
						<span class="product-category">Fiber glass pools</span>
						<h3>Tampa pool</h3>
					</div>
				</a>

				<a href="<?php echo esc_url(home_url('/product/atlanta-pool/')); ?>" class="product-card">
					<div class="product-image">
						<img src="<?php echo get_template_directory_uri(); ?>/assets/images/atlanta.webp"
							alt="Atlanta Pool"<?php echo kdpool_get_image_attrs('atlanta.webp'); ?>>
					</div>
					<div class="product-info">
						<span class="product-category">Fiber glass pools</span>
						<h3>Atlanta Pool</h3>
					</div>
				</a>

				<a href="<?php echo esc_url(home_url('/product/chicago-pool/')); ?>" class="product-card">
					<div class="product-image">
						<img src="<?php echo get_template_directory_uri(); ?>/assets/images/chicago.webp"
							alt="Chicago Pool"<?php echo kdpool_get_image_attrs('chicago.webp'); ?>>
					</div>
					<div class="product-info">
						<span class="product-category">Fiber glass pools</span>
						<h3>Chicago Pool</h3>
					</div>
				</a>

				<a href="<?php echo esc_url(home_url('/product/las-vegas-pool/')); ?>" class="product-card">
					<div class="product-image">
						<img src="<?php echo get_template_directory_uri(); ?>/assets/images/las.webp"
							alt="Las Vegas Pool"<?php echo kdpool_get_image_attrs('las.webp'); ?>>
					</div>
					<div class="product-info">
						<span class="product-category">Fiber glass pools</span>
						<h3>Las Vegas Pool</h3>
					</div>
				</a>

				<a href="<?php echo esc_url(home_url('/product/drummondville-pool/')); ?>" class="product-card">
					<div class="product-image">
						<img src="<?php echo get_template_directory_uri(); ?>/assets/images/drummondville.webp"
							alt="Drummondville Pool"<?php echo kdpool_get_image_attrs('drummondville.webp'); ?>>
					</div>
					<div class="product-info">
						<span class="product-category">Fiber glass pools</span>
						<h3>Drummondville Pool</h3>
					</div>
				</a>

				<a href="<?php echo esc_url(home_url('/product/montreal-pool/')); ?>" class="product-card">
					<div class="product-image">
						<img src="<?php echo get_template_directory_uri(); ?>/assets/images/montreal.webp"
							alt="Montreal Pool"<?php echo kdpool_get_image_attrs('montreal.webp'); ?>>
					</div>
					<div class="product-info">
						<span class="product-category">Fiber glass pools</span>
						<h3>Montreal Pool</h3>
					</div>
				</a>

				<!-- Duplicate Set for Seamless Vertical Scroll -->
				<a href="<?php echo esc_url(home_url('/product/tampa-pool/')); ?>" class="product-card"
					aria-hidden="true">
					<div class="product-image">
						<img src="<?php echo get_template_directory_uri(); ?>/assets/images/tampa.webp"
							alt="Tampa pool"<?php echo kdpool_get_image_attrs('tampa.webp'); ?>>
					</div>
					<div class="product-info">
						<span class="product-category">Fiber glass pools</span>
						<h3>Tampa pool</h3>
					</div>
				</a>

				<a href="<?php echo esc_url(home_url('/product/atlanta-pool/')); ?>" class="product-card"
					aria-hidden="true">
					<div class="product-image">
						<img src="<?php echo get_template_directory_uri(); ?>/assets/images/atlanta.webp"
							alt="Atlanta Pool"<?php echo kdpool_get_image_attrs('atlanta.webp'); ?>>
					</div>
					<div class="product-info">
						<span class="product-category">Fiber glass pools</span>
						<h3>Atlanta Pool</h3>
					</div>
				</a>

				<a href="<?php echo esc_url(home_url('/product/chicago-pool/')); ?>" class="product-card"
					aria-hidden="true">
					<div class="product-image">
						<img src="<?php echo get_template_directory_uri(); ?>/assets/images/chicago.webp"
							alt="Chicago Pool"<?php echo kdpool_get_image_attrs('chicago.webp'); ?>>
					</div>
					<div class="product-info">
						<span class="product-category">Fiber glass pools</span>
						<h3>Chicago Pool</h3>
					</div>
				</a>

				<a href="<?php echo esc_url(home_url('/product/las-vegas-pool/')); ?>" class="product-card"
					aria-hidden="true">
					<div class="product-image">
						<img src="<?php echo get_template_directory_uri(); ?>/assets/images/las.webp"
							alt="Las Vegas Pool"<?php echo kdpool_get_image_attrs('las.webp'); ?>>
					</div>
					<div class="product-info">
						<span class="product-category">Fiber glass pools</span>
						<h3>Las Vegas Pool</h3>
					</div>
				</a>

				<a href="<?php echo esc_url(home_url('/product/drummondville-pool/')); ?>" class="product-card"
					aria-hidden="true">
					<div class="product-image">
						<img src="<?php echo get_template_directory_uri(); ?>/assets/images/drummondville.webp"
							alt="Drummondville Pool"<?php echo kdpool_get_image_attrs('drummondville.webp'); ?>>
					</div>
					<div class="product-info">
						<span class="product-category">Fiber glass pools</span>
						<h3>Drummondville Pool</h3>
					</div>
				</a>

				<a href="<?php echo esc_url(home_url('/product/montreal-pool/')); ?>" class="product-card"
					aria-hidden="true">
					<div class="product-image">
						<img src="<?php echo get_template_directory_uri(); ?>/assets/images/montreal.webp"
							alt="Montreal Pool"<?php echo kdpool_get_image_attrs('montreal.webp'); ?>>
					</div>
					<div class="product-info">
						<span class="product-category">Fiber glass pools</span>
						<h3>Montreal Pool</h3>
					</div>
				</a>

			</div>
		</div>

	</div>


</section>