<?php
/**
 * Services Intro Section
 */
?>

<section class="services-intro-section bg-light-section">
    <!-- Animated Water Bubbles -->
    <div class="bubbles-container">
        <div class="bubble"></div>
        <div class="bubble"></div>
        <div class="bubble"></div>
        <div class="bubble"></div>
        <div class="bubble"></div>
        <div class="bubble"></div>
        <div class="bubble"></div>
    </div>

    <div class="kd-container">
        <div class="services-intro-grid">
            
            <!-- Left Column: Content & Tabs -->
            <div class="services-intro-content">
                <div class="section-subtitle">
                    <?php echo kdpool_get_icon('swimming-pool'); ?>
                    <span>ABOUT US</span>
                </div>
                <h2 class="services-intro-title">
                    Expert Pool Builders Delivering Quality, Service, and Style
                </h2>
                
                <p>KD Pool Builders has become the first choice for pool builders and construction in Buffalo, NY, and the surrounding areas. We work to turn your property into a serene oasis, and specialize in building, installing, and maintaining swimming pools. Regardless of whether you are looking for pool installation Buffalo NY, new pool construction Buffalo NY, or fiberglass pool installation Buffalo NY, you can expect great results from our professionals.</p>
                
                <p>In addition to construction and installation, we also offer pool maintenance services to ensure that your swimming pool remains safe, functional, and aesthetically pleasing throughout the year. This includes pool cleaning, repairs, remodeling, and inspections. Remember, an investment in a pool is more than just a personal one. It's also an investment in the value of your home. In most cases, pools will boost the value of a home.</p>

                <!-- Interactive Tabs -->
                <div class="services-intro-tabs-wrapper">
                    <!-- Tab Navigation -->
                    <ul class="services-intro-tabs-nav">
                        <li class="tab-item active" data-tab="tab-cleaning">
                            Cleaning <?php echo kdpool_get_icon('arrow-right'); ?>
                        </li>
                        <li class="tab-item" data-tab="tab-inspection">
                            Inspection <?php echo kdpool_get_icon('arrow-right'); ?>
                        </li>
                        <li class="tab-item" data-tab="tab-maintenance">
                            Maintenance <?php echo kdpool_get_icon('arrow-right'); ?>
                        </li>
                    </ul>

                    <!-- Tab Content Panels -->
                    <div class="services-intro-tabs-content">
                        <!-- Panel: Cleaning -->
                        <div id="tab-cleaning" class="tab-panel active">
                            <ul class="tab-bullet-list">
                                <li>Clears debris from your pool surface.</li>
                                <li>Keeps pool water clean, and safe.</li>
                                <li>Stops algae and bacteria from growing.</li>
                                <li>Maintains your pool's look.</li>
                                <li>Keep filters and pumps running smoothly.</li>
                            </ul>
                        </div>
                        
                        <!-- Panel: Inspection -->
                        <div id="tab-inspection" class="tab-panel">
                            <ul class="tab-bullet-list">
                                <li>Thorough leak detection and structural checks.</li>
                                <li>Pump, filter, and heater efficiency testing.</li>
                                <li>Electrical and safety system evaluations.</li>
                                <li>Detailed reports on pool health.</li>
                                <li>Preventative maintenance recommendations.</li>
                            </ul>
                        </div>

                        <!-- Panel: Maintenance -->
                        <div id="tab-maintenance" class="tab-panel">
                            <ul class="tab-bullet-list">
                                <li>Regular water chemical balancing and testing.</li>
                                <li>Winterizing and summer opening services.</li>
                                <li>Skimmer and pump basket cleanouts.</li>
                                <li>Tile brushing and vacuuming.</li>
                                <li>Prolongs the lifespan of your pool equipment.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Right Column: Image -->
            <div class="services-intro-image">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/images/pool-1.webp" alt="Pool Cleaner Maintenance"<?php echo kdpool_get_image_attrs('pool-1.webp'); ?>>
            </div>

        </div>
    </div>
</section>
