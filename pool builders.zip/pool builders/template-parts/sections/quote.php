<section class="quote-section">
	<!-- Decorative Pool Shapes -->
	<div class="quote-shape quote-shape-left">
		<img src="<?php echo get_template_directory_uri(); ?>/assets/images/pool-1.webp" alt="Pool Project Left"<?php echo kdpool_get_image_attrs('pool-1.webp'); ?>>
	</div>
	<div class="quote-shape quote-shape-right">
		<img src="<?php echo get_template_directory_uri(); ?>/assets/images/pool-2.webp" alt="Pool Project Right"<?php echo kdpool_get_image_attrs('pool-2.webp'); ?>>
	</div>

	<!-- Wavy Background Pattern overlay -->
	<div class="quote-pattern-bg"></div>

	<div class="kd-container quote-content">
		<h2>Request a Quote</h2>
		<p>Ready to Work Together? Build a project with us!</p>
		<a href="<?php echo esc_url(home_url('/contact/')); ?>" class="btn btn-primary">REQUEST A QUOTE</a>
	</div>

	
</section>


