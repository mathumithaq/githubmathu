<section class="about-wcu-section bg-light-section">
	<div class="kd-container">

		<div class="wcu-header">
			<div class="section-subtitle">
				<?php echo kdpool_get_icon('swimming-pool'); ?>
				<span>WHY CHOOSE US</span>
			</div>
			<h2 class="section-title">Why Choose KD Pool Builders?</h2>
			<p>KD Pool Builders is your trusted one-stop solution for everything swimming pool-related. You should choose us because:</p>
		</div>

		<!-- 4 Column Grid -->
		<div class="wcu-grid">

			<!-- Card 1 -->
			<div class="wcu-card">
				<div class="wcu-card-top">
					<h4>Quality service with high-quality pool design and materials</h4>
					<p>KD Pool Builders never compromises on the quality of materials. We always ensure to provide
						our customers with the best high-quality materials with a 25+ year warranty.</p>
				</div>
				<div class="wcu-card-bottom">
					<?php echo kdpool_get_icon('badge'); ?>
				</div>
			</div>

			<!-- Card 2 -->
			<div class="wcu-card">
				<div class="wcu-card-top">
					<h4>Professionalism with efficient and skilled installation crew</h4>
					<p>At KD Pool Builders, we always provide you with service through highly skilled professionals
						in the field and a very passionate crew.</p>
				</div>
				<div class="wcu-card-bottom">
					<?php echo kdpool_get_icon('team'); ?>
				</div>
			</div>

			<!-- Card 3 -->
			<div class="wcu-card">
				<div class="wcu-card-top">
					<h4>Reliability with attention to detail in construction</h4>
					<p>We pay close attention to every aspect understanding all the details and work towards 100%
						success with 0% error.</p>
				</div>
				<div class="wcu-card-bottom">
					<?php echo kdpool_get_icon('tool'); ?>
				</div>
			</div>

			<!-- Card 4 -->
			<div class="wcu-card">
				<div class="wcu-card-top">
					<h4>Transparent communication with prompt response to concerns</h4>
					<p>We consider it our utmost responsibility to provide high end customer support being available
						24/7 for any query and support.</p>
				</div>
				<div class="wcu-card-bottom">
					<?php echo kdpool_get_icon('chat'); ?>
				</div>
			</div>

		</div>
	</div>
</section>
