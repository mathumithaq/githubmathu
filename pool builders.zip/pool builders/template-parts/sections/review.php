<section class="reviews-section">
	<div class="kd-container">
		<div class="reviews-grid">
			
			<!-- Left Column: Content & Slider -->
			<div class="reviews-left">
				<div class="reviews-header">
					<div class="section-subtitle">
						<?php echo kdpool_get_icon('swimming-pool'); ?>
						<span>Our Testimonials</span>
					</div>
					<h2 class="section-title">What Our Customers Are Saying Now</h2>
				</div>

				<div class="reviews-slider-box">
					<!-- Slider Track -->
					<div class="reviews-slider-track">
						
						<!-- Review 1 -->
						<div class="review-slide active">
							<p class="review-text">"KD Pool Builders were great, as promised. The project was completed on time passing beyond my expectations. I am really impressed with how they explained and described estimations. My family and kids loved their service. They have used high-quality materials, armed with an efficient and skilled installation team. They maintained clear communication throughout the project and always made sure to respond to our concerns. I am truly grateful for their work. Thank you, KD Pool Builders."</p>
							<div class="review-meta">
								<div class="reviewer-avatar">
									<img src="<?php echo get_template_directory_uri(); ?>/assets/images/review1.webp" alt="Reviewer"<?php echo kdpool_get_image_attrs('review1.webp'); ?>>
								</div>
								<div class="reviewer-info">
									<h3>Jay Theja</h3>
									<div class="stars">
										<?php for($i=0; $i<5; $i++) echo kdpool_get_icon('star'); ?>
									</div>
								</div>
							</div>
							<div class="quote-icon">
								<?php echo kdpool_get_icon('quote'); ?>
							</div>
						</div>

						<!-- Review 2 -->
						<div class="review-slide">
							<p class="review-text">"I am very happy to have chosen KD Pool Builders for my home pool renovation. The transformation was incredible, they resurfaced the pool, retiled it, and even upgraded the deck. This team is very professional, always efficient, and completes the job on time. I highly recommend their services."</p>
							<div class="review-meta">
								<div class="reviewer-avatar">
									<img src="<?php echo get_template_directory_uri(); ?>/assets/images/review2.webp" alt="Reviewer"<?php echo kdpool_get_image_attrs('review2.webp'); ?>>
								</div>
								<div class="reviewer-info">
									<h3>Tom H</h3>
									<span>Tech Entrepreneur</span>
									<div class="stars">
										<?php for($i=0; $i<5; $i++) echo kdpool_get_icon('star'); ?>
									</div>
								</div>
							</div>
							<div class="quote-icon">
								<?php echo kdpool_get_icon('quote'); ?>
							</div>
						</div>

						<!-- Review 3 -->
						<div class="review-slide">
							<p class="review-text">"We have been working with KD Pool Builders for our commercial pool maintenance for the past year, and their service has been excellent. From regular cleanings to inspections and ensuring compliance with regulations, they have taken care of everything. Our guests love the quality of the pool, and this team always makes sure to keep it in top condition while protecting the customer's trust."</p>
							<div class="review-meta">
								<div class="reviewer-avatar">
									<img src="<?php echo get_template_directory_uri(); ?>/assets/images/review3.webp" alt="Reviewer"<?php echo kdpool_get_image_attrs('review3.webp'); ?>>
								</div>
								<div class="reviewer-info">
									<h3>Susan K</h3>
									<span>Facility Manager</span>
									<div class="stars">
										<?php for($i=0; $i<5; $i++) echo kdpool_get_icon('star'); ?>
									</div>
								</div>
							</div>
							<div class="quote-icon">
								<?php echo kdpool_get_icon('quote'); ?>
							</div>
						</div>

						<!-- Review 4 -->
						<div class="review-slide">
							<p class="review-text">"I recently hired KD Pool Builders for a pool inspection at my home, and I was amazed at their attention to detail. The technician thoroughly inspected everything, from the equipment to the water quality. The report they provided was clear and helpful, and they gave us lots of tips to improve the life of the pool. Thanks to KD Pool Builders, I now feel much more confident in the safety and efficiency of our pool."</p>
							<div class="review-meta">
								<div class="reviewer-avatar">
									<img src="<?php echo get_template_directory_uri(); ?>/assets/images/review4.webp" alt="Reviewer"<?php echo kdpool_get_image_attrs('review4.webp'); ?>>
								</div>
								<div class="reviewer-info">
									<h3>Kumto Warming</h3>
									<span>Shop Owner</span>
									<div class="stars">
										<?php for($i=0; $i<5; $i++) echo kdpool_get_icon('star'); ?>
									</div>
								</div>
							</div>
							<div class="quote-icon">
								<?php echo kdpool_get_icon('quote'); ?>
							</div>
						</div>

					</div>
					
					<!-- Dots Navigation -->
					<div class="reviews-slider-dots">
						<span class="dot active" data-slide="0"></span>
						<span class="dot" data-slide="1"></span>
						<span class="dot" data-slide="2"></span>
						<span class="dot" data-slide="3"></span>
					</div>
				</div>
			</div>

			<!-- Right Column: Image -->
			<div class="reviews-right">
				<div class="reviews-image-wrapper">
					<img src="<?php echo get_template_directory_uri(); ?>/assets/images/review.webp" alt="KD Pool Builders Satisfied Customer"<?php echo kdpool_get_image_attrs('review.webp'); ?>>
				</div>
			</div>

		</div>
	</div>

	
</section>





