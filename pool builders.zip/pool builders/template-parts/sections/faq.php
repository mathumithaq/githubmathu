<section class="faq-section bg-light-section">
	<div class="kd-container">

		<!-- Section Header -->
		<div class="faq-header">
			<div class="section-subtitle">
				<?php echo kdpool_get_icon('swimming-pool'); ?>
				<span>Learn More From</span>
			</div>
			<h2 class="section-title">FREQUENTLY ASKED QUESTIONS</h2>
		</div>

		<!-- Accordion Container -->
		<div class="faq-accordion">

			<!-- Item 1 -->
			<div class="faq-item active">
				<div class="faq-question">
					<h3>1. How do I know what type or shape of pool would be best for my yard?</h3>
					<span class="faq-icon"><?php echo kdpool_get_icon('swimming-pool'); ?></span>
				</div>
				<div class="faq-answer">
					<p>At KD Pool Builders, we are always there for our clients to help deciding the best option that
						works for them. Based on the dimensions and area of your yard, the choices may differ. However,
						you do not need to worry about any concerns as we have the best team with years of industry
						expertise.</p>
				</div>
			</div>

			<!-- Item 2 -->
			<div class="faq-item">
				<div class="faq-question">
					<h3>2. Does your company design a pool that suits both my requirement and budget?</h3>
					<span class="faq-icon"><?php echo kdpool_get_icon('swimming-pool'); ?></span>
				</div>
				<div class="faq-answer">
					<p>Yes, we have a team of experienced pool designers and they work closely with you to understand
						your requirement and budget. Also, we have a wide range of pool options to choose as per your
						preferences.</p>
				</div>
			</div>

			<!-- Item 3 -->
			<div class="faq-item">
				<div class="faq-question">
					<h3>3. How long does it take to install a fiberglass pool?</h3>
					<span class="faq-icon">
						<?php echo kdpool_get_icon('swimming-pool'); ?>
					</span>
				</div>
				<div class="faq-answer">
					<p>Fiberglass pools are known for their quick installation. The complete installation, including
						patio work, can take a maximum of 2 to 4 weeks. But there are cases where it can be installed in
						as little as 1 week.</p>
				</div>
			</div>

			<!-- Item 4 -->
			<div class="faq-item">
				<div class="faq-question">
					<h3>4. What are the benefits of installing fiberglass pool over a traditional pool?</h3>
					<span class="faq-icon">
						<?php echo kdpool_get_icon('swimming-pool'); ?>
					</span>
				</div>
				<div class="faq-answer">
					<p>The main advantage of fiberglass pools is their quick installation time (2 to 4 weeks). In
						addition, they are known for their included features such as benches, spas, and automatic pool
						covers. Also, these fiberglass pools are durable, easy to clean and maintain, and customizable.
						Notably, they add about 5% to the resale value of your property.</p>
				</div>
			</div>

			<!-- Item 5 -->
			<div class="faq-item">
				<div class="faq-question">
					<h3>5. How much maintenance cost and maintenance time is involved for my swimming pool?</h3>
					<span class="faq-icon">
						<?php echo kdpool_get_icon('swimming-pool'); ?>
					</span>
				</div>
				<div class="faq-answer">
					<p>The maintenance cost and time required depend on the type of pool you own. But with today's
						technology, you don't have to worry about it unnecessarily. And it's even easier if you get in
						touch with us. Our team will advise you on how to handle the maintenance. However, by installing
						a fiberglass pool, you can significantly reduce both maintenance costs and time.</p>
				</div>
			</div>

		</div>
	</div>
</section>