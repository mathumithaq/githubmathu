<section class="hero-section">
	<div class="hero-bg-overlay"></div>
	<div class="kd-container">
		
		<!-- Slider Area -->
		<div class="hero-slider-wrap">
			
			<!-- Slide 1 -->
			<div class="hero-slide active">
				<div class="hero-slide-grid layout-left">
					<div class="hero-slide-image">
						<img src="<?php echo get_template_directory_uri(); ?>/assets/images/slider1.webp" alt="KD Pool Builders - Pool 1"<?php echo kdpool_get_image_attrs('slider1.webp', 'eager', 'high'); ?>>
					</div>
					<div class="hero-slide-text">
						<div class="hero-top-title">
							<?php echo kdpool_get_icon('swimming-pool'); ?>
							<span>WE ARE PROFESSIONAL POOL BUILDERS</span>
						</div>
						<p class="hero-welcome-text">Welcome to KD Pool Builders,</p>
						<h1>A leading Pool Building Company, Buffalo, NYC</h1>
						<div class="hero-btn-group">
							<a href="<?php echo esc_url( home_url( '/products/' ) ); ?>" class="btn btn-primary">Our Products</a>
							<a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>" class="btn btn-outline">Contact Us</a>
						</div>
					</div>
				</div>
			</div>

			<!-- Slide 2 -->
			<div class="hero-slide">
				<div class="hero-slide-grid layout-right">
					<div class="hero-slide-image">
						<img src="<?php echo get_template_directory_uri(); ?>/assets/images/slider2.webp" alt="KD Pool Builders - Pool 2"<?php echo kdpool_get_image_attrs('slider2.webp'); ?>>
					</div>
					<div class="hero-slide-text">
						<div class="hero-top-title">
							<?php echo kdpool_get_icon('swimming-pool'); ?>
							<span>WE ARE PROFESSIONAL POOL BUILDERS</span>
						</div>
						<h2>A well-maintained pool is more than just water-it's your daily escape.</h2>
						<p class="slide-desc">KD Pool Builders is a leading pool construction company based in Buffalo, New York. With 10 years of industry expertise, KD Pool Builders is committed to providing the best, highest quality swimming pools that will transform the look and feel of your home or business. </p>
						<div class="hero-btn-group">
							<a href="<?php echo esc_url( home_url( '/products/' ) ); ?>" class="btn btn-primary">Our Products</a>
							<a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>" class="btn btn-outline">Contact Us</a>
						</div>
					</div>
				</div>
			</div>

			<!-- Slide 3 -->
			<div class="hero-slide">
				<div class="hero-slide-grid layout-left">
					<div class="hero-slide-image">
						<img src="<?php echo get_template_directory_uri(); ?>/assets/images/slider3.webp" alt="KD Pool Builders - Pool 3"<?php echo kdpool_get_image_attrs('slider3.webp'); ?>>
					</div>
					<div class="hero-slide-text">
						<div class="hero-top-title">
							<?php echo kdpool_get_icon('swimming-pool'); ?>
							<span>WE ARE PROFESSIONAL POOL BUILDERS</span>
						</div>
						<p class="slide-desc">Our team is driven by a commitment to making your vision a reality. 
							From renovating your existing pool, professional inspections, and safety certifications to building a brand-new pool, our team at KD Pool Builders brings expertise, reliability, and a personal touch to every project.</p>
						<div class="hero-btn-group">
							<a href="<?php echo esc_url( home_url( '/products/' ) ); ?>" class="btn btn-primary">Our Products</a>
							<a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>" class="btn btn-outline">Contact Us</a>
						</div>
					</div>
				</div>
			</div>
			
			<!-- Slider Controls -->
			<div class="hero-slider-dots">
				<span class="dot active" data-slide="0"></span>
				<span class="dot" data-slide="1"></span>
				<span class="dot" data-slide="2"></span>
			</div>
		</div>
	</div>
	
	<div class="hero-bottom-shape">
		<?php echo kdpool_get_icon('divider-wave-line'); ?>
	</div>

</section>


