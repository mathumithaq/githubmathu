<section class="latest-works-section">
	<div class="kd-container">
		
		<!-- Section Header -->
		<div class="works-header">
			<div class="works-header-left">
				<div class="section-subtitle">
					<?php echo kdpool_get_icon('swimming-pool'); ?>
					<span>Latest Works</span>
				</div>
				<h2 class="section-title">Explore Our Recent Projects</h2>
			</div>
			<div class="works-header-right">
				<a href="<?php echo esc_url( home_url( '/blog/' ) ); ?>" class="btn btn-primary">VIEW PROJECTS</a>
			</div>
		</div>
	</div>

	<!-- Marquee Container -->
	<div class="marquee-wrapper">
		
		<!-- Row 1: Left to Right -->
		<div class="marquee-track track-left-to-right">
			<!-- Original Set -->
			<div class="marquee-content">
				<div class="work-item"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/work1.webp" alt="Work 1"<?php echo kdpool_get_image_attrs('work1.webp'); ?>></div>
				<div class="work-item"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/work2.webp" alt="Work 2"<?php echo kdpool_get_image_attrs('work2.webp'); ?>></div>
				<div class="work-item"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/work3.webp" alt="Work 3"<?php echo kdpool_get_image_attrs('work3.webp'); ?>></div>
				<div class="work-item"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/work4.webp" alt="Work 4"<?php echo kdpool_get_image_attrs('work4.webp'); ?>></div>
				<div class="work-item"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/work5.webp" alt="Work 5"<?php echo kdpool_get_image_attrs('work5.webp'); ?>></div>
			</div>
			<!-- Duplicated Set for seamless loop -->
			<div class="marquee-content" aria-hidden="true">
				<div class="work-item"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/work1.webp" alt="Work 1"<?php echo kdpool_get_image_attrs('work1.webp'); ?>></div>
				<div class="work-item"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/work2.webp" alt="Work 2"<?php echo kdpool_get_image_attrs('work2.webp'); ?>></div>
				<div class="work-item"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/work3.webp" alt="Work 3"<?php echo kdpool_get_image_attrs('work3.webp'); ?>></div>
				<div class="work-item"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/work4.webp" alt="Work 4"<?php echo kdpool_get_image_attrs('work4.webp'); ?>></div>
				<div class="work-item"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/work5.webp" alt="Work 5"<?php echo kdpool_get_image_attrs('work5.webp'); ?>></div>
			</div>
		</div>

		<!-- Row 2: Right to Left -->
		<div class="marquee-track track-right-to-left">
			<!-- Original Set -->
			<div class="marquee-content">
				<div class="work-item"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/work6.webp" alt="Work 6"<?php echo kdpool_get_image_attrs('work6.webp'); ?>></div>
				<div class="work-item"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/work7.webp" alt="Work 7"<?php echo kdpool_get_image_attrs('work7.webp'); ?>></div>
				<div class="work-item"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/work8.webp" alt="Work 8"<?php echo kdpool_get_image_attrs('work8.webp'); ?>></div>
				<div class="work-item"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/work9.webp" alt="Work 9"<?php echo kdpool_get_image_attrs('work9.webp'); ?>></div>
				<div class="work-item"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/work10.webp" alt="Work 10"<?php echo kdpool_get_image_attrs('work10.webp'); ?>></div>
			</div>
			<!-- Duplicated Set for seamless loop -->
			<div class="marquee-content" aria-hidden="true">
				<div class="work-item"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/work6.webp" alt="Work 6"<?php echo kdpool_get_image_attrs('work6.webp'); ?>></div>
				<div class="work-item"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/work7.webp" alt="Work 7"<?php echo kdpool_get_image_attrs('work7.webp'); ?>></div>
				<div class="work-item"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/work8.webp" alt="Work 8"<?php echo kdpool_get_image_attrs('work8.webp'); ?>></div>
				<div class="work-item"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/work9.webp" alt="Work 9"<?php echo kdpool_get_image_attrs('work9.webp'); ?>></div>
				<div class="work-item"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/work10.webp" alt="Work 10"<?php echo kdpool_get_image_attrs('work10.webp'); ?>></div>
			</div>
		</div>

	</div>

	
</section>





