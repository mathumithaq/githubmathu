<section class="services-tab-section">



	<div class="kd-container">
		<!-- Section Header -->
		<div class="services-tab-header">
			<div class="header-left">
				<div class="section-subtitle">
					<?php echo kdpool_get_icon('swimming-pool'); ?>
					<span>About Us</span>
				</div>
				<h2 class="section-title">WHY CHOOSE<br>KD Pool Builders?</h2>
			</div>
			<div class="header-right">
				<p>KD Pool Builders is your trusted one-stop solution for all requirements of a swimming pool.</p>
				<a href="<?php echo esc_url(home_url('/contact/')); ?>" class="btn btn-primary">GET IN TOUCH</a>
			</div>
		</div>

		<div class="services-tab-grid">

			<!-- Left Column: Services List -->
			<div class="services-list">

				<!-- Item 1 (Active by default) -->
				<div class="service-item active" data-target="slide-1">
					<div class="service-info">
						<h2>Quality service with high-quality pool design and materials</h2>
						<p>KD Pool Builders never compromises on the quality of materials. We always ensure to provide
							our customers with the best high-quality materials with a 25+ year warranty.</p>
					</div>
					<button class="service-btn" aria-label="View Details">
						<?php echo kdpool_get_icon('swimming-pool'); ?>
					</button>
				</div>

				<!-- Item 2 -->
				<div class="service-item" data-target="slide-2">
					<div class="service-info">
						<h2>Professionalism with efficient and skilled installation crew</h2>
						<p>At KD Pool Builders, we always provide you with service through highly skilled professionals
							in the field and a very passionate crew.</p>
					</div>
					<button class="service-btn" aria-label="View Details">
						<?php echo kdpool_get_icon('swimming-pool'); ?>
					</button>
				</div>

				<!-- Item 3 -->
				<div class="service-item" data-target="slide-3">
					<div class="service-info">
						<h2>Reliability with attention to detail in construction</h2>
						<p>We pay close attention to every aspect understanding all the details and work towards 100%
							success with 0% error.</p>
					</div>
					<button class="service-btn" aria-label="View Details">
						<?php echo kdpool_get_icon('swimming-pool'); ?>
					</button>
				</div>

				<!-- Item 4 -->
				<div class="service-item" data-target="slide-4">
					<div class="service-info">
						<h2>Transparent communication with prompt response to concerns</h2>
						<p>We consider it our utmost responsibility to provide high end customer support being available
							24/7 for any query and support.</p>
					</div>
					<button class="service-btn" aria-label="View Details">
						<?php echo kdpool_get_icon('swimming-pool'); ?>
					</button>
				</div>

			</div>

			<!-- Right Column: Dynamic Image Display -->
			<div class="services-image-area">
				<div class="services-shape-bg"></div>
				<div class="services-images-wrapper">
					<img src="<?php echo get_template_directory_uri(); ?>/assets/images/about1.webp" alt="Pool Design"
						class="service-img slide-1 active"<?php echo kdpool_get_image_attrs('about1.webp'); ?>>
					<img src="<?php echo get_template_directory_uri(); ?>/assets/images/about2.webp"
						alt="Professional Crew" class="service-img slide-2"<?php echo kdpool_get_image_attrs('about2.webp'); ?>>
					<img src="<?php echo get_template_directory_uri(); ?>/assets/images/about3.webp"
						alt="Reliable Construction" class="service-img slide-3"<?php echo kdpool_get_image_attrs('about3.webp'); ?>>
					<img src="<?php echo get_template_directory_uri(); ?>/assets/images/about4.webp"
						alt="Transparent Communication" class="service-img slide-4"<?php echo kdpool_get_image_attrs('about4.webp'); ?>>
				</div>
			</div>

		</div>
	</div>


</section>