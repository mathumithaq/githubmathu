<section class="reviews-section bg-dark-section">
	<div class="kd-container">
		<div class="reviews-grid">
			
			<!-- Left Column: Content & Slider -->
			<div class="reviews-left">
				<div class="reviews-header">
					<div class="section-subtitle">
						<?php echo kdpool_get_icon('swimming-pool'); ?>
						<span>Our Testimonials</span>
					</div>
					<h2 class="section-title">What Our Customers Are Saying Now</h2>
				</div>

				<div class="reviews-slider-box">
					<!-- Slider Track -->
					<div class="reviews-slider-track">
						
						<!-- Review 1 -->
						<div class="review-slide active">
							<p class="review-text">"KD Pool Builders was the right choice when we needed urgent pool repairs. The fixes were done quickly, efficiently, and perfectly. I have never witnessed a crew so careful in a project before."</p>
							<div class="review-meta">
								<div class="reviewer-avatar">
									<img src="<?php echo get_template_directory_uri(); ?>/assets/images/review1.webp" alt="Reviewer"<?php echo kdpool_get_image_attrs('review1.webp'); ?>>
								</div>
								<div class="reviewer-info">
									<h3>James R.</h3>
									<span>Buffalo, NY</span>
									<div class="stars">
										<?php for($i=0; $i<5; $i++) echo kdpool_get_icon('star'); ?>
									</div>
								</div>
							</div>
							<div class="quote-icon">
								<?php echo kdpool_get_icon('quote'); ?>
							</div>
						</div>

						<!-- Review 2 -->
						<div class="review-slide">
							<p class="review-text">"We chose to renovate our old pool, and the outcome is really amazing. The quality of work and commitment from KD Pool Builders not only made the whole thing very smooth but also quite fun. Our pool has undergone a major transformation!"</p>
							<div class="review-meta">
								<div class="reviewer-avatar">
									<img src="<?php echo get_template_directory_uri(); ?>/assets/images/review2.webp" alt="Reviewer"<?php echo kdpool_get_image_attrs('review2.webp'); ?>>
								</div>
								<div class="reviewer-info">
									<h3>Emily & Mark T.</h3>
									<span>Buffalo, NY</span>
									<div class="stars">
										<?php for($i=0; $i<5; $i++) echo kdpool_get_icon('star'); ?>
									</div>
								</div>
							</div>
							<div class="quote-icon">
								<?php echo kdpool_get_icon('quote'); ?>
							</div>
						</div>

						<!-- Review 3 -->
						<div class="review-slide">
							<p class="review-text">"KD Pool Builders has made a huge difference in our backyard! The whole process from initial design to final touches was handled by a professional, attentive team that really understood our vision. Our pool is now the main attraction of summer parties!"</p>
							<div class="review-meta">
								<div class="reviewer-avatar">
									<img src="<?php echo get_template_directory_uri(); ?>/assets/images/review3.webp" alt="Reviewer"<?php echo kdpool_get_image_attrs('review3.webp'); ?>>
								</div>
								<div class="reviewer-info">
									<h3>Sarah M.</h3>
									<span>Buffalo, NY</span>
									<div class="stars">
										<?php for($i=0; $i<5; $i++) echo kdpool_get_icon('star'); ?>
									</div>
								</div>
							</div>
							<div class="quote-icon">
								<?php echo kdpool_get_icon('quote'); ?>
							</div>
						</div>

						<!-- Review 4 -->
						<div class="review-slide">
							<p class="review-text">"KD Pool Builders kept all their promises from the beginning to the end. The new swimming pool construction and installation were without a fault, and their commercial pool services are the best. Would suggest them very much for anyone wanting a perfect pool."</p>
							<div class="review-meta">
								<div class="reviewer-avatar">
									<img src="<?php echo get_template_directory_uri(); ?>/assets/images/review4.webp" alt="Reviewer"<?php echo kdpool_get_image_attrs('review4.webp'); ?>>
								</div>
								<div class="reviewer-info">
									<h3>Anthony L.</h3>
									<span>Buffalo, NY</span>
									<div class="stars">
										<?php for($i=0; $i<5; $i++) echo kdpool_get_icon('star'); ?>
									</div>
								</div>
							</div>
							<div class="quote-icon">
								<?php echo kdpool_get_icon('quote'); ?>
							</div>
						</div>

					</div>
					
					<!-- Dots Navigation -->
					<div class="reviews-slider-dots">
						<span class="dot active" data-slide="0"></span>
						<span class="dot" data-slide="1"></span>
						<span class="dot" data-slide="2"></span>
						<span class="dot" data-slide="3"></span>
					</div>
				</div>
			</div>

			<!-- Right Column: Image -->
			<div class="reviews-right">
				<div class="reviews-image-wrapper">
					<img src="<?php echo get_template_directory_uri(); ?>/assets/images/review.webp" alt="KD Pool Builders Satisfied Customer"<?php echo kdpool_get_image_attrs('review.webp'); ?>>
				</div>
			</div>

		</div>
	</div>

	
</section>





