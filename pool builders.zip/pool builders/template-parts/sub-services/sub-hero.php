<?php
/**
 * Sub Service Hero Template
 */
?>
<section class="sub-hero-section">
	<div class="sub-hero-bg-overlay"></div>
	
	<div class="kd-container sub-hero-container">
		<div class="sub-hero-content">
			<!-- Breadcrumbs (Home & Sub Menu Name) -->
			<div class="breadcrumbs sub-hero-breadcrumbs">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>">
					<?php echo kdpool_get_icon('home', 'home-icon'); ?>
					Home
				</a>
				<span class="sep">/</span>
				<?php
					$raw_title = get_the_title();
					$formatted_title = ucwords(str_replace('-', ' ', $raw_title));
					
					// Special case for commercial pool
					if (stripos($formatted_title, 'Commercial Pool') !== false && stripos($formatted_title, 'Services') === false) {
						$formatted_title = str_ireplace('Commercial Pool', 'Commercial Pool Services', $formatted_title);
					}

					// Append Buffalo NY if not present
					if (stripos($formatted_title, 'Buffalo') === false) {
						$formatted_title .= ' Buffalo NY';
					}
				?>
				<span class="current"><?php echo esc_html($formatted_title); ?></span>
			</div>

			<h1 class="sub-hero-title"><?php echo esc_html($formatted_title); ?></h1>
			
			<?php if (has_excerpt()) : ?>
				<div class="sub-hero-excerpt">
					<?php echo get_the_excerpt(); ?>
				</div>
			<?php endif; ?>
		</div>
		
		<div class="sub-hero-image-wrap">
			<div class="sub-hero-image-outline"></div>
			<div class="sub-hero-image-inner">
				<video autoplay loop muted playsinline class="sub-hero-video-direct" style="width: 100%; height: 100%; object-fit: cover;">
					<source src="<?php echo get_template_directory_uri(); ?>/assets/videos/hero.mp4" type="video/mp4">
					Your browser does not support the video tag.
				</video>
			</div>
		</div>
	</div>

	<!-- Bottom Wave matching the other sections -->
	<div class="sub-hero-bottom-shape">
		<?php echo kdpool_get_icon('divider-wave-line'); ?>
	</div>
</section>

