<?php
// Helper function to safely fetch ACF fields or native Custom Fields
if (!function_exists('kdpool_get_custom_field')) {
    function kdpool_get_custom_field($field_name, $default = '')
    {
        $val = '';
        if (function_exists('get_field')) {
            $val = get_field($field_name);
        }
        if (empty($val)) {
            $val = get_post_meta(get_the_ID(), $field_name, true);
        }
        return !empty($val) ? $val : $default;
    }
}

$default_title = trim(str_ireplace('Buffalo NY', 'in Buffalo, NY', get_the_title()));

$subtitle = kdpool_get_custom_field('intro_subtitle', 'Welcome to KD Pool Builders');
$title = kdpool_get_custom_field('intro_title', $default_title);
$intro_text = kdpool_get_custom_field('intro_text', '');
$intro_list = kdpool_get_custom_field('intro_list', '');

$fallback_img = get_template_directory_uri() . '/assets/images/pool-1.webp';

if (!function_exists('kdpool_get_safe_img_url')) {
    function kdpool_get_safe_img_url($field_name, $fallback)
    {
        $val = kdpool_get_custom_field($field_name);
        if (is_array($val) && isset($val['url'])) {
            return $val['url'];
        } elseif (is_string($val) && !empty($val)) {
            return $val;
        }
        return $fallback;
    }
}

$img1 = kdpool_get_safe_img_url('intro_image_1', $fallback_img);
$img2 = kdpool_get_safe_img_url('intro_image_2', $fallback_img);
$img3 = kdpool_get_safe_img_url('intro_image_3', $fallback_img);
$img4 = kdpool_get_safe_img_url('intro_image_4', $fallback_img);

// Badge is now fully dynamic based on service name
$badge_title = 'KD Pool Builders';
$badge_text = $service_name;
?>
<section class="sub-intro-section sub-service-section sub-service-section-even">
    <div class="sub-service-section-overlay"></div>
    <div class="kd-container sub-intro-container">
        <!-- Left Side: Content -->
        <div class="sub-intro-content">
            <div class="section-subtitle">
                <?php echo kdpool_get_icon('swimming-pool'); ?>
                <span><?php echo esc_html($subtitle); ?></span>
            </div>

            <h2 class="sub-intro-title-new">
                <?php echo wp_kses_post($title); ?>
            </h2>

            <?php if ($intro_text): ?>
                <div class="sub-intro-text">
                    <?php echo wp_kses_post($intro_text); ?>
                </div>
            <?php endif; ?>

            <?php if ($intro_list): ?>
                <div class="sub-intro-list">
                    <?php
                    $pool_icon = kdpool_get_icon('swimming-pool');

                    // If user entered plain text with new lines instead of HTML list
                    if (stripos($intro_list, '<li') === false) {
                        $lines = array_filter(array_map('trim', explode("\n", $intro_list)));
                        if (!empty($lines)) {
                            echo '<ul>';
                            foreach ($lines as $line) {
                                echo '<li><span class="list-icon">' . $pool_icon . '</span>' . esc_html($line) . '</li>';
                            }
                            echo '</ul>';
                        }
                    } else {
                        // If it's already an HTML list
                        $safe_list = wp_kses_post($intro_list);
                        echo preg_replace('/<li(.*?)>/i', '<li$1><span class="list-icon">' . $pool_icon . '</span>', $safe_list);
                    }
                    ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Right Side: Image Grid -->
        <div class="sub-intro-images">
            <div class="sub-intro-img-grid">
                <div class="sub-intro-img-col sub-intro-left-col">
                    <div class="sub-intro-img-item sub-intro-img-1">
                        <img src="<?php echo esc_url($img1); ?>" alt="Intro Image 1"<?php echo kdpool_get_image_attrs($img1); ?>>
                    </div>
                    <div class="sub-intro-img-item sub-intro-img-2">
                        <img src="<?php echo esc_url($img2); ?>" alt="Intro Image 2"<?php echo kdpool_get_image_attrs($img2); ?>>
                    </div>
                </div>

                <div class="sub-intro-img-col sub-intro-right-col">
                    <div class="sub-intro-img-item sub-intro-img-3">
                        <img src="<?php echo esc_url($img3); ?>" alt="Intro Image 3"<?php echo kdpool_get_image_attrs($img3); ?>>
                    </div>
                    <div class="sub-intro-img-item sub-intro-img-4">
                        <img src="<?php echo esc_url($img4); ?>" alt="Intro Image 4"<?php echo kdpool_get_image_attrs($img4); ?>>
                    </div>
                </div>

                <div class="sub-intro-badge">
                    <div class="sub-intro-badge-inner">
                        <span class="sub-intro-badge-title"><?php echo esc_html($badge_title); ?></span>
                        <span class="sub-intro-badge-text"><?php echo esc_html($badge_text); ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>