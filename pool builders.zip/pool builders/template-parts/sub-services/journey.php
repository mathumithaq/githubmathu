<?php
/**
 * Journey Section Template Part for Sub Services
 */

$post_id = get_the_ID() ?: get_queried_object_id();

$meta_subtitle = function_exists('get_field') && get_field('journey_subtitle', $post_id) ? get_field('journey_subtitle', $post_id) : get_post_meta($post_id, 'journey_subtitle', true);
$subtitle = !empty($meta_subtitle) ? $meta_subtitle : '';

$meta_title = function_exists('get_field') && get_field('journey_title', $post_id) ? get_field('journey_title', $post_id) : get_post_meta($post_id, 'journey_title', true);
$title = !empty($meta_title) ? $meta_title : '';

$meta_description = function_exists('get_field') && get_field('journey_description', $post_id) ? get_field('journey_description', $post_id) : get_post_meta($post_id, 'journey_description', true);
$description = !empty($meta_description) ? $meta_description : '';

$stats = [
    [
        'stat_number' => '2500',
        'stat_suffix' => '+',
        'stat_label'  => 'Successful Projects'
    ],
    [
        'stat_number' => '2000',
        'stat_suffix' => '+',
        'stat_label'  => 'Happy Clients'
    ],
    [
        'stat_number' => '100',
        'stat_suffix' => '%',
        'stat_label'  => 'Reliable Service'
    ],
    [
        'stat_number' => '5',
        'stat_suffix' => '★',
        'stat_label'  => 'Top Rated'
    ]
];

$is_empty_stats = true;
foreach ($stats as $s) {
    if (!empty($s['stat_label'])) {
        $is_empty_stats = false;
        break;
    }
}

if (!$title && $is_empty_stats) {
    return; // Do not render section if there is no content
}
?>

<section class="journey-section" style="background-image: url('<?php echo get_template_directory_uri(); ?>/assets/images/pool-footer-bg.webp');">
    <div class="journey-overlay"></div>

    <div class="kd-container journey-container">
        <!-- Left Side: Card with title and text and bubbles -->
        <div class="journey-card-content">
            <!-- Bubble Effect -->
            <div class="journey-bubbles">
                <svg class="bubble b1" viewBox="0 0 100 100"><circle cx="50" cy="50" r="50"/></svg>
                <svg class="bubble b2" viewBox="0 0 100 100"><circle cx="50" cy="50" r="50"/></svg>
                <svg class="bubble b3" viewBox="0 0 100 100"><circle cx="50" cy="50" r="50"/></svg>
                <svg class="bubble b4" viewBox="0 0 100 100"><circle cx="50" cy="50" r="50"/></svg>
                <svg class="bubble b5" viewBox="0 0 100 100"><circle cx="50" cy="50" r="50"/></svg>
            </div>
            
            <div class="journey-header">
                <?php if ($subtitle) : ?>
                    <div class="section-subtitle journey-subtitle">
                        <?php echo function_exists('kdpool_get_icon') ? kdpool_get_icon('swimming-pool') : ''; ?>
                        <span><?php echo esc_html($subtitle); ?></span>
                    </div>
                <?php endif; ?>
                
                <?php if ($title) : ?>
                    <h2 class="journey-title"><?php echo esc_html($title); ?></h2>
                <?php endif; ?>
                
                <?php if ($description) : ?>
                    <p class="journey-desc"><?php echo esc_html($description); ?></p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Right Side: Stats / Numbers -->
        <div class="journey-stats-wrapper">
            <div class="journey-stats-grid">
                <?php foreach ($stats as $stat) : 
                    $number = !empty($stat['stat_number']) ? $stat['stat_number'] : 0;
                    $suffix = !empty($stat['stat_suffix']) ? $stat['stat_suffix'] : '';
                    $label = !empty($stat['stat_label']) ? $stat['stat_label'] : '';
                ?>
                    <div class="journey-stat-item">
                        <h3 class="journey-stat-value">
                            <span class="journey-stat-number" data-target="<?php echo esc_attr($number); ?>" data-suffix="<?php echo esc_attr($suffix); ?>">0</span><?php echo esc_html($suffix); ?>
                        </h3>
                        <p class="journey-stat-label"><?php echo esc_html($label); ?></p>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
