<?php
// Empty or standard the_content() wrapper
?>
<div class="sub-service-content">
    <div class="kd-container">
        <?php the_content(); ?>
    </div>
</div>