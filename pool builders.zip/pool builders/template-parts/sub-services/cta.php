<?php
/**
 * CTA Section - Oval Pool Design
 */
$service_name = trim(str_ireplace('Buffalo NY', '', get_the_title()));
$phone = get_theme_mod( 'header_phone', '(716) 300-2773' ); 
$phone_url = 'tel:+17163002773';
?>
<section class="sub-cta-section sub-service-section">
    <div class="kd-container">
        
        <div class="sub-cta-oval-pool">
            <!-- Animated SVG Water Bubbles -->
            <div class="sub-cta-bubbles">
                <svg class="bubble b1" viewBox="0 0 100 100"><circle cx="50" cy="50" r="50"/></svg>
                <svg class="bubble b2" viewBox="0 0 100 100"><circle cx="50" cy="50" r="50"/></svg>
                <svg class="bubble b3" viewBox="0 0 100 100"><circle cx="50" cy="50" r="50"/></svg>
                <svg class="bubble b4" viewBox="0 0 100 100"><circle cx="50" cy="50" r="50"/></svg>
                <svg class="bubble b5" viewBox="0 0 100 100"><circle cx="50" cy="50" r="50"/></svg>
                <svg class="bubble b6" viewBox="0 0 100 100"><circle cx="50" cy="50" r="50"/></svg>
            </div>

            <!-- Content -->
            <div class="sub-cta-content">
                <h2 class="sub-cta-title">Get a <?php echo esc_html($service_name); ?> Quote</h2>
                
                <div class="sub-cta-buttons">
                    <a href="<?php echo esc_attr($phone_url); ?>" class="btn">
                        <?php echo kdpool_get_icon('phone'); ?>
                        Call <?php echo esc_html($phone); ?>
                    </a>
                    
                    <a href="<?php echo esc_url(home_url('/contact/')); ?>" class="btn btn-outline">
                        Get a Free Quote
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="btn-arrow"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
                    </a>
                </div>
            </div>
            
        </div>

    </div>
</section>
