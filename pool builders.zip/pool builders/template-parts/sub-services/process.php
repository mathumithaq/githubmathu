<?php
/**
 * Process Section Template Part
 * 
 * Expected $args:
 * - 'section_title' (string): Title of the section (optional)
 * - 'section_subtitle' (string): Subtitle of the section (optional)
 * - 'steps' (array): Array of step items. Each item is an array with:
 *    - 'title' (string)
 *    - 'text' (string)
 *    - 'icon' (string) : svg icon name or raw svg
 */

$post_id = get_the_ID() ?: get_queried_object_id();

$meta_section_title = function_exists('get_field') && get_field('process_section_title', $post_id) ? get_field('process_section_title', $post_id) : get_post_meta($post_id, 'process_section_title', true);
$section_title = !empty($meta_section_title) ? $meta_section_title : (!empty($args['section_title']) ? $args['section_title'] : '');

$meta_section_subtitle = function_exists('get_field') && get_field('process_section_subtitle', $post_id) ? get_field('process_section_subtitle', $post_id) : get_post_meta($post_id, 'process_section_subtitle', true);
$section_subtitle = !empty($meta_section_subtitle) ? $meta_section_subtitle : (!empty($args['section_subtitle']) ? $args['section_subtitle'] : '');

$meta_section_desc = function_exists('get_field') && get_field('process_section_desc', $post_id) ? get_field('process_section_desc', $post_id) : get_post_meta($post_id, 'process_section_desc', true);
$section_desc = !empty($meta_section_desc) ? $meta_section_desc : (!empty($args['section_desc']) ? $args['section_desc'] : '');

$header_img = get_template_directory_uri() . '/assets/images/process.webp';

$meta_step1 = function_exists('get_field') && get_field('process_step_1_text', $post_id) ? get_field('process_step_1_text', $post_id) : get_post_meta($post_id, 'process_step_1_text', true);
$meta_step2 = function_exists('get_field') && get_field('process_step_2_text', $post_id) ? get_field('process_step_2_text', $post_id) : get_post_meta($post_id, 'process_step_2_text', true);
$meta_step3 = function_exists('get_field') && get_field('process_step_3_text', $post_id) ? get_field('process_step_3_text', $post_id) : get_post_meta($post_id, 'process_step_3_text', true);
$meta_step4 = function_exists('get_field') && get_field('process_step_4_text', $post_id) ? get_field('process_step_4_text', $post_id) : get_post_meta($post_id, 'process_step_4_text', true);

$steps = [
    [
        'title' => 'Initial Consultation',
        'text' => !empty($meta_step1) ? $meta_step1 : '',
        'icon' => 'clipboard-check'
    ],
    [
        'title' => 'Customized Solutions',
        'text' => !empty($meta_step2) ? $meta_step2 : '',
        'icon' => 'lightbulb'
    ],
    [
        'title' => 'Final Walkthrough',
        'text' => !empty($meta_step3) ? $meta_step3 : '',
        'icon' => 'handshake'
    ],
    [
        'title' => 'Ongoing Support',
        'text' => !empty($meta_step4) ? $meta_step4 : '',
        'icon' => 'headset'
    ]
];





if (!$section_title && empty($steps)) {
    return; // Do not render section if there is no content
}

$bg_image = get_template_directory_uri() . '/assets/images/pool-footer-bg.webp';
?>
<section class="process-section" style="background-image: url('<?php echo esc_url($bg_image); ?>');">
    <div class="process-overlay"></div>
    <div class="kd-container process-content-container">

        <?php if ($section_title || $section_subtitle || $section_desc): ?>
            <div class="process-header-split">
                <!-- Left: Image with Pool Shape Title Overlay -->
                <div class="process-header-left">
                    <div class="process-header-image-container">
                        <?php if ($header_img): ?>
                            <img src="<?php echo esc_url($header_img); ?>" alt="Process Overview" class="process-header-img"<?php echo kdpool_get_image_attrs($header_img); ?>>
                        <?php endif; ?>

                        <div class="process-pool-title-shape">
                            <?php if ($section_subtitle): ?>
                                <div class="section-subtitle">
                                    <?php echo function_exists('kdpool_get_icon') ? kdpool_get_icon('swimming-pool') : ''; ?>
                                    <span><?php echo esc_html($section_subtitle); ?></span>
                                </div>
                            <?php endif; ?>
                            <?php if ($section_title): ?>
                                <h2 class="section-title"><?php echo esc_html($section_title); ?></h2>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <!-- Right: Description -->
                <div class="process-header-right">
                    <?php if ($section_desc): ?>
                        <div class="process-text-box">
                            <p class="section-desc"><?php echo esc_html($section_desc); ?></p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>



        <!-- Bottom: SVG Icons Section -->
        <?php if (!empty($steps)): ?>
            <div class="process-steps-grid">
                <?php foreach ($steps as $index => $step):
                    $num = str_pad($index + 1, 2, '0', STR_PAD_LEFT);
                    $title = !empty($step['title']) ? $step['title'] : '';
                    $text = !empty($step['text']) ? $step['text'] : '';
                    $icon = !empty($step['icon']) ? $step['icon'] : '';
                    ?>
                    <div class="process-step-item">
                        <div class="process-icon-new">
                            <?php
                            if (strpos($icon, '<svg') !== false) {
                                echo $icon; // Raw SVG
                            } elseif (strpos($icon, '.webp') !== false || strpos($icon, '.png') !== false || strpos($icon, '.jpg') !== false || strpos($icon, 'http') !== false) {
                                echo '<img src="' . esc_url($icon) . '" alt="' . esc_attr($title) . '" class="process-step-img"' . kdpool_get_image_attrs($icon) . '>';
                            } elseif (function_exists('kdpool_get_icon') && !empty($icon)) {
                                echo kdpool_get_icon($icon);
                            }
                            ?>
                        </div>
                        <div class="process-content">
                            <h3 class="process-step-title"><?php echo esc_html($title); ?></h3>
                            <?php if ($text): ?>
                                <p class="process-step-desc"><?php echo esc_html($text); ?></p>
                            <?php endif; ?>
                        </div>
                        <div class="process-number-connector">
                            <div class="process-number-circle"><?php echo $num; ?></div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

    </div>
</section>