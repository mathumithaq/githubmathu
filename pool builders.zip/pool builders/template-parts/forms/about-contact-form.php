<section class="about-contact-section">
	<div class="about-contact-overlay"></div>
	<div class="kd-container">
		<div class="about-contact-grid">
			
			<!-- Left Column: Content & Pool Shape Image -->
			<div class="about-contact-left">
				<div class="contact-header">
					<div class="section-subtitle">
						<?php echo kdpool_get_icon('swimming-pool'); ?>
						<span>Get in Touch</span>
					</div>
					<h2 class="section-title">Contact Us</h2>
					<p class="contact-desc">Are you ready to experience the KD Pool Builders difference? Contact us today to learn more about our services, schedule a consultation, or request a free quote.</p>
				</div>
				
				<!-- Pool Shaped Image -->
				<div class="pool-shape-image-wrapper">
					<img src="<?php echo get_template_directory_uri(); ?>/assets/images/about2.webp" alt="Pool Contact" class="pool-shape-img"<?php echo kdpool_get_image_attrs('about2.webp'); ?>>
				</div>
			</div>

			<!-- Right Column: Form -->
			<div class="about-contact-right">
				<?php get_template_part('template-parts/forms/contact-iframe'); ?>
			</div>

		</div>
	</div>
</section>
