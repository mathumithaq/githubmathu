<footer id="colophon" class="site-footer-premium">
	<!-- Footer Wave Shape Divider -->
	<div class="footer-wave">
		<?php echo kdpool_get_icon('divider-wave-line', 'shape-fill'); ?>
	</div>

	<!-- Dark Glassy Background Layer -->
	<div class="footer-overlay"></div>

	<div class="footer-content-wrapper kd-container">
		<div class="footer-grid-5col">

			<!-- Column 1: About Text -->
			<div class="footer-col footer-about-col">
				<h3>ABOUT US</h3>
				<p class="footer-about-text">
					KD Pool Builders is a leading pool construction company based in Buffalo, New York. With 10 years of
					industry expertise, KD Pool Builders is committed to providing the best, highest quality swimming
					pools that will transform the look and feel of your home or business.
				</p>
			</div>

			<!-- Column 2: Useful Links -->
			<div class="footer-col footer-links-col">
				<h3>QUICK LINKS</h3>
				<div class="footer-links-list">
					<a href="<?php echo esc_url(home_url('/')); ?>" class="footer-link">Home</a>
					<a href="<?php echo esc_url(home_url('/about/')); ?>" class="footer-link">About</a>
					<a href="<?php echo esc_url(home_url('/products/')); ?>" class="footer-link">Products</a>
					<a href="<?php echo esc_url(home_url('/faq/')); ?>" class="footer-link">FAQs</a>
					<a href="<?php echo esc_url(home_url('/blog/')); ?>" class="footer-link">Blog</a>
					<a href="<?php echo esc_url(home_url('/contact/')); ?>" class="footer-link">Contact</a>
				</div>
			</div>

			<!-- Column 3: Center Logo -->
			<div class="footer-col footer-center-logo-col">
				<a href="<?php echo esc_url(home_url('/')); ?>" class="footer-brand-link-center">
					<img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo-kd-pool-builders-trans.webp"
						alt="KD Pool Builders" class="footer-logo-img-center"<?php echo kdpool_get_image_attrs('logo-kd-pool-builders-trans.webp'); ?> />
				</a>
			</div>

			<!-- Column 4: Contact Us -->
			<div class="footer-col footer-contact-col">
				<h3>CONTACT US</h3>
				<div class="footer-contact-list">
					<a href="https://www.google.com/maps/place/KD+Pool+Builders/@42.9137967,-78.8679311,17z/data=!4m15!1m8!3m7!1s0x89d312edcb020411:0xe6e3b1e56c74d528!2s1496+Main+St,+Buffalo,+NY+14209,+USA!3b1!8m2!3d42.9137967!4d-78.8653562!16s%2Fg%2F11crsn8khm!3m5!1s0x876bec2f3cfc15c3:0xfbd9759a04531a80!8m2!3d42.9137909!4d-78.8654466!16s%2Fg%2F11b8tczzf6?entry=ttu&g_ep=EgoyMDI2MDYyNC4wIKXMDSoASAFQAw%3D%3D"
						target="_blank" rel="noopener noreferrer" class="footer-contact-item">
						<?php echo kdpool_get_icon('location', 'footer-icon'); ?>
						<span>1496 Main St, Buffalo, NY<br>14209, United States.</span>
					</a>

					<a href="tel:+17163002773" class="footer-contact-item">
						<?php echo kdpool_get_icon('phone', 'footer-icon'); ?>
						<span>(716) 300-2773</span>
					</a>

					<a href="mailto:sales@kdpoolbuilders.com" class="footer-contact-item">
						<?php echo kdpool_get_icon('mail', 'footer-icon'); ?>
						<span>sales@kdpoolbuilders.com</span>
					</a>
				</div>


			</div>

			<!-- Column 5: Follow Us -->
			<div class="footer-col footer-social-col">
				<h3>FOLLOW US</h3>
				<div class="footer-socials">
					<a href="https://web.facebook.com/kdpoolbuilders1/" class="footer-social-btn" aria-label="Facebook"
						target="_blank">
						<?php echo kdpool_get_icon('facebook', 'footer-social-icon'); ?>
					</a>
					<a href="https://www.instagram.com/kdpool_builders/" class="footer-social-btn"
						aria-label="Instagram" target="_blank">
						<?php echo kdpool_get_icon('instagram', 'footer-social-icon'); ?>
					</a>
				</div>
			</div>

		</div><!-- .footer-grid-5col -->

		<!-- Full Width Animated Map -->
		<div class="footer-map-wrapper">
			<div class="footer-map-container">
				<iframe 
					title="KD Pool Builders Location Map"
					src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2922.0592727747644!2d-78.8654466!3d42.9137909!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x876bec2f3cfc15c3%3A0xfbd9759a04531a80!2sKD%20Pool%20Builders!5e0!3m2!1sen!2slk!4v1782742896483!5m2!1sen!2slk" 
					width="100%" 
					height="100%" 
					style="border:0;" 
					allowfullscreen="" 
					loading="lazy" 
					referrerpolicy="no-referrer-when-downgrade">
				</iframe>
			</div>
		</div>

		<!-- Horizontal Photo Marquee -->
		<div class="footer-photo-marquee">
			<div class="marquee-track">
				<!-- Set 1 -->
				<img src="<?php echo get_template_directory_uri(); ?>/assets/images/pool-1.webp"
					alt="KD Pool Builders Work"<?php echo kdpool_get_image_attrs('pool-1.webp'); ?>>
				<img src="<?php echo get_template_directory_uri(); ?>/assets/images/pool-2.webp"
					alt="KD Pool Builders Work"<?php echo kdpool_get_image_attrs('pool-2.webp'); ?>>
				<img src="<?php echo get_template_directory_uri(); ?>/assets/images/pool-3.webp"
					alt="KD Pool Builders Work"<?php echo kdpool_get_image_attrs('pool-3.webp'); ?>>
				<img src="<?php echo get_template_directory_uri(); ?>/assets/images/pool-4.webp"
					alt="KD Pool Builders Work"<?php echo kdpool_get_image_attrs('pool-4.webp'); ?>>
				<!-- Set 2 -->
				<img src="<?php echo get_template_directory_uri(); ?>/assets/images/pool-1.webp"
					alt="KD Pool Builders Work"<?php echo kdpool_get_image_attrs('pool-1.webp'); ?>>
				<img src="<?php echo get_template_directory_uri(); ?>/assets/images/pool-2.webp"
					alt="KD Pool Builders Work"<?php echo kdpool_get_image_attrs('pool-2.webp'); ?>>
				<img src="<?php echo get_template_directory_uri(); ?>/assets/images/pool-3.webp"
					alt="KD Pool Builders Work"<?php echo kdpool_get_image_attrs('pool-3.webp'); ?>>
				<img src="<?php echo get_template_directory_uri(); ?>/assets/images/pool-4.webp"
					alt="KD Pool Builders Work"<?php echo kdpool_get_image_attrs('pool-4.webp'); ?>>
				<!-- Set 3 -->
				<img src="<?php echo get_template_directory_uri(); ?>/assets/images/pool-1.webp"
					alt="KD Pool Builders Work"<?php echo kdpool_get_image_attrs('pool-1.webp'); ?>>
				<img src="<?php echo get_template_directory_uri(); ?>/assets/images/pool-2.webp"
					alt="KD Pool Builders Work"<?php echo kdpool_get_image_attrs('pool-2.webp'); ?>>
				<img src="<?php echo get_template_directory_uri(); ?>/assets/images/pool-3.webp"
					alt="KD Pool Builders Work"<?php echo kdpool_get_image_attrs('pool-3.webp'); ?>>
				<img src="<?php echo get_template_directory_uri(); ?>/assets/images/pool-4.webp"
					alt="KD Pool Builders Work"<?php echo kdpool_get_image_attrs('pool-4.webp'); ?>>
				<!-- Set 4 -->
				<img src="<?php echo get_template_directory_uri(); ?>/assets/images/pool-1.webp"
					alt="KD Pool Builders Work"<?php echo kdpool_get_image_attrs('pool-1.webp'); ?>>
				<img src="<?php echo get_template_directory_uri(); ?>/assets/images/pool-2.webp"
					alt="KD Pool Builders Work"<?php echo kdpool_get_image_attrs('pool-2.webp'); ?>>
				<img src="<?php echo get_template_directory_uri(); ?>/assets/images/pool-3.webp"
					alt="KD Pool Builders Work"<?php echo kdpool_get_image_attrs('pool-3.webp'); ?>>
				<img src="<?php echo get_template_directory_uri(); ?>/assets/images/pool-4.webp"
					alt="KD Pool Builders Work"<?php echo kdpool_get_image_attrs('pool-4.webp'); ?>>
			</div>
		</div>

		<div class="footer-divider"></div>

		<!-- Bottom: Copyright -->
		<div class="footer-bottom-copyright">
			<div class="copyright-text">
				&copy; <?php echo date('Y'); ?> <a href="<?php echo esc_url(home_url('/')); ?>"
					class="copyright-link">KD Pool Builders</a> All Rights Reserved.
				<span class="policy-sep" style="margin: 0 10px;">|</span>
			</div>
			<div class="footer-policy-links">
				<a href="<?php echo esc_url(home_url('/privacy-policy/')); ?>">Privacy Policy</a>
				<span class="policy-sep">|</span>
				<a href="<?php echo esc_url(home_url('/terms-and-conditions/')); ?>">Terms and Conditions</a>
			</div>
		</div>
	</div><!-- .footer-content-wrapper -->

	<!-- Back to Top Button -->
	<button id="back-to-top" class="back-to-top-btn" aria-label="Back to top">
		<?php echo kdpool_get_icon('arrow-up'); ?>
	</button>
</footer><!-- #colophon -->
