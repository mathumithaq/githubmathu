<?php
/**
 * Template Name: Contact Page
 */
get_header(); 
get_template_part('template-parts/header/inner-hero');
?>

<main class="contact-page-main">
    <div class="kd-container">
        <!-- Overlapping Hero Features -->
        <div class="contact-hero-features">
            <!-- Item 1: Address -->
            <div class="ch-feature-item">
                <div class="ch-feature-icon">
                    <?php echo kdpool_get_icon('location'); ?>
                </div>
                <h4>Address</h4>
                <p><a href="https://www.google.com/maps/place/KD+Pool+Builders/@42.9137967,-78.8679311,17z/data=!4m15!1m8!3m7!1s0x89d312edcb020411:0xe6e3b1e56c74d528!2s1496+Main+St,+Buffalo,+NY+14209,+USA!3b1!8m2!3d42.9137967!4d-78.8653562!16s%2Fg%2F11crsn8khm!3m5!1s0x876bec2f3cfc15c3:0xfbd9759a04531a80!8m2!3d42.9137909!4d-78.8654466!16s%2Fg%2F11b8tczzf6?entry=ttu&g_ep=EgoyMDI2MDYyNC4wIKXMDSoASAFQAw%3D%3D" target="_blank" rel="noopener noreferrer">1496 Main St, Buffalo, NY 14209,<br>United States.</a></p>
                <div class="ch-feature-underline"></div>
            </div>

            <!-- Item 2: Email -->
            <div class="ch-feature-item">
                <div class="ch-feature-icon">
                    <?php echo kdpool_get_icon('mail'); ?>
                </div>
                <h4>Email</h4>
                <p><a href="mailto:sales@kdpoolbuilders.com">sales@kdpoolbuilders.com</a></p>
                <div class="ch-feature-underline"></div>
            </div>

            <!-- Item 3: Phone -->
            <div class="ch-feature-item">
                <div class="ch-feature-icon">
                    <?php echo kdpool_get_icon('phone'); ?>
                </div>
                <h4>Phone</h4>
                <p><a href="tel:+17163002773">(716) 300-2773</a></p>
                <div class="ch-feature-underline"></div>
            </div>
        </div>

        <div class="contact-split-container">
            
            <!-- Left Side: Image with Overlay Tag -->
            <div class="contact-left-side" style="background-image: url('<?php echo get_template_directory_uri(); ?>/assets/images/contactimg.webp');">
                <div class="contact-tag-overlay">
                    <div class="section-subtitle contact-subtitle">
                        <?php echo kdpool_get_icon('swimming-pool'); ?>
                        <span>Contact Info</span>
                    </div>
                    <h2>Are you looking for help from KD Pool Builders?</h2>
                    <p>Depending on your urgency and the matter, there are several ways you can contact us.</p>
                    <p>Please feel free to contact us, we are always happy to help you!</p>

                    <div class="contact-socials">
                        <a href="https://web.facebook.com/kdpoolbuilders1/" target="_blank" aria-label="Facebook">
                            <?php echo kdpool_get_icon('facebook', 'contact-social-icon'); ?>
                        </a>
                        <a href="https://www.instagram.com/kdpool_builders/" target="_blank" aria-label="Instagram">
                            <?php echo kdpool_get_icon('instagram', 'contact-social-icon'); ?>
                        </a>
                    </div>
                </div>
            </div>

            <!-- Right Side: Form -->
            <div class="contact-right-side">
                <iframe
                    src="https://apps.kdpoolbuilders.com/widget/form/8amffelu5GI6O2J08fUm"
                    style="width:100%;height:100%;border:none;border-radius:3px"
                    id="inline-8amffelu5GI6O2J08fUm" 
                    data-layout="{'id':'INLINE'}"
                    data-trigger-type="alwaysShow"
                    data-trigger-value=""
                    data-activation-type="alwaysActivated"
                    data-activation-value=""
                    data-deactivation-type="neverDeactivate"
                    data-deactivation-value=""
                    data-form-name="Form 0"
                    data-height="695"
                    data-layout-iframe-id="inline-8amffelu5GI6O2J08fUm"
                    data-form-id="8amffelu5GI6O2J08fUm"
                    title="Form 0"
                >
                </iframe>
            </div>

        </div>
    </div>
</main>

<?php get_footer(); ?>
