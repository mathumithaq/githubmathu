<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<!-- Screen Opening Animation -->
<div class="page-loader">
	<div class="loader-half loader-left">
		<div class="loader-logo-half left-logo">
			<img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo-kd-pool-builders-trans.webp" alt="KD Pool Builders Logo"<?php echo kdpool_get_image_attrs('logo-kd-pool-builders-trans.webp', 'eager'); ?>>
		</div>
	</div>
	<div class="loader-half loader-right">
		<div class="loader-logo-half right-logo">
			<img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo-kd-pool-builders-trans.webp" alt="KD Pool Builders Logo"<?php echo kdpool_get_image_attrs('logo-kd-pool-builders-trans.webp', 'eager'); ?>>
		</div>
	</div>
</div>


<div id="page" class="site">
	<?php get_template_part( 'template-parts/header/site-header' ); ?>
