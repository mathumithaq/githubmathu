<?php
/**
 * Template Name: Product Page
 */

get_header();
get_template_part('template-parts/header/inner-hero');
?>
<!-- FAQ Section -->
<section class="faq-section bg-light-section">
	<div class="kd-container">
		
		<!-- FAQ Intro -->
		<div class="faq-header" style="margin-bottom: 50px;">
			<div class="section-subtitle">
				<?php echo kdpool_get_icon('swimming-pool'); ?>
				<span>Learn More From</span>
			</div>
			<h2 class="section-title">FREQUENTLY ASKED QUESTIONS</h2>
			<h3 class="faq-intro-title" style="margin-top: 20px;">Hello How Can We Help?</h3>
			<p class="faq-intro-text">As industry experts, we at KD Pool Builders are ready to make your journey easier by
				answering your questions and providing expert guidance. Whether you’re planning on owning a new pool or
				looking to maintain your existing one, we’re always here to helping you make your dream a reality.</p>
			<p class="faq-intro-text">Below, we’ve answered some of the most frequently asked questions from our customers
				to create a stress-free pool building experience. If you need additional help, contact our team today!</p>
		</div>

		<!-- Accordion Container -->
		<div class="faq-accordion">

			<!-- Item 1 -->
			<div class="faq-item active">
				<div class="faq-question">
					<h3>1. How do I know what type or shape of pool would be best for my yard?</h3>
					<span class="faq-icon"><?php echo kdpool_get_icon('swimming-pool'); ?></span>
				</div>
				<div class="faq-answer">
					<p>At KD Pool Builders, we are always there for our clients to help deciding the best option that works for them. Based on the dimensions and area of your yard, the choices may differ. However, you do not need to worry about any concerns as we have the best team with years of industry expertise.</p>
				</div>
			</div>

			<!-- Item 2 -->
			<div class="faq-item">
				<div class="faq-question">
					<h3>2. Does your company design a pool that suits both my requirement and budget?</h3>
					<span class="faq-icon"><?php echo kdpool_get_icon('swimming-pool'); ?></span>
				</div>
				<div class="faq-answer">
					<p>Yes, we have a team of experienced pool designers and they work closely with you to understand your requirement and budget. Also, we have a wide range of pool options to choose as per your preferences.</p>
				</div>
			</div>

			<!-- Item 3 -->
			<div class="faq-item">
				<div class="faq-question">
					<h3>3. How long does it take to install a fiberglass pool?</h3>
					<span class="faq-icon"><?php echo kdpool_get_icon('swimming-pool'); ?></span>
				</div>
				<div class="faq-answer">
					<p>Fiberglass pools are known for their quick installation. The complete installation, including patio work, can take a maximum of 2 to 4 weeks. But there are cases where it can be installed in as little as 1 week.</p>
				</div>
			</div>

			<!-- Item 4 -->
			<div class="faq-item">
				<div class="faq-question">
					<h3>4. What are the benefits of installing fiberglass pool over a traditional pool?</h3>
					<span class="faq-icon"><?php echo kdpool_get_icon('swimming-pool'); ?></span>
				</div>
				<div class="faq-answer">
					<p>The main advantage of fiberglass pools is their quick installation time (2 to 4 weeks). In addition, they are known for their included features such as benches, spas, and automatic pool covers. Also, these fiberglass pools are durable, easy to clean and maintain, and customizable. Notably, they add about 5% to the resale value of your property.</p>
				</div>
			</div>

			<!-- Item 5 -->
			<div class="faq-item">
				<div class="faq-question">
					<h3>5. How much maintenance cost and maintenance time is involved for my swimming pool?</h3>
					<span class="faq-icon"><?php echo kdpool_get_icon('swimming-pool'); ?></span>
				</div>
				<div class="faq-answer">
					<p>The maintenance cost and time required depend on the type of pool you own. But with today's technology, you don't have to worry about it unnecessarily. And it's even easier if you get in touch with us. Our team will advise you on how to handle the maintenance. However, by installing a fiberglass pool, you can significantly reduce both maintenance costs and time.</p>
				</div>
			</div>

			<!-- Item 6 -->
			<div class="faq-item">
				<div class="faq-question">
					<h3>6. Do we get a warranty for pool installations?</h3>
					<span class="faq-icon"><?php echo kdpool_get_icon('swimming-pool'); ?></span>
				</div>
				<div class="faq-answer">
					<p>Yes, we offer warranties on our pool installations. Please contact us for specific warranty details based on the type of pool you choose.</p>
				</div>
			</div>

			<!-- Item 7 -->
			<div class="faq-item">
				<div class="faq-question">
					<h3>7. What shape of pool is recommended by your company?</h3>
					<span class="faq-icon"><?php echo kdpool_get_icon('swimming-pool'); ?></span>
				</div>
				<div class="faq-answer">
					<p>The ideal shape depends on your yard size and personal preferences. We offer a variety of shapes and can help you choose the best fit during our consultation.</p>
				</div>
			</div>

			<!-- Item 8 -->
			<div class="faq-item">
				<div class="faq-question">
					<h3>8. How does a pool add value to my property?</h3>
					<span class="faq-icon"><?php echo kdpool_get_icon('swimming-pool'); ?></span>
				</div>
				<div class="faq-answer">
					<p>A beautifully designed pool can significantly increase your property's resale value, typically adding around 5% to the home's value depending on the market.</p>
				</div>
			</div>

			<!-- Item 9 -->
			<div class="faq-item">
				<div class="faq-question">
					<h3>9. Which type of pool services do you offer?</h3>
					<span class="faq-icon"><?php echo kdpool_get_icon('swimming-pool'); ?></span>
				</div>
				<div class="faq-answer">
					<p>We offer comprehensive services including pool installation, cleaning, repair, remodeling, inspections, and commercial pool services.</p>
				</div>
			</div>

			<!-- Item 10 -->
			<div class="faq-item">
				<div class="faq-question">
					<h3>10. How long do I have to wait for technicians to attend?</h3>
					<span class="faq-icon"><?php echo kdpool_get_icon('swimming-pool'); ?></span>
				</div>
				<div class="faq-answer">
					<p>We pride ourselves on prompt service. Response times may vary depending on the season, but we strive to attend to all requests as quickly as possible.</p>
				</div>
			</div>

		</div>
	</div>
</section>
<?php
get_footer();