<?php get_header(); ?>
<main id="primary" class="site-main">
	<?php get_template_part('template-parts/sections/hero'); ?>
	<?php get_template_part('template-parts/sections/why-choose-us'); ?>
	<?php get_template_part('template-parts/sections/range-of-products'); ?>
	<?php get_template_part('template-parts/sections/latest-works'); ?>
	<?php get_template_part('template-parts/sections/review'); ?>
	<?php get_template_part('template-parts/sections/quote'); ?>
	<?php get_template_part('template-parts/sections/faq'); ?>
	<?php get_template_part('template-parts/sections/map'); ?>
</main>

<?php get_footer(); ?>