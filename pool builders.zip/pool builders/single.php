<?php
/**
 * The template for displaying all single posts.
 */

get_header(); 
?>
<main id="primary" class="site-main single-blog-main">
    <div class="kd-container single-layout-wrapper">
        
        <!-- Main Content Area -->
        <div class="single-blog-content-area">
        <?php while ( have_posts() ) : the_post(); ?>
            <article id="post-<?php the_ID(); ?>" <?php post_class('single-blog-article'); ?>>
                
                <?php if ( has_post_thumbnail() ) : ?>
                    <div class="single-blog-featured-image">
                        <?php the_post_thumbnail( 'large', array( 'class' => 'img-responsive', 'loading' => 'lazy', 'decoding' => 'async' ) ); ?>
                    </div>
                <?php endif; ?>

                <header class="single-post-header">
                    <div class="single-blog-meta">
                        <span class="meta-date">
                            <?php echo kdpool_get_icon('clock'); ?>
                            Updated: <?php echo get_the_modified_date(); ?>
                        </span>
                        <span class="meta-author">
                            <?php echo kdpool_get_icon('user'); ?>
                            by: <?php the_author(); ?>
                        </span>
                        <span class="meta-category">
                            <?php echo kdpool_get_icon('folder'); ?>
                            <?php the_category(', '); ?>
                        </span>
                    </div>
                    
                    <h1 class="single-post-title"><?php the_title(); ?></h1>
                </header>

                <div class="single-blog-content">
                    <?php the_content(); ?>
                </div>

                <div class="single-blog-tags-social">
                    <div class="single-blog-tags">
                        <?php the_tags('<span class="tag-label">Tags:</span> ', '', ''); ?>
                    </div>
                    <div class="single-blog-share">
                        <span class="share-label">Share:</span>
                        <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo urlencode(get_permalink()); ?>" target="_blank" aria-label="Share on Facebook"><?php echo kdpool_get_icon('facebook'); ?></a>
                        <a href="https://www.instagram.com/kdpool_builders/" target="_blank" aria-label="KD Pool Builders Instagram"><?php echo kdpool_get_icon('instagram'); ?></a>
                    </div>
                </div>

                <!-- Author Bio Box -->
                <div class="single-author-box">
                    <div class="author-avatar">
                        <?php echo get_avatar( get_the_author_meta('ID'), 80 ); ?>
                    </div>
                    <div class="author-info">
                        <h4>Written by <?php the_author_posts_link(); ?></h4>
                        <p><?php the_author_meta('description') ? the_author_meta('description') : 'A passionate writer sharing insights and tips on pool construction and maintenance.'; ?></p>
                    </div>
                </div>

                <!-- Post Navigation -->
                <div class="single-blog-navigation">
                    <div class="nav-previous">
                        <?php previous_post_link( '%link', kdpool_get_icon('arrow-left-circle') . ' <span>Previous Post</span><br>%title' ); ?>
                    </div>
                    <div class="nav-next">
                        <?php next_post_link( '%link', '<span>Next Post</span> ' . kdpool_get_icon('arrow-right-circle') . '<br>%title' ); ?>
                    </div>
                </div>

            </article>
        <?php endwhile; ?>
        </div> <!-- .single-blog-content-area -->

        <!-- Sidebar Area -->
        <aside class="single-blog-sidebar">
            
            <!-- Search Widget -->
            <div class="sidebar-widget search-widget">
                <h3 class="widget-title">Search</h3>
                <form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
                    <input type="search" class="search-field" placeholder="Search blog..." value="<?php echo get_search_query(); ?>" name="s" />
                    <button type="submit" class="search-submit" aria-label="Search">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                    </button>
                </form>
            </div>

            <!-- Recent Posts Widget -->
            <div class="sidebar-widget recent-posts-widget">
                <h3 class="widget-title">Recent Posts</h3>
                <ul>
                    <?php
                    $recent_posts = wp_get_recent_posts(array(
                        'numberposts' => 4,
                        'post_status' => 'publish'
                    ));
                    foreach($recent_posts as $recent_post) : ?>
                        <li>
                            <a href="<?php echo get_permalink($recent_post['ID']) ?>">
                                <?php echo esc_html($recent_post['post_title']) ?>
                            </a>
                        </li>
                    <?php endforeach; wp_reset_query(); ?>
                </ul>
            </div>

            <!-- Related Posts Widget -->
            <div class="sidebar-widget related-posts-widget">
                <h3 class="widget-title">Related Posts</h3>
                <ul>
                    <?php
                    global $post;
                    $categories = get_the_category($post->ID);
                    if ($categories) {
                        $category_ids = array();
                        foreach($categories as $individual_category) {
                            $category_ids[] = $individual_category->term_id;
                        }
                        $args = array(
                            'category__in'     => $category_ids,
                            'post__not_in'     => array($post->ID),
                            'posts_per_page'   => 4,
                            'ignore_sticky_posts' => 1
                        );
                        $related_query = new WP_Query($args);
                        if ($related_query->have_posts()) {
                            while ($related_query->have_posts()) {
                                $related_query->the_post();
                                ?>
                                <li>
                                    <a href="<?php the_permalink(); ?>">
                                        <?php the_title(); ?>
                                    </a>
                                </li>
                                <?php
                            }
                        } else {
                            echo '<li>No related posts yet.</li>';
                        }
                        wp_reset_postdata();
                    }
                    ?>
                </ul>
            </div>

            <!-- Categories Widget -->
            <div class="sidebar-widget categories-widget">
                <h3 class="widget-title">Categories</h3>
                <ul>
                    <?php wp_list_categories(array('title_li' => '', 'show_count' => true)); ?>
                </ul>
            </div>

            <!-- Comments Widget (Moved to Right Side Bottom) -->
            <div class="sidebar-widget comments-widget">
                <?php
                if ( comments_open() || get_comments_number() ) :
                    comments_template();
                endif;
                ?>
            </div>

        </aside>
    </div>
</main>

<?php get_footer(); ?>
