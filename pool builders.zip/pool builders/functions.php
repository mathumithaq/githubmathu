<?php
/**
 * KD Pool Theme Functions
 */

if (!function_exists('kdpool_setup')):
	function kdpool_setup()
	{
		// Add default posts and comments RSS feed links to head.
		add_theme_support('automatic-feed-links');

		// Let WordPress manage the document title.
		add_theme_support('title-tag');

		// Enable support for Post Thumbnails on posts and pages.
		add_theme_support('post-thumbnails');

		// Register the primary navigation menu.
		register_nav_menus(array(
			'primary' => esc_html__('Primary Menu', 'kdpool'),
			'footer' => esc_html__('Footer Menu', 'kdpool'),
		));

		// Switch default core markup to HTML5
		add_theme_support('html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
			'style',
			'script',
		));

		// WooCommerce Support
		add_theme_support( 'woocommerce' );
		add_theme_support( 'wc-product-gallery-zoom' );
		add_theme_support( 'wc-product-gallery-lightbox' );
		add_theme_support( 'wc-product-gallery-slider' );
	}
endif;
add_action('after_setup_theme', 'kdpool_setup');

/**
 * Asset helpers.
 */
function kdpool_asset_version( $relative_path ) {
	$file_path = get_template_directory() . $relative_path;
	return file_exists( $file_path ) ? filemtime( $file_path ) : wp_get_theme()->get( 'Version' );
}

function kdpool_enqueue_style_asset( $handle, $relative_path, $deps = array() ) {
	$file_path = get_template_directory() . $relative_path;
	if ( file_exists( $file_path ) ) {
		wp_enqueue_style(
			$handle,
			get_template_directory_uri() . $relative_path,
			$deps,
			kdpool_asset_version( $relative_path )
		);
	}
}

function kdpool_enqueue_script_asset( $handle, $relative_path, $deps = array() ) {
	$file_path = get_template_directory() . $relative_path;
	if ( file_exists( $file_path ) ) {
		wp_enqueue_script(
			$handle,
			get_template_directory_uri() . $relative_path,
			$deps,
			kdpool_asset_version( $relative_path ),
			true
		);
	}
}

/**
 * Return safe loading/size attributes for local theme images.
 */
function kdpool_get_image_attrs( $image, $loading = 'lazy', $fetchpriority = '' ) {
	$attrs = array(
		'decoding' => 'async',
	);

	if ( ! empty( $loading ) ) {
		$attrs['loading'] = $loading;
	}

	if ( ! empty( $fetchpriority ) ) {
		$attrs['fetchpriority'] = $fetchpriority;
	}

	$theme_dir = trailingslashit( get_template_directory() );
	$theme_uri = trailingslashit( get_template_directory_uri() );
	$image_path = '';

	if ( false !== strpos( $image, $theme_uri ) ) {
		$relative_path = ltrim( str_replace( $theme_uri, '', $image ), '/' );
		$image_path    = $theme_dir . $relative_path;
	} elseif ( 0 === strpos( $image, 'assets/' ) ) {
		$image_path = $theme_dir . $image;
	} elseif ( false === strpos( $image, '://' ) ) {
		$image_path = $theme_dir . 'assets/images/' . ltrim( $image, '/' );
	}

	static $image_dimensions = array();
	if ( $image_path && file_exists( $image_path ) ) {
		if ( ! isset( $image_dimensions[ $image_path ] ) ) {
			$image_dimensions[ $image_path ] = @getimagesize( $image_path );
		}

		if ( ! empty( $image_dimensions[ $image_path ][0] ) && ! empty( $image_dimensions[ $image_path ][1] ) ) {
			$attrs['width']  = (int) $image_dimensions[ $image_path ][0];
			$attrs['height'] = (int) $image_dimensions[ $image_path ][1];
		}
	}

	$output = '';
	foreach ( $attrs as $name => $value ) {
		$output .= sprintf( ' %s="%s"', esc_attr( $name ), esc_attr( $value ) );
	}

	return $output;
}

/**
 * Enqueue scripts and styles.
 */
function kdpool_scripts() {
	$is_about_page    = is_page_template( 'page-about.php' ) || is_page( 'about' );
	$is_products_page = is_page_template( 'page-products.php' ) || is_page( 'products' ) || ( function_exists( 'is_shop' ) && is_shop() );
	$is_services_page = is_page_template( 'page-services.php' ) || is_page( array( 'service', 'services' ) );
	$is_sub_service   = is_page_template( 'templates/template-sub-service.php' );
	$is_contact_page  = is_page_template( 'page-contact.php' ) || is_page( 'contact' );
	$is_faq_page      = is_page_template( 'page-faq.php' ) || is_page( 'faq' );
	$is_blog_context  = is_home() || is_archive() || is_single() || is_search() || is_page_template( 'page-blog.php' ) || is_page( 'blog' );
	$is_legal_page    = is_page_template( 'page-legal.php' ) || is_page( array( 'privacy-policy', 'terms-and-conditions', 'terms-of-condition', 'privacy', 'terms' ) );

	// One small base bundle replaces separate global/header/footer requests.
	kdpool_enqueue_style_asset( 'kdpool-base-style', '/assets/css/base.css' );

	if ( is_front_page() ) {
		kdpool_enqueue_style_asset( 'kdpool-front-page-style', '/assets/css/front-page.css', array( 'kdpool-base-style' ) );
	} else {
		kdpool_enqueue_style_asset( 'kdpool-inner-hero-style', '/assets/css/inner-hero.css', array( 'kdpool-base-style' ) );
	}

	if ( $is_about_page || $is_products_page || $is_services_page ) {
		kdpool_enqueue_style_asset( 'kdpool-about-style', '/assets/css/about.css', array( 'kdpool-base-style' ) );
	}

	if ( $is_about_page || $is_services_page ) {
		kdpool_enqueue_style_asset( 'kdpool-why-choose-us-style', '/assets/css/why-choose-us.css', array( 'kdpool-base-style' ) );
	}

	if ( $is_products_page ) {
		kdpool_enqueue_style_asset( 'kdpool-range-of-products-style', '/assets/css/range-of-products.css', array( 'kdpool-base-style' ) );
	}

	if ( $is_about_page || $is_services_page || $is_sub_service ) {
		kdpool_enqueue_style_asset( 'kdpool-review-style', '/assets/css/review.css', array( 'kdpool-base-style' ) );
	}

	if ( $is_about_page || $is_products_page || $is_services_page || $is_faq_page ) {
		kdpool_enqueue_style_asset( 'kdpool-faq-style', '/assets/css/faq.css', array( 'kdpool-base-style' ) );
	}

	if ( $is_blog_context ) {
		kdpool_enqueue_style_asset( 'kdpool-blog-style', '/assets/css/blog.css', array( 'kdpool-base-style' ) );
	}

	if ( $is_contact_page ) {
		kdpool_enqueue_style_asset( 'kdpool-contact-style', '/assets/css/contact.css', array( 'kdpool-base-style' ) );
	}

	if ( $is_sub_service ) {
		kdpool_enqueue_style_asset( 'kdpool-process-style', '/assets/css/process.css', array( 'kdpool-base-style' ) );
	}

	if ( $is_sub_service || $is_services_page ) {
		kdpool_enqueue_style_asset( 'kdpool-sub-services-style', '/assets/css/sub-services.css', array( 'kdpool-base-style' ) );
	}

	if ( $is_services_page ) {
		kdpool_enqueue_style_asset( 'kdpool-main-service-style', '/assets/css/mainservice.css', array( 'kdpool-base-style' ) );
		kdpool_enqueue_style_asset( 'kdpool-services-intro-style', '/assets/css/services-intro.css', array( 'kdpool-base-style' ) );
	}

	if ( class_exists( 'WooCommerce' ) && ( is_woocommerce() || is_cart() || is_checkout() || is_account_page() ) ) {
		kdpool_enqueue_style_asset( 'kdpool-woocommerce-style', '/assets/css/woocommerce-custom.css', array( 'kdpool-base-style' ) );
	}

	if ( $is_legal_page ) {
		kdpool_enqueue_style_asset( 'kdpool-legal-style', '/assets/css/legal.css', array( 'kdpool-base-style' ) );
	}

	kdpool_enqueue_script_asset( 'kdpool-main-js', '/assets/js/main.js' );

	if ( $is_about_page ) {
		kdpool_enqueue_script_asset( 'kdpool-about-js', '/assets/js/about.js' );
	}

	// main.js already handles the products carousel. Keep range-of-products.js available in the theme,
	// but do not load it by default to avoid duplicate scrolling logic and one extra JS request.

	if ( $is_sub_service || $is_services_page ) {
		kdpool_enqueue_script_asset( 'kdpool-sub-services-js', '/assets/js/sub-services.js' );
	}

	if ( $is_services_page ) {
		kdpool_enqueue_script_asset( 'kdpool-services-intro-js', '/assets/js/services-intro.js' );
	}

	// Load the form embed only on templates that actually render the GHL iframe.
	if ( $is_contact_page || $is_about_page || $is_products_page ) {
		wp_enqueue_script( 'kdpool-ghl-form-embed', 'https://apps.kdpoolbuilders.com/js/form_embed.js', array(), null, true );
	}

	// Delay the chat widget until after initial rendering so it no longer blocks the critical network tree.
	wp_add_inline_script(
		'kdpool-main-js',
		"window.addEventListener('load',function(){setTimeout(function(){var s=document.createElement('script');s.src='https://widgets.leadconnectorhq.com/loader.js';s.defer=true;s.dataset.resourcesUrl='https://widgets.leadconnectorhq.com/chat-widget/loader.js';s.dataset.widgetId='690a00d67907ec923e621f1a';document.body.appendChild(s);},2500);});"
	);
}
add_action( 'wp_enqueue_scripts', 'kdpool_scripts' );

/**
 * Defer JavaScript to improve page load speed.
 */
function kdpool_defer_scripts( $tag, $handle, $src ) {
	$defer_scripts = array(
		'kdpool-main-js',
		'kdpool-about-js',
		'kdpool-range-of-products-js',
		'kdpool-sub-services-js',
		'kdpool-services-intro-js',
		'kdpool-ghl-form-embed',
		'woocommerce',
		'wc-cart-fragments',
		'wc-add-to-cart',
		'wc-order-attribution',
		'sourcebuster-js',
		'wc-blocks-middleware',
		'wc-blocks-data-store',
	);

	if ( in_array( $handle, $defer_scripts, true ) ) {
		if ( false === strpos( $tag, ' defer' ) && false === strpos( $tag, ' async' ) ) {
			return str_replace( ' src', ' defer="defer" src', $tag );
		}
	}

	return $tag;
}
add_filter( 'script_loader_tag', 'kdpool_defer_scripts', 10, 3 );

/**
 * Add selective preconnects for third-party services used by the theme.
 */
function kdpool_resource_hints( $urls, $relation_type ) {
	if ( 'preconnect' === $relation_type ) {
		if ( is_page_template( 'page-contact.php' ) || is_page_template( 'page-about.php' ) || is_page_template( 'page-products.php' ) || is_page( array( 'contact', 'about', 'products' ) ) ) {
			$urls[] = 'https://apps.kdpoolbuilders.com';
		}
	}

	return array_unique( $urls );
}
add_filter( 'wp_resource_hints', 'kdpool_resource_hints', 10, 2 );

/**
 * Remove WooCommerce scripts and styles on non-WooCommerce pages.
 */
function kdpool_manage_woocommerce_styles() {
	if ( function_exists( 'is_woocommerce' ) ) {
		if ( ! is_woocommerce() && ! is_cart() && ! is_checkout() && ! is_account_page() ) {
			wp_dequeue_style( 'woocommerce-layout' );
			wp_dequeue_style( 'woocommerce-smallscreen' );
			wp_dequeue_style( 'woocommerce-general' );
			wp_dequeue_style( 'wc-blocks-style' );
			wp_dequeue_style( 'wc-blocks-vendors-style' );
			wp_dequeue_style( 'woocommerce-inline' );
			wp_dequeue_style( 'wc-blocks-packages-style' );
		}
	}
}
add_action( 'wp_enqueue_scripts', 'kdpool_manage_woocommerce_styles', 99 );


/**
 * Add loading/decoding attributes if WordPress outputs a custom logo.
 */
function kdpool_custom_logo_image_attrs( $html ) {
	if ( false === strpos( $html, '<img' ) || false !== strpos( $html, ' loading=' ) ) {
		return $html;
	}

	return preg_replace( '/<img\s/', '<img loading="eager" decoding="async" ', $html, 1 );
}
add_filter( 'get_custom_logo', 'kdpool_custom_logo_image_attrs' );

/**
 * Preload the first hero image on the front page because it is the likely LCP image.
 */
function kdpool_preload_front_page_hero_image() {
	if ( is_front_page() ) {
		printf(
			'<link rel="preload" as="image" href="%s" type="image/webp" fetchpriority="high">' . "\n",
			esc_url( get_template_directory_uri() . '/assets/images/slider1.webp' )
		);
	}
}
add_action( 'wp_head', 'kdpool_preload_front_page_hero_image', 1 );

/**
 * Customizer Settings
 */
function kdpool_customize_register($wp_customize)
{
	// Theme Options Panel/Section
	$wp_customize->add_section('kdpool_theme_options', array(
		'title' => esc_html__('Theme Options', 'kdpool'),
		'priority' => 130,
	));

	// Header Button Text
	$wp_customize->add_setting('header_btn_text', array(
		'default' => 'GET A QUOTE',
		'sanitize_callback' => 'sanitize_text_field',
	));
	$wp_customize->add_control('header_btn_text', array(
		'label' => esc_html__('Header Button Text', 'kdpool'),
		'section' => 'kdpool_theme_options',
		'type' => 'text',
	));

	// Header Button URL
	$wp_customize->add_setting('header_btn_url', array(
		'default' => '#',
		'sanitize_callback' => 'esc_url_raw',
	));
	$wp_customize->add_control('header_btn_url', array(
		'label' => esc_html__('Header Button URL', 'kdpool'),
		'section' => 'kdpool_theme_options',
		'type' => 'url',
	));

	// Header Phone
	$wp_customize->add_setting('header_phone', array(
		'default' => '(716) 300-2773',
		'sanitize_callback' => 'sanitize_text_field',
	));
	$wp_customize->add_control('header_phone', array(
		'label' => esc_html__('Header Phone', 'kdpool'),
		'section' => 'kdpool_theme_options',
		'type' => 'text',
	));

	// Footer Email
	$wp_customize->add_setting('footer_email', array(
		'default' => 'sales@kdpoolbuilders.com',
		'sanitize_callback' => 'sanitize_email',
	));
	$wp_customize->add_control('footer_email', array(
		'label' => esc_html__('Footer Email', 'kdpool'),
		'section' => 'kdpool_theme_options',
		'type' => 'email',
	));

	// Footer Phone
	$wp_customize->add_setting('footer_phone', array(
		'default' => '(716)300-2773',
		'sanitize_callback' => 'sanitize_text_field',
	));
	$wp_customize->add_control('footer_phone', array(
		'label' => esc_html__('Footer Phone', 'kdpool'),
		'section' => 'kdpool_theme_options',
		'type' => 'text',
	));

	// Footer Address
	$wp_customize->add_setting('footer_address', array(
		'default' => '1496 Main St, Buffalo, NY 14209, United States.',
		'sanitize_callback' => 'sanitize_text_field',
	));
	$wp_customize->add_control('footer_address', array(
		'label' => esc_html__('Footer Address', 'kdpool'),
		'section' => 'kdpool_theme_options',
		'type' => 'textarea',
	));

	// Footer Instagram
	$wp_customize->add_setting('social_instagram', array(
		'default' => 'https://www.instagram.com/kdpool_builders/',
		'sanitize_callback' => 'esc_url_raw',
	));
	$wp_customize->add_control('social_instagram', array(
		'label' => esc_html__('Instagram URL', 'kdpool'),
		'section' => 'kdpool_theme_options',
		'type' => 'url',
	));

	// Footer Facebook
	$wp_customize->add_setting('social_facebook', array(
		'default' => 'https://web.facebook.com/kdpoolbuilders1/',
		'sanitize_callback' => 'esc_url_raw',
	));
	$wp_customize->add_control('social_facebook', array(
		'label' => esc_html__('Facebook URL', 'kdpool'),
		'section' => 'kdpool_theme_options',
		'type' => 'url',
	));
}
add_action('customize_register', 'kdpool_customize_register');

/**
 * Get Inline SVG Icon
 */
function kdpool_get_icon($icon, $class = '')
{
	$file_path = get_template_directory() . '/assets/icons/' . $icon . '.svg';

	if (!file_exists($file_path)) {
		return '';
	}

	$svg = file_get_contents($file_path);

	// Add custom class if provided
	if ($class) {
		$svg = preg_replace('/<svg /', '<svg class="' . esc_attr($class) . '" ', $svg, 1);
	}

	// Replace hardcoded fills with currentColor so CSS can control it
	$svg = preg_replace('/fill="#[a-fA-F0-9]{3,6}"/', 'fill="currentColor"', $svg);

	return $svg;
}

/**
 * Limit blog posts per page to 4 on the blog index.
 */
function kdpool_blog_posts_per_page($query)
{
	if (!is_admin() && $query->is_main_query() && $query->is_home()) {
		$query->set('posts_per_page', 4);
	}
}
add_action('pre_get_posts', 'kdpool_blog_posts_per_page');

/**
 * Custom WooCommerce Title and Breadcrumbs (Inner Hero Style)
 */
function kdpool_custom_woocommerce_title_breadcrumb() {
    if ( is_product() ) {
        $page_title = get_the_title();
        ?>
        <div class="breadcrumbs" style="margin-bottom: 15px; text-align: left;">
            <a href="<?php echo esc_url( home_url( '/' ) ); ?>">
                <?php echo kdpool_get_icon('home', 'home-icon'); ?>
                Home
            </a>
            <span class="separator">/</span>
            <span class="category-crumb">Fiber glass pool</span>
            <span class="separator">/</span>
            <span class="current-page"><?php echo esc_html($page_title); ?></span>
        </div>
        
        <h1 class="product_title entry-title inner-hero-title" style="text-align: left; margin-bottom: 25px;"><?php echo esc_html($page_title); ?></h1>
        <?php
    }
}
add_action( 'woocommerce_single_product_summary', 'kdpool_custom_woocommerce_title_breadcrumb', 5 );

/**
 * Move WooCommerce Breadcrumb below Product Title (Removed for Custom Inner Hero)
 */
remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20 );
remove_action( 'woocommerce_single_product_summary', 'woocommerce_breadcrumb', 6 );
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_title', 5 );
