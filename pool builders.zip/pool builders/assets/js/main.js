document.addEventListener('DOMContentLoaded', function() {
	// 1. Sticky Header
	var header = document.querySelector('.site-header');
	if (header) {
		window.addEventListener('scroll', function() {
			if (window.scrollY > 50) {
				header.classList.add('is-sticky');
			} else {
				header.classList.remove('is-sticky');
			}
		});
	}

	// 2. Mobile Menu
	var menuToggle = document.querySelector('.menu-toggle');
	var menuClose = document.querySelector('.menu-close');
	var menuOverlay = document.querySelector('.mobile-menu-overlay');

	if (menuToggle && header) {
		menuToggle.addEventListener('click', function(e) {
			e.preventDefault();
			header.classList.toggle('menu-active');
		});
	}

	if (menuClose && header) {
		menuClose.addEventListener('click', function(e) {
			e.preventDefault();
			header.classList.remove('menu-active');
		});
	}

	if (menuOverlay && header) {
		menuOverlay.addEventListener('click', function(e) {
			header.classList.remove('menu-active');
		});
	}

	// 3. Mobile Dropdown Toggle (if there are sub-menus)
	var menuItemsWithChildren = document.querySelectorAll('.menu-item-has-children > a');
	menuItemsWithChildren.forEach(function(item) {
		item.addEventListener('click', function(e) {
			if (window.innerWidth <= 767) {
				e.preventDefault();
				this.parentElement.classList.toggle('active');
			}
		});
	});

	// 4. Back to Top Button
	var backToTopBtn = document.getElementById('back-to-top');
	if (backToTopBtn) {
		window.addEventListener('scroll', function() {
			if (window.scrollY > 300) {
				backToTopBtn.classList.add('show');
			} else {
				backToTopBtn.classList.remove('show');
			}
		});
		backToTopBtn.addEventListener('click', function(e) {
			e.preventDefault();
			window.scrollTo({ top: 0, behavior: 'smooth' });
		});
	}

	// 5. Hero Slider
	const slides = document.querySelectorAll('.hero-slide');
	const dots = document.querySelectorAll('.hero-slider-dots .dot');
	if (slides.length > 0) {
		let currentSlide = 0;
		let sliderInterval;

		const goToSlide = (index) => {
			slides.forEach((slide, i) => {
				if (i === index) {
					slide.classList.add('active');
					if(dots[i]) dots[i].classList.add('active');
				} else {
					slide.classList.remove('active');
					if(dots[i]) dots[i].classList.remove('active');
				}
			});
			currentSlide = index;
		};

		const nextSlide = () => {
			let index = currentSlide + 1;
			if (index >= slides.length) index = 0;
			goToSlide(index);
		};

		// Auto play
		const startSlider = () => {
			sliderInterval = setInterval(nextSlide, 5000); // Change slide every 5s
		};

		const resetInterval = () => {
			clearInterval(sliderInterval);
			startSlider();
		};

		// Dot click
		dots.forEach((dot, index) => {
			dot.addEventListener('click', () => {
				goToSlide(index);
				resetInterval();
			});
		});

		startSlider();
	}

	// 6. Services Dynamic Tabs
	const serviceItems = document.querySelectorAll('.service-item');
	const serviceImages = document.querySelectorAll('.service-img');
	
	if (serviceItems.length > 0 && serviceImages.length > 0) {
		serviceItems.forEach(item => {
			item.addEventListener('mouseenter', function() {
				// Remove active class from all items and images
				serviceItems.forEach(el => el.classList.remove('active'));
				serviceImages.forEach(el => el.classList.remove('active'));
				
				// Add active class to hovered item
				this.classList.add('active');
				
				// Get target image class and activate it
				const targetClass = this.getAttribute('data-target');
				const targetImage = document.querySelector('.service-img.' + targetClass);
				if (targetImage) {
					targetImage.classList.add('active');
				}
			});
		});
	}
	
	// 7. FAQ Accordion
	const faqQuestions = document.querySelectorAll('.faq-question');
	if (faqQuestions.length > 0) {
		faqQuestions.forEach(question => {
			question.addEventListener('click', function() {
				const item = this.parentElement;
				
				// Toggle active class
				if (item.classList.contains('active')) {
					item.classList.remove('active');
				} else {
					// Optionally close others
					document.querySelectorAll('.faq-item').forEach(el => el.classList.remove('active'));
					item.classList.add('active');
				}
			});
		});
	}

	// 8. Reviews Slider
	const reviewSlides = document.querySelectorAll('.review-slide');
	const reviewDots = document.querySelectorAll('.reviews-slider-dots .dot');
	if (reviewSlides.length > 0) {
		let currentReview = 0;
		let reviewInterval;

		const goToReview = (index) => {
			reviewSlides.forEach((slide, i) => {
				if (i === index) {
					slide.classList.add('active');
					if(reviewDots[i]) reviewDots[i].classList.add('active');
				} else {
					slide.classList.remove('active');
					if(reviewDots[i]) reviewDots[i].classList.remove('active');
				}
			});
			currentReview = index;
		};

		const nextReview = () => {
			let index = currentReview + 1;
			if (index >= reviewSlides.length) index = 0;
			goToReview(index);
		};

		const startReviewSlider = () => {
			reviewInterval = setInterval(nextReview, 5000); // 5 seconds
		};

		const resetReviewInterval = () => {
			clearInterval(reviewInterval);
			startReviewSlider();
		};

		reviewDots.forEach((dot, index) => {
			dot.addEventListener('click', () => {
				goToReview(index);
				resetReviewInterval();
			});
		});

		startReviewSlider();
	}

	// 9. Auto-scroll and Drag-to-scroll for Carousels
	const carousels = [
		{ selector: '.products-carousel-wrap', direction: 'vertical', speed: 1 },
		{ selector: '.wwd-carousel-wrapper', direction: 'horizontal', speed: 1 }
	];

	carousels.forEach(config => {
		const el = document.querySelector(config.selector);
		if (!el) return;

		let isDown = false;
		let startPos, scrollPos;
		let autoScrollInterval;

		el.style.cursor = 'grab';

		const startAutoScroll = () => {
			autoScrollInterval = setInterval(() => {
				if (!isDown) {
					if (config.direction === 'vertical') {
						el.scrollTop += config.speed;
					} else {
						el.scrollLeft += config.speed;
					}
				}
			}, 30);
		};

		startAutoScroll();

		el.addEventListener('mouseenter', () => clearInterval(autoScrollInterval));
		el.addEventListener('mouseleave', () => {
			isDown = false;
			el.style.cursor = 'grab';
			clearInterval(autoScrollInterval);
			startAutoScroll();
		});

		el.addEventListener('mousedown', (e) => {
			isDown = true;
			el.style.cursor = 'grabbing';
			if (config.direction === 'vertical') {
				startPos = e.pageY - el.offsetTop;
				scrollPos = el.scrollTop;
			} else {
				startPos = e.pageX - el.offsetLeft;
				scrollPos = el.scrollLeft;
			}
		});

		el.addEventListener('mouseup', () => {
			isDown = false;
			el.style.cursor = 'grab';
		});
		
		el.addEventListener('mouseleave', () => {
			isDown = false;
			el.style.cursor = 'grab';
		});

		el.addEventListener('mousemove', (e) => {
			if (!isDown) return;
			e.preventDefault();
			if (config.direction === 'vertical') {
				const y = e.pageY - el.offsetTop;
				const walk = (y - startPos) * 2; 
				el.scrollTop = scrollPos - walk;
			} else {
				const x = e.pageX - el.offsetLeft;
				const walk = (x - startPos) * 2; 
				el.scrollLeft = scrollPos - walk;
			}
		});

		// Handle native scrolling (trackpad, wheel, and programmatic updates)
		el.addEventListener('scroll', () => {
			if (config.direction === 'vertical') {
				const halfHeight = el.scrollHeight / 2;
				if (el.scrollTop >= halfHeight) {
					el.scrollTop -= halfHeight;
					if (isDown) scrollPos -= halfHeight;
				} else if (el.scrollTop <= 0) {
					el.scrollTop += halfHeight;
					if (isDown) scrollPos += halfHeight;
				}
			} else {
				const halfWidth = el.scrollWidth / 2;
				if (el.scrollLeft >= halfWidth) {
					el.scrollLeft -= halfWidth;
					if (isDown) scrollPos -= halfWidth;
				} else if (el.scrollLeft <= 0) {
					el.scrollLeft += halfWidth;
					if (isDown) scrollPos += halfWidth;
				}
			}
		});
	});
});
