﻿document.addEventListener('DOMContentLoaded', function() {
    const wrap = document.querySelector('.products-carousel-wrap');
    const carousel = document.querySelector('.products-carousel');
    if (!wrap || !carousel) return;

    let isHovered = false;
    let isTouching = false;
    let animationId;

    wrap.addEventListener('mouseenter', () => isHovered = true);
    wrap.addEventListener('mouseleave', () => isHovered = false);
    wrap.addEventListener('touchstart', () => isTouching = true, {passive: true});
    wrap.addEventListener('touchend', () => {
        setTimeout(() => isTouching = false, 1000);
    });

    function autoScroll() {
        if (!isHovered && !isTouching) {
            wrap.scrollTop += 1;
            if (wrap.scrollTop >= (carousel.scrollHeight / 2) - 15) {
                wrap.scrollTop = 0;
            }
        }
        animationId = requestAnimationFrame(autoScroll);
    }

    wrap.addEventListener('scroll', () => {
        if (isHovered || isTouching) {
            if (wrap.scrollTop >= (carousel.scrollHeight / 2) - 15) {
                wrap.scrollTop = 0;
            } else if (wrap.scrollTop <= 0) {
                wrap.scrollTop = (carousel.scrollHeight / 2) - 30;
            }
        }
    });

    animationId = requestAnimationFrame(autoScroll);
});
