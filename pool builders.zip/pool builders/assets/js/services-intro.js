document.addEventListener('DOMContentLoaded', function() {
    const tabItems = document.querySelectorAll('.services-intro-tabs-nav .tab-item');
    const tabPanels = document.querySelectorAll('.services-intro-tabs-content .tab-panel');

    if (tabItems.length === 0 || tabPanels.length === 0) return;

    tabItems.forEach(item => {
        item.addEventListener('click', function() {
            // Remove active class from all tabs and panels
            tabItems.forEach(tab => tab.classList.remove('active'));
            tabPanels.forEach(panel => panel.classList.remove('active'));

            // Add active class to clicked tab
            this.classList.add('active');

            // Find matching panel and show it
            const targetId = this.getAttribute('data-tab');
            const targetPanel = document.getElementById(targetId);
            
            if (targetPanel) {
                targetPanel.classList.add('active');
            }
        });
    });
});
