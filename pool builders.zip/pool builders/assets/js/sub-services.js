// JavaScript for Sub Services (currently empty as video is inline and autoplaying)

document.addEventListener('DOMContentLoaded', function() {
    const counters = document.querySelectorAll('.journey-stat-number');
    const speed = 100; // The lower the slower

    const observer = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const target = entry.target;
                const updateCount = () => {
                    const targetValue = +target.getAttribute('data-target');
                    const count = +target.innerText;
                    const inc = targetValue / speed;

                    if (count < targetValue) {
                        target.innerText = Math.ceil(count + inc);
                        setTimeout(updateCount, 15);
                    } else {
                        target.innerText = targetValue.toLocaleString();
                    }
                };
                updateCount();
                observer.unobserve(target); // Only animate once
            }
        });
    }, { threshold: 0.5 });

    counters.forEach(counter => {
        observer.observe(counter);
    });
});
