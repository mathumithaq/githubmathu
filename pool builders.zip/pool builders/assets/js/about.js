﻿document.addEventListener('DOMContentLoaded', function() {
    const track = document.querySelector('.reviews-track');
    const dots = document.querySelectorAll('.review-dots span');
    const cards = document.querySelectorAll('.review-card');
    if(!track || !dots.length || !cards.length) return;

    dots.forEach(dot => {
        dot.addEventListener('click', () => {
            const index = dot.getAttribute('data-index');
            const targetCard = cards[index];
            if(targetCard) {
                const containerCenter = track.offsetWidth / 2;
                const cardCenter = targetCard.offsetWidth / 2;
                const targetScroll = targetCard.offsetLeft - containerCenter + cardCenter;
                track.scrollTo({ left: targetScroll, behavior: 'smooth' });
            }
        });
    });

    track.addEventListener('scroll', () => {
        let closestIndex = 0;
        let minDiff = Infinity;
        const trackCenter = track.scrollLeft + (track.offsetWidth / 2);
        
        cards.forEach((card, index) => {
            const cardCenter = card.offsetLeft + (card.offsetWidth / 2);
            const diff = Math.abs(trackCenter - cardCenter);
            if(diff < minDiff) {
                minDiff = diff;
                closestIndex = index;
            }
        });

        dots.forEach(d => d.classList.remove('active'));
        if(dots[closestIndex]) dots[closestIndex].classList.add('active');
    });
    
    setTimeout(() => {
        const containerCenter = track.offsetWidth / 2;
        const cardCenter = cards[0].offsetWidth / 2;
        track.scrollLeft = cards[0].offsetLeft - containerCenter + cardCenter;
    }, 100);
});
