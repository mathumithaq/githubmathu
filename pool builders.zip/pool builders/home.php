<?php
/**
 * The template for displaying the blog posts index.
 */

get_header(); 
get_template_part('template-parts/header/inner-hero');
?>
<main id="primary" class="site-main blog-list-main bg-light-section">
    <div class="kd-container">
        <div class="blog-list-wrapper">
            <?php if ( have_posts() ) : ?>
                <div class="blog-list-container">
                    <?php 
                    $post_count = 0;
                    while ( have_posts() ) : the_post(); 
                        $post_count++;
                        // Alternate the class based on odd/even
                        $alt_class = ($post_count % 2 == 0) ? 'alt-layout' : '';
                    ?>
                        
                        <article id="post-<?php the_ID(); ?>" <?php post_class('blog-list-card ' . $alt_class); ?>>
                            
                            <!-- CONTENT SIDE -->
                            <div class="blog-list-content">
                                <div class="blog-list-meta">
                                    <span class="meta-date">
                                        <i class="far fa-clock"></i>
                                        <?php echo get_the_modified_date(); ?>
                                    </span>
                                    <span class="meta-category">
                                        <i class="far fa-folder"></i>
                                        <?php the_category(', '); ?>
                                    </span>
                                    <span class="meta-author">
                                        <i class="far fa-user"></i>
                                        by: <?php the_author(); ?>
                                    </span>
                                </div>
                                
                                <h2 class="blog-list-title">
                                    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                </h2>
                                
                                <div class="blog-list-footer">
                                    <a href="<?php the_permalink(); ?>" class="blog-list-read-more">
                                        Read More <span class="read-more-icon"><?php echo kdpool_get_icon('arrow-right'); ?></span>
                                    </a>
                                </div>
                            </div>

                            <!-- IMAGE SIDE -->
                            <?php if ( has_post_thumbnail() ) : ?>
                                <div class="blog-list-image">
                                    <a href="<?php the_permalink(); ?>">
                                        <?php the_post_thumbnail( 'large', array( 'class' => 'img-responsive', 'loading' => 'lazy', 'decoding' => 'async' ) ); ?>
                                    </a>
                                </div>
                            <?php else : ?>
                                <!-- Fallback image if no featured image -->
                                <div class="blog-list-image">
                                    <a href="<?php the_permalink(); ?>">
                                        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/placeholder.webp" alt="No image" class="img-responsive"<?php echo kdpool_get_image_attrs('placeholder.webp'); ?>>
                                    </a>
                                </div>
                            <?php endif; ?>
                            
                        </article>

                    <?php endwhile; ?>
                </div>

                <!-- Pagination -->
                <div class="blog-pagination">
                    <?php 
                    the_posts_pagination( array(
                        'prev_text' => '<i class="fas fa-arrow-left"></i> Prev',
                        'next_text' => 'Next <i class="fas fa-arrow-right"></i>',
                    ) );
                    ?>
                </div>

            <?php else : ?>
                <p class="no-posts-found">No blog posts found. Try publishing some posts from your WordPress dashboard!</p>
            <?php endif; ?>
        </div>
    </div>
</main>

<?php get_footer(); ?>
