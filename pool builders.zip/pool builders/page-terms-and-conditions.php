<?php
/**
 * Template for Terms and Conditions Page
 */
get_header(); ?>

<main class="legal-page-main" style="background-image: url('<?php echo get_template_directory_uri(); ?>/assets/images/pool-footer-bg.webp');">
    <!-- Dark overlay -->
    <div class="legal-page-overlay"></div>
    
    <!-- White content box -->
    <div class="kd-container legal-content-box">
        <h1 class="legal-page-title">Terms and Conditions</h1>
        
        <div class="legal-content">
            <h2>Welcome to KD Pool Builders!</h2>
            <p>These terms and conditions outline the rules and regulations for the use of KD Pool Builders’s Website, located at https://kdpoolbuilders.com/</p>
            <p>By accessing this website we assume you accept these terms and conditions. Do not continue to use KD Pool Builders if you do not agree to take all of the terms and conditions stated on this page.</p>
            <p>The following terminology applies to these Terms and Conditions, Privacy Statement and Disclaimer Notice, and all Agreements: “Client”, “You” and “Your” refers to you, the person who logs on this website and is compliant with the Company’s terms and conditions. “The Company”, “Ourselves”, “We”, “Our” and “Us”, refers to our Company. “Party”, “Parties”, or “Us”, refers to both the Client and ourselves. All terms refer to the offer, acceptance, and consideration of payment necessary to undertake the process of our assistance to the Client in the most appropriate manner for the express purpose of meeting the Client’s needs in respect of the provision of the Company’s stated services, in accordance with and subject to, prevailing law of United States. Any use of the above terminology or other words in the singular, plural, capitalization, and/or he/she or they, are taken as interchangeable and therefore as referring to the same.</p>
            <h2>Cookies</h2>
            <p>We employ the use of cookies. By accessing KD Pool Builders, you agree to use cookies in agreement with KD Pool Builders’s Privacy Policy.</p>
            <p>Most interactive websites use cookies to let us retrieve the user’s details for each visit. Cookies are used by our website to enable the functionality of certain areas to make it easier for people visiting our website. Some of our affiliate/advertising partners may also use cookies.</p>
            <h2>License</h2>
            <p>Unless otherwise stated, KD Pool Builders and/or its licensors own the intellectual property rights for all material on KD Pool Builders. All intellectual property rights are reserved. You may access this from KD Pool Builders for your own personal use subject to restrictions set in these terms and conditions.</p>
            <p>You must not:</p>
            <ul>
            <li>Republish material from KD Pool Builders</li>
            <li>Sell, rent, or sub-license material from KD Pool Builders</li>
            <li>Reproduce, duplicate or copy material from KD Pool Builders</li>
            <li>Redistribute content from KD Pool Builders</li>
            </ul>
            <h2>Carrier Liability Disclaimer</h2>
            <p>By using our SMS services, you acknowledge and agree that KD Pool Builders is not liable for delays or failures in message delivery caused by your mobile carrier. Message delivery may be affected by network congestion, technical issues, or service interruptions beyond our control.</p>
            <h2>SMS Help & Customer Support</h2>
            <p>For assistance regarding SMS messages, you can contact KD Pool Builders via:</p>
            <p>Email: sales@kdpoolbuilders.com<br>
            Phone: (716) 300-2773</p>
            <h2>SMS Opt-Out Instructions</h2>
            <p>You may opt out of receiving SMS messages from KD Pool Builders at any time. To opt out, reply “STOP” to any SMS received, or contact us directly via the above email or phone. Opting out will not affect your ability to receive other communications you have consented to.</p>
            <h2>SMS Messaging Terms</h2>
            <p>By opting in to receive SMS messages from KD Pool Builders, you consent to receive promotional and transactional messages regarding products, services, or updates. Message and data rates may apply. Message frequency may vary. Opting in is voluntary and does not condition the purchase of goods or services.</p>
            <h2>Age Requirement (18+)</h2>
            <p>You must be at least 18 years old to use this website or participate in SMS marketing campaigns. By using this website or subscribing to SMS messages, you represent and warrant that you are 18 years of age or older.</p>
            <h2>Content Liability</h2>
            <p>We shall not be held responsible for any content that appears on your Website. You agree to protect and defend us against all claims on your Website. No link(s) should appear on any Website that may be interpreted as libelous, obscene, or criminal, or which infringes, otherwise violates, or advocates the infringement or other violation of, any third-party rights.</p>
            <h2>Your Privacy</h2>
            <p>Please read our Privacy Policy for information on how we collect, use, and protect your personal data.</p>
            <h2>Disclaimer</h2>
            <p>To the maximum extent permitted by applicable law, we exclude all representations, warranties, and conditions relating to our website and the use of this website. Nothing in this disclaimer will:</p>
            <ul>
            <li>Limit or exclude our or your liability for death or personal injury;</li>
            <li>Limit or exclude our or your liability for fraud or fraudulent misrepresentation;</li>
            <li>Modify any of our or your liabilities in any way that is not permitted under applicable law; or</li>
            <li>Exclude any of our or your liabilities that may not be excluded under applicable law.</li>
            </ul>
            <p>The limitations and prohibitions of liability set in this Section and elsewhere in this disclaimer: (a) are subject to the preceding paragraph; and (b) govern all liabilities arising under the disclaimer, including liabilities arising in contract, in tort, and for breach of statutory duty.</p>
            <p>As long as the website and the information and services on the website are provided free of charge, we will not be liable for any loss or damage of any nature.</p>
        </div>
    </div>
</main>

<?php get_footer(); ?>
