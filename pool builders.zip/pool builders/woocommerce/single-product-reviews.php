<?php
/**
 * Display single product reviews (comments)
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product-reviews.php.
 *
 * @see     https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 4.3.0
 */

defined( 'ABSPATH' ) || exit;

global $product;

if ( ! comments_open() ) {
	return;
}
?>
<div id="reviews" class="woocommerce-Reviews">
	<div id="comments">
		<h2 class="woocommerce-Reviews-title">
			<?php
			$count = $product->get_review_count();
			if ( $count && wc_review_ratings_enabled() ) {
				/* translators: 1: reviews count 2: product name */
				$reviews_title = sprintf( esc_html_n( '%1$s review for %2$s', '%1$s reviews for %2$s', $count, 'woocommerce' ), esc_html( $count ), '<span>' . get_the_title() . '</span>' );
				echo apply_filters( 'woocommerce_reviews_title', $reviews_title, $count, $product ); // WPCS: XSS ok.
			} else {
				esc_html_e( 'Reviews', 'woocommerce' );
			}
			?>
		</h2>

		<?php if ( have_comments() ) : ?>
			<ol class="commentlist">
				<?php wp_list_comments( apply_filters( 'woocommerce_product_review_list_args', array( 'callback' => 'woocommerce_comments' ) ) ); ?>
			</ol>

			<?php
			if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) :
				echo '<nav class="woocommerce-pagination">';
				paginate_comments_links(
					apply_filters(
						'woocommerce_comment_pagination_args',
						array(
							'prev_text' => is_rtl() ? '&rarr;' : '&larr;',
							'next_text' => is_rtl() ? '&larr;' : '&rarr;',
							'type'      => 'list',
						)
					)
				);
				echo '</nav>';
			endif;
			?>
		<?php else : ?>
			<p class="woocommerce-noreviews"><?php esc_html_e( 'There are no reviews yet.', 'woocommerce' ); ?></p>
		<?php endif; ?>
	</div>

	<?php if ( get_option( 'woocommerce_review_rating_verification_required' ) === 'no' || wc_customer_bought_product( '', get_current_user_id(), $product->get_id() ) ) : ?>
		<div id="review_form_wrapper">
			<div id="review_form">
				<?php
				$commenter    = wp_get_current_commenter();
                
                // Construct the custom fields using fieldset and legend for the floating label look
                $fields = array(
                    'author' => '<div class="review-form-row">
                                    <fieldset class="custom-floating-fieldset">
                                        <legend>Full Name</legend>
                                        <input id="author" name="author" type="text" value="' . esc_attr( $commenter['comment_author'] ) . '" size="30" required placeholder="John Doe" />
                                    </fieldset>',
                    'email'  => '   <fieldset class="custom-floating-fieldset">
                                        <legend>Email</legend>
                                        <input id="email" name="email" type="email" value="' . esc_attr( $commenter['comment_author_email'] ) . '" size="30" required placeholder="john@example.com" />
                                    </fieldset>
                                </div>',
                );
                
                $comment_field = '';
                
                if ( wc_review_ratings_enabled() ) {
                    // Custom Star Rating UI
                    $comment_field .= '<div class="custom-star-rating-wrapper">
                                        <div class="custom-stars-container">
                                            <div class="custom-star-item" data-val="1"><span class="star-icon">&#9734;</span><span>Bad (1/5)</span></div>
                                            <div class="custom-star-item" data-val="2"><span class="star-icon">&#9734;</span><span>So-so (2/5)</span></div>
                                            <div class="custom-star-item" data-val="3"><span class="star-icon">&#9734;</span><span>Ok (3/5)</span></div>
                                            <div class="custom-star-item" data-val="4"><span class="star-icon">&#9734;</span><span>Good (4/5)</span></div>
                                            <div class="custom-star-item" data-val="5"><span class="star-icon">&#9734;</span><span>Great (5/5)</span></div>
                                        </div>
                                        <select name="rating" id="rating" required style="display:none;">
                                            <option value="">Rate&hellip;</option>
                                            <option value="5">Perfect</option>
                                            <option value="4">Good</option>
                                            <option value="3">Average</option>
                                            <option value="2">Not that bad</option>
                                            <option value="1">Very poor</option>
                                        </select>
                                      </div>';
                }

                $comment_field .= '<fieldset class="custom-floating-fieldset review-textarea-fieldset">
                                    <legend>Review</legend>
                                    <textarea id="comment" name="comment" cols="45" rows="5" required placeholder="I love my new pool..."></textarea>
                                  </fieldset>';
                                  
                // Custom Terms checkbox
                $comment_field .= '<div class="custom-review-terms">
                                    <label>
                                        <input type="checkbox" required>
                                        <span class="custom-checkbox-box"></span>
                                        I accept the <strong>terms and conditions</strong> of submitting the review
                                    </label>
                                   </div>';
                
				$comment_form_args = array(
					'title_reply_before'  => '<h3 id="reply-title" class="comment-reply-title" style="display:none;">',
					'title_reply_after'   => '</h3>',
					'comment_notes_before'=> '',
					'comment_notes_after' => '',
					'fields'              => apply_filters( 'woocommerce_comment_form_fields', $fields ),
					'label_submit'        => esc_html__( 'Rate product', 'woocommerce' ),
					'logged_in_as'        => '',
					'comment_field'       => $comment_field,
                    'submit_button'       => '<div class="custom-review-actions">
                                                <button type="button" class="custom-cancel-btn" onclick="document.getElementById(\'commentform\').reset();">Cancel</button>
                                                <button type="submit" name="%1$s" id="%2$s" class="custom-submit-btn">%4$s <i class="fas fa-sparkles"></i></button>
                                              </div>',
                    'submit_field'        => '%1$s %2$s',
				);

				comment_form( apply_filters( 'woocommerce_product_review_comment_form_args', $comment_form_args ) );
				?>
			</div>
		</div>
	<?php else : ?>
		<p class="woocommerce-verification-required"><?php esc_html_e( 'Only logged in customers who have purchased this product may leave a review.', 'woocommerce' ); ?></p>
	<?php endif; ?>
</div>

<script>
// Logic for custom star rating
document.addEventListener("DOMContentLoaded", function() {
    const starItems = document.querySelectorAll('.custom-star-item');
    const hiddenSelect = document.getElementById('rating');
    
    if(starItems.length > 0 && hiddenSelect) {
        starItems.forEach(item => {
            item.addEventListener('click', function() {
                let val = this.getAttribute('data-val');
                hiddenSelect.value = val;
                
                // Update UI
                starItems.forEach(s => {
                    s.classList.remove('active');
                    s.querySelector('.star-icon').innerHTML = '&#9734;'; // Empty star
                });
                
                this.classList.add('active');
                this.querySelector('.star-icon').innerHTML = '&#9733;'; // Filled star
            });
        });
    }
});
</script>
