<?php
/**
 * Related Products
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/related.php.
 *
 * @see         https://woocommerce.com/document/template-structure/
 * @package     WooCommerce\Templates
 * @version     3.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( $related_products ) : ?>

	<section class="related products">

		<?php
		$heading = apply_filters( 'woocommerce_product_related_products_heading', __( 'Related products', 'woocommerce' ) );

		if ( $heading ) :
			?>
			<h2><?php echo esc_html( $heading ); ?></h2>
		<?php endif; ?>

		<ul class="products custom-related-carousel">

			<?php foreach ( $related_products as $related_product ) : ?>

				<?php
				$post_object = get_post( $related_product->get_id() );

				setup_postdata( $GLOBALS['post'] =& $post_object ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited, Squiz.PHP.DisallowMultipleAssignments.Found

				// Get the featured image URL
				$image_url = get_the_post_thumbnail_url( $post_object->ID, 'large' );
				if ( ! $image_url ) {
					$image_url = wc_placeholder_img_src( 'large' );
				}
				?>

				<li <?php wc_product_class( 'arched-product-card', $related_product ); ?>>
					<a href="<?php echo esc_url( $related_product->get_permalink() ); ?>" class="arched-card-link">
						<div class="arched-card-inner">
                            <div class="arched-card-image" style="background-image: url('<?php echo esc_url( $image_url ); ?>');">
                            </div>
                            <div class="arched-card-content">
                                <span class="arched-number"><?php echo sprintf('%02d', $iterator ?? 1); $iterator = ($iterator ?? 1) + 1; ?></span>
                                <h2 class="arched-card-title"><?php echo esc_html( $related_product->get_name() ); ?></h2>
                                <p class="arched-card-desc"><?php echo wp_trim_words( get_the_excerpt($post_object->ID), 15, '...' ); ?></p>
                                <span class="button">Read more</span>
                            </div>
                        </div>
					</a>
				</li>

			<?php endforeach; ?>

		</ul>

	</section>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const slider = document.querySelector('.custom-related-carousel');
        if (!slider) return;

        let isDown = false;
        let startX;
        let scrollLeft;
        let autoScrollInterval;

        // Manual drag scroll
        slider.addEventListener('mousedown', (e) => {
            isDown = true;
            slider.style.cursor = 'grabbing';
            // Disable scroll snap during manual drag for smooth movement
            slider.style.scrollSnapType = 'none';
            startX = e.pageX - slider.offsetLeft;
            scrollLeft = slider.scrollLeft;
            clearInterval(autoScrollInterval); // pause auto scroll when interacting
        });
        
        slider.addEventListener('mouseleave', () => {
            isDown = false;
            slider.style.cursor = 'grab';
            slider.style.scrollSnapType = 'x mandatory';
            startAutoScroll();
        });
        
        slider.addEventListener('mouseup', () => {
            isDown = false;
            slider.style.cursor = 'grab';
            slider.style.scrollSnapType = 'x mandatory';
            startAutoScroll();
        });
        
        slider.addEventListener('mousemove', (e) => {
            if (!isDown) return;
            e.preventDefault();
            const x = e.pageX - slider.offsetLeft;
            const walk = (x - startX) * 2; // scroll-fast
            slider.scrollLeft = scrollLeft - walk;
        });

        // Initialize grab cursor
        slider.style.cursor = 'grab';

        // Auto horizontal move
        function startAutoScroll() {
            clearInterval(autoScrollInterval);
            autoScrollInterval = setInterval(() => {
                // If reached the end, go back to start
                if (slider.scrollLeft + slider.clientWidth >= slider.scrollWidth - 10) {
                    slider.scrollTo({ left: 0, behavior: 'smooth' });
                } else {
                    slider.scrollBy({ left: 350, behavior: 'smooth' }); // Scroll by one card width + gap
                }
            }, 3000); // 3 seconds interval
        }

        // Start auto scroll on load
        startAutoScroll();
    });
    </script>
	<?php
endif;

wp_reset_postdata();
