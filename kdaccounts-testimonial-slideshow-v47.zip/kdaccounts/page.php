<?php get_header(); ?>

<main id="primary" class="site-main">

    <?php 
    // Include the dynamic inner hero section
    get_template_part( 'template-parts/sections/inner-hero' ); 
    ?>

    <div class="container" style="padding-top: 80px; padding-bottom: 80px;">
        <?php
        while ( have_posts() ) :
            the_post();
            
            // Output standard WordPress page content
            the_content();
            
        endwhile; // End of the loop.
        ?>
    </div>

</main>

<?php get_footer(); ?>