<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package KD_Accounts_Theme
 */

get_template_part( 'template-parts/footer/site-footer' );

wp_footer();
?>
<!-- Chatbot Widget Delayed Load -->
<script>
    window.addEventListener("load", function () {
        setTimeout(function () {
            var script = document.createElement("script");
            script.src = "https://widgets.leadconnectorhq.com/loader.js";
            script.setAttribute("data-resources-url", "https://widgets.leadconnectorhq.com/chat-widget/loader.js");
            script.setAttribute("data-widget-id", "690b70817907ec8b900378ad");
            document.body.appendChild(script);
        }, 3000); // 3-second delay
    });
</script>
</body>
</html>
