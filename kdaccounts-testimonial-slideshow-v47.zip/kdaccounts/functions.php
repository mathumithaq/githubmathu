<?php
/**
 * KD Accounts Theme functions and definitions
 */

if (!defined('_S_VERSION')) {
    // Static version — allows browser to cache assets. Change only on deployment.
    define('_S_VERSION', '1.2.0');
}

/**
 * Helper function to dynamically fetch page links by title.
 * This ensures that if the user changes the URL slug in the WP Admin, the link automatically updates.
 */
if (!function_exists('kd_get_dynamic_link')) {
    function kd_get_dynamic_link($title, $fallback_slug)
    {
        $page = get_page_by_title($title);
        if ($page) {
            // Use post_name (slug) directly — avoids parent slug appearing in URL
            // e.g. /services/accounting-services/ → /accounting-services/
            return home_url('/' . $page->post_name . '/');
        }
        return home_url('/' . $fallback_slug . '/');
    }
}

/**
 * =========================================================================
 * WordPress Bloat Removal — Removes unused WordPress features
 * that add render-blocking scripts/styles.
 * =========================================================================
 */
function kd_remove_wp_bloat()
{
    // Remove WP emoji scripts and styles (saves ~50 KB of render-blocking JS)
    remove_action('wp_head', 'print_emoji_detection_script', 7);
    remove_action('wp_print_styles', 'print_emoji_styles');
    remove_action('admin_print_scripts', 'print_emoji_detection_script');
    remove_action('admin_print_styles', 'print_emoji_styles');
    remove_filter('the_content_feed', 'wp_staticize_emoji');
    remove_filter('comment_text_rss', 'wp_staticize_emoji');
    remove_filter('wp_mail', 'wp_staticize_emoji_for_email');

    // Remove oEmbed (saves JS and a DNS lookup)
    remove_action('wp_head', 'wp_oembed_add_host_js');
    remove_action('wp_head', 'wp_oembed_add_discovery_links');

    // Remove feed links (RSS — not needed for most pages)
    remove_action('wp_head', 'feed_links', 2);
    remove_action('wp_head', 'feed_links_extra', 3);

    // Remove wlwmanifest link (Windows Live Writer — obsolete)
    remove_action('wp_head', 'wlwmanifest_link');

    // Remove RSD link
    remove_action('wp_head', 'rsd_link');

    // Remove shortlink tag
    remove_action('wp_head', 'wp_shortlink_wp_head');

    // Remove REST API link (front-end exposure not needed)
    remove_action('wp_head', 'rest_output_link_wp_head');
    remove_action('wp_head', 'wp_oembed_add_host_js');

    // Remove WP generator meta tag (security + bloat)
    remove_action('wp_head', 'wp_generator');
}
add_action('init', 'kd_remove_wp_bloat');

/**
 * Remove WordPress Block / Gutenberg CSS and plugin CSS that is not used
 * (saves ~70 KB of render-blocking CSS on every page load)
 */
function kd_dequeue_block_styles()
{
    wp_dequeue_style('wp-block-library');
    wp_dequeue_style('wp-block-library-theme');
    wp_dequeue_style('global-styles');
    wp_dequeue_style('classic-theme-styles');
    // Remove subscription block CSS (render-blocking, not used in this theme)
    wp_dequeue_style('blocks-subscription');
    wp_dequeue_style('jetpack-subscriptions');
    wp_dequeue_style('wpcom-notes-button');
}
add_action('wp_enqueue_scripts', 'kd_dequeue_block_styles', 100);

/**
 * =========================================================================
 * Add defer attribute to all theme JS — prevents render-blocking
 * =========================================================================
 */
function kd_defer_scripts($tag, $handle, $src)
{
    $defer_scripts = [
        'kdaccounts-navigation',
        'kdaccounts-ajax-router',
        'kdaccounts-testimonials',
    ];

    if (in_array($handle, $defer_scripts)) {
        return '<script defer src="' . esc_url($src) . '"></script>' . "\n";
    }

    return $tag;
}
add_filter('script_loader_tag', 'kd_defer_scripts', 10, 3);

/**
 * =========================================================================
 * Theme Scripts & Styles Enqueue
 * =========================================================================
 */
function kdaccounts_scripts()
{
    // CSS is now inlined in the head via kdaccounts_inline_critical_css() to prevent render-blocking.

    // Navigation — loaded on all pages (needed for header)
    wp_enqueue_script('kdaccounts-navigation', get_template_directory_uri() . '/assets/js/navigation.js', array(), _S_VERSION, true);

    // Use native navigation so destination body/main classes, head assets and
    // page-specific scripts are initialized together on the first visit.

    // Lazy load scripts (for GHL form, etc.)
    wp_enqueue_script('kdaccounts-lazyload', get_template_directory_uri() . '/assets/js/lazyload.js', array(), _S_VERSION, true);

    if (is_page('bookkeeping-services')) {
        wp_enqueue_script('kdaccounts-review-slideshow', get_template_directory_uri() . '/assets/js/bookkeeping-reviews.js', array(), filemtime(get_template_directory() . '/assets/js/bookkeeping-reviews.js'), true);
    }

    // Testimonials — only load on pages that actually have the testimonials section
    $load_testimonials = is_front_page() || is_page('about') || is_page('home');
    if ($load_testimonials) {
        wp_enqueue_script('kdaccounts-testimonials', get_template_directory_uri() . '/assets/js/testimonials.js', array(), _S_VERSION, true);
    }
}
add_action('wp_enqueue_scripts', 'kdaccounts_scripts');

/**
 * Inline critical CSS to completely eliminate render-blocking requests
 * without causing Flash of Unstyled Content (FOUC).
 */
function kdaccounts_inline_critical_css() {
    $theme_dir = get_template_directory();
    $theme_uri = get_template_directory_uri();
    
    echo "<style id='kdaccounts-inline-css'>\n";
    
    $css_files = array('fonts.css', 'global.css', 'section.css');
    foreach ($css_files as $file) {
        $path = $theme_dir . '/assets/css/' . $file;
        if (file_exists($path)) {
            $css = file_get_contents($path);
            // Fix relative paths for fonts and images when inlined
            $css = str_replace('../fonts/', $theme_uri . '/assets/fonts/', $css);
            $css = str_replace('../images/', $theme_uri . '/assets/images/', $css);
            echo $css . "\n";
        }
    }
    
    echo "</style>\n";
}
add_action('wp_head', 'kdaccounts_inline_critical_css', 5);

/**
 * Defer any remaining non-critical stylesheets (like subscription.css or WP blocks)
 */
function kdaccounts_defer_styles($tag, $handle) {
    if (is_admin()) {
        return $tag;
    }
    
    // Do not defer WordPress core styles that are critical for logged-in users (like the Admin Bar)
    $exclude_handles = array('admin-bar', 'dashicons', 'wp-block-library');
    if (in_array($handle, $exclude_handles)) {
        return $tag;
    }

    return str_replace("rel='stylesheet'", "rel='stylesheet' media='print' onload=\"this.media='all'\"", $tag);
}
add_filter('style_loader_tag', 'kdaccounts_defer_styles', 10, 2);

/**
 * =========================================================================
 * Preload Critical Fonts & Add Preconnects
 * Fonts are the #1 cause of LCP delay when not preloaded.
 * Keep preconnects to max 2 — PageSpeed warns about too many.
 * =========================================================================
 */
function kd_add_resource_hints()
{
    $theme_uri = get_template_directory_uri();

    // Preload critical fonts — prevents FOUT and improves LCP
    echo '<link rel="preload" href="' . esc_url($theme_uri) . '/assets/fonts/cinzel.woff2" as="font" type="font/woff2" crossorigin="anonymous">' . "\n";
    echo '<link rel="preload" href="' . esc_url($theme_uri) . '/assets/fonts/inter.woff2" as="font" type="font/woff2" crossorigin="anonymous">' . "\n";
    echo '<link rel="preload" href="' . esc_url($theme_uri) . '/assets/fonts/montserrat.woff2" as="font" type="font/woff2" crossorigin="anonymous">' . "\n";

    // Preload LCP hero image — homepage
    if (is_front_page()) {
        echo '<link rel="preload" href="' . esc_url($theme_uri) . '/assets/images/hero-bg.webp" as="image" fetchpriority="high">' . "\n";
    }

    // Preload LCP image — sub-service & all inner pages
    // Uses generic check instead of slugs — works regardless of URL structure on Hostinger
    if (!is_front_page() && !is_home() && is_singular('page')) {
        echo '<link rel="preload" href="' . esc_url($theme_uri) . '/assets/images/sub-hero-bg.webp" as="image" fetchpriority="high">' . "\n";
    }

    // Only preconnect to KD Lead on contact/consultation pages (max 2 preconnects)
    if (is_page('contact') || is_page('consultation') || is_page('free-consultation')) {
        echo '<link rel="preconnect" href="https://link.kdlead.com" crossorigin>' . "\n";
    }
}
add_action('wp_head', 'kd_add_resource_hints', 1);

/**
 * =========================================================================
 * Add Dynamic SEO Meta Description Fallback
 * Fixes PageSpeed "Document does not have a meta description"
 * =========================================================================
 */
function kd_add_meta_description()
{
    // Don't output if an SEO plugin (like Yoast or RankMath) is already handling it
    if (defined('WPSEO_VERSION') || defined('RANK_MATH_VERSION'))
        return;

    $desc = get_bloginfo('description'); // Default fallback

    if (is_singular()) {
        global $post;
        $excerpt = strip_tags($post->post_excerpt);
        if (empty($excerpt)) {
            $excerpt = wp_trim_words(strip_shortcodes(strip_tags($post->post_content)), 25, '...');
        }
        if (!empty($excerpt)) {
            $desc = $excerpt;
        }
    }

    if (empty($desc)) {
        $desc = "Professional Accounting, Bookkeeping, and Tax Services in Buffalo, NY.";
    }

    echo '<meta name="description" content="' . esc_attr($desc) . '">' . "\n";
}
// Disabled 2026-08-21: Rank Math outputs the meta description; this duplicated it. 
// add_action('wp_head', 'kd_add_meta_description', 5);

/**
 * =========================================================================
 * Theme Setup
 * =========================================================================
 */
function kdaccounts_setup()
{
    // Add default posts and comments RSS feed links to head.
    add_theme_support('automatic-feed-links');

    // Let WordPress manage the document title.
    add_theme_support('title-tag');

    // Enable support for Post Thumbnails on posts and pages.
    add_theme_support('post-thumbnails');

    // Remove default WordPress resource hints (preconnects) to fix PageSpeed warnings
    remove_action('wp_head', 'wp_resource_hints', 2);

    // Register Menus
    register_nav_menus(
        array(
            'menu-1' => esc_html__('Primary', 'kdaccounts-theme'),
            'footer' => esc_html__('Footer Menu', 'kdaccounts-theme'),
        )
    );
}
add_action('after_setup_theme', 'kdaccounts_setup');

/**
 * Add Pricing Plans settings to WordPress Customizer for multiple services
 */
function kdaccounts_customize_register($wp_customize)
{
    $wp_customize->add_panel("pricing_plans_panel", array(
        "title" => __("Pricing Plans", "kdaccounts-theme"),
        "description" => __("Manage global pricing plans for all services", "kdaccounts-theme"),
        "priority" => 30,
    ));

    $services = [
        1 => "Bookkeeping Services",
        2 => "Accounting Services",
        3 => "Taxation Services",
        4 => "Business Formation"
    ];

    $tiers = [
        1 => "Bronze",
        2 => "Silver",
        3 => "Gold",
        4 => "Platinum"
    ];

    // Default prices from screenshots
    $default_prices = [
        1 => ["$150", "$250", "$400", "$600"],
        2 => ["$200", "$350", "$500", "$750"],
        3 => ["$250", "$400", "$700", "$1000"],
        4 => ["$300", "$500", "$800", "$1200"]
    ];

    foreach ($services as $s_id => $s_name) {
        $wp_customize->add_section("pricing_svc_{$s_id}", array(
            "title" => $s_name,
            "panel" => "pricing_plans_panel",
        ));

        foreach ($tiers as $t_id => $t_name) {
            // Price
            $wp_customize->add_setting("pricing_svc_{$s_id}_tier_{$t_id}_price", array(
                "default" => $default_prices[$s_id][$t_id - 1],
                "sanitize_callback" => "sanitize_text_field",
            ));
            $wp_customize->add_control("pricing_svc_{$s_id}_tier_{$t_id}_price", array(
                "label" => sprintf(__("%s Price", "kdaccounts-theme"), $t_name),
                "section" => "pricing_svc_{$s_id}",
                "type" => "text",
            ));

            // Desc
            $wp_customize->add_setting("pricing_svc_{$s_id}_tier_{$t_id}_desc", array(
                "default" => "Description for $t_name",
                "sanitize_callback" => "sanitize_textarea_field",
            ));
            $wp_customize->add_control("pricing_svc_{$s_id}_tier_{$t_id}_desc", array(
                "label" => sprintf(__("%s Features", "kdaccounts-theme"), $t_name),
                "section" => "pricing_svc_{$s_id}",
                "type" => "textarea",
            ));

            // Link
            $wp_customize->add_setting("pricing_svc_{$s_id}_tier_{$t_id}_link", array(
                "default" => "#",
                "sanitize_callback" => "esc_url_raw",
            ));
            $wp_customize->add_control("pricing_svc_{$s_id}_tier_{$t_id}_link", array(
                "label" => sprintf(__("%s Button Link", "kdaccounts-theme"), $t_name),
                "section" => "pricing_svc_{$s_id}",
                "type" => "url",
            ));
        }
    }
}
add_action("customize_register", "kdaccounts_customize_register");

/**
 * Limit blog page to 3 posts per page
 */
function kd_custom_blog_posts_per_page($query) {
    if ( !is_admin() && $query->is_main_query() && $query->is_home() ) {
        $query->set( 'posts_per_page', 3 );
    }
}
add_action( 'pre_get_posts', 'kd_custom_blog_posts_per_page' );

/**
 * Automatically generate and output a meta description for SEO
 */
function kdaccounts_add_meta_description() {
    $meta_desc = "";
    
    // For single posts or pages
    if ( is_singular() ) {
        global $post;
        
        // Use custom excerpt if available
        if ( has_excerpt($post->ID) ) {
            $meta_desc = strip_tags( get_the_excerpt() );
        } else {
            // Otherwise generate one from the content
            $meta_desc = strip_tags( $post->post_content );
            $meta_desc = strip_shortcodes( $meta_desc );
            $meta_desc = str_replace( array("\n", "\r", "\t"), ' ', $meta_desc );
            $meta_desc = substr( $meta_desc, 0, 155 );
        }
    } 
    
    // Fallback for everything else (homepage, archives, 404s, weird urls, etc.)
    if ( empty(trim($meta_desc)) ) {
        $meta_desc = get_bloginfo( 'description', 'display' );
        if ( empty($meta_desc) ) {
            $meta_desc = "KD Accounting & Tax offers professional tax and accounting services in Buffalo, NY.";
        }
    }
    
    // Always output a description
    echo '<meta name="description" content="' . esc_attr( trim($meta_desc) ) . '..." />' . "\n";
}
// Disabled 2026-08-21: Rank Math outputs the meta description; this duplicated it. 
// add_action( 'wp_head', 'kdaccounts_add_meta_description', 5 );


//
function custom_google_analytics() {
    ?>
    <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}

    window.addEventListener('load', function () {
        setTimeout(function () {

            var script = document.createElement('script');
            script.src = 'https://www.googletagmanager.com/gtag/js?id=G-4HC427T2Y9';
            script.async = true;

            script.onload = function () {
                gtag('js', new Date());
                gtag('config', 'G-4HC427T2Y9');
            };

            document.head.appendChild(script);

        }, 1500);
    });
    </script>
    <?php
}
add_action('wp_head', 'custom_google_analytics');


/* Blog listing: 9 posts per page */
function kda_blog_posts_per_page($query) {
    if (!is_admin() && $query->is_main_query() && $query->is_home()) {
        $query->set('posts_per_page', 9);
    }
}
add_action('pre_get_posts', 'kda_blog_posts_per_page');

/* Custom post types (podcast) */
require_once get_template_directory() . '/inc/custom-post-types.php';

/* Dedicated Bookkeeping Services page; replaces the former shared sections. */
add_filter('template_include', function ($template) {
    if (is_page('bookkeeping-services')) {
        return get_template_directory() . '/page-bookkeeping-services.php';
    }
    return $template;
}, 99);
function kd_bookkeeping_seo_title($title) {
    return is_page('bookkeeping-services') ? 'Bookkeeping Services in Buffalo, NY | KD Accounting & Tax' : $title;
}
function kd_bookkeeping_seo_description($description) {
    return is_page('bookkeeping-services') ? 'Monthly and catch-up bookkeeping for Buffalo and Erie County small businesses, with clear reports and sales tax-ready records. Call (716) 589-2665.' : $description;
}
add_filter('pre_get_document_title', 'kd_bookkeeping_seo_title', 99);
add_filter('rank_math/frontend/title', 'kd_bookkeeping_seo_title', 99);
add_filter('rank_math/frontend/description', 'kd_bookkeeping_seo_description', 99);
add_filter('wpseo_title', 'kd_bookkeeping_seo_title', 99);
add_filter('wpseo_metadesc', 'kd_bookkeeping_seo_description', 99);
add_action('wp_head', function () {
    if (is_page('bookkeeping-services') && !defined('RANK_MATH_VERSION') && !defined('WPSEO_VERSION')) {
        echo '<meta name="description" content="' . esc_attr(kd_bookkeeping_seo_description('')) . '">' . "\n";
    }
}, 5);
