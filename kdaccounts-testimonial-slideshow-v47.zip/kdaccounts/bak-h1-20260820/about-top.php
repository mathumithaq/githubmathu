<?php
/**
 * About Top Section
 */
?>
<section class="about-top-section">
    <div class="container about-top-grid">
        <!-- Left Side: Image and Experience Badge -->
        <div class="about-top-image-col">
            <span class="section-subtitle">VISION AND MISSION</span>
            <h1 class="about-top-title">WE WORK FOR REALIZE YOUR FINANCIAL GOALS IN BUFFALO, NY</h1>
            
            <div class="about-top-image-wrapper">
                <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/about-financial-goals.webp'); ?>" alt="Expert CPA Accountants" loading="lazy">
                
                <!-- 10 Years Experience Badge -->
                <div class="experience-badge">
                    <div class="badge-icon">
                        <?php echo file_get_contents(get_template_directory() . '/assets/icons/icon-badge.svg'); ?>
                    </div>
                    <span class="badge-text">10 years of industry experience</span>
                </div>
            </div>
        </div>
        
        <!-- Right Side: Content -->
        <div class="about-top-content-col">
            <p class="about-top-desc">As reputable CPA accountants in Buffalo, we are extremely committed to providing stress-free, ethical, and reliable financial solutions. All the services that we offer are informed by integrity, accuracy, and a sincere concern about your financial health. Whether it is minimizing tax liability or achieving full compliance, we aim to be clear, confident, and successful in the long term, so you can have true peace of mind as we take care of the numbers.</p>
            
            <div class="about-top-features">
                <!-- Mission -->
                <div class="about-top-feature-box">
                    <div class="feature-icon">
                        <?php echo file_get_contents(get_template_directory() . '/assets/icons/icon-target.svg'); ?>
                    </div>
                    <div class="feature-text">
                        <h3>Our Mission</h3>
                        <p>Our mission is simple: to deliver precise, compliant, and honest accounting and tax services that streamline your finances. We aim to reduce financial stress, improve tax efficiency, and provide personalized guidance that supports confident decision-making and sustainable economic growth.</p>
                    </div>
                </div>
                
                <!-- Vision -->
                <div class="about-top-feature-box">
                    <div class="feature-icon">
                        <?php echo file_get_contents(get_template_directory() . '/assets/icons/icon-vision.svg'); ?>
                    </div>
                    <div class="feature-text">
                        <h3>Our Vision</h3>
                        <p>KD Accounting & Tax has the vision to be the most trusted financial partner in Buffalo, providing ethical service, personalized guidance, and long-term relationships. We want to develop a future that will guarantee that all clients have financial clarity, high compliance, and the ability to grow with strategic financial planning, of course, with transparency as our base.</p>
                    </div>
                </div>
            </div>
            
            <a href="<?php echo esc_url(home_url('/about')); ?>" class="btn btn-primary btn-about-top">More About Us</a>
                <?php get_template_part('partials/call-us', null, array('inline' => true)); ?>
        </div>
        
    </div>

</section>
