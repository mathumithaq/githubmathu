<?php
/**
 * "Call Us" strip — reusable phone CTA appended to sections.
 */
$kda_callus_inline = ! empty( $args['inline'] );
?>
<div class="kda-callus<?php echo $kda_callus_inline ? ' kda-callus--inline' : ''; ?>">
    <a href="tel:+17165892665">
        <span class="kda-callus-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg></span>
        Call Us <strong>716-589-2665</strong>
    </a>
</div>
