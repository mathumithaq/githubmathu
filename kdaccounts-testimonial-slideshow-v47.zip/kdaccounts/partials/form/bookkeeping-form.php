<?php
/**
 * Compact consultation form used in hero sections (homepage + inner pages).
 * Posts to the LeadConnector inbound webhook. IDs are unique (kdah-*) so the
 * partial can coexist with the contact-section form on the same page.
 * Include at most once per page.
 */
?>
<div class="kda-form-card kda-form-card--hero">
    <h3 class="kda-form-title">Request a Free Consultation</h3>
    <p class="kda-form-sub">We&rsquo;ll get back to you within one business day.</p>

    <form class="kda-form" id="kdaHeroForm" novalidate>
        <div class="kda-form-row">
            <div class="kda-field">
                <label for="kdah-name">Your Name <span aria-hidden="true">*</span></label>
                <input type="text" id="kdah-name" name="fullName" required autocomplete="name" placeholder="e.g., John Smith">
            </div>
            <div class="kda-field">
                <label for="kdah-phone">Phone <span aria-hidden="true">*</span></label>
                <input type="tel" id="kdah-phone" name="phone" required autocomplete="tel" placeholder="Your phone number">
            </div>
        </div>

        <div class="kda-form-row">
            <div class="kda-field">
                <label for="kdah-email">Email</label>
                <input type="email" id="kdah-email" name="email" autocomplete="email" placeholder="Your email">
            </div>
            <div class="kda-field">
                <label for="kdah-service">Service <span aria-hidden="true">*</span></label>
                <select id="kdah-service" name="service">
                    <option>Accounting Services</option>
                    <option>Tax Services</option>
                    <option>Bookkeeping Services</option>
                    <option>Tax Planning</option>
                    <option>Payroll Management</option>
                    <option>Business Registration &amp; Compliance</option>
                    <option>Other</option>
                </select>
            </div>
        </div>

        <div class="kda-consent">
            <details class="kda-consent-acc">
                <summary>
                    <input type="checkbox" id="kdahMarketingConsent" required>
                    <span>I consent to receive <strong>marketing</strong> text messages<em aria-hidden="true">*</em></span>
                    <span class="kda-pm" aria-hidden="true">+</span>
                </summary>
                <div class="kda-consent-terms">By checking this box, I consent to receive marketing text messages from KD Accounting &amp; Tax at the phone number provided. Frequency may vary. Message &amp; data rates may apply. Text HELP for assistance, reply STOP to opt out.</div>
            </details>
            <details class="kda-consent-acc">
                <summary>
                    <input type="checkbox" id="kdahTransactionalConsent" required>
                    <span>I consent to receive <strong>non-marketing</strong> text messages<em aria-hidden="true">*</em></span>
                    <span class="kda-pm" aria-hidden="true">+</span>
                </summary>
                <div class="kda-consent-terms">By checking this box, I consent to receive non-marketing text messages from KD Accounting &amp; Tax about my appointment reminders, document requests, filing updates etc. Message &amp; data rates may apply.</div>
            </details>
        </div>

        <button class="btn kda-form-submit" type="submit">
            <span class="kda-btn-label">Send Message</span>
            <span class="kda-btn-arr" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M7 17L17 7"></path><path d="M9 7h8v8"></path></svg></span>
        </button>

        <p class="kda-form-note" id="kdahFormStatus" role="status" aria-live="polite">We typically respond within one business day. For urgent matters, call (716)&nbsp;589-2665.</p>
    </form>
</div>

<script>
(function () {
    var form = document.getElementById('kdaHeroForm');
    if (!form) return;

    form.querySelectorAll('.kda-consent-acc summary input[type="checkbox"]').forEach(function (cb) {
        cb.addEventListener('click', function (e) { e.stopPropagation(); });
    });

    form.addEventListener('submit', function (e) {
        e.preventDefault();
        if (!form.reportValidity()) return;

        var btn = form.querySelector('button[type="submit"]');
        var status = document.getElementById('kdahFormStatus');
        btn.disabled = true;
        status.className = 'kda-form-note';
        status.innerText = 'Sending your request…';

        var formData = {
            formId: 'kdaccounts_hero_form_01',
            formName: 'KD Accounting & Tax Hero Form',
            submissionId: 'SUB-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9),
            timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
            page: window.location.pathname,

            fullName: document.getElementById('kdah-name').value,
            email: document.getElementById('kdah-email').value,
            phone: document.getElementById('kdah-phone').value,
            serviceInterestedIn: document.getElementById('kdah-service').value,
            companyName: '',
            message: '',

            marketingConsentAccepted: document.getElementById('kdahMarketingConsent').checked,
            transactionalConsentAccepted: document.getElementById('kdahTransactionalConsent').checked
        };

        fetch('https://services.leadconnectorhq.com/hooks/ZUOyKmPSpPwKe3Z23Ngw/webhook-trigger/3864993d-1e21-4edd-aa23-bad900687858', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(formData)
        })
        .then(function (response) {
            if (response.ok) {
                form.reset();
                status.classList.add('is-success');
                status.innerText = 'Thank you! Your request has been sent — we’ll be in touch shortly.';
            } else {
                status.classList.add('is-error');
                status.innerText = 'Something went wrong sending your request. Please call us at (716) 589-2665.';
            }
            btn.disabled = false;
        })
        .catch(function () {
            status.classList.add('is-error');
            status.innerText = 'Network error — please try again or call (716) 589-2665.';
            btn.disabled = false;
        });
    });
})();
</script>
