<?php
/**
 * Native contact form -> LeadConnector inbound webhook.
 * Mirrors the pattern implemented on naturewisetreecare.com.
 * Previous GHL iframe embed backed up in form.php.bak-20260819.
 */
?>
<div class="kda-form-card">
    <span class="kda-form-eyebrow">Free Consultation</span>
    <h3 class="kda-form-title">Request a Free Consultation</h3>
    <p class="kda-form-sub">Tell us a little about what you need &mdash; we&rsquo;ll get back to you within one business day.</p>

    <form class="kda-form" id="kdaContactForm" novalidate>

        <div class="kda-form-row">
            <div class="kda-field">
                <label for="kda-name">Your Name <span aria-hidden="true">*</span></label>
                <input type="text" id="kda-name" name="fullName" required autocomplete="name" placeholder="e.g., John Smith">
            </div>
            <div class="kda-field">
                <label for="kda-email">Email</label>
                <input type="email" id="kda-email" name="email" autocomplete="email" placeholder="name@example.com">
            </div>
        </div>

        <div class="kda-form-row">
            <div class="kda-field">
                <label for="kda-phone">Phone <span aria-hidden="true">*</span></label>
                <input type="tel" id="kda-phone" name="phone" required autocomplete="tel" placeholder="Your phone number">
            </div>
            <div class="kda-field">
                <label for="kda-service">Service Interested In <span aria-hidden="true">*</span></label>
                <select id="kda-service" name="service">
                    <option>Accounting Services</option>
                    <option>Tax Services</option>
                    <option>Bookkeeping Services</option>
                    <option>Tax Planning</option>
                    <option>Payroll Management</option>
                    <option>Business Registration &amp; Compliance</option>
                    <option>Other</option>
                </select>
            </div>
        </div>

        <div class="kda-field">
            <label for="kda-company">Business / Company Name</label>
            <input type="text" id="kda-company" name="companyName" autocomplete="organization" placeholder="Optional &mdash; if this is for your business">
        </div>

        <div class="kda-field">
            <label for="kda-message">Your Message</label>
            <textarea id="kda-message" name="message" rows="4" placeholder="e.g., Need help with quarterly filings and bookkeeping&hellip;"></textarea>
        </div>

        <div class="kda-consent">
            <details class="kda-consent-acc">
                <summary>
                    <input type="checkbox" id="kdaMarketingConsent" required>
                    <span>I consent to receive <strong>marketing</strong> text messages<em aria-hidden="true">*</em></span>
                    <span class="kda-pm" aria-hidden="true">+</span>
                </summary>
                <div class="kda-consent-terms">By checking this box, I consent to receive marketing text messages from KD Accounting &amp; Tax at the phone number provided. Frequency may vary. Message &amp; data rates may apply. Text HELP for assistance, reply STOP to opt out.</div>
            </details>
            <details class="kda-consent-acc">
                <summary>
                    <input type="checkbox" id="kdaTransactionalConsent" required>
                    <span>I consent to receive <strong>non-marketing</strong> text messages<em aria-hidden="true">*</em></span>
                    <span class="kda-pm" aria-hidden="true">+</span>
                </summary>
                <div class="kda-consent-terms">By checking this box, I consent to receive non-marketing text messages from KD Accounting &amp; Tax about my appointment reminders, document requests, filing updates etc. Message &amp; data rates may apply.</div>
            </details>
        </div>

        <button class="btn kda-form-submit" type="submit">
            <span class="kda-btn-label">Send Message</span>
            <span class="kda-btn-arr" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M7 17L17 7"></path><path d="M9 7h8v8"></path></svg></span>
        </button>

        <p class="kda-form-note" id="kdaFormStatus" role="status" aria-live="polite">We typically respond within one business day. For urgent matters, please call (716)&nbsp;589-2665.</p>
    </form>
</div>

<script>
(function () {
    var form = document.getElementById('kdaContactForm');
    if (!form) return;

    // Keep checkbox clicks from toggling the accordion
    form.querySelectorAll('.kda-consent-acc summary input[type="checkbox"]').forEach(function (cb) {
        cb.addEventListener('click', function (e) { e.stopPropagation(); });
    });

    form.addEventListener('submit', function (e) {
        e.preventDefault();

        if (!form.reportValidity()) return;

        var btn = form.querySelector('button[type="submit"]');
        var status = document.getElementById('kdaFormStatus');
        btn.disabled = true;
        status.className = 'kda-form-note';
        status.innerText = 'Sending your request…';

        var submissionId = 'SUB-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9);

        var formData = {
            // Tracking details
            formId: 'kdaccounts_contact_form_01',
            formName: 'KD Accounting & Tax Main Website Form',
            submissionId: submissionId,
            timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,

            // Contact fields
            fullName: document.getElementById('kda-name').value,
            email: document.getElementById('kda-email').value,
            phone: document.getElementById('kda-phone').value,
            serviceInterestedIn: document.getElementById('kda-service').value,
            companyName: document.getElementById('kda-company').value,
            message: document.getElementById('kda-message').value,

            // Consent fields (true/false)
            marketingConsentAccepted: document.getElementById('kdaMarketingConsent').checked,
            transactionalConsentAccepted: document.getElementById('kdaTransactionalConsent').checked
        };

        fetch('https://services.leadconnectorhq.com/hooks/ZUOyKmPSpPwKe3Z23Ngw/webhook-trigger/3864993d-1e21-4edd-aa23-bad900687858', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(formData)
        })
        .then(function (response) {
            if (response.ok) {
                form.reset();
                status.classList.add('is-success');
                status.innerText = 'Thank you! Your request has been sent — we’ll be in touch shortly.';
            } else {
                status.classList.add('is-error');
                status.innerText = 'Something went wrong sending your request. Please call us at (716) 589-2665.';
            }
            btn.disabled = false;
        })
        .catch(function () {
            status.classList.add('is-error');
            status.innerText = 'Network error — please try again or call (716) 589-2665.';
            btn.disabled = false;
        });
    });
})();
</script>
