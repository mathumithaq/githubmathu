<?php
/**
 * Blog listing — 9 posts per page (see kda_blog_posts_per_page in functions.php)
 * with a sidebar of categories and authors.
 */

get_header(); ?>

<main id="primary" class="site-main">

    <!-- Blog Hero Section -->
    <?php get_template_part('template-parts/sub-services/sub-hero'); ?>

    <!-- Blog Listing Section -->
    <section class="blog-listing-section">
        <div class="container kda-blog-layout">

            <div class="kda-blog-main">
                <?php if ( have_posts() ) : ?>
                    <div class="blog-listing-grid">
                        <?php while ( have_posts() ) : the_post(); ?>
                            <article id="post-<?php the_ID(); ?>" <?php post_class('blog-card'); ?>>

                                <div class="blog-card-image">
                                    <?php $kda_cats = get_the_category(); if ( ! empty( $kda_cats ) ) : ?><a class="blog-card-cat" href="<?php echo esc_url( get_category_link( $kda_cats[0] ) ); ?>"><?php echo esc_html( $kda_cats[0]->name ); ?></a><?php endif; ?>
                                    <?php if ( has_post_thumbnail() ) : ?>
                                        <a href="<?php the_permalink(); ?>" aria-label="<?php echo esc_attr( 'Read more about ' . get_the_title() ); ?>">
                                            <?php the_post_thumbnail('medium_large'); ?>
                                        </a>
                                    <?php else : ?>
                                        <a href="<?php the_permalink(); ?>" class="blog-placeholder-img" aria-label="<?php echo esc_attr( 'Read more about ' . get_the_title() ); ?>">
                                            <!-- Fallback color block -->
                                        </a>
                                    <?php endif; ?>
                                </div>

                                <div class="blog-card-content">
                                    <div class="blog-card-meta">
                                        <span class="blog-date">
                                            <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/calendar.svg" alt="Date" width="16" height="16">
                                            <?php echo get_the_date(); ?>
                                        </span>
                                        <span class="blog-author">
                                            <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/user.svg" alt="Author" width="16" height="16">
                                            <a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta('ID') ) ); ?>"><?php the_author(); ?></a>
                                        </span>
                                    </div>

                                    <h2 class="blog-card-title">
                                        <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                    </h2>

                                    <p class="blog-card-excerpt"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 20, '&hellip;' ) ); ?></p>
                                <a href="<?php the_permalink(); ?>" class="blog-card-link">Read Article <span aria-hidden="true">&rarr;</span></a>
                                </div>

                            </article>
                        <?php endwhile; ?>
                    </div>

                    <div class="blog-pagination">
                        <?php
                            the_posts_pagination( array(
                                'mid_size'  => 2,
                                'prev_text' => __( 'Previous', 'kdaccounts-theme' ),
                                'next_text' => __( 'Next', 'kdaccounts-theme' ),
                                'screen_reader_text' => ' ',
                            ) );
                        ?>
                    </div>

                <?php else : ?>
                    <div class="no-posts-found">
                        <p><?php esc_html_e( 'Sorry, no posts matched your criteria.', 'kdaccounts-theme' ); ?></p>
                    </div>
                <?php endif; ?>
            </div>

            <aside class="kda-blog-sidebar">

                <div class="kda-widget">
                    <h3 class="kda-widget-title">Categories</h3>
                    <ul class="kda-widget-list">
                        <?php
                        wp_list_categories( array(
                            'title_li'   => '',
                            'show_count' => true,
                            'hide_empty' => true,
                        ) );
                        ?>
                    </ul>
                </div>

                <div class="kda-widget">
                    <h3 class="kda-widget-title">Authors</h3>
                    <ul class="kda-widget-list kda-author-list">
                        <?php
                        $kda_authors = get_users( array( 'has_published_posts' => array('post') ) );
                        foreach ( $kda_authors as $kda_author ) :
                            $kda_count = count_user_posts( $kda_author->ID, 'post', true );
                        ?>
                            <li>
                                <a href="<?php echo esc_url( get_author_posts_url( $kda_author->ID ) ); ?>">
                                    <span class="kda-author-initial" aria-hidden="true"><?php echo esc_html( strtoupper( mb_substr( $kda_author->display_name, 0, 1 ) ) ); ?></span>
                                    <?php echo esc_html( $kda_author->display_name ); ?>
                                    <span class="kda-widget-count">(<?php echo intval( $kda_count ); ?>)</span>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>

                <div class="kda-widget kda-widget-cta">
                    <h3 class="kda-widget-title">Need Help Now?</h3>
                    <p>Talk to a certified accountant about your taxes or books.</p>
                    <a class="btn" href="<?php echo esc_url( home_url('/contact/') ); ?>">Free Consultation</a>
                    <?php get_template_part('partials/call-us'); ?>
                </div>

            </aside>

        </div>
    </section>

</main>

<?php get_footer(); ?>
