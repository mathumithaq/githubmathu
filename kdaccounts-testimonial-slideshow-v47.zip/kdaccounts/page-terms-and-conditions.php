<?php
/*
Template Name: Terms & Conditions
*/

get_header();

// Setup variables for inner-hero to keep consistency with other pages
$hero_title = "Terms & Conditions";
$hero_breadcrumb = "Terms & Conditions";
// Using the same hero background used in sub-services as fallback
$bg_image_url = get_template_directory_uri() . '/assets/images/inner-hero-bg.jpg'; 
if (!file_exists(get_template_directory() . '/assets/images/inner-hero-bg.jpg')) {
    $bg_image_url = get_template_directory_uri() . '/assets/images/services-hero-bg.jpg';
}

include get_template_directory() . '/template-parts/sections/inner-hero.php';
?>

<section class="legal-content-section">
    <div class="container legal-content-container">
        
        <p><strong>Effective Date: January 12, 2026</strong></p>
        <p>Welcome to kdaccounts.com. These Terms & Conditions (“Terms”) govern your access to and use of the website kdaccounts.com (the “Website”), operated by kdaccounts.com (“we,” “us,” or “our”).</p>
        <p>By accessing or using the Website, you signify that you have read, understood, and agree to be bound by these Terms, including any future modifications. If you do not agree to these Terms, you may not access or use the Website.</p>

        <h3>1. Acceptance of Terms</h3>
        <p>By using our Website, you confirm that you accept these Terms and that you agree to comply with them. If you do not agree to these Terms, you must not use our Website. We recommend that you print a copy of these Terms for future reference.</p>

        <h3>2. Access and Use of the Website</h3>
        <p>kdaccounts.com grants you a limited, non-exclusive, non-transferable, and revocable license to access and use the Website for your personal, non-commercial use, strictly in accordance with these Terms. You agree not to use the Website for any unlawful purpose or in any way that might harm, disable, overburden, or impair the Website.</p>

        <h3>3. Minimum Age Requirement</h3>
        <p>The Website is not intended for individuals under the age of 13. By accessing or using the Website, you represent and warrant that you are at least 13 years of age. If you are under 13, you are not permitted to use this Website.</p>

        <h3>4. Intellectual Property Rights</h3>
        <p>All content, features, and functionality on the Website, including but not limited to text, graphics, logos, images, and their arrangement, are owned by kdaccounts.com or its licensors and are protected by United States and international copyright, trademark, patent, trade secret, and other intellectual property or proprietary rights laws.</p>
        <p>You may not reproduce, distribute, modify, create derivative works of, publicly display, publicly perform, republish, download, store, or transmit any of the material on our Website, except as generally permitted by the Website’s functionality for personal, non-commercial use.</p>

        <h3>5. User Conduct</h3>
        <p>You agree to use the Website only for lawful purposes and in a way that does not infringe the rights of, restrict, or inhibit anyone else’s use and enjoyment of the Website. Prohibited behavior includes harassing or causing distress or inconvenience to any other user, transmitting obscene or offensive content, or disrupting the normal flow of dialogue within the Website.</p>

        <h3>6. Data Collection and Cookies</h3>
        <p>kdaccounts.com is committed to protecting your privacy. We want to be transparent about what data we do and do not collect:</p>
        <ul>
            <li><strong>No Personal Data:</strong> kdaccounts.com does not collect any personal data from you, such as your name, email address, physical address, or phone number.</li>
            <li><strong>No Device Data:</strong> kdaccounts.com does not collect device-specific data, such as IP addresses or unique device identifiers.</li>
            <li><strong>No Payment Information:</strong> kdaccounts.com does not collect any payment information.</li>
            <li><strong>Cookies/Tracking:</strong> We do use cookies and similar tracking technologies to enhance your experience on kdaccounts.com. These cookies are used for purposes such as:
                <ul>
                    <li><strong>Website Functionality:</strong> To ensure the Website operates correctly.</li>
                    <li><strong>Analytics:</strong> To understand how our Website is used (e.g., which pages are most popular, how long users spend on the site) and to improve its performance and user experience.</li>
                    <li><strong>Preferences:</strong> To remember your site preferences.</li>
                </ul>
                <p>The data collected through these cookies is aggregated and anonymous, meaning it cannot be used to identify you personally. It is used solely to improve the Website’s performance and user experience.</p>
            </li>
            <li><strong>No Third-Party Services:</strong> kdaccounts.com does not integrate or use any third-party services that would collect data from your use of our Website.</li>
        </ul>
        <p>You have the option to accept or decline cookies. Most web browsers automatically accept cookies, but you can usually modify your browser setting to decline cookies if you prefer. Please note that disabling cookies may affect the functionality of kdaccounts.com.</p>

        <h3>7. Disclaimers (No Warranties)</h3>
        <p class="legal-disclaimer">THE WEBSITE IS PROVIDED ON AN “AS IS” AND “AS AVAILABLE” BASIS, WITHOUT ANY WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED. TO THE FULLEST EXTENT PERMISSIBLE PURSUANT TO APPLICABLE LAW, KDACCOUNTS.COM DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT.</p>
        <p class="legal-disclaimer">KDACCOUNTS.COM DOES NOT WARRANT THAT THE WEBSITE WILL BE UNINTERRUPTED, SECURE, OR ERROR-FREE, THAT DEFECTS WILL BE CORRECTED, OR THAT THE WEBSITE OR THE SERVER THAT MAKES IT AVAILABLE ARE FREE OF VIRUSES OR OTHER HARMFUL COMPONENTS. KDACCOUNTS.COM DOES NOT WARRANT OR MAKE ANY REPRESENTATIONS REGARDING THE USE OR THE RESULTS OF THE USE OF THE CONTENT ON THE WEBSITE IN TERMS OF THEIR CORRECTNESS, ACCURACY, RELIABILITY, OR OTHERWISE.</p>

        <h3>8. Limitation of Liability</h3>
        <p class="legal-disclaimer">IN NO EVENT SHALL KDACCOUNTS.COM, ITS AFFILIATES, LICENSORS, SERVICE PROVIDERS, EMPLOYEES, AGENTS, OFFICERS, OR DIRECTORS BE LIABLE FOR DAMAGES OF ANY KIND, UNDER ANY LEGAL THEORY, ARISING OUT OF OR IN CONNECTION WITH YOUR USE, OR INABILITY TO USE, THE WEBSITE, ANY WEBSITES LINKED TO IT, ANY CONTENT ON THE WEBSITE OR SUCH OTHER WEBSITES, INCLUDING ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL, CONSEQUENTIAL, OR PUNITIVE DAMAGES, INCLUDING BUT NOT LIMITED TO, PERSONAL INJURY, PAIN AND SUFFERING, EMOTIONAL DISTRESS, LOSS OF REVENUE, LOSS OF PROFITS, LOSS OF BUSINESS OR ANTICIPATED SAVINGS, LOSS OF USE, LOSS OF GOODWILL, LOSS OF DATA, AND WHETHER CAUSED BY TORT (INCLUDING NEGLIGENCE), BREACH OF CONTRACT, OR OTHERWISE, EVEN IF FORESEEABLE.</p>
        <p class="legal-disclaimer">THE FOREGOING DOES NOT AFFECT ANY LIABILITY WHICH CANNOT BE EXCLUDED OR LIMITED UNDER APPLICABLE LAW.</p>

        <h3>9. Indemnification</h3>
        <p>You agree to defend, indemnify, and hold harmless kdaccounts.com, its affiliates, licensors, and service providers, and its and their respective officers, directors, employees, contractors, agents, licensors, suppliers, successors, and assigns from and against any claims, liabilities, damages, judgments, awards, losses, costs, expenses, or fees (including reasonable attorneys’ fees) arising out of or relating to your violation of these Terms or your use of the Website, including, but not limited to, any use of the Website’s content, services, and products other than as expressly authorized in these Terms.</p>

        <h3>10. Termination</h3>
        <p>We may terminate or suspend your access to all or part of the Website, without prior notice or liability, for any reason whatsoever, including without limitation if you breach these Terms. All provisions of these Terms which by their nature should survive termination shall survive termination, including, without limitation, ownership provisions, warranty disclaimers, indemnity, and limitations of liability.</p>

        <h3>11. Governing Law and Jurisdiction</h3>
        <p>These Terms and your use of the Website shall be governed by and construed in accordance with the laws of the United States, without regard to its conflict of law provisions.</p>
        <p>Any legal suit, action, or proceeding arising out of, or related to, these Terms or the Website shall be instituted exclusively in the federal or state courts located in the United States, although we retain the right to bring any suit, action, or proceeding against you for breach of these Terms in your country of residence or any other relevant country. You waive any and all objections to the exercise of jurisdiction over you by such courts and to venue in such courts.</p>

        <h3>12. Changes to These Terms</h3>
        <p>We reserve the right, at our sole discretion, to modify or replace these Terms at any time. If a revision is material, we will make reasonable efforts to provide at least 30 days’ notice prior to any new terms taking effect. What constitutes a material change will be determined at our sole discretion.</p>
        <p>By continuing to access or use our Website after those revisions become effective, you agree to be bound by the revised terms. If you do not agree to the new terms, in whole or in part, please stop using the Website.</p>

        <h3>13. Severability</h3>
        <p>If any provision of these Terms is held by a court or other tribunal of competent jurisdiction to be invalid, illegal, or unenforceable for any reason, such provision shall be eliminated or limited to the minimum extent such that the remaining provisions of the Terms will continue in full force and effect.</p>

        <h3>14. Entire Agreement</h3>
        <p>These Terms constitute the sole and entire agreement between you and kdaccounts.com regarding the Website and supersede all prior and contemporaneous understandings, agreements, representations, and warranties, both written and oral, regarding the Website.</p>

        <h3>15. Contact Information</h3>
        <p>To ask questions or comment about these Terms, please contact us at:</p>
        <p>
            <strong>Email:</strong> <a href="mailto:sales@kdaccounts.com">sales@kdaccounts.com</a><br>
            <strong>Website:</strong> <a href="https://kdaccounts.com">kdaccounts.com</a>
        </p>
    </div>
</section>

<?php
get_footer();
