<?php
/**
 * Template Name: Pricing Plan
 *
 * Pricing page — shows the same monthly plan comparison + add-on services
 * table as the homepage (template-parts/sections/pricing-comparison.php).
 * Previous per-service tier cards: page-pricing.php.bak-20260821.
 */

get_header(); ?>

<main id="primary" class="site-main">
    <?php get_template_part( 'template-parts/sub-services/sub-hero' ); ?>
    <?php get_template_part( 'template-parts/sections/pricing-comparison' ); ?>
    <?php get_template_part( 'template-parts/sections/faq' ); ?>
</main>

<?php get_footer(); ?>
