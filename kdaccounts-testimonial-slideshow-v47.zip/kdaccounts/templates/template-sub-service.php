<?php
/**
 * Template Name: Sub Service
 * 
 * Custom template for the Sub Service page.
 */

get_header(); ?>

<main id="primary" class="site-main">

    <?php get_template_part( 'template-parts/sub-services/sub-hero' ); ?>
    
    <?php get_template_part( 'template-parts/sub-services/sub-content' ); ?>
    
    <?php get_template_part( 'template-parts/sub-services/sub-offerings' ); ?>
    
    <?php get_template_part( 'template-parts/sub-services/sub-why-choose' ); ?>
    
    <?php 
        global $post;
        $slug = $post->post_name;
        $service_id = get_post_meta($post->ID, 'pricing_service_id', true);
        
        // Auto-detect based on common slugs if custom field is not set
        if (empty($service_id)) {
            if (strpos($slug, 'bookkeeping') !== false) {
                $service_id = 1;
            } elseif (strpos($slug, 'accounting') !== false) {
                $service_id = 2;
            } elseif (strpos($slug, 'taxatation') !== false) {
                $service_id = 3;
            } elseif (strpos($slug, 'business') !== false) {
                $service_id = 4;
            }
        }
        
        get_template_part( 'template-parts/sub-services/sub-pricing', null, [
            'service_id' => $service_id
        ]); 
    ?>
    
    <?php get_template_part( 'template-parts/sub-services/sub-cta' ); ?>
</main>

<?php get_footer(); ?>
