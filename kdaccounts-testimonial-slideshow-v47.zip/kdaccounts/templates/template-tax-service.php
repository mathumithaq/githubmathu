<?php
/**
 * Template Name: Tax Service
 * 
 * Custom dynamic template for the Tax Services pages.
 */

get_header(); 

// Dynamic Data Store based on the page slug
global $post;
$slug = $post->post_name;

// Per-page overrides for tax-related slugs. Titles here will be used when the
// page slug matches the array key. Hero titles are rendered as H1 in the
// tax templates so these appear as the primary page heading.
$tax_data = [
    'tax-planning-services' => [
        'hero' => [
            'subtitle' => 'TAX PLANNING',
            'title' => 'Expert Tax Planning Services in Buffalo, NY',
            'description' => 'Want to minimize your tax liability and maximize your refunds? Our personalized tax planning strategies help reduce your tax burdens and save you money. We offer comprehensive tax planning services, including:',
            'list' => [],
            'button_text' => 'SCHEDULE A CONSULTATION',
            'button_link' => '#',
            'image' => get_template_directory_uri() . '/assets/images/service-tax-planning.webp'
        ]
    ],
    'tax-preparation' => [
        'hero' => [
            'subtitle' => 'TAX PREPARATION',
            'title' => 'Reliable and Stress-Free Tax Preparation Services in Buffalo, NY',
            'description' => 'Navigating your tax return doesn\'t have to be a daunting task. Our team of experts in Buffalo, NY, provides comprehensive tax preparation and filing services to ensure your tax return is accurate and stress-free.',
            'list' => [],
            'button_text' => 'SCHEDULE A CONSULTATION',
            'button_link' => '#',
            'image' => get_template_directory_uri() . '/assets/images/service-tax.webp'
        ],
        'overview' => [
            'subtitle' => 'SMALL BUSINESS SPECIALISTS',
            'title' => 'SIMPLIFIED AND AFFORDABLE TAX PREP FOR SMALL BUSINESSES IN BUFFALO, NY',
            'description' => 'Owners of small businesses require not just filing but also advice to help them grow and comply. Our tax accountant in Buffalo, NY, offers specialized tax services for individuals, entrepreneurs, and small businesses, ensuring you receive maximum returns with no errors.',
            'image' => get_template_directory_uri() . '/assets/images/tax-overview.webp'
        ]
    ],
    'default' => [
        'hero' => [
            'subtitle' => 'THE STRATEGIC APPROACH',
            'title' => 'EXPERIENCE THE STRATEGIC TAX PREPARER IN BUFFALO, NY',
            'description' => 'By choosing us, the most trusted tax preparation service in Buffalo, NY, you get to work with dedicated professionals. KD Accounting and Tax\'s tax planning strategy is designed to secure your income, minimise long-term liability, and support smarter financial decisions year-round, not just during tax time.',
            'list' => [
                'Individualized tax structure according to your intentions and revenues.',
                'Planning of strategies to reduce liability and credit deduction.',
                'Timing and income tax strategies to optimize tax use.',
                'Taxation of business for long-term savings.',
                'Tax planning for retirement and investment.',
                'Planning throughout the year to prevent surprises and errors.'
            ],
            'button_text' => 'SCHEDULE A CONSULTATION',
            'button_link' => '#',
            'image' => get_template_directory_uri() . '/assets/images/tax-hero.webp'
        ],
        'overview' => [
            'subtitle' => 'SMALL BUSINESS SPECIALISTS',
            'title' => 'SIMPLIFIED AND AFFORDABLE TAX PREP FOR SMALL BUSINESSES IN BUFFALO, NY',
            'description' => 'Owners of small businesses require not just filing but also advice to help them grow and comply. Our tax accountant in Buffalo, NY, offers specialized tax services for individuals, entrepreneurs, and small businesses, ensuring you receive maximum returns with no errors. We also handle business and personal tax returns, prepare Schedule C filings, and review bookkeeping records to mitigate audit risk. Our professionals also help establish effective bookkeeping systems that enhance cash flow tracking and the accuracy of report preparation. Our proactive tax planning and reporting will help reduce liabilities and keep your business financially thriving throughout the year.',
            'image' => get_template_directory_uri() . '/assets/images/tax-overview.webp'
        ],
        'core_services' => [
            'subtitle' => 'CORE SERVICES',
            'title' => 'BUFFALO TAX PREPARATION SOLUTIONS UNDER ONE TRUSTED ROOF',
            'cards' => [
                [
                    'number' => '01',
                    'title' => 'TAX PREPARATION',
                    'description' => 'We prepare and file personal, corporate, partnership, and LLC tax returns, W-2s, 1099s, and Schedule C returns, ensuring accuracy, compliance, and the maximum allowable deductions.',
                    'link' => home_url('/tax-preparation/')
                ],
                [
                    'number' => '02',
                    'title' => 'TAX PLANNING',
                    'description' => 'Our tax planning includes deduction planning, income timing, retirement tax planning, quarterly tax planning, and year-round planning to minimize liabilities and avoid unwanted tax penalties.',
                    'link' => home_url('/tax-planning-services/')
                ],
                [
                    'number' => '03',
                    'title' => 'BUSINESS TAX SERVICES',
                    'description' => 'We help maximize corporate and partnership returns, provide bookkeeping reviews, develop optimization plans, reduce audit risk, and provide ongoing advisory services to enhance long-term compliance and profitability.',
                    'link' => home_url('/business-tax-services/')
                ]
            ]
        ]
    ]
];

// Future pages like 'tax-planning-services' can be added to the array above overriding the default values.
// First, determine base fallback data
$base_data = isset($tax_data[$slug]) ? $tax_data[$slug] : $tax_data['default'];

// Helper function to get data from ACF or Native WP Custom Fields
if (!function_exists('kd_get_dynamic_field')) {
    function kd_get_dynamic_field($key) {
        global $post;
        $post_id = $post ? $post->ID : null;
        
        // 1. Try ACF if active
        if (function_exists('get_field')) {
            $val = get_field($key, $post_id);
            if (!empty($val)) return $val;
        }
        
        // 2. Try Native WP Custom Fields
        if ($post_id) {
            $val = get_post_meta($post_id, $key, true);
            if (!empty($val)) return $val;
        }
        
        return null;
    }
}

// Now merge dynamic content if it exists
$page_data = [
    'hero' => [
        'subtitle'    => kd_get_dynamic_field('hero_subtitle') ?: $base_data['hero']['subtitle'],
        'title'       => kd_get_dynamic_field('hero_title') ?: $base_data['hero']['title'],
        'description' => kd_get_dynamic_field('hero_description') ?: $base_data['hero']['description'],
        'list'        => [],
        'button_text' => kd_get_dynamic_field('hero_button_text') ?: $base_data['hero']['button_text'],
        'button_link' => kd_get_dynamic_field('hero_button_link') ?: $base_data['hero']['button_link'],
        'image'       => kd_get_dynamic_field('hero_image') ?: $base_data['hero']['image'],
    ],
    'overview' => [
        'subtitle'    => kd_get_dynamic_field('overview_subtitle') ?: $base_data['overview']['subtitle'],
        'title'       => kd_get_dynamic_field('overview_title') ?: $base_data['overview']['title'],
        'description' => kd_get_dynamic_field('overview_description') ?: $base_data['overview']['description'],
        'image'       => kd_get_dynamic_field('overview_image') ?: $base_data['overview']['image'],
    ],
    'core_services' => [
        'subtitle'    => kd_get_dynamic_field('core_services_subtitle') ?: $base_data['core_services']['subtitle'],
        'title'       => kd_get_dynamic_field('core_services_title') ?: $base_data['core_services']['title'],
        'cards'       => [],
    ]
];

// Handle Hero Features Repeater
if (function_exists('have_rows') && have_rows('hero_features_list')) {
    while (have_rows('hero_features_list')) {
        the_row();
        $page_data['hero']['list'][] = get_sub_field('feature_text');
    }
} else {
    $page_data['hero']['list'] = $base_data['hero']['list'];
}

// Handle Core Services Cards Repeater
if (function_exists('have_rows') && have_rows('core_services_cards')) {
    while (have_rows('core_services_cards')) {
        the_row();
        $page_data['core_services']['cards'][] = [
            'number'      => get_sub_field('card_number'),
            'title'       => get_sub_field('card_title'),
            'description' => get_sub_field('card_description'),
            'link'        => get_sub_field('card_link') ?: '#'
        ];
    }
} else {
    // Fallback: Check for native WP custom fields (card_1_title, card_2_title, etc.)
    $native_cards = [];
    for ($i = 1; $i <= 6; $i++) {
        $c_title = kd_get_dynamic_field('card_' . $i . '_title');
        if ($c_title) {
            $native_cards[] = [
                'number'      => '0' . $i,
                'title'       => $c_title,
                'description' => kd_get_dynamic_field('card_' . $i . '_description') ?: '',
                'link'        => kd_get_dynamic_field('card_' . $i . '_link') ?: '#'
            ];
        }
    }
    
    if (!empty($native_cards)) {
        $page_data['core_services']['cards'] = $native_cards;
    } else {
        $page_data['core_services']['cards'] = $base_data['core_services']['cards'];
    }
}
?>

<main id="primary" class="site-main tax-services-main">
    
    <?php get_template_part( 'template-parts/sections/inner-hero' ); ?>

    <?php if ($slug === 'business-tax-services' || $slug === 'business-tax') : ?>
        <?php get_template_part( 'template-parts/tax-services/tax-business-extra' ); ?>
    <?php endif; ?>

    <?php get_template_part( 'template-parts/tax-services/tax-hero', null, $page_data['hero'] ); ?>
    
    <?php get_template_part( 'template-parts/tax-services/tax-overview', null, $page_data['overview'] ); ?>
    
    <?php get_template_part( 'template-parts/tax-services/tax-core-services', null, $page_data['core_services'] ); ?>
    
</main>

<?php get_footer(); ?>
