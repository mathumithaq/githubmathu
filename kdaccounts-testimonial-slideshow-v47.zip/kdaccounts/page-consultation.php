<?php
/**
 * Template Name: Contact Page
 * 
 * Custom template for the Contact page.
 */

get_header(); ?>

<main id="primary" class="site-main">

    <?php get_template_part( 'template-parts/sections/inner-hero' ); ?>
    <?php get_template_part( 'template-parts/sections/contactsec' ); ?>
    
</main>

<?php get_footer(); ?>
