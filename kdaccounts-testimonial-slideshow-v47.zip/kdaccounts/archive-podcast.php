<?php
/**
 * Podcast archive - /podcasts/
 */
get_header();
$kda_img = get_template_directory_uri() . '/assets/images/';
?>
<main id="primary" class="site-main">

    <section class="kda-hero kda-hero--inner">
        <div class="kda-hero-slides" aria-hidden="true">
            <img class="kda-hero-slide" src="<?php echo esc_url($kda_img . 'hero-slide-1.webp'); ?>" alt="" width="1920" height="1080" fetchpriority="high" decoding="async">
            <img class="kda-hero-slide" src="<?php echo esc_url($kda_img . 'hero-slide-2.webp'); ?>" alt="" width="1920" height="1080" loading="lazy" decoding="async">
            <img class="kda-hero-slide" src="<?php echo esc_url($kda_img . 'hero-slide-3.webp'); ?>" alt="" width="1920" height="1080" loading="lazy" decoding="async">
        </div>
        <div class="kda-hero-scrim"></div>
        <div class="container kda-hero-inner">
            <div class="kda-hero-left">
                <div class="kda-hero-crumbs">
                    <a href="<?php echo esc_url(home_url('/')); ?>">Home</a>
                    <span class="sep" aria-hidden="true">&rsaquo;</span>
                    <span>Podcasts</span>
                </div>
                <h1 class="kda-hero-title">Podcasts</h1>
                <p class="kda-hero-sub">Practical conversations on taxes, bookkeeping, and running a business in Buffalo, NY &mdash; from the team at KD Accounting &amp; Tax.</p>
                <div class="kda-hero-ctas">
                    <a href="<?php echo esc_url(home_url('/contact/')); ?>" class="btn">Schedule an Appointment</a>
                </div>
            </div>
            <aside class="kda-hero-form">
                <?php get_template_part('partials/form/hero-form'); ?>
            </aside>
        </div>
    </section>

    <section class="kda-podcasts-section">
        <div class="container">
            <?php if (have_posts()) : ?>
                <div class="kda-pod-list">
                    <?php while (have_posts()) : the_post(); ?>
                        <article class="kda-pod-card kda-pod-card--row">
                            <a class="kda-pod-thumb" href="<?php the_permalink(); ?>" aria-label="<?php echo esc_attr(get_the_title()); ?>">
                                <?php if (has_post_thumbnail()) : ?>
                                    <?php the_post_thumbnail('medium'); ?>
                                <?php else : ?>
                                    <span class="kda-pod-thumb-fallback"><img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/logo.webp'); ?>" alt="" loading="lazy"></span>
                                <?php endif; ?>
                            </a>
                            <div class="kda-pod-main">
                            <div class="kda-pod-head">
                                <span class="kda-pod-date"><?php echo get_the_date('M j, Y'); ?></span>
                                <h2 class="kda-pod-title"><a class="kda-pod-title-link" href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                            </div>
                            <div class="kda-pod-body">
                                <?php the_content(); ?>
                            </div>
                            </div>
                        </article>
                    <?php endwhile; ?>
                </div>

                <div class="blog-pagination">
                    <?php the_posts_pagination(array('mid_size' => 2, 'prev_text' => 'Previous', 'next_text' => 'Next', 'screen_reader_text' => ' ')); ?>
                </div>
            <?php else : ?>
                <div class="kda-pod-empty">
                    <h2>Episodes Coming Soon</h2>
                    <p>We are recording our first episodes now. In the meantime, explore our <a href="<?php echo esc_url(home_url('/blog/')); ?>">articles</a> or <a href="<?php echo esc_url(home_url('/contact/')); ?>">get in touch</a> with a question.</p>
                </div>
            <?php endif; ?>

            <?php get_template_part('partials/call-us'); ?>
        </div>
    </section>

</main>
<?php get_footer(); ?>
