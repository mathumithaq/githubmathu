<?php
/**
 * Author archive — author details header + their posts.
 */

get_header();

$kda_author = get_queried_object();
$kda_bio    = get_the_author_meta( 'description', $kda_author->ID );
if ( empty( $kda_bio ) ) {
    $kda_bio = $kda_author->display_name . ' is part of the KD Accounting & Tax team in Buffalo, NY, writing practical guides on tax preparation, IRS notices, bookkeeping, and small-business finances.';
}
$kda_post_count = count_user_posts( $kda_author->ID, 'post', true );
?>

<main id="primary" class="site-main">

    <!-- Author Hero -->
    <section class="kda-author-hero">
        <div class="container">
            <div class="kda-author-card">
                <span class="kda-author-avatar" aria-hidden="true"><?php echo esc_html( strtoupper( mb_substr( $kda_author->display_name, 0, 1 ) ) ); ?></span>
                <div class="kda-author-info">
                    <span class="kda-author-label">Author</span>
                    <h1 class="kda-author-name"><?php echo esc_html( $kda_author->display_name ); ?></h1>
                    <p class="kda-author-bio"><?php echo esc_html( $kda_bio ); ?></p>
                    <span class="kda-author-count"><?php echo intval( $kda_post_count ); ?> article<?php echo $kda_post_count == 1 ? '' : 's'; ?> published</span>
                </div>
            </div>
        </div>
    </section>

    <!-- Author's Posts -->
    <section class="blog-listing-section kda-author-posts">
        <div class="container">
            <?php if ( have_posts() ) : ?>
                <div class="blog-listing-grid">
                    <?php while ( have_posts() ) : the_post(); ?>
                        <article id="post-<?php the_ID(); ?>" <?php post_class('blog-card'); ?>>
                            <div class="blog-card-image">
                                    <?php $kda_cats = get_the_category(); if ( ! empty( $kda_cats ) ) : ?><a class="blog-card-cat" href="<?php echo esc_url( get_category_link( $kda_cats[0] ) ); ?>"><?php echo esc_html( $kda_cats[0]->name ); ?></a><?php endif; ?>
                                <?php if ( has_post_thumbnail() ) : ?>
                                    <a href="<?php the_permalink(); ?>" aria-label="<?php echo esc_attr( 'Read more about ' . get_the_title() ); ?>">
                                        <?php the_post_thumbnail('medium_large'); ?>
                                    </a>
                                <?php else : ?>
                                    <a href="<?php the_permalink(); ?>" class="blog-placeholder-img" aria-label="<?php echo esc_attr( 'Read more about ' . get_the_title() ); ?>"></a>
                                <?php endif; ?>
                            </div>
                            <div class="blog-card-content">
                                <div class="blog-card-meta">
                                    <span class="blog-date">
                                        <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/calendar.svg" alt="Date" width="16" height="16">
                                        <?php echo get_the_date(); ?>
                                    </span>
                                </div>
                                <h2 class="blog-card-title">
                                    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                </h2>
                                <p class="blog-card-excerpt"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 20, '&hellip;' ) ); ?></p>
                                <a href="<?php the_permalink(); ?>" class="blog-card-link">Read Article <span aria-hidden="true">&rarr;</span></a>
                            </div>
                        </article>
                    <?php endwhile; ?>
                </div>

                <div class="blog-pagination">
                    <?php
                        the_posts_pagination( array(
                            'mid_size'  => 2,
                            'prev_text' => __( 'Previous', 'kdaccounts-theme' ),
                            'next_text' => __( 'Next', 'kdaccounts-theme' ),
                            'screen_reader_text' => ' ',
                        ) );
                    ?>
                </div>
            <?php else : ?>
                <div class="no-posts-found">
                    <p><?php esc_html_e( 'No posts by this author yet.', 'kdaccounts-theme' ); ?></p>
                </div>
            <?php endif; ?>
        </div>
    </section>

</main>

<?php get_footer(); ?>
