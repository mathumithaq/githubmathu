<?php
/**
 * Single Post Template
 */

get_header(); ?>

<!-- Reading Progress Bar -->
<div class="reading-progress-container">
    <div class="reading-progress-bar" id="readingProgressBar"></div>
</div>

<main id="primary" class="site-main single-blog-main">

    <?php while (have_posts()):
        the_post(); ?>

        <!-- Hero Section -->
        <section class="single-hero">
            <div class="container">
                <div class="single-hero-content">
                    <?php
                    // Get the first category
                    $categories = get_the_category();
                    if (!empty($categories)) {
                        echo '<span class="single-category-badge">' . esc_html(strtoupper($categories[0]->name)) . '</span>';
                    }
                    ?>

                    <h1 class="single-title"><?php the_title(); ?></h1>

                    <?php
                    // Subtitle if available (ACF or custom field)
                    $subtitle = get_post_meta(get_the_ID(), 'sub_title', true);
                    if (!empty($subtitle)): ?>
                        <p class="single-subtitle"><?php echo esc_html($subtitle); ?></p>
                    <?php endif; ?>

                    <div class="single-meta">
                        <div class="single-meta-author">
                            <?php echo file_get_contents(get_template_directory() . '/assets/icons/user.svg'); ?>
                            <span><?php the_author(); ?></span>
                        </div>
                        <div class="single-meta-date">
                            <span><?php echo get_the_date('F j, Y'); ?></span>
                            <?php if (get_post_modified_time('U', true) > get_post_time('U', true)): ?><span class="single-last-updated">Last updated: <?php echo esc_html(get_the_modified_date('F j, Y')); ?></span><?php endif; ?>
                            <span class="meta-dot">&bull;</span>
                            <span class="reading-time">
                                <?php
                                $word_count = str_word_count(strip_tags(get_the_content()));
                                $reading_time = ceil($word_count / 200);
                                echo $reading_time . ' min read';
                                ?>
                            </span>
                        </div>
                    </div>
                </div>


            </div>
        </section>

        <!-- Content Section -->
        <section class="single-content-section">
            <div class="container single-layout">



                <!-- Right Sticky Sidebar -->
                <aside class="single-sidebar-right">
                    <div class="toc-widget">
                        
                        <div class="toc-line"></div>
                        <ol id="toc-list" class="toc-list" aria-label="Article contents">
                            <!-- Filled by JS -->
                        </ol>
                    </div>
                </aside>

                <!-- Main Content -->
                <article class="single-article-content" id="article-content">
                <?php if (has_post_thumbnail()): ?>
                    <div class="single-featured-image">
                        <?php the_post_thumbnail('full'); ?>
                    </div>
                <?php endif; ?>
                    <?php the_content(); ?>

                    <?php
                    // Author box
                    $kda_author_id   = get_the_author_meta('ID');
                    $kda_author_name = get_the_author();
                    $kda_author_bio  = get_the_author_meta('description');
                    if (empty($kda_author_bio)) {
                        $kda_author_bio = $kda_author_name . ' is part of the KD Accounting & Tax team in Buffalo, NY, writing practical guides on tax preparation, IRS notices, bookkeeping, and small-business finances — so individuals and business owners can make confident financial decisions.';
                    }
                    ?>
                    <div class="author-box">
                        <div class="author-box-avatar">
                            <span class="author-box-initial" aria-hidden="true"><?php echo esc_html(strtoupper(mb_substr($kda_author_name, 0, 1))); ?></span>
                        </div>
                        <div class="author-box-content">
                            <span class="author-box-label">About the Author</span>
                            <h3 class="author-box-name"><?php echo esc_html($kda_author_name); ?></h3>
                            <p class="author-box-bio"><?php echo esc_html($kda_author_bio); ?></p>
                            <a class="author-box-link" href="<?php echo esc_url(get_author_posts_url($kda_author_id)); ?>">
                                View all posts by <?php echo esc_html($kda_author_name); ?>
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" width="15" height="15"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
                            </a>
                        </div>
                    </div>
                </article>



            </div>
        </section>

    <?php endwhile; ?>

</main>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Reading Progress Bar
        const progressBar = document.getElementById('readingProgressBar');
        window.addEventListener('scroll', () => {
            const winScroll = document.body.scrollTop || document.documentElement.scrollTop;
            const height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
            const scrolled = (winScroll / height) * 100;
            if (progressBar) progressBar.style.width = scrolled + '%';
        });

        // Auto-generate TOC
        const articleContent = document.getElementById('article-content');
        const tocList = document.getElementById('toc-list');
        if (articleContent && tocList) {
            const headings = articleContent.querySelectorAll('h2, h3:not(.author-box-name)');
            if (headings.length > 0) {
                headings.forEach((heading, index) => {
                    // Assign ID if it doesn't have one
                    if (!heading.id) {
                        heading.id = 'heading-' + index;
                    }
                    const li = document.createElement('li');
                    li.className = 'toc-item toc-' + heading.tagName.toLowerCase();

                    const a = document.createElement('a');
                    a.href = '#' + heading.id;
                    a.textContent = heading.textContent;

                    // Smooth scroll
                    a.addEventListener('click', function (e) {
                        e.preventDefault();
                        document.getElementById(heading.id).scrollIntoView({
                            behavior: 'smooth'
                        });
                    });

                    li.appendChild(a);
                    tocList.appendChild(li);
                });
            } else {
                // Hide TOC if no headings
                document.querySelector('.single-sidebar-right').style.display = 'none';
            }
        }
    });
</script>

<?php get_footer(); ?>