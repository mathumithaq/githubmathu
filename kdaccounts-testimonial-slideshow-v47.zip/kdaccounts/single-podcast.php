<?php
/**
 * Single podcast episode.
 */
get_header();
?>
<main id="primary" class="site-main">
    <?php while (have_posts()) : the_post(); ?>
        <section class="kda-podcasts-section kda-podcast-single">
            <div class="container">
                <div class="kda-pod-single-head">
                    <div class="kda-hero-crumbs kda-pod-crumbs">
                        <a href="<?php echo esc_url(home_url('/')); ?>">Home</a>
                        <span class="sep" aria-hidden="true">&rsaquo;</span>
                        <a href="<?php echo esc_url(get_post_type_archive_link('podcast')); ?>">Podcasts</a>
                    </div>
                    <span class="kda-pod-date"><?php echo get_the_date('M j, Y'); ?></span>
                    <h1 class="kda-pod-title"><?php the_title(); ?></h1>
                </div>
                <div class="kda-pod-card">
                    <div class="kda-pod-body">
                        <?php the_content(); ?>
                    </div>
                </div>
                <p style="text-align:center; margin-top:30px;">
                    <a class="blog-card-link" href="<?php echo esc_url(get_post_type_archive_link('podcast')); ?>">&larr; All Episodes</a>
                </p>
            </div>
        </section>
    <?php endwhile; ?>
</main>
<?php get_footer(); ?>
