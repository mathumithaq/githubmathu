<?php
/** Bookkeeping Services — dedicated page, screenshot content. */
get_header();
$bk_id = get_queried_object_id();
$bk_icons = get_template_directory_uri() . '/assets/icons/';
$bk_reviews_url = get_post_meta($bk_id, 'bk_google_reviews_url', true);
$bk_rating = get_post_meta($bk_id, 'bk_google_rating', true);
$bk_count = get_post_meta($bk_id, 'bk_google_review_count', true);
?>
<main id="primary" class="site-main bk-page">
<?php get_template_part('template-parts/sections/bookkeeping-hero'); ?>
<?php get_template_part('template-parts/sections/bookkeeping-testimonials'); ?>
<section class="bk-summary"><div class="container">
<span class="section-subtitle">Intro &amp; Quick Summary</span><h2>Your Buffalo Bookkeeping at a Glance</h2>
<div class="bk-summary-grid"><div><p>Maybe your books are a spreadsheet you stopped updating in March. Maybe it's a QuickBooks file nobody has reconciled since last tax season, or a folder of receipts in the truck. If you run a business in Buffalo, you're probably very good at the work itself: the job site, the kitchen, the client meetings. Bookkeeping is the thing that slides.</p>
<p>KD Accounting &amp; Tax provides small business bookkeeping for owners across Buffalo and Erie County, from monthly bookkeeping and catch-up work to clear financial reporting. The goal is simple. Accurate books every month, so your numbers are ready when you need them, whether that's for a bank, a sales tax return, or tax season.</p></div>
<dl class="bk-facts"><div><dt>Who it's for</dt><dd>Small businesses, LLCs, sole proprietors, contractors, restaurants, retailers, and professional offices in Buffalo and Erie County</dd></div><div><dt>What's included</dt><dd>Transaction categorization, bank and credit card reconciliations, monthly financial statements, and sales tax-ready records</dd></div><div><dt>Pricing</dt><dd>Monthly plans from $149/month, based on your transaction volume</dd></div><div><dt>Getting started</dt><dd>A free estimate and a look at where your books stand today</dd></div></dl></div>
<p class="bk-bottom-call"><strong>Have questions about your books?</strong> Talk to a local bookkeeper today. <a class="btn bk-phone-button" href="tel:+17165892665">Call Us 716-589-2665</a></p>
</div></section>
<section class="bk-signs"><div class="container">
<span class="section-subtitle">Know the Signs</span><h2>5 Signs Your Buffalo Business Needs a Bookkeeper</h2><p>Not sure if it's time to hand off the books? These are the signs worth paying attention to:</p>
<ol class="bk-sign-list">
<?php $signs = array(
array("You don't know your real profit.", "Money comes in and goes out, but you couldn't say what you actually made last month."),
array('Your bank balance is your budget.', "If you check the account before every purchase, you're managing cash by guesswork."),
array('Tax season is a scramble.', 'You spend late nights in March and April hunting for receipts and rebuilding the year.'),
array("Your QuickBooks file doesn't match the bank.", 'Unreconciled accounts, duplicate entries, and a growing uncategorized balance all point to books that need attention.'),
array("You're growing.", 'New employees, a second location, a loan application, or sales tax collection all make accurate books more important and more time-consuming.')
); foreach ($signs as $index => $sign): ?><li><span class="bk-number" aria-hidden="true"><?php echo esc_html(sprintf('%02d', $index + 1)); ?></span><div><h3><?php echo esc_html($sign[0]); ?></h3><p><?php echo esc_html($sign[1]); ?></p></div></li><?php endforeach; ?>
</ol><p>If two or more of these sound familiar, a monthly bookkeeping plan will likely save you time and stress.</p>
<p class="bk-bottom-call"><strong>Sound familiar?</strong> Let's talk about getting your books back on track. <a class="btn bk-phone-button" href="tel:+17165892665">Call Us 716-589-2665</a></p>
</div></section>
<?php get_template_part('template-parts/sections/bookkeeping-services-details'); ?>
<?php get_template_part('template-parts/sections/bookkeeping-process'); ?>
<?php get_template_part('template-parts/sections/bookkeeping-pricing'); ?>
<?php get_template_part('template-parts/sections/bookkeeping-cta'); ?>
<?php get_template_part('template-parts/sections/bookkeeping-industries'); ?>
<?php get_template_part('template-parts/sections/bookkeeping-why'); ?>
<?php get_template_part('template-parts/sections/bookkeeping-areas'); ?>
<?php get_template_part('template-parts/sections/bookkeeping-cta-current'); ?>
<?php get_template_part('template-parts/sections/bookkeeping-faq'); ?>
<?php get_template_part('template-parts/sections/bookkeeping-final-cta'); ?>
<?php get_template_part('template-parts/sections/bookkeeping-guides'); ?>
</main>
<?php get_footer(); ?>
