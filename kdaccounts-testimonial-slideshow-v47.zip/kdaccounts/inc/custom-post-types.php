<?php
/**
 * Custom post types.
 */

/**
 * Podcast episodes - added 2026-08-21.
 * Add episodes under "Podcasts" in wp-admin: title, description in the editor,
 * and paste a YouTube/Spotify link or add an Audio block for the player.
 * Archive: /podcasts/
 */
function kda_register_podcast_cpt() {
    register_post_type('podcast', array(
        'labels' => array(
            'name'          => 'Podcasts',
            'singular_name' => 'Podcast Episode',
            'add_new'       => 'Add Episode',
            'add_new_item'  => 'Add New Episode',
            'edit_item'     => 'Edit Episode',
            'new_item'      => 'New Episode',
            'view_item'     => 'View Episode',
            'search_items'  => 'Search Episodes',
            'not_found'     => 'No episodes found',
        ),
        'public'        => true,
        'has_archive'   => 'podcasts',
        'rewrite'       => array('slug' => 'podcast', 'with_front' => false),
        'menu_icon'     => 'dashicons-microphone',
        'menu_position' => 6,
        'show_in_rest'  => true,
        'supports'      => array('title', 'editor', 'thumbnail', 'excerpt'),
    ));
}
add_action('init', 'kda_register_podcast_cpt');
