# KD Accounts Theme — Changelog

All notable changes to this project are documented in this file.
Format follows [Semantic Versioning](https://semver.org/): `MAJOR.MINOR.PATCH`

---

## [1.2.0] – 2026-08-04 — Performance Optimization

Focused on achieving 90+ PageSpeed Insights score on both Mobile and Desktop.

### Performance
- Fixed `_S_VERSION` from `time()` to static `'1.2.0'` — enables browser caching for all CSS/JS assets
- Added `defer` attribute to `navigation.js`, `ajax-router.js`, and `testimonials.js` — eliminates render-blocking JavaScript
- Made `section.css` load asynchronously using `media='print'` + `onload` technique — removes 1,620ms render-blocking
- Removed CSS dependency chain — fonts/global/sections now load in parallel instead of sequentially
- Added `fetchpriority="high"` and `decoding="async"` to hero LCP image
- Added `loading="lazy"` to all below-fold images (about, testimonials sections)
- Added `width` and `height` attributes to testimonial images — prevents CLS layout shift

### Fonts
- Converted `montserrat.ttf` (727 KB) → `montserrat.woff2` (210 KB) — **71% reduction**
- Added `font-weight` ranges to all `@font-face` declarations
- Added `preload` hints for Cinzel and Inter fonts in `<head>` — improves LCP
- Cleaned up duplicate `format()` declaration on Inter font

### Images
- Converted `sub-content.png` (675 KB) → `sub-content.webp` (66 KB) — **90% reduction**
- Compressed `about-roadmap.webp` from 828×1024 → 800×800 — matches display dimensions
- Compressed `about-financial-goals.webp` to 800×800 optimized size

### WordPress Cleanup
- Removed WordPress emoji scripts and styles (~50 KB render-blocking JS)
- Removed oEmbed JS and discovery links
- Removed Gutenberg block CSS (not used in this theme) — saves ~70 KB
- Removed `blocks/subscription.css` render-blocking plugin stylesheet
- Removed `wlwmanifest`, RSD link, shortlink, REST API link, generator meta tag
- Limited `preconnect` hints to contact pages only — fixes "too many preconnects" warning
- `testimonials.js` now loads only on homepage and about page (not site-wide)

### Bug Fixes
- Removed `background-attachment: fixed` from body — caused GPU repaint on every scroll frame (major mobile jank)
- Fixed 404 error for `offerings-bg.webp` by replacing it with a solid light background color (`#F8FAFC`)
- Fixed 404 error for `cta-bg.webp` by falling back to the existing `footer-bg.webp` image
- Fixed "Flash of Unstyled Content" (FOUC) and blank initial paint in PageSpeed filmstrip by loading `section.css` synchronously again (GZIP handles size optimization).

### SEO & Accessibility
- Added dynamic `<meta name="description">` fallback to resolve PageSpeed missing meta description audit
- Fixed contrast on `.offer-card` (gold background) — changed white text (`#FFFFFF`) to dark text (`#1E293B`)
- Fixed contrast on `.pricing-header .section-subtitle` — changed from gold (`#C5A880`) to dark gold (`#704A11`)
- Fixed contrast on `.pricing-num` — darkened from light gray (`#888888`) to slate (`#475569`)

---

## [1.1.0] – 2026-08-03 — UI Fixes & Accessibility

### Accessibility
- Fixed low contrast ratio on `.about-text-lead` — darkened from `#4b5563` to `#1f2937` (WCAG AA compliant)
- Fixed low contrast ratio on `.about-text-secondary` — darkened from `#6b7280` to `#374151` (WCAG AA compliant)

### Single Blog Page
- Added `font-size: 30px` and `line-height: 1.3` to `.single-article-content h2` — reduces excessive heading spacing

### Section Spacing
- Added `.legal-content-section` to global section padding rule (`padding: 60px 0`)

---

## [1.0.0] – 2026-07-01 — Initial Release

Full custom WordPress theme designed and developed for KD Accounting & Tax, Buffalo.

### Features
- Custom WordPress theme built from scratch (`kdaccounts-theme`)
- Fully responsive layout — Mobile, Tablet, Desktop
- AJAX-powered page navigation (`ajax-router.js`) — smooth page transitions
- Sticky header with scroll-activated state
- Dropdown navigation with mobile hamburger menu
- Hero section with background image and CTA
- Services, Features, Who We Are, Why Choose Us sections
- Testimonials slider with auto-play, touch swipe, and dot navigation
- FAQ accordion section
- Latest Blog Posts section
- Financial Support / Solutions section
- Contact form via KD Lead (GoHighLevel) iframe embed
- Footer with navigation links, social icons, and copyright

### Sub-Service Pages
- Dynamic sub-service page template (Bookkeeping, Accounting, Tax, Business Formation)
- Sub-hero, sub-content, sub-offerings, sub-why-choose sections
- Pricing Plans (4 tiers: Bronze, Silver, Gold, Platinum) — configurable via WordPress Customizer

### Additional Pages
- About page with roadmap and team sections
- Contact page
- Consultation / Free Consultation page
- Blog listing and single blog post pages
- Privacy Policy and Terms & Conditions pages

### Design System
- Gold/Bronze color palette (`#C5A880`, `#1E293B`)
- Typography: Cinzel (headings), Inter (body), Montserrat (buttons)
- CSS custom properties (design tokens) via `:root`
- Alternating section backgrounds (white / light gray)
- Global image border style (gold border, rounded top-right corner)
- Floating action buttons (WhatsApp, scroll-to-top)

### WordPress Integration
- WordPress Customizer integration for Pricing Plans (4 services × 4 tiers)
- Dynamic page links via `kd_get_dynamic_link()` helper
- Post Thumbnails, Title Tag, Nav Menus support
- Reading Progress Bar on single blog pages
- Table of Contents (TOC) widget on single blog pages

---

*Maintained by KD Accounts Development Team*
*Versioning: [Semantic Versioning 2.0.0](https://semver.org/)*
