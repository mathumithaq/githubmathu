<?php
$source = 'C:\Users\mathu\.gemini\antigravity-ide\brain\6288621a-7e43-4c56-99f4-55a405316082\about_top_image_1785336109058.png';
$destination = 'c:\xampp\htdocs\wordpress\wp-content\themes\kdaccounts-theme\assets\images\about-financial-goals.webp';

if (file_exists($source)) {
    // Load PNG
    $image = imagecreatefrompng($source);
    if ($image !== false) {
        // Convert to webp with 70% quality to ensure <100kb
        imagepalettetotruecolor($image);
        imagealphablending($image, true);
        imagesavealpha($image, true);
        imagewebp($image, $destination, 70);
        imagedestroy($image);
        echo "Successfully converted to WebP. File size: " . filesize($destination) . " bytes\n";
    } else {
        echo "Failed to load PNG.\n";
    }
} else {
    echo "Source file does not exist.\n";
}
?>
