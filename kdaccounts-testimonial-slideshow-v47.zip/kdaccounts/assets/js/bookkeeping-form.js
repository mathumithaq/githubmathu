
(function () {
    var form = document.getElementById('kdaHeroForm');
    if (!form) return;

    form.querySelectorAll('.kda-consent-acc summary input[type="checkbox"]').forEach(function (cb) {
        cb.addEventListener('click', function (e) { e.stopPropagation(); });
    });

    form.addEventListener('submit', function (e) {
        e.preventDefault();
        if (!form.reportValidity()) return;

        var btn = form.querySelector('button[type="submit"]');
        var status = document.getElementById('kdahFormStatus');
        btn.disabled = true;
        status.className = 'kda-form-note';
        status.innerText = 'Sending your request…';

        var formData = {
            formId: 'kdaccounts_hero_form_01',
            formName: 'KD Accounting & Tax Hero Form',
            submissionId: 'SUB-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9),
            timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
            page: window.location.pathname,

            fullName: document.getElementById('kdah-name').value,
            email: document.getElementById('kdah-email').value,
            phone: document.getElementById('kdah-phone').value,
            serviceInterestedIn: document.getElementById('kdah-service').value,
            companyName: document.getElementById('kdah-company').value,
            message: document.getElementById('kdah-message').value,

            marketingConsentAccepted: document.getElementById('kdahMarketingConsent').checked,
            transactionalConsentAccepted: document.getElementById('kdahTransactionalConsent').checked
        };

        fetch('https://services.leadconnectorhq.com/hooks/ZUOyKmPSpPwKe3Z23Ngw/webhook-trigger/3864993d-1e21-4edd-aa23-bad900687858', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(formData)
        })
        .then(function (response) {
            if (response.ok) {
                form.reset();
                status.classList.add('is-success');
                status.innerText = 'Thank you! Your request has been sent — we’ll be in touch shortly.';
            } else {
                status.classList.add('is-error');
                status.innerText = 'Something went wrong sending your request. Please call us at (716) 589-2665.';
            }
            btn.disabled = false;
        })
        .catch(function () {
            status.classList.add('is-error');
            status.innerText = 'Network error — please try again or call (716) 589-2665.';
            btn.disabled = false;
        });
    });
})();
