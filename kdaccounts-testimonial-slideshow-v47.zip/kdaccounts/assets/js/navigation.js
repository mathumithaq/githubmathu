document.addEventListener('DOMContentLoaded', function() {
    const menuToggle = document.querySelector('.menu-toggle');
    const mainNavigation = document.querySelector('.main-navigation');
    const dropdownToggles = document.querySelectorAll('.has-dropdown > a');

    if (menuToggle && mainNavigation) {
        menuToggle.addEventListener('click', function(e) {
            e.preventDefault();
            mainNavigation.classList.toggle('toggled');
            menuToggle.classList.toggle('toggled');
            const expanded = menuToggle.getAttribute('aria-expanded') === 'true' || false;
            menuToggle.setAttribute('aria-expanded', !expanded);
        });
    }

    const menuClose = document.querySelector('.menu-close');
    if (menuClose && mainNavigation) {
        menuClose.addEventListener('click', function(e) {
            e.preventDefault();
            mainNavigation.classList.remove('toggled');
            menuToggle.classList.remove('toggled');
            menuToggle.setAttribute('aria-expanded', 'false');
        });
    }

    // Dropdown toggle on parent link click (desktop and mobile)
    dropdownToggles.forEach(function(toggle) {
        toggle.addEventListener('click', function(e) {
            if (this.getAttribute('href') === '#') {
                e.preventDefault();
                const parent = this.closest('.has-dropdown');
                
                // Close other dropdowns
                document.querySelectorAll('.has-dropdown.active').forEach(function(dropdown) {
                    if (dropdown !== parent) {
                        dropdown.classList.remove('active');
                    }
                });
                
                parent.classList.toggle('active');
            }
        });
    });

    // On desktop, hovering another item should close active dropdowns
    document.querySelectorAll('.has-dropdown').forEach(function(dropdown) {
        dropdown.addEventListener('mouseenter', function() {
            document.querySelectorAll('.has-dropdown.active').forEach(function(activeDropdown) {
                if (activeDropdown !== dropdown) {
                    activeDropdown.classList.remove('active');
                }
            });
        });
    });

    // Close dropdowns when clicking outside
    document.addEventListener('click', function(e) {
        if (!e.target.closest('.has-dropdown')) {
            document.querySelectorAll('.has-dropdown.active').forEach(function(dropdown) {
                dropdown.classList.remove('active');
            });
        }
    });

    // Hide menus when a link is clicked
    const allNavLinks = document.querySelectorAll('.main-navigation a');
    allNavLinks.forEach(function(link) {
        link.addEventListener('click', function(e) {
            // If it's a real link (not just a "#" for dropdown toggle)
            if (this.getAttribute('href') !== '#') {
                if (mainNavigation) {
                    mainNavigation.classList.remove('toggled');
                }
                if (menuToggle) {
                    menuToggle.classList.remove('toggled');
                    menuToggle.setAttribute('aria-expanded', 'false');
                }
                document.querySelectorAll('.has-dropdown.active').forEach(function(dropdown) {
                    dropdown.classList.remove('active');
                });
            }
        });
    });

    // Sticky Header functionality
    const siteHeader = document.querySelector('.site-header');
    if (siteHeader) {
        window.addEventListener('scroll', function() {
            if (window.pageYOffset > 50) {
                siteHeader.classList.add('is-sticky');
            } else {
                siteHeader.classList.remove('is-sticky');
            }
        });
    }

    // Floating action buttons functionality
    const floatingBtns = document.querySelector('.floating-action-buttons');
    const scrollTopBtn = document.querySelector('.scroll-to-top');
    
    if (floatingBtns) {
        window.addEventListener('scroll', function() {
            if (window.pageYOffset > 500) { /* Show after scrolling past hero section */
                floatingBtns.classList.add('show');
            } else {
                floatingBtns.classList.remove('show');
            }
        });

        scrollTopBtn.addEventListener('click', function(e) {
            e.preventDefault();
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }
});
