document.addEventListener('DOMContentLoaded', function() {
    const track = document.querySelector('.ts-track');
    const cards = Array.from(document.querySelectorAll('.ts-card'));
    const prevBtn = document.querySelector('.ts-arrow.prev');
    const nextBtn = document.querySelector('.ts-arrow.next');
    const dots = Array.from(document.querySelectorAll('.ts-dot'));
    
    if (cards.length === 0 || !track) return;

    let currentIndex = 0;
    const cardCount = cards.length;
    let autoSlideInterval;

    function updateSlider() {
        // Move track
        track.style.transform = `translateX(-${currentIndex * 100}%)`;
        
        // Update dots
        dots.forEach((dot, index) => {
            if (index === currentIndex) {
                dot.classList.add('active');
            } else {
                dot.classList.remove('active');
            }
        });
        
        // Update cards (optional fade effect class)
        cards.forEach((card, index) => {
            if (index === currentIndex) {
                card.classList.add('active');
            } else {
                card.classList.remove('active');
            }
        });
    }

    function nextSlide() {
        currentIndex = (currentIndex + 1) % cardCount;
        updateSlider();
    }

    function prevSlide() {
        currentIndex = (currentIndex - 1 + cardCount) % cardCount;
        updateSlider();
    }

    function startAutoSlide() {
        autoSlideInterval = setInterval(nextSlide, 6000); // 6 seconds
    }

    function resetAutoSlide() {
        clearInterval(autoSlideInterval);
        startAutoSlide();
    }

    if (nextBtn) {
        nextBtn.addEventListener('click', () => {
            nextSlide();
            resetAutoSlide();
        });
    }

    if (prevBtn) {
        prevBtn.addEventListener('click', () => {
            prevSlide();
            resetAutoSlide();
        });
    }

    dots.forEach((dot, index) => {
        dot.addEventListener('click', () => {
            currentIndex = index;
            updateSlider();
            resetAutoSlide();
        });
    });

    // Touch swipe support
    let startX = 0;
    let endX = 0;
    
    track.addEventListener('touchstart', e => {
        startX = e.changedTouches[0].screenX;
        clearInterval(autoSlideInterval);
    }, {passive: true});

    track.addEventListener('touchend', e => {
        endX = e.changedTouches[0].screenX;
        if (startX - endX > 50) nextSlide();
        if (endX - startX > 50) prevSlide();
        startAutoSlide();
    }, {passive: true});

    startAutoSlide();
});
