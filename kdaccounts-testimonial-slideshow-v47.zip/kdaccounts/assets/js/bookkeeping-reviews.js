document.addEventListener('DOMContentLoaded', function () {
  const slider = document.querySelector('.bk-review-slideshow');
  if (!slider) return;
  const cards = Array.from(slider.querySelectorAll('.ts-new-card'));
  const status = slider.querySelector('.bk-review-status');
  const pause = slider.querySelector('.bk-review-pause');
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)');
  let index = 0, timer, paused = reduced.matches, hovered = false, focused = false;
  function show(next) {
    index = (next + cards.length) % cards.length;
    cards.forEach((card, i) => { card.hidden = i !== index; });
    status.textContent = (index + 1) + ' / ' + cards.length;
  }
  function schedule() {
    clearInterval(timer);
    pause.textContent = paused ? 'Play slideshow' : 'Pause slideshow';
    if (!paused && !hovered && !focused && !document.hidden) {
      timer = setInterval(() => show(index + 1), 6000);
    }
  }
  slider.querySelector('.bk-review-prev').addEventListener('click', () => { show(index - 1); schedule(); });
  slider.querySelector('.bk-review-next').addEventListener('click', () => { show(index + 1); schedule(); });
  pause.addEventListener('click', () => { paused = !paused; schedule(); });
  slider.addEventListener('mouseenter', () => { hovered = true; schedule(); });
  slider.addEventListener('mouseleave', () => { hovered = false; schedule(); });
  slider.addEventListener('focusin', () => { focused = true; schedule(); });
  slider.addEventListener('focusout', event => { if (!slider.contains(event.relatedTarget)) { focused = false; schedule(); } });
  document.addEventListener('visibilitychange', schedule);
  let touchX;
  slider.addEventListener('touchstart', event => { touchX = event.changedTouches[0].clientX; }, {passive: true});
  slider.addEventListener('touchend', event => {
    const distance = touchX - event.changedTouches[0].clientX;
    if (Math.abs(distance) > 50) { show(index + (distance > 0 ? 1 : -1)); schedule(); }
  }, {passive: true});
  show(0); schedule();
});
