window.addEventListener("load", function () {
    setTimeout(function () {
        // Set the iframe source for the GHL form
        var formIframe = document.getElementById("inline-LkKXxSbVLqa7dzzILjPa");
        if (formIframe && formIframe.getAttribute("data-src")) {
            formIframe.src = formIframe.getAttribute("data-src");
        }

        // Lazy load Google Maps iframes
        var mapIframes = document.querySelectorAll("iframe.lazy-map");
        mapIframes.forEach(function(iframe) {
            if (iframe.getAttribute("data-src")) {
                iframe.src = iframe.getAttribute("data-src");
            }
        });

        // Load the form embed script
        var script = document.createElement("script");
        script.src = "https://link.kdlead.com/js/form_embed.js";
        document.body.appendChild(script);
    }, 3000);
});