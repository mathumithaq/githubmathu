<?php
/**
 * Template Name: About Page
 * 
 * Custom template for the About page.
 */

get_header(); ?>

<main id="primary" class="site-main">

    <?php get_template_part( 'template-parts/sections/inner-hero' ); ?>
    <?php get_template_part( 'template-parts/sections/testimonials' ); ?>
    <?php get_template_part( 'template-parts/sections/about-top' ); ?>
    <?php get_template_part( 'template-parts/sections/about-roadmap' ); ?>
    <?php get_template_part( 'template-parts/sections/services' ); ?>
    <?php get_template_part( 'template-parts/sections/contact' ); ?>
</main>

<?php get_footer(); ?>
