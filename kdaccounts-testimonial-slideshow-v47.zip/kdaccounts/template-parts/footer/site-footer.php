<?php
/**
 * Site Footer — 4-column layout: brand / services / company / contact + mini map,
 * trust-badge strip, bottom bar. Previous version backed up in
 * site-footer.php.bak-20260819.
 */
?>
<footer class="site-footer kdf">

    <div class="container kdf-wrap">

        <div class="kdf-columns">

            <!-- 1. Brand -->
            <div class="kdf-col kdf-brand">
                <a href="<?php echo esc_url(home_url('/')); ?>" aria-label="KD Accounting Home" class="kdf-logo">
                    <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/logo.webp'); ?>" alt="KD Accounting & Tax Logo" width="160" height="60" loading="lazy">
                </a>
                <p class="kdf-desc">When you choose <span class="kdf-strong">KD Accounting &amp; Tax</span>, you get a certified Buffalo, NY team with over 10 years of experience in accounting, tax, bookkeeping, payroll, and business registration &mdash; keeping your finances accurate, compliant, and on track.</p>

                <div class="kdf-socials">
                    <a href="https://www.facebook.com/KDaccountingandTax" target="_blank" rel="noopener noreferrer" aria-label="Facebook"><?php echo file_get_contents(get_template_directory() . '/assets/icons/facebook.svg'); ?></a>
                    <a href="https://x.com/kdaccountingtax" target="_blank" rel="noopener noreferrer" aria-label="X (Twitter)"><?php echo file_get_contents(get_template_directory() . '/assets/icons/twitter.svg'); ?></a>
                    <a href="https://www.pinterest.com/kdaccountingandtax/" target="_blank" rel="noopener noreferrer" aria-label="Pinterest"><?php echo file_get_contents(get_template_directory() . '/assets/icons/pinterest.svg'); ?></a>
                    <a href="https://www.instagram.com/kdaccounting_and_tax/" target="_blank" rel="noopener noreferrer" aria-label="Instagram"><?php echo file_get_contents(get_template_directory() . '/assets/icons/instagram.svg'); ?></a>
                    <a href="https://www.linkedin.com/company/kd-accounting-and-tax/" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn"><?php echo file_get_contents(get_template_directory() . '/assets/icons/linkedin.svg'); ?></a>
                </div>
            </div>

            <!-- 2. Services -->
            <div class="kdf-col">
                <h3 class="kdf-heading">Services</h3>
                <ul class="kdf-links">
                    <li><a href="<?php echo esc_url(kd_get_dynamic_link('Accounting Services', 'accounting-services')); ?>">Accounting Services</a></li>
                    <li><a href="<?php echo esc_url(kd_get_dynamic_link('Tax Filing Services', 'tax-filing-services')); ?>">Tax Services</a></li>
                    <li><a href="<?php echo esc_url(kd_get_dynamic_link('Bookkeeping Services', 'bookkeeping-services')); ?>">Bookkeeping Services</a></li>
                    <li><a href="<?php echo esc_url(home_url('/tax-planning-services/')); ?>">Tax Planning</a></li>
                    <li><a href="<?php echo esc_url(kd_get_dynamic_link('Business Registration Services', 'business-registration-services')); ?>">Business Registration</a></li>
                </ul>
                <a class="kdf-view-all" href="<?php echo esc_url(home_url('/#services')); ?>">View All Services <span aria-hidden="true">&rarr;</span></a>
            </div>

            <!-- 3. Company -->
            <div class="kdf-col">
                <h3 class="kdf-heading">Company</h3>
                <ul class="kdf-links">
                    <li><a href="<?php echo esc_url(kd_get_dynamic_link('About Us', 'about')); ?>">About</a></li>
                    <li><a href="<?php echo esc_url(kd_get_dynamic_link('Contact Us', 'contact')); ?>">Contact</a></li>
                    <li><a href="<?php echo esc_url(home_url('/know-us/pricing-plan/')); ?>">Pricing Plan</a></li>
                    <li><a href="<?php echo esc_url(home_url('/know-us/blog/')); ?>">Blog</a></li>
                    <li><a href="<?php echo esc_url( home_url('/podcasts/') ); ?>">Podcasts</a></li>
                    <li><a href="<?php echo esc_url(is_front_page() ? '#faq' : home_url('/') . '#faq'); ?>">FAQs</a></li>
                </ul>
            </div>

            <!-- 4. Contact Info + mini map -->
            <div class="kdf-col kdf-contact">
                <h3 class="kdf-heading">Contact Info</h3>
                <p class="kdf-biz-name">KD Accounting &amp; Tax</p>
                <ul class="kdf-contact-list">
                    <li><a href="https://maps.app.goo.gl/6ZUSDpMDwzuPC92t8" target="_blank" rel="noopener noreferrer">162 Woodlawn Ave, Buffalo, NY 14208</a></li>
                    <li><a href="tel:+17165892665">(716) 589-2665</a></li>
                    <li><a href="mailto:sales@kdaccounts.com">sales@kdaccounts.com</a></li>
                </ul>

                <div class="kdf-map">
                    <iframe title="KD Accounting & Tax Google Map" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2225.7768014476023!2d-78.85885549999999!3d42.9140826!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89d313ce1bc950a3%3A0xd84ceefc1440ddfe!2sKD%20Accounting%20%26%20Tax!5e1!3m2!1sen!2slk!4v1785943552631!5m2!1sen!2slk" width="100%" height="150" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="strict-origin-when-cross-origin"></iframe>
                </div>
            </div>

        </div><!-- .kdf-columns -->

        <!-- Trust strip -->
        <div class="kdf-trust">
            <span class="kdf-trust-item"><span class="kdf-stars" aria-hidden="true">&#9733;&#9733;&#9733;&#9733;&#9733;</span> Five-Star Client Reviews</span>
            <span class="kdf-trust-sep" aria-hidden="true">&middot;</span>
            <span class="kdf-trust-item">Certified Accountants</span>
            <span class="kdf-trust-sep" aria-hidden="true">&middot;</span>
            <span class="kdf-trust-item">10+ Years Experience</span>
            <span class="kdf-trust-sep" aria-hidden="true">&middot;</span>
            <span class="kdf-trust-item">One-Stop Financial Solutions</span>
            <span class="kdf-trust-sep" aria-hidden="true">&middot;</span>
            <span class="kdf-trust-item">Serving Buffalo &amp; Western New York</span>
        </div>

        <!-- Bottom bar -->
        <div class="kdf-bottom">
            <p class="kdf-copy">&copy; <?php echo date('Y'); ?> <a href="<?php echo esc_url(home_url('/')); ?>">KD Accounting &amp; Tax</a>, Buffalo NY. All Rights Reserved.</p>
            <div class="kdf-bottom-links">
                <a href="tel:+17165892665" class="kdf-bottom-phone">(716) 589-2665</a>
                <span class="kdf-trust-sep" aria-hidden="true">&middot;</span>
                <a href="<?php echo esc_url(kd_get_dynamic_link('Terms & Conditions', 'terms-and-conditions')); ?>">Terms of Service</a>
                <span class="kdf-trust-sep" aria-hidden="true">&middot;</span>
                <a href="<?php echo esc_url(kd_get_dynamic_link('Privacy Policy', 'privacy-policy')); ?>">Privacy Policy</a>
                <span class="kdf-trust-sep" aria-hidden="true">&middot;</span>
                <a href="<?php echo esc_url(home_url('/sitemap_index.xml')); ?>">Sitemap</a>
            </div>
        </div>

    </div><!-- .container -->

    <!-- Floating Action Buttons -->
    <div class="floating-action-buttons">
        <a href="tel:+17165892665" class="floating-btn call-btn" aria-label="Call Us">
            <?php echo file_get_contents(get_template_directory() . '/assets/icons/phone.svg'); ?>
        </a>
        <a href="#" class="floating-btn scroll-to-top" aria-label="Scroll to top">
            <?php echo file_get_contents(get_template_directory() . '/assets/icons/arrow-up.svg'); ?>
        </a>
    </div>

</footer>
