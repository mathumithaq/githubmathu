<?php
/**
 * Tax Core Services Section
 * 
 * Used in Tax Services Template
 */

$data = wp_parse_args($args, [
    'subtitle' => '',
    'title' => '',
    'cards' => []
]);
?>
<section class="tax-section tax-core-services global-bg">
    <div class="container">
        <!-- Section Header -->
        <div class="tax-section-header text-left">
            <?php if (!empty($data['subtitle'])) : ?>
                <span class="section-subtitle"><?php echo esc_html($data['subtitle']); ?></span>
            <?php endif; ?>

            <?php if (!empty($data['title'])) : ?>
                <h2 class="section-title"><?php echo esc_html($data['title']); ?></h2>
            <?php endif; ?>
        </div>

        <!-- Cards Grid -->
        <?php if (!empty($data['cards']) && is_array($data['cards'])) : ?>
            <div class="tax-cards-grid">
                <?php foreach ($data['cards'] as $card) : ?>
                    <div class="tax-card">
                        <div class="tax-card-number"><?php echo esc_html($card['number']); ?></div>
                        <h3 class="tax-card-title"><?php echo esc_html($card['title']); ?></h3>
                        <p class="tax-card-text"><?php echo wp_kses_post($card['description']); ?></p>
                    <!--<a href="<//?php echo esc_url($card['link']); ?>" class="btn w-100 text-center">Service Details</a>-->
						<a href="<?php
							if ($card['number'] == '01') {
								echo esc_url(home_url('/tax-preparation/'));
							} elseif ($card['number'] == '02') {
								echo esc_url(home_url('/tax-planning-services/'));
							} elseif ($card['number'] == '03') {
								echo esc_url(home_url('/business-tax-services/'));
							}
						?>" class="btn w-100 text-center">Service Details</a>	
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</section>
