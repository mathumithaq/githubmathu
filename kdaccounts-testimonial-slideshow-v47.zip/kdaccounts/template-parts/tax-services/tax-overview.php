<?php
/**
 * Tax Overview Section
 * 
 * Used in Tax Services Template
 */

$data = wp_parse_args($args, [
    'subtitle' => '',
    'title' => '',
    'description' => '',
    'button_1_text' => '',
    'button_1_link' => '',
    'button_2_text' => '',
    'button_2_link' => '',
    'image' => ''
]);
?>
<section class="tax-section tax-overview">
    <div class="container">
        <!-- Top Text Content -->
        <div class="tax-overview-top-text" style="text-align: left; margin-bottom: 40px;">
            <?php if (!empty($data['subtitle'])) : ?>
                <span class="section-subtitle"><?php echo esc_html($data['subtitle']); ?></span>
            <?php endif; ?>

            <?php if (!empty($data['title'])) : ?>
                <h2 class="section-title"><?php echo esc_html($data['title']); ?></h2>
            <?php endif; ?>
        </div>
        <div class="tax-grid">
        <!-- Left Content -->
        <div class="tax-content-col">

            <?php if (!empty($data['description'])) : ?>
                <p class="section-description"><?php echo wp_kses_post($data['description']); ?></p>
            <?php endif; ?>

        </div>

        <!-- Right Image -->
        <div class="tax-image-col">
            <div class="tax-image-wrapper border-gold border-rounded-lg">
                <img src="<?php echo esc_url($data['image']); ?>" alt="<?php echo esc_attr($data['title']); ?>" loading="lazy" class="tax-img-wide">
            </div>
        </div>
    </div>
    </div>
</section>
