<?php
/**
 * Tax Hero Section
 * 
 * Used in Tax Services Template
 */

$data = wp_parse_args($args, [
    'subtitle' => '',
    'title' => '',
    'description' => '',
    'list' => [],
    'button_text' => '',
    'button_link' => '',
    'image' => ''
]);
?>
<section class="tax-section tax-hero">
    <div class="container">
        <!-- Top Text Content -->
        <div class="tax-hero-top-text" style="text-align: left; margin-bottom: 40px;">
            <?php if (!empty($data['subtitle'])) : ?>
                <span class="section-subtitle"><?php echo esc_html($data['subtitle']); ?></span>
            <?php endif; ?>

            <?php if (!empty($data['title'])) : ?>
                <h2 class="section-title"><?php echo esc_html($data['title']); ?></h2>
            <?php endif; ?>
        </div>

        <div class="tax-grid">
            <!-- Left Image -->
            <div class="tax-image-col">
                <div class="tax-image-wrapper border-gold border-rounded-lg">
                    <img src="<?php echo esc_url($data['image']); ?>" alt="<?php echo esc_attr($data['title']); ?>" loading="lazy" class="tax-img-tall">
                </div>
            </div>

            <!-- Right Content -->
            <div class="tax-content-col">

            <?php if (!empty($data['description'])) : ?>
                <p class="section-description"><?php echo wp_kses_post($data['description']); ?></p>
            <?php endif; ?>

            <?php if (!empty($data['list']) && is_array($data['list'])) : ?>
                <ul class="tax-check-list">
                    <?php foreach ($data['list'] as $item) : ?>
                        <li>
                            <span class="tax-check-icon">
                                <?php echo file_get_contents(get_template_directory() . '/assets/icons/icon-check.svg'); ?>
                            </span>
                            <?php echo wp_kses_post($item); ?>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>

            <?php if (!empty($data['button_text'])) : ?>
                <div class="tax-btn-wrapper">
                    <a href="<?php echo esc_url( home_url('/contact/') ); ?>" class="btn"><?php echo esc_html($data['button_text']); ?></a>
                </div>
            <?php endif; ?>
        </div>
    </div>
    </div>
</section>
