<section class="tax-business-extra">
    <div class="container">
        
        <div class="tax-section-header">
            <span class="section-subtitle">BUSINESS TAXATION</span>
            <h2 class="section-title">ALL-INCLUSIVE BUSINESS TAXATION IN BUFFALO, NY</h2>
        </div>

        <div class="tax-business-grid">
            
            <!-- Card 1 -->
            <div class="tax-business-card">
                <div class="tax-business-image">
                    <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/business-tax-prep.webp'); ?>" alt="Business Tax Preparation" width="800" height="800" loading="lazy">
                </div>
                <div class="tax-business-content">
                    <div class="tax-business-icon">
                        <?php echo file_get_contents(get_template_directory() . '/assets/icons/business-tax-prep.svg'); ?>
                    </div>
                    <h3 class="tax-business-title">BUSINESS TAX PREPARATION</h3>
                    <p class="tax-business-desc">Our business tax preparation services cover the full filing of government taxes. We thoroughly evaluate financial information and tax laws at the local, state, and federal levels to ensure accuracy and identify pertinent deductions and other legal compliance requirements. This approach to business taxes helps avoid filing errors, mitigate liability risk, and ensure your business is ahead in the market.</p>
                </div>
            </div>

            <!-- Card 2 -->
            <div class="tax-business-card">
                <div class="tax-business-image">
                    <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/business-tax-plan.webp'); ?>" alt="Business Tax Planning" width="800" height="800" loading="lazy">
                </div>
                <div class="tax-business-content">
                    <div class="tax-business-icon">
                        <?php echo file_get_contents(get_template_directory() . '/assets/icons/business-tax-plan.svg'); ?>
                    </div>
                    <h3 class="tax-business-title">BUSINESS TAX PLANNING</h3>
                    <p class="tax-business-desc">Our smart business tax planning enables you to manage taxes before you face any liability. We continuously evaluate strategies, provide direct tax advice, and assist businesses with operations in multiple jurisdictions. Proactive planning enables you to improve your cash flow, adapt to changes in tax laws, and make sound financial decisions toward your goals. We offer personalized tax planning sessions!</p>
                </div>
            </div>

            <!-- Card 3 -->
            <div class="tax-business-card">
                <div class="tax-business-image">
                    <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/business-audit.webp'); ?>" alt="Business Audit Support" width="800" height="800" loading="lazy">
                </div>
                <div class="tax-business-content">
                    <div class="tax-business-icon">
                        <?php echo file_get_contents(get_template_directory() . '/assets/icons/business-audit.svg'); ?>
                    </div>
                    <h3 class="tax-business-title">BUSINESS AUDIT SUPPORT</h3>
                    <p class="tax-business-desc">Professional business tax prep for audit support enables companies to navigate audits with clarity and control. We assist with organizing records and pre-audit evaluations, and serve as your representative in communications with revenue services. Our meticulous audit guidance is aimed at safeguarding your business interests, reducing interruptions, and giving you confidence in a well-prepared additional response to IRS audit questions.</p>
                </div>
            </div>

        </div>
    </div>
</section>
