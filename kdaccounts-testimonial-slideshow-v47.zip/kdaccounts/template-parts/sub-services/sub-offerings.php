<?php
/**
 * Dynamic Sub Service Offerings Section
 */

$page_id = get_queried_object_id();

// Fetch native custom fields
$subtitle = get_post_meta($page_id, 'sub_offer_subtitle', true);
$title = get_post_meta($page_id, 'sub_offer_title', true);
$desc = get_post_meta($page_id, 'sub_offer_desc', true);

// Fetch cards data (can be stored as JSON in 'sub_offer_cards_data' custom field)
$cards_json = get_post_meta($page_id, 'sub_offer_cards_data', true);

// Fallbacks
if (empty($subtitle)) { $subtitle = 'WHAT WE OFFER'; }
if (empty($title)) { $title = 'Our Accounting Services'; }

if (!empty($cards_json)) {
    $cards = json_decode($cards_json, true);
}

// Fallback to the hardcoded data if no custom field data exists
if (empty($cards) || !is_array($cards)) {
    global $post;
    $slug = $post->post_name;
    
    if ($slug === 'bookkeeping-services') {
        $cards = [
            [
                'title' => 'Transaction Recording & General Ledger Maintenance',
                'desc' => 'We help businesses keep their financial records organized by recording and categorizing all income, expenses, and transactions. Our general ledger maintenance ensures accuracy, simplifies tax preparation, and gives you a clear financial picture to guide your business decisions.<br><br>General ledger maintenance helps prevent errors, simplifies tax preparation, and provides a clear financial picture.',
                'style' => 'dark',
                'class' => 'offer-card-1'
            ],
            [
                'title' => 'Bank & Credit Card Reconciliation',
                'desc' => 'We reconcile your bank and credit card statements with your books to identify discrepancies, prevent fraud, and ensure your financial data remains accurate and reliable.',
                'style' => 'light',
                'class' => 'offer-card-2'
            ],
            [
                'title' => 'Payroll Processing & Employee Compensation',
                'desc' => 'Let us handle your payroll with precision and compliance. We provide:',
                'style' => 'light',
                'class' => 'offer-card-3',
                'lists' => [
                    [
                        'items' => [
                            'Timely employee wage calculations and direct deposits',
                            'Accurate tracking of timesheets, leave, commissions, and reimbursements',
                            'Compliance with tax regulations, including tax deductions and payroll filings',
                            'Sending payslips via email and managing superannuation payments',
                            'Accurate and timely processing of employee wages',
                            'Process superannuation payments',
                            'Tax deductions and payroll filings'
                        ]
                    ]
                ],
                'footer_desc' => 'Our payroll services ensure that your employees are paid on time and in full, while keeping you compliant with tax laws.'
            ],
            [
                'title' => 'Tax-Ready Bookkeeping & Compliance',
                'desc' => 'We make sure your books are always tax-ready, taking the stress out of tax season. Our services include:',
                'style' => 'dark',
                'class' => 'offer-card-4',
                'lists' => [
                    [
                        'items' => [
                            'Maintaining proper financial documentation for easy tax filing',
                            'Tracking deductible expenses and ensuring full compliance with tax regulations'
                        ]
                    ]
                ],
                'footer_desc' => 'Our goal is to keep your finances organized and ready for tax filing, so you can focus on your business, not the paperwork.',
                'button_text' => 'MORE TAX FILING SERVICES',
                'button_url' => '/tax-filing/'
            ],
            [
                'title' => 'Bookkeeping Clean-Up & Catch-Up Services',
                'desc' => 'If your financial records are messy or outdated, don\'t worry. We can help you get back on track by:',
                'style' => 'dark',
                'class' => 'offer-card-5',
                'lists' => [
                    [
                        'items' => [
                            'Cleaning up past financial data',
                            'Re-recording months of unrecorded transactions.'
                        ]
                    ]
                ],
                'footer_desc' => 'Are you ready to take the stress out of your bookkeeping? Contact KD Accounting & Tax for professional, reliable bookkeeping services in Buffalo, NY. Schedule a consultation today and let us help you manage your finances so you can focus on growing your business.'
            ],
            [
                'title' => 'Accounting Software Support',
                'desc' => 'We specialize in QuickBooks, Xero, and Excel, offering:',
                'style' => 'light',
                'class' => 'offer-card-6',
                'lists' => [
                    [
                        'items' => [
                            'Software setup and customization to fit your business needs',
                            'Troubleshooting and technical support when issues arise',
                            'Training sessions for business owners and staff, so you can manage your bookkeeping with confidence'
                        ]
                    ]
                ],
                'footer_desc' => 'Our experts ensure that your accounting software is running smoothly and that you\'re getting the most out of it.'
            ]
        ];
    } elseif ($slug === 'business-registration-services') {
        $cards = [
            [
                'title' => 'Help Choosing a Business Structure',
                'desc' => 'Selecting the right business structure is crucial for your growth. Whether you\'re starting a sole proprietorship, LLC, or corporation, we\'ll guide you through the pros and cons of each type, helping you choose the best fit based on your future goals and business needs.',
                'style' => 'dark',
                'class' => 'offer-card-1'
            ],
            [
                'title' => 'Business Name Registration',
                'desc' => 'A memorable business name is key to your success. We\'ll walk you through the process of choosing a name that aligns with your brand while ensuring compliance with local regulations. Let us help you avoid potential legal hurdles and establish a strong identity from day one.',
                'style' => 'light',
                'class' => 'offer-card-2'
            ],
            [
                'title' => 'Applying for Your EIN (Employer Identification Number)',
                'desc' => 'The EIN, or federal tax ID, is required for tax filings, business activities, and hiring employees. Our team will assist you in obtaining your EIN with ease, ensuring you meet all IRS requirements without any hassle.',
                'style' => 'light',
                'class' => 'offer-card-3'
            ],
            [
                'title' => 'Tax and Benefits Guidance',
                'desc' => 'Our experts will provide tailored advice on taxes, deductions, and benefits that apply to your business in Buffalo and Albany, NY. We\'ll help you understand your tax obligations and offer strategies to minimize your tax liabilities.',
                'style' => 'dark',
                'class' => 'offer-card-4'
            ],
            [
                'title' => 'Opening Business Bank Accounts',
                'desc' => 'Separate your personal and business finances by opening a dedicated business bank account. This is essential for protecting your personal assets and managing your business\'s finances. We\'ll recommend the best banks with competitive services and low fees to help you get started.',
                'style' => 'dark',
                'class' => 'offer-card-5'
            ],
            [
                'title' => 'Protecting Your Intellectual Property',
                'desc' => 'If your business relies on unique ideas, trademarks, or inventions, safeguarding your intellectual property is crucial. We\'ll guide you through the process of registering patents and trademarks, ensuring your valuable assets are legally protected.',
                'style' => 'light',
                'class' => 'offer-card-6'
            ],
            [
                'title' => 'Setting Up Accounting and Record-Keeping Systems',
                'desc' => 'Efficient accounting and record-keeping are vital for staying compliant and making informed business decisions. We\'ll help you choose and implement the best accounting systems, streamline your processes, and maintain accurate financial records for growth and tax compliance.',
                'style' => 'light',
                'class' => 'offer-card-7'
            ]
        ];
    } elseif ($slug === 'tax-filing' || $slug === 'tax-filing-services') {
        $cards = [
            [
                'title' => 'Tax Preparation and Filing',
                'desc' => 'Navigating your tax return doesn\'t have to be a daunting task. Our team of experts in Buffalo, NY, provides comprehensive tax preparation and filing services to ensure your tax return is accurate and stress-free. We specialize in:',
                'style' => 'dark',
                'class' => 'offer-card-1',
                'lists' => [
                    [
                        'items' => [
                            "Reviewing Your Tax Return:\nWe double-check your return to identify potential issues that the IRS might flag.",
                            "Online Filing for Quick Refunds:\nWe help you file your return online for fast processing and quicker refunds.",
                            "Maximizing Tax Deductions:\nWe highlight potential deductions to reduce your tax liability for the coming year.",
                            "Expected Refund Timeline:\nProviding guidance on the expected timeline for receiving a refund and instructions on how to track its status."
                        ]
                    ],
                    [
                        'heading' => 'We also assist with important tax documents, including:',
                        'items' => [
                            "Form 1040:\nThe standard individual income tax return form.",
                            "Form 1099:\nUsed for reporting various types of income other than wages, salaries, and tips.",
                            "Form W-2:\nThe wage and tax statement form that reports annual wages and the amount of taxes withheld."
                        ]
                    ]
                ],
                'footer_desc' => 'We guide you through the entire process, including when to expect a refund and how to track it.'
            ],
            [
                'title' => 'Tax Planning',
                'desc' => 'Want to minimize your tax liability and maximize your refunds? Our personalized tax planning strategies help reduce your tax burdens and save you money. We offer comprehensive tax planning services, including:',
                'style' => 'light',
                'class' => 'offer-card-2',
                'lists' => [
                    [
                        'items' => [
                            "Income Tax Planning:\nStrategies to minimize taxable income and maximize deductions.",
                            "Retirement Tax Planning:\nPlans to reduce taxes on retirement income and investments.",
                            "Estate Tax Planning:\nAssistance in reducing the estate tax burden for heirs and beneficiaries.",
                            "Business Tax Planning:\nEffective strategies for reducing business taxes and optimizing cash flow."
                        ]
                    ]
                ],
                'footer_desc' => 'Proper tax planning ensures you take full advantage of tax credits and benefits available to you, keeping you ahead of the curve!'
            ],
            [
                'title' => 'Tax Problems & IRS Issues',
                'desc' => 'Dealing with tax issues can be overwhelming. Whether you\'re facing payroll tax problems, unpaid returns, or an IRS audit, we are here to help resolve these challenges. Our tax professionals offer support in:',
                'style' => 'light',
                'class' => 'offer-card-3',
                'lists' => [
                    [
                        'items' => [
                            "Payroll Tax Problems:\nAssistance with correcting payroll tax issues for businesses.",
                            "Non-Filed Tax Returns:\nHelp filing missing tax returns and resolving penalties.",
                            "IRS Audit Representation:\nRepresentation and guidance during an IRS audit to ensure your rights are protected.",
                            "Tax Debt Relief:\nNegotiating payment plans or settling tax debts to reduce financial stress."
                        ]
                    ]
                ]
            ],
            [
                'title' => 'Business Tax Services',
                'desc' => 'For businesses in Buffalo, NY, managing taxes can be complicated. Whether you\'re a small startup or an established corporation, we offer reliable business tax services, including:',
                'style' => 'dark',
                'class' => 'offer-card-4',
                'lists' => [
                    [
                        'items' => [
                            "Business Tax Planning:\nTailored strategies to reduce taxes and improve financial health.",
                            "Business Tax Preparation:\nAccurate and efficient preparation of business tax returns.",
                            "Business Tax Accounting:\nEnsuring your business complies with tax laws and regulations."
                        ]
                    ]
                ],
                'footer_desc' => 'With our expertise in KD Accounting and Bookkeeping, your business can stay compliant, avoid penalties, and keep your tax filings accurate and timely.'
            ]
        ];
    } else {
        // Accounting Services & Default Fallback
        $cards = [
            [
                'title' => 'Financial Statements Preparation',
                'desc' => 'We prepare accurate and reliable financial statements to help businesses monitor their financial health, make informed decisions, and ensure compliance with regulatory standards.',
                'style' => 'dark',
                'class' => 'offer-card-1',
                'has_sparkle' => true,
                'lists' => [
                    [
                        'items' => [
                            "Statement of Financial Position\n(formerly Balance Sheet)",
                            "Statement of Comprehensive Income\n(formerly Income Statement/Profit & Loss Report)",
                            "Statement of Cash Flows\n(formerly Cash Flow Statement)",
                            "Statement of Changes in Equity\n(formerly Statement of Retained Earnings)"
                        ]
                    ]
                ]
            ],
            [
                'title' => 'Accounts Payable & Receivable Management',
                'desc' => 'Our accounts payable and receivable services are designed to ensure that your business maintains healthy cash flow by efficiently managing both vendor payments and customer collections. We focus on optimizing processes to reduce costs and streamline operations.',
                'style' => 'light',
                'class' => 'offer-card-2',
                'lists' => [
                    [
                        'heading' => '01. Accounts Payable Management:',
                        'desc' => 'Organize and track vendor payments',
                        'items' => [
                            'Vendor Payment Organization.',
                            'Cash Flow Optimization.',
                            'Negotiating Payment Terms.',
                            'Reconciliation & Compliance.',
                            'Accurate Financial Reporting.',
                            'Aging Analysis.'
                        ]
                    ],
                    [
                        'heading' => '02. Accounts Receivable Management',
                        'items' => [
                            'Credit Policy Development.',
                            'Invoice Generation & Timeliness.',
                            'Monitoring Receivables.',
                            'Collections & Follow-Up.',
                            'Dispute Resolution.',
                            'Cash Flow Monitoring.',
                            'Aging Analysis.'
                        ]
                    ]
                ]
            ],
            [
                'title' => 'Budgeting, Forecasting & KPI Analysis',
                'desc' => 'Our budgeting, forecasting, and KPI analysis services offer essential tools to steer your business toward financial success by providing clear financial insights and actionable data.',
                'style' => 'light',
                'class' => 'offer-card-3',
                'lists' => [
                    [
                        'heading' => '01. Budgeting & Financial Planning',
                        'desc' => 'We work with you to develop comprehensive budgets that align with your business goals and ensure optimal resource allocation.',
                        'items' => [
                            'Sales Budget.',
                            'Purchase Budget.',
                            'Cash Budget.',
                            'Operating Budget.',
                            'Capital Expenditure Budget.'
                        ]
                    ],
                    [
                        'heading' => '02. Forecasting',
                        'desc' => 'We provide data-driven forecasting to help your business make informed decisions about its financial future.',
                        'items' => [
                            'Revenue Forecasting.',
                            'Expense Forecasting.',
                            'Cash Flow Forecasting.'
                        ]
                    ],
                    [
                        'heading' => '03. KPI Tracking',
                        'desc' => 'We track and analyze key performance indicators (KPIs) to assess your financial health and operational efficiency.',
                        'items' => [
                            'Financial Performance Metrics.',
                            'Liquidity Ratios.',
                            'Profitability Ratios.',
                            'Operational Efficiency.'
                        ]
                    ]
                ]
            ],
            [
                'title' => 'Outsourced Accounting Solutions',
                'desc' => 'For businesses looking to reduce overhead and improve operational efficiency, we offer tailored Outsourced Accounting Packages designed to meet the unique needs of your organization. Our expert team manages your accounting functions, allowing you to focus on what matters most—growing your business and achieving long-term success.',
                'style' => 'dark',
                'class' => 'offer-card-4',
                'lists' => [
                    [
                        'items' => [
                            'Full-Service Accounting Packages.',
                            'Custom Accounting Solutions.',
                            'Cloud-Based Accounting Services.',
                            'Payroll Processing & Compliance.',
                            'Financial Reporting & Analysis.',
                            'Tax Preparation & Planning.',
                            'Accounts Payable & Receivable Management.',
                            'Business Consulting & Strategic Planning.'
                        ]
                    ]
                ]
            ]
        ];
    }
}

// Override with Native Custom Fields if they exist
foreach ($cards as $i => &$card) {
    $card_num = $i + 1;
    
    // Override Card Title
    $custom_title = get_post_meta($page_id, 'offer_card_' . $card_num . '_title', true);
    if (!empty($custom_title)) {
        $card['title'] = $custom_title;
    }
    
    // Add Card Description
    $custom_desc = get_post_meta($page_id, 'offer_card_' . $card_num . '_desc', true);
    if (!empty($custom_desc)) {
        $card['desc'] = $custom_desc;
    }
    
    // Override Lists/Columns
    if (isset($card['lists']) && is_array($card['lists'])) {
        foreach ($card['lists'] as $j => &$list) {
            $col_num = $j + 1;
            
            // Override Column Heading
            $custom_heading = get_post_meta($page_id, 'offer_card_' . $card_num . '_col_' . $col_num . '_heading', true);
            if (!empty($custom_heading)) {
                $list['heading'] = $custom_heading;
            }
            
            // Override Column Items
            $custom_items = get_post_meta($page_id, 'offer_card_' . $card_num . '_col_' . $col_num . '_item', false);
            if (!empty($custom_items)) {
                $list['items'] = $custom_items;
            }
        }
    }
}
unset($card, $list); // Break references

?>

<section class="sub-offerings-section">
    <div class="container">
        
        <div class="sub-offerings-header">
            <?php if (!empty($subtitle)) : ?>
                <span class="section-subtitle"><?php echo esc_html($subtitle); ?></span>
            <?php endif; ?>
            <h2><?php echo wp_kses_post($title); ?></h2>
            <?php if (!empty($desc)) : ?>
                <p class="sub-offerings-desc"><?php echo wp_kses_post($desc); ?></p>
            <?php endif; ?>
        </div>

        <div class="offerings-grid">
            <?php foreach ($cards as $index => $card) : 
                $card_num = str_pad($index + 1, 2, '0', STR_PAD_LEFT);
            ?>
                <div class="offer-card">
                    <h3 class="offer-card-title">
                        <span class="offer-card-num"><?php echo esc_html($card_num); ?>.</span>
                        <?php echo esc_html($card['title']); ?>
                    </h3>
                    
                    <?php if (!empty($card['desc'])) : ?>
                        <p class="offer-card-desc" style="margin-top: -10px; margin-bottom: 20px; font-size: 0.95rem; opacity: 0.9; line-height: 1.5;"><?php echo wp_kses_post($card['desc']); ?></p>
                    <?php endif; ?>
                    
                    <div class="offer-card-lists">
                        <?php if (!empty($card['lists'])) : ?>
                            <?php foreach ($card['lists'] as $list) : ?>
                                <div class="offer-list-column">
                                    <?php if (!empty($list['heading'])) : ?>
                                        <h4 class="offer-list-heading"><?php echo wp_kses_post($list['heading']); ?></h4>
                                    <?php endif; ?>
                                    
                                    <?php if (!empty($list['desc'])) : ?>
                                        <p class="offer-list-desc" style="font-size: 0.9rem; opacity: 0.9; margin-top: -10px; margin-bottom: 15px; line-height: 1.5;"><?php echo wp_kses_post($list['desc']); ?></p>
                                    <?php endif; ?>
                                    
                                    <?php if (!empty($list['items'])) : ?>
                                        <ul class="offer-list">
                                            <?php foreach ($list['items'] as $item) : 
                                                // Handle newlines in items for bold heading vs text
                                                $parts = explode('\n', $item);
                                                if (count($parts) === 1) {
                                                    $parts = explode("\n", $item); // Handle actual newlines if decoded from JSON
                                                }
                                            ?>
                                                <li>
                                                    <span class="offer-bullet"></span>
                                                    <div class="offer-item-content">
                                                        <?php if (count($parts) > 1) : ?>
                                                            <strong><?php echo esc_html($parts[0]); ?></strong>
                                                            <span><?php echo esc_html($parts[1]); ?></span>
                                                        <?php else: ?>
                                                            <span><?php echo esc_html($item); ?></span>
                                                        <?php endif; ?>
                                                    </div>
                                                </li>
                                            <?php endforeach; ?>
                                        </ul>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                    
                    <?php if (!empty($card['footer_desc'])) : ?>
                        <p class="offer-card-footer-desc" style="margin-top: 20px; margin-bottom: 0; font-size: 0.95rem; opacity: 0.9; line-height: 1.5;"><?php echo wp_kses_post($card['footer_desc']); ?></p>
                    <?php endif; ?>
                    
                    <?php if (!empty($card['button_text']) && !empty($card['button_url'])) : ?>
                        <div style="margin-top: 25px;">
                            <a href="<?php echo esc_url($card['button_url']); ?>" class="btn-outline"><?php echo esc_html($card['button_text']); ?></a>
                        </div>
                    <?php endif; ?>                </div>
            <?php endforeach; ?>
        </div>
        
    </div>

    <?php get_template_part('partials/call-us'); ?>
</section>
