<header class="site-header">
    <div class="container">
        <div class="site-logo">
            <a href="<?php echo esc_url( home_url( '/' ) ); ?>">
                <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/logo.webp' ); ?>" alt="<?php bloginfo('name'); ?> Logo">
            </a>
        </div>
        <div class="header-right">
            <button class="menu-toggle" aria-controls="primary-menu" aria-expanded="false" aria-label="Toggle navigation">
                <span class="hamburger-box">
                    <span class="hamburger-inner"></span>
                </span>
            </button>
        </div>
        
        <nav class="main-navigation">
            <!-- Mobile Sidebar Header (Visible only on mobile) -->
            <div class="mobile-sidebar-header">
                <a href="<?php echo esc_url( home_url( '/' ) ); ?>">
                    <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/logo.webp' ); ?>" alt="<?php bloginfo('name'); ?> Logo">
                </a>
                <button class="menu-close" aria-label="Close menu"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="24" height="24"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg></button>
            </div>
            
            <ul>
                <?php 
                global $wp;
                $current_url = home_url(add_query_arg(array(), $wp->request)) . '/';
                $home_url = trailingslashit(home_url());
                $is_home_active = ($current_url === $home_url) ? 'active' : '';
                ?>
                <li><a href="<?php echo esc_url( $home_url ); ?>" class="<?php echo $is_home_active; ?>">Home</a></li>
                <li><a href="<?php echo esc_url( kd_get_dynamic_link('About Us', 'about') ); ?>" class="<?php echo is_page( 'about' ) ? 'active' : ''; ?>">About Us</a></li>
                <li class="has-dropdown <?php echo ( is_page('accounting-services') || is_page('bookkeeping-services') || is_page('business-registration-services') || is_page('payroll-services') ) ? 'current-menu-ancestor' : ''; ?>">
                    <a href="#">Accounting <span class="dropdown-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="16" height="16"><polyline points="6 9 12 15 18 9"></polyline></svg></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="<?php echo esc_url( kd_get_dynamic_link('Accounting Services', 'accounting-services') ); ?>" class="<?php echo is_page( 'accounting-services' ) ? 'active' : ''; ?>">Accounting Services</a></li>
                        <li><a href="<?php echo esc_url( kd_get_dynamic_link('Bookkeeping Services', 'bookkeeping-services') ); ?>" class="<?php echo is_page( 'bookkeeping-services' ) ? 'active' : ''; ?>">Bookkeeping Services</a></li>
                        <li><a href="<?php echo esc_url( kd_get_dynamic_link('Business Registration Services', 'business-registration-services') ); ?>" class="<?php echo is_page( 'business-registration-services' ) ? 'active' : ''; ?>">Business Registration Services</a></li>
                    </ul>
                </li>
                <li class="has-dropdown <?php echo ( is_page('tax-services') || is_page('tax-preparation') || is_page('tax-planning') || is_page('tax-filing') || is_page('business-tax') || is_page('business-tax-services') ) ? 'current-menu-ancestor' : ''; ?>">
                    <a href="#">Tax Services <span class="dropdown-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="16" height="16"><polyline points="6 9 12 15 18 9"></polyline></svg></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="<?php echo esc_url( kd_get_dynamic_link('Tax Preparation', 'tax-preparation') ); ?>" class="<?php echo is_page( 'tax-preparation' ) ? 'active' : ''; ?>">Tax Preparation</a></li>
                        <li><a href="<?php echo esc_url( kd_get_dynamic_link('Tax Planning Services', 'tax-planning-services') ); ?>" class="<?php echo is_page( 'tax-planning' ) ? 'active' : ''; ?>">Tax Planning Services</a></li>
                        <li><a href="<?php echo esc_url( kd_get_dynamic_link('Tax Filing Services', 'tax-filing') ); ?>" class="<?php echo is_page( 'tax-filing' ) ? 'active' : ''; ?>">Tax Filing Services</a></li>
                        <li><a href="<?php echo esc_url( kd_get_dynamic_link('Business Tax Services', 'business-tax-services') ); ?>" class="<?php echo is_page( 'business-tax' ) ? 'active' : ''; ?>">Business Tax Services</a></li>
                    </ul>
                </li>
                <li class="has-dropdown <?php echo ( is_page('pricing-plan') || is_page('blog') || is_home() || is_singular('post') ) ? 'current-menu-ancestor' : ''; ?>">
                    <a href="#">Know Us <span class="dropdown-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="16" height="16"><polyline points="6 9 12 15 18 9"></polyline></svg></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="<?php echo esc_url( kd_get_dynamic_link('Pricing Plan', 'pricing-plan') ); ?>" class="<?php echo is_page( 'pricing-plan' ) ? 'active' : ''; ?>">Pricing Plan</a></li>
                        <li><a href="<?php echo esc_url( home_url( '/blog/' ) ); ?>" class="<?php echo ( is_home() || is_singular('post') ) ? 'active' : ''; ?>">Blog</a></li>
                        <li><a href="<?php echo esc_url( home_url( '/podcasts/' ) ); ?>" class="<?php echo ( is_post_type_archive('podcast') || is_singular('podcast') ) ? 'active' : ''; ?>">Podcasts</a></li>
                    </ul>
                </li>
                <li><a href="<?php echo esc_url( kd_get_dynamic_link('Contact Us', 'contact') ); ?>" class="<?php echo is_page( 'contact' ) ? 'active' : ''; ?>">Contact Us</a></li>
            </ul>
            
        </nav>
<div class="header-cta">
    <a href="tel:+17165892665" class="btn-header">(716) 589-2665</a>
        </div>
    </div>
</header>
