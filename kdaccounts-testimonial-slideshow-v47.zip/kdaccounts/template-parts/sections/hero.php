<?php
/**
 * Hero — content slider + inline consultation form.
 * Slides rotate background photo and headline together (6s, pause on hover,
 * static for prefers-reduced-motion). Form posts to the LeadConnector webhook
 * with hero-specific element IDs so it can coexist with the contact-section form.
 * Previous static hero backed up in hero.php.bak-20260819.
 */
$kda_img = get_template_directory_uri() . '/assets/images/';
?>
<section class="kda-hero" id="kda-hero">

    <div class="kda-hero-slides" aria-hidden="true">
        <img class="kda-hero-slide active" src="<?php echo esc_url($kda_img . 'hero-slide-1.webp'); ?>" alt="" width="1920" height="1080" fetchpriority="high" decoding="async">
        <img class="kda-hero-slide" src="<?php echo esc_url($kda_img . 'hero-slide-2.webp'); ?>" alt="" width="1920" height="1080" loading="lazy" decoding="async">
        <img class="kda-hero-slide" src="<?php echo esc_url($kda_img . 'hero-slide-3.webp'); ?>" alt="" width="1920" height="1080" loading="lazy" decoding="async">
    </div>
    <div class="kda-hero-scrim"></div>

    <div class="container kda-hero-inner">

        <div class="kda-hero-left">
            <span class="kda-hero-eyebrow">Certified &middot; Buffalo, NY</span>

            <div class="kda-hero-copy">
                <div class="kda-hero-text active">
                    <h1 class="kda-hero-title">Your Certified Buffalo Accounting Partner <span class="hl">Built on Trust</span></h1>
                    <p class="kda-hero-sub">More than an accounting firm &mdash; a certified guide committed to your financial peace of mind. Our team with 10+ years of experience will lead you to financial confidence.</p>
                    <div class="kda-hero-ctas">
                        <a href="<?php echo esc_url(home_url('/contact/')); ?>" class="btn">Schedule an Appointment</a>
                        <a href="<?php echo esc_url(home_url('/#services')); ?>" class="kda-hero-link">Explore Services &rarr;</a>
                    </div>
                </div>
                <div class="kda-hero-text">
                    <h2 class="kda-hero-title">Stress-Free <span class="hl">Tax Season</span> Starts Here</h2>
                    <p class="kda-hero-sub">Accurate preparation, proactive planning, and IRS support for individuals and businesses &mdash; so you keep more of what you earn and never miss a deadline.</p>
                    <div class="kda-hero-ctas">
                        <a href="<?php echo esc_url(home_url('/contact/')); ?>" class="btn">Get Tax Help</a>
                        <a href="<?php echo esc_url(home_url('/tax-preparation/')); ?>" class="kda-hero-link">Tax Services &rarr;</a>
                    </div>
                </div>
                <div class="kda-hero-text">
                    <h2 class="kda-hero-title">Books Balanced. <span class="hl">Payroll on Time.</span> Every Month.</h2>
                    <p class="kda-hero-sub">Precise bookkeeping, reliable payroll, and clean financial records that keep your Buffalo business compliant &mdash; and ready to grow.</p>
                    <div class="kda-hero-ctas">
                        <a href="<?php echo esc_url(home_url('/contact/')); ?>" class="btn">Talk to an Accountant</a>
                        <a href="<?php echo esc_url(home_url('/services/bookkeeping-services/')); ?>" class="kda-hero-link">Bookkeeping &rarr;</a>
                    </div>
                </div>
            </div>

            <div class="kda-hero-dots" role="tablist" aria-label="Hero slides">
                <button type="button" class="kda-hero-dot active" aria-label="Slide 1"><span class="fill"></span></button>
                <button type="button" class="kda-hero-dot" aria-label="Slide 2"><span class="fill"></span></button>
                <button type="button" class="kda-hero-dot" aria-label="Slide 3"><span class="fill"></span></button>
            </div>
        </div>

        <aside class="kda-hero-form">
            <?php get_template_part('partials/form/hero-form'); ?>
        </aside>

    </div>
</section>

<script>
(function () {
    /* ---- Slider ---- */
    var hero = document.getElementById('kda-hero');
    if (!hero) return;
    var slides = hero.querySelectorAll('.kda-hero-slide'),
        texts  = hero.querySelectorAll('.kda-hero-text'),
        dots   = hero.querySelectorAll('.kda-hero-dot'),
        idx = 0, timer = null,
        reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    function go(n) {
        idx = n % slides.length;
        slides.forEach(function (s, i) { s.classList.toggle('active', i === idx); });
        texts.forEach(function (t, i) { t.classList.toggle('active', i === idx); });
        dots.forEach(function (d, i) {
            d.classList.remove('active');
            var f = d.querySelector('.fill');
            f.style.transition = 'none'; f.style.width = '0';
            void f.offsetWidth;
            if (i === idx) { d.classList.add('active'); f.style.transition = ''; }
        });
    }
    function arm() {
        if (reduced) return;
        clearInterval(timer);
        timer = setInterval(function () { go(idx + 1); }, 6000);
    }
    dots.forEach(function (d, i) {
        d.addEventListener('click', function () { go(i); arm(); });
    });
    hero.addEventListener('mouseenter', function () { clearInterval(timer); });
    hero.addEventListener('mouseleave', arm);
    arm();

})();
</script>
