<?php
/**
 * Latest Posts / Article Section — header row with "View All" link,
 * cards aligned with the blog-listing card design (chip, excerpt, read link).
 * Previous version: latest-posts.php.bak-20260821
 */
?>
<section class="latest-posts-section bk-guides" id="related-bookkeeping-guides">
    <div class="container">

        <div class="posts-header kda-lp-header">
            <div class="kda-lp-heading">
                <span class="section-subtitle">FROM THE BLOG</span>
                <h2 class="posts-main-title">Related Bookkeeping Guides</h2>
            </div>
            <a class="kda-lp-viewall" href="<?php echo esc_url( home_url('/blog/') ); ?>">View All Articles <span aria-hidden="true">&rarr;</span></a>
        </div>

        <div class="posts-grid kda-lp-grid">
            <?php
            // Only the six selected bookkeeping guides, in screenshot order.
            $guide_slugs = array(
                'bookkeeping-services-cost-buffalo-ny',
                'what-is-recording-transactions-definition-steps-and-examples',
                'monthly-accounting-checklist-small-business',
                'accounting-for-contractors-buffalo-ny',
                'restaurants-retail-bookkeeping-solutions-buffalo-ny',
                'bookkeeping-for-law-firms-buffalo-ny-legal-accounting-guide',
            );
            $guide_ids = array();
            foreach ($guide_slugs as $guide_slug) {
                $guide_post = get_page_by_path($guide_slug, OBJECT, 'post');
                if ($guide_post && 'publish' === $guide_post->post_status) {
                    $guide_ids[] = (int) $guide_post->ID;
                }
            }
            $latest_posts = new WP_Query(array(
                'post_type' => 'post',
                'posts_per_page' => 6,
                'post_status' => 'publish',
                'post__in' => $guide_ids ? $guide_ids : array(0),
                'orderby' => 'post__in',
                'ignore_sticky_posts' => true,
                'no_found_rows' => true,
            ));

            if ($latest_posts->have_posts()) :
                while ($latest_posts->have_posts()) : $latest_posts->the_post();
                    $kda_cats = get_the_category();
            ?>
                <article class="post-card kda-lp-card">
                    <div class="post-image-wrapper kda-lp-image">
                        <a href="<?php the_permalink(); ?>" aria-label="<?php echo esc_attr(sprintf(__('Read more about %s', 'kdaccounts'), get_the_title())); ?>">
                            <?php if (has_post_thumbnail()) : ?>
                                <?php the_post_thumbnail('medium_large', ['loading' => 'lazy']); ?>
                            <?php else : ?>
                                <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/about-2.webp'); ?>" alt="<?php the_title_attribute(); ?>" loading="lazy">
                            <?php endif; ?>
                        </a>
                        <?php if ( ! empty( $kda_cats ) ) : ?>
                            <a class="blog-card-cat" href="<?php echo esc_url( get_category_link( $kda_cats[0] ) ); ?>"><?php echo esc_html( $kda_cats[0]->name ); ?></a>
                        <?php endif; ?>
                    </div>
                    <div class="post-content kda-lp-content">
                        <div class="post-meta kda-lp-meta">
                            <span><?php echo get_the_date('M j, Y'); ?></span>
                            <span class="kda-lp-dot" aria-hidden="true">&middot;</span>
                            <span><?php the_author(); ?></span>
                        </div>
                        <h3 class="post-title kda-lp-title">
                            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                        </h3>
                        <p class="kda-lp-excerpt"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 18, '&hellip;' ) ); ?></p>
                        <a href="<?php the_permalink(); ?>" class="blog-card-link">Read Article <span aria-hidden="true">&rarr;</span></a>
                    </div>
                </article>
            <?php
                endwhile;
                wp_reset_postdata();
            else :
            ?>
                <p>The selected bookkeeping guides are not published yet.</p>
            <?php endif; ?>
        </div>
        <p class="bk-bottom-call"><strong>Rather talk to an expert?</strong> <a class="btn bk-phone-button" href="tel:+17165892665">Call Us (716) 589-2665</a></p>
    </div>
</section>
