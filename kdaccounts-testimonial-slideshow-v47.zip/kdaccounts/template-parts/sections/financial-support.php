﻿<?php
/**
 * Financial Support Section
 */
?>
<section class="financial-support-section">
    <div class="container">
        
        <div class="fs-header">
            <span class="section-subtitle">FINANCIAL SUPPORT</span>
            <h2 class="fs-main-title">WE'RE YOUR TRUSTED AND RELIABLE FINANCIAL SUPPORT</h2>
        </div>
        
        <div class="fs-grid">
            
            <!-- Card 1: Text -->
            <div class="fs-card fs-text-card">
                <div class="fs-icon">
                    <?php echo file_get_contents(get_template_directory() . '/assets/icons/tax-prep.svg'); ?>
                </div>
                <h3 class="fs-card-title">PROFESSIONAL TAX PREPARATION</h3>
                <p class="fs-card-text">We offer professional tax preparation services tailored to your finances. From income tax help to business tax prep, with legal compliance.</p>
            </div>
            
            <!-- Card 2: Image -->
            <div class="fs-card fs-image-card">
                <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/fs-boardroom.webp'); ?>" alt="Professional Tax Preparation" loading="lazy">
            </div>
            
            <!-- Card 3: Text -->
            <div class="fs-card fs-text-card">
                <div class="fs-icon">
                    <?php echo file_get_contents(get_template_directory() . '/assets/icons/cpa.svg'); ?>
                </div>
                <h3 class="fs-card-title">CERTIFIED PUBLIC ACCOUNTANTS</h3>
                <p class="fs-card-text">Accurate bookkeeping solution from our certified public accountants, ensuring timely financial guidance, compliance, and business growth.</p>
            </div>
            
            <!-- Card 4: Image -->
            <div class="fs-card fs-image-card">
                <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/feature-individual.webp'); ?>" alt="Certified Public Accountants" loading="lazy">
            </div>
            
            <!-- Card 5: Text -->
            <div class="fs-card fs-text-card">
                <div class="fs-icon">
                    <?php echo file_get_contents(get_template_directory() . '/assets/icons/software.svg'); ?>
                </div>
                <h3 class="fs-card-title">ACCOUNTING SOFTWARE SUPPORT</h3>
                <p class="fs-card-text">Our bookkeeping software assistance offers setup, personalization, troubleshooting, and training sessions for Xero, Excel, and QuickBooks.</p>
            </div>
            
            <!-- Card 6: Image -->
            <div class="fs-card fs-image-card">
                <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/solutions-consultation.webp'); ?>" alt="Accounting Software Support" loading="lazy">
            </div>

        </div>
    </div>

    <?php get_template_part('partials/call-us'); ?>
</section>

