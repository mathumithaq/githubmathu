<?php
/**
 * Contact page main section — info cards, map, and form.
 * Previous version in bak-doc-changes-20260819/.
 */
?>
<section class="contactsec-section kda-contact-revamp">
    <div class="container">

        <div class="text-center" style="margin-bottom: 18px;">
            <span class="section-subtitle">Get In Touch</span>
            <h2 class="kda-contact-title">Connect With Us</h2>
            <p class="kda-contact-sub">Give us a call, send an email, or drop a message with the form &mdash; we respond within one business day. Prefer to talk in person? Visit our Buffalo, NY office.</p>
        </div>

        <!-- Info cards -->
        <div class="kda-contact-cards">
            <a class="kda-contact-card" href="tel:+17165892665">
                <span class="kda-cc-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg></span>
                <span class="kda-cc-label">Call Us</span>
                <span class="kda-cc-value">(716) 589-2665</span>
            </a>
            <a class="kda-contact-card" href="mailto:sales@kdaccounts.com">
                <span class="kda-cc-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg></span>
                <span class="kda-cc-label">Email Us</span>
                <span class="kda-cc-value">sales@kdaccounts.com</span>
            </a>
            <a class="kda-contact-card" href="https://maps.app.goo.gl/6ZUSDpMDwzuPC92t8" target="_blank" rel="noopener noreferrer">
                <span class="kda-cc-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg></span>
                <span class="kda-cc-label">Visit Us</span>
                <span class="kda-cc-value">162 Woodlawn Ave, Buffalo, NY 14208</span>
            </a>
            <a class="kda-contact-card" href="https://share.google/4U4qnqwcqc2vbs63r" target="_blank" rel="noopener noreferrer">
                <span class="kda-cc-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg></span>
                <span class="kda-cc-label">Google Reviews</span>
                <span class="kda-cc-value">Read our five-star reviews</span>
            </a>
        </div>

        <div class="contactsec-grid">

            <!-- Left: Map -->
            <div class="contactsec-left">
                <div class="contactsec-map kda-contact-map">
                    <iframe class="lazy-map" title="Google Maps Location" data-src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2225.7768014476023!2d-78.85885549999999!3d42.9140826!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89d313ce1bc950a3%3A0xd84ceefc1440ddfe!2sKD%20Accounting%20%26%20Tax!5e1!3m2!1sen!2slk!4v1785943552631!5m2!1sen!2slk" width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="strict-origin-when-cross-origin"></iframe>
                </div>
            </div>

            <!-- Right: Form -->
            <div class="contactsec-right">
                <div class="ghl-form-wrapper">
                    <?php get_template_part('partials/form/form'); ?>
                </div>
            </div>

        </div>

        <?php get_template_part('partials/call-us'); ?>
    </div>
</section>
