<?php
/**
 * Features / Who We Serve — three audience cards.
 * Previous zig-zag layout: features.php.bak-20260821
 */
$kda_img = get_template_directory_uri() . '/assets/images/';
$kda_audiences = [
    [
        'num'   => '01',
        'icon'  => 'business.svg',
        'image' => 'feature-business.webp?v=3',
        'title' => 'For Businesses',
        'text'  => 'From startups to established companies, we give Buffalo businesses the financial foundation to grow — accurate books, smart tax strategy, payroll, and compliance handled by one certified team.',
        'link'  => home_url('/business-tax-services/'),
        'cta'   => 'Business Services',
    ],
    [
        'num'   => '02',
        'icon'  => 'individual.svg',
        'image' => 'feature-individual.webp?v=3',
        'title' => 'For Individuals',
        'text'  => 'Stress-free personal tax preparation and planning. We help you file accurately, maximize deductions, resolve IRS notices, and make confident decisions about your financial future.',
        'link'  => home_url('/tax-preparation/'),
        'cta'   => 'Personal Tax Help',
    ],
    [
        'num'   => '03',
        'icon'  => 'resources.svg',
        'image' => 'feature-resources.webp?v=3',
        'title' => 'Resources',
        'text'  => 'Financial success starts with being well-informed. Our guides, tips, and tools on taxes, bookkeeping, and business finances help you make the right move at every step.',
        'link'  => home_url('/blog/'),
        'cta'   => 'Read Our Guides',
    ],
];
?>
<section class="features-section kda-features">
    <div class="container">

        <div class="kda-features-header">
            <span class="section-subtitle">Who We Serve</span>
            <h2 class="kda-features-title">Smart Financial Services for Businesses, Individuals &amp; More</h2>
            <p class="kda-features-sub">Whatever your situation, KD Accounting &amp; Tax brings the same certified expertise and personal attention to every client in Buffalo, NY.</p>
        </div>

        <div class="kda-features-grid">
            <?php foreach ($kda_audiences as $a) : ?>
                <article class="kda-feature-card">
                    <a class="kda-feature-media" href="<?php echo esc_url($a['link']); ?>" aria-label="<?php echo esc_attr($a['title']); ?>">
                        <img src="<?php echo esc_url($kda_img . $a['image']); ?>" alt="<?php echo esc_attr($a['title']); ?>" loading="lazy" width="800" height="500">
                        <span class="kda-feature-num" aria-hidden="true"><?php echo esc_html($a['num']); ?></span>
                    </a>
                    <div class="kda-feature-body">
                        <div class="kda-feature-head">
                            <span class="kda-feature-icon"><?php echo file_get_contents(get_template_directory() . '/assets/icons/' . $a['icon']); ?></span>
                            <h3 class="kda-feature-title"><?php echo esc_html($a['title']); ?></h3>
                        </div>
                        <p class="kda-feature-text"><?php echo esc_html($a['text']); ?></p>
                        <a class="blog-card-link" href="<?php echo esc_url($a['link']); ?>"><?php echo esc_html($a['cta']); ?> <span aria-hidden="true">&rarr;</span></a>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </div>

    <?php get_template_part('partials/call-us'); ?>
</section>
