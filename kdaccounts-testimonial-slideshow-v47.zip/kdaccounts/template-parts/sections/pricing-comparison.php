<?php
/**
 * Pricing Comparison Section — monthly plans + add-on services.
 */
$kda_plans = array('Bronze', 'Silver', 'Gold', 'Platinum');
$kda_prices = array('$149/mo', '$249/mo', '$399/mo', '$599/mo');
$kda_best = array(
    'Startups & very small businesses',
    'Growing small businesses',
    'Established businesses',
    'Businesses needing full financial support',
);
// value: true = check, false = dash, string = text
$kda_rows = array(
    array('Bookkeeping', 'Up to 100 transactions', 'Up to 200 transactions', 'Up to 400 transactions', 'Customized / high-volume'),
    array('Transaction Recording', true, true, true, true),
    array('Bank Reconciliation', false, true, true, true),
    array('Monthly Financial Statements', true, true, true, true),
    array('Accounts Payable', false, false, true, true),
    array('Accounts Receivable', false, false, true, true),
    array('Financial Review', false, 'Quarterly', 'Monthly', 'Monthly'),
    array('Tax Planning', 'Basic', true, true, 'Advanced'),
    array('Business Tax Preparation', false, 'Add-on', true, true),
    array('Personal Tax Preparation', false, 'Add-on', 'Add-on', true),
    array('Tax Compliance Support', false, true, true, true),
    array('Budgeting & Forecasting', false, false, true, true),
    array('Cash Flow Analysis', false, true, true, true),
    array('Business Formation Guidance', 'Add-on', true, true, true),
    array('QuickBooks Support', true, true, true, true),
    array('Accountant Consultation', 'Basic', 'Monthly', 'Monthly', 'Priority'),
    array('Dedicated Accountant', false, false, true, true),
    array('Custom Financial Reporting', false, false, true, true),
    array('Strategic Business Advisory', false, false, true, true),
    array('Priority Support', false, false, false, true),
);
$kda_addons = array(
    array('Individual Tax Return', '$199+'),
    array('Business Tax Return', '$499+'),
    array('S-Corp Tax Return', '$699+'),
    array('Partnership Tax Return', '$699+'),
    array('C-Corp Tax Return', '$799+'),
    array('Business Formation', '$199+'),
    array('Payroll Services', '$99+/mo'),
    array('QuickBooks Setup', '$149+'),
    array('Bookkeeping Cleanup', 'Custom Quote'),
    array('IRS/Tax Notice Assistance', 'Custom Quote'),
);

function kda_price_cell($v) {
    if ($v === true)  return '<span class="kda-check" aria-label="Included">&#10003;</span>';
    if ($v === false) return '<span class="kda-dash" aria-label="Not included">&mdash;</span>';
    return esc_html($v);
}
?>
<section class="kda-pricing-section" id="pricing">
    <div class="container">

        <div class="kda-pricing-header">
            <span class="section-subtitle">PRICING</span>
            <h2 class="kda-pricing-title">Simple Monthly Plans for Every Stage of Business</h2>
            <p class="kda-pricing-sub">Compare our packages and pick what fits &mdash; every plan is backed by our certified Buffalo, NY team.</p>
        </div>

        <div class="kda-pricing-scroll">
            <table class="kda-pricing-table">
                <thead>
                    <tr>
                        <th class="kda-feature-col" scope="col"><span class="kda-sr">Feature</span></th>
                        <?php foreach ($kda_plans as $i => $p) : ?>
                            <th scope="col" class="<?php echo $p === 'Gold' ? 'kda-plan-popular' : ''; ?>">
                                <?php if ($p === 'Gold') : ?><span class="kda-popular-badge">Most Popular</span><?php endif; ?>
                                <span class="kda-plan-name"><?php echo esc_html($p); ?></span>
                                <span class="kda-plan-price"><?php echo esc_html($kda_prices[$i]); ?></span>
                            </th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody>
                    <tr class="kda-bestfor-row">
                        <th scope="row">Best For</th>
                        <?php foreach ($kda_best as $b) : ?><td><?php echo esc_html($b); ?></td><?php endforeach; ?>
                    </tr>
                    <?php foreach ($kda_rows as $row) : ?>
                        <tr>
                            <th scope="row"><?php echo esc_html($row[0]); ?></th>
                            <td><?php echo kda_price_cell($row[1]); ?></td>
                            <td><?php echo kda_price_cell($row[2]); ?></td>
                            <td class="kda-col-popular"><?php echo kda_price_cell($row[3]); ?></td>
                            <td><?php echo kda_price_cell($row[4]); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    <tr class="kda-cta-row">
                        <th scope="row"></th>
                        <?php foreach ($kda_plans as $p) : ?>
                            <td<?php echo $p === 'Gold' ? ' class="kda-col-popular"' : ''; ?>><a class="btn kda-plan-btn" href="<?php echo esc_url(home_url('/contact/')); ?>">Get Started</a></td>
                        <?php endforeach; ?>
                    </tr>
                </tbody>
            </table>
        </div>

        <div class="kda-addons">
            <h3 class="kda-addons-title">Add-On Services</h3>
            <div class="kda-pricing-scroll">
                <table class="kda-addons-table">
                    <thead>
                        <tr><th scope="col">Add-On Service</th><th scope="col">Starting At</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($kda_addons as $a) : ?>
                            <tr><th scope="row"><?php echo esc_html($a[0]); ?></th><td><?php echo esc_html($a[1]); ?></td></tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <p class="kda-pricing-note">Not sure which plan fits? Tell us about your business and we&rsquo;ll recommend one &mdash; no obligation.</p>
        </div>

    </div>
</section>
