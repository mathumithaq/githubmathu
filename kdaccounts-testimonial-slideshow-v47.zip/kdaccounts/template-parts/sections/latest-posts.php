<?php
/**
 * Latest Posts / Article Section — header row with "View All" link,
 * cards aligned with the blog-listing card design (chip, excerpt, read link).
 * Previous version: latest-posts.php.bak-20260821
 */
?>
<section class="latest-posts-section">
    <div class="container">

        <div class="posts-header kda-lp-header">
            <div class="kda-lp-heading">
                <span class="section-subtitle">FROM THE BLOG</span>
                <h2 class="posts-main-title">Latest Articles</h2>
            </div>
            <a class="kda-lp-viewall" href="<?php echo esc_url( home_url('/blog/') ); ?>">View All Articles <span aria-hidden="true">&rarr;</span></a>
        </div>

        <div class="posts-grid kda-lp-grid">
            <?php
            $latest_posts = new WP_Query([
                'post_type' => 'post',
                'posts_per_page' => 3,
                'post_status' => 'publish',
                'ignore_sticky_posts' => true,
            ]);

            if ($latest_posts->have_posts()) :
                while ($latest_posts->have_posts()) : $latest_posts->the_post();
                    $kda_cats = get_the_category();
            ?>
                <article class="post-card kda-lp-card">
                    <div class="post-image-wrapper kda-lp-image">
                        <a href="<?php the_permalink(); ?>" aria-label="<?php echo esc_attr(sprintf(__('Read more about %s', 'kdaccounts'), get_the_title())); ?>">
                            <?php if (has_post_thumbnail()) : ?>
                                <?php the_post_thumbnail('medium_large', ['loading' => 'lazy']); ?>
                            <?php else : ?>
                                <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/about-2.webp'); ?>" alt="<?php the_title_attribute(); ?>" loading="lazy">
                            <?php endif; ?>
                        </a>
                        <?php if ( ! empty( $kda_cats ) ) : ?>
                            <a class="blog-card-cat" href="<?php echo esc_url( get_category_link( $kda_cats[0] ) ); ?>"><?php echo esc_html( $kda_cats[0]->name ); ?></a>
                        <?php endif; ?>
                    </div>
                    <div class="post-content kda-lp-content">
                        <div class="post-meta kda-lp-meta">
                            <span><?php echo get_the_date('M j, Y'); ?></span>
                            <span class="kda-lp-dot" aria-hidden="true">&middot;</span>
                            <span><?php the_author(); ?></span>
                        </div>
                        <h3 class="post-title kda-lp-title">
                            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                        </h3>
                        <p class="kda-lp-excerpt"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 18, '&hellip;' ) ); ?></p>
                        <a href="<?php the_permalink(); ?>" class="blog-card-link">Read Article <span aria-hidden="true">&rarr;</span></a>
                    </div>
                </article>
            <?php
                endwhile;
                wp_reset_postdata();
            else :
            ?>
                <p>No recent articles found.</p>
            <?php endif; ?>
        </div>
    </div>
</section>
