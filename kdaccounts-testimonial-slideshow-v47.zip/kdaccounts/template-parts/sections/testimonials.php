<?php
/**
 * Testimonials Section (Single Card Slider)
 */
?>
<section class="testimonials-section">
    <div class="container" style="position: relative; z-index: 2; display: flex; flex-direction: column; align-items: center;">
        
        <span class="section-subtitle">TESTIMONIALS</span>
        <h2 class="testimonials-main-title">What Our Clients Say</h2>
        
        <div class="testimonials-grid">
            
            <!-- Review 1 -->
            <div class="ts-new-card">
                <div class="ts-avatar-circle" style="background-color: #01559c;">
                    <span>D</span>
                </div>
                <h3 class="ts-author-name">Dominar</h3>
                <span class="ts-author-role">1 review</span>
                <p class="ts-review-text">Excellent service</p>
                <div class="google-review-pill">
            <div class="ts-stars-row">
                <?php echo str_repeat(file_get_contents(get_template_directory() . '/assets/icons/star.svg'), 5); ?>
            </div>
            <div class="google-icon-wrapper" tabindex="0">
                <div class="google-tooltip">Posted on Google</div>
                <?php echo file_get_contents(get_template_directory() . '/assets/icons/google-color.svg'); ?>
            </div>
            <?php echo file_get_contents(get_template_directory() . '/assets/icons/verified-blue.svg'); ?>
        </div>
            </div>

            <!-- Review 2 -->
            <div class="ts-new-card">
                <div class="ts-avatar-circle" style="background-color: #a33bbb;">
                    <span>S</span>
                </div>
                <h3 class="ts-author-name">Shri Tharma</h3>
                <span class="ts-author-role">3 reviews</span>
                <p class="ts-review-text">We had our llc company tax return and sales tax .</p>
                <div class="google-review-pill">
            <div class="ts-stars-row">
                <?php echo str_repeat(file_get_contents(get_template_directory() . '/assets/icons/star.svg'), 5); ?>
            </div>
            <div class="google-icon-wrapper" tabindex="0">
                <div class="google-tooltip">Posted on Google</div>
                <?php echo file_get_contents(get_template_directory() . '/assets/icons/google-color.svg'); ?>
            </div>
            <?php echo file_get_contents(get_template_directory() . '/assets/icons/verified-blue.svg'); ?>
        </div>
            </div>

            <!-- Review 3 -->
            <div class="ts-new-card">
                <div class="ts-avatar-circle" style="background-color: #00503f;">
                    <span>M</span>
                </div>
                <h3 class="ts-author-name">Muku Niro</h3>
                <span class="ts-author-role">3 reviews</span>
                <p class="ts-review-text">We filed our c corp company tax return for last 7 years and Alex and his cpa team did best</p>
                <div class="google-review-pill">
            <div class="ts-stars-row">
                <?php echo str_repeat(file_get_contents(get_template_directory() . '/assets/icons/star.svg'), 5); ?>
            </div>
            <div class="google-icon-wrapper" tabindex="0">
                <div class="google-tooltip">Posted on Google</div>
                <?php echo file_get_contents(get_template_directory() . '/assets/icons/google-color.svg'); ?>
            </div>
            <?php echo file_get_contents(get_template_directory() . '/assets/icons/verified-blue.svg'); ?>
        </div>
            </div>

        </div>

        
    </div>

    <div class="kda-view-reviews">
        <a class="btn" href="https://share.google/4U4qnqwcqc2vbs63r" target="_blank" rel="noopener noreferrer">View Reviews</a>
        <?php get_template_part('partials/call-us', null, array('inline' => true)); ?>
    </div>
</section>

