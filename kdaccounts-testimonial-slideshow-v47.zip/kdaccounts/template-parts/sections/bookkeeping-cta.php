<?php /** Bookkeeping estimate banner. */ ?>
<section class="bk-estimate-banner"><div class="container">
<span class="section-subtitle">Let's Take a Look</span>
<h2>Not sure where your books stand? Let's take a look.</h2>
<div class="bk-actions"><a class="btn" href="#bk-estimate">Get a Free Estimate</a><a class="bk-call bk-industry-call" href="tel:+17165892665"><img src="<?php echo esc_url(get_template_directory_uri() . '/assets/icons/icon-phone.svg'); ?>" width="22" height="22" alt="">Call Us 716-589-2665</a></div>
</div></section>
