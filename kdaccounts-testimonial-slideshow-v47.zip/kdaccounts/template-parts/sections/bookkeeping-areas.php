<?php /** Buffalo and Erie County service areas and office information. */ ?>
<section class="bk-areas" id="bookkeeping-service-areas"><div class="container">
<span class="section-subtitle">Service Areas</span><h2>Bookkeeping Services Across Buffalo and Erie County</h2>
<p>We work with businesses throughout Buffalo and across Erie County, including:</p>
<table class="bk-area-table"><thead><tr><th scope="col">Area</th><th scope="col">ZIP codes</th></tr></thead><tbody>
<tr><th scope="row">Central Buffalo (home of our office)</th><td>14208</td></tr>
<tr><th scope="row">Downtown Buffalo</th><td>14202, 14203</td></tr>
<tr><th scope="row">Allentown</th><td>14201</td></tr>
<tr><th scope="row">Elmwood Village</th><td>14222</td></tr>
<tr><th scope="row">North Buffalo</th><td>14214, 14216</td></tr>
<tr><th scope="row">South Buffalo</th><td>14210, 14220</td></tr>
<tr><th scope="row">Amherst</th><td>14221, 14226, 14228</td></tr>
<tr><th scope="row">Williamsville</th><td>14221</td></tr>
<tr><th scope="row">Cheektowaga</th><td>14225, 14227</td></tr>
<tr><th scope="row">Tonawanda</th><td>14150, 14217, 14223</td></tr>
<tr><th scope="row">Kenmore</th><td>14217, 14223</td></tr>
<tr><th scope="row">West Seneca</th><td>14224</td></tr>
<tr><th scope="row">Orchard Park</th><td>14127</td></tr>
<tr><th scope="row">Hamburg</th><td>14075</td></tr>
<tr><th scope="row">Lackawanna</th><td>14218</td></tr>
<tr><th scope="row">Lancaster</th><td>14086</td></tr>
</tbody></table>
<p>Don't see your ZIP code? If you're anywhere in Western New York, give us a call.</p>
<p>Prefer to work remotely? You can send documents electronically and meet with us by phone or video, so your location isn't a barrier.</p>
<div class="bk-office-grid"><div><h3>KD Accounting &amp; Tax</h3>
<address class="bk-office-address"><a href="https://maps.app.goo.gl/6ZUSDpMDwzuPC92t8" target="_blank" rel="noopener noreferrer">162 Woodlawn Ave<br>Buffalo, NY 14208</a><br><a class="btn bk-phone-button" href="tel:+17165892665">(716) 589-2665</a></address>
<h3 class="bk-hours-heading">Office Hours</h3><dl class="bk-office-hours">
<div><dt>Monday</dt><dd>9 AM–5 PM</dd></div>
<div><dt>Tuesday</dt><dd>9 AM–5 PM</dd></div>
<div><dt>Wednesday</dt><dd>9 AM–5 PM</dd></div>
<div><dt>Thursday</dt><dd>9 AM–5 PM</dd></div>
<div><dt>Friday</dt><dd>9 AM–5 PM</dd></div>
<div><dt>Saturday</dt><dd>9 AM–5 PM</dd></div>
<div><dt>Sunday</dt><dd>Closed</dd></div>
</dl></div><iframe class="bk-office-map" title="KD Accounting &amp; Tax office at 162 Woodlawn Ave, Buffalo" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2225.7768014476023!2d-78.85885549999999!3d42.9140826!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89d313ce1bc950a3%3A0xd84ceefc1440ddfe!2sKD%20Accounting%20%26%20Tax!5e1!3m2!1sen!2slk!4v1785943552631!5m2!1sen!2slk" width="600" height="400" loading="lazy" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe></div>
<p class="bk-bottom-call"><strong>Anywhere in Erie County? We can help.</strong> <a class="btn bk-phone-button" href="tel:+17165892665">Call Us 716-589-2665</a></p>
</div></section>
