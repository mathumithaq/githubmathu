<?php
/** Original inner hero layout, Bookkeeping screenshot copy. */
$kda_img = get_template_directory_uri() . '/assets/images/';
?>
<section class="kda-hero kda-hero--inner">

    <div class="kda-hero-slides" aria-hidden="true">
        <img class="kda-hero-slide" src="<?php echo esc_url($kda_img . 'hero-slide-1.webp'); ?>" alt="" width="1920" height="1080" fetchpriority="high" decoding="async">
        <img class="kda-hero-slide" src="<?php echo esc_url($kda_img . 'hero-slide-2.webp'); ?>" alt="" width="1920" height="1080" loading="lazy" decoding="async">
        <img class="kda-hero-slide" src="<?php echo esc_url($kda_img . 'hero-slide-3.webp'); ?>" alt="" width="1920" height="1080" loading="lazy" decoding="async">
    </div>
    <div class="kda-hero-scrim"></div>

    <div class="container kda-hero-inner">

        <div class="kda-hero-left">
            <div class="kda-hero-crumbs">
                <a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a>
                <span class="sep" aria-hidden="true">&rsaquo;</span>
                <span>Bookkeeping Services</span>
            </div>

            <?php
            $badge_id = get_queried_object_id();
            $badge_rating = get_post_meta($badge_id, 'bk_google_rating', true);
            $badge_count = get_post_meta($badge_id, 'bk_google_review_count', true);
            $badge_url = get_post_meta($badge_id, 'bk_google_reviews_url', true);
            ?>
            <a class="kda-google-badge" href="<?php echo esc_url($badge_url ?: '#bk-reviews'); ?>">
                <?php if (is_numeric($badge_rating) && is_numeric($badge_count) && $badge_count > 0): ?>
                <span aria-hidden="true">★★★★★</span> <?php echo esc_html($badge_rating); ?> · <?php echo esc_html($badge_count); ?> Google Reviews
                <?php else: ?>Google Reviews<?php endif; ?>
            </a>

            <h1 class="kda-hero-title">Bookkeeping Services in Buffalo, NY</h1>

            <p class="kda-hero-sub"><strong>Clean books every month. No tax-season panic.</strong><br>Monthly bookkeeping, catch-up work, and clear financial reports for small businesses across Buffalo and Erie County, from a local team that also offers tax preparation.</p>

            <div class="kda-hero-ctas">
                <a href="#bk-estimate" class="btn">Get a Free Estimate</a>
                <a href="tel:+17165892665" class="btn btn-outline">Call Us: 716-589-2665</a>
            </div>
            <?php get_template_part('template-parts/sections/hero-trust'); ?>
        </div>

        <aside class="kda-hero-form" id="bk-estimate">
            <?php get_template_part('partials/form/hero-form'); ?>
        </aside>

    </div>
</section>
