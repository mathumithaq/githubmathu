<?php
/**
 * Why Choose Section (Floating Cards Layout)
 */
?>
<section class="solutions-section">
    <div class="container">
        <div class="solutions-header" style="text-align: center;">
            <span class="section-subtitle">OUR EXPERTISE</span>
            <h2 class="solutions-main-title">SIMPLIFY YOUR FINANCIAL SUCCESS WITH A ONE-STOP SOLUTION FOR TAX & ACCOUNTING IN BUFFALO, NY</h2>
        </div>
        
        <div class="solutions-grid">
            
            <!-- Card 1 -->
            <div class="solution-hover-card">
                <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/solutions-consultation.webp'); ?>" alt="Small Business Accounting" class="solution-card-img" loading="lazy">
                <div class="solution-card-overlay">
                    <div class="solutions-icon">
                        <?php echo file_get_contents(get_template_directory() . '/assets/icons/small-business.svg'); ?>
                    </div>
                    <h3 class="solutions-item-title">SMALL BUSINESS ACCOUNTING</h3>
                    <p class="solutions-item-text">Our small business accounting service is specially designed to provide expert financial records, cash flow management, timely reports, and tax compliance. This will remove the burden of payroll costs and employee management.</p>
                </div>
            </div>
            
            <!-- Card 2 -->
            <div class="solution-hover-card">
                <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/feature-business.webp'); ?>" alt="Tax Preparation and Planning" class="solution-card-img" loading="lazy">
                <div class="solution-card-overlay">
                    <div class="solutions-icon">
                        <?php echo file_get_contents(get_template_directory() . '/assets/icons/tax-planning.svg'); ?>
                    </div>
                    <h3 class="solutions-item-title">TAX PREPARATION AND PLANNING</h3>
                    <p class="solutions-item-text">Our tax services typically include tax preparation and planning, IRS Support, and business tax services that help find the path of deductions, credits, and planning strategies to reduce liabilities.</p>
                </div>
            </div>
            
            <!-- Card 3 -->
            <div class="solution-hover-card">
                <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/about-1.webp'); ?>" alt="IRS Audit Support" class="solution-card-img" loading="lazy">
                <div class="solution-card-overlay">
                    <div class="solutions-icon">
                        <?php echo file_get_contents(get_template_directory() . '/assets/icons/audit-support.svg'); ?>
                    </div>
                    <h3 class="solutions-item-title">IRS AUDIT SUPPORT</h3>
                    <p class="solutions-item-text">We know an IRS audit means overwhelming stress, but no need to worry anymore. We help secure your investments with our IRS audit support. We guide, represent, and advise to face audits with full confidence.</p>
                </div>
            </div>

        </div>
    </div>

    <?php get_template_part('partials/call-us'); ?>
</section>

