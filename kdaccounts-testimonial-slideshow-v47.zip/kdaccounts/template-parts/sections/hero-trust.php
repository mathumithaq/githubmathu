<ul class="kda-hero-trust" aria-label="Service benefits">
<?php foreach (array('Professional Bookkeeping', 'Free Estimate', 'Local Buffalo Office', 'QuickBooks, Xero & Excel', 'Bookkeeping + Tax Under One Roof', 'NY Sales Tax-Ready Records') as $benefit): ?>
<li><img src="<?php echo esc_url(get_template_directory_uri() . '/assets/icons/check-circle.svg'); ?>" width="18" height="18" alt=""><?php echo esc_html($benefit); ?></li>
<?php endforeach; ?>
</ul>