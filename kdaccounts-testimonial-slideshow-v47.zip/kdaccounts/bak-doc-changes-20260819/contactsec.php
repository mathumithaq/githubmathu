<?php
/**
 * Contact/Consultation Section
 */
?>
<section class="contactsec-section">
    <div class="container">
        
        <!-- Global Subtitle Design -->
        <div class="text-center" style="margin-bottom: 50px;">
            <span class="section-subtitle">Get In Touch</span>
        </div>
        
        <div class="contactsec-grid">
            
            <!-- Left Side: Text and Map -->
            <div class="contactsec-left">
                <div class="contactsec-text">
                    <h2>Connect With Us</h2>
                    <p>Got questions? Need a finance service? Connect with us any time. Just give a call, send an email, or reach out on social media for fast, reliable support. Visit us at our main location in Buffalo, NY, or use the contact form to drop a message requesting information, a quote, or a schedule.</p>
                </div>
                
                <div class="contactsec-map">
                    <iframe class="lazy-map" title="Google Maps Location" data-src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2225.7768014476023!2d-78.85885549999999!3d42.9140826!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89d313ce1bc950a3%3A0xd84ceefc1440ddfe!2sKD%20Accounting%20%26%20Tax!5e1!3m2!1sen!2slk!4v1785943552631!5m2!1sen!2slk" width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="strict-origin-when-cross-origin"></iframe>
                </div>
                
                <div class="contactsec-info" style="margin-top: 40px; display: flex; flex-direction: column; gap: 30px;">
                    <div class="contact-info-item" style="display: flex; align-items: flex-start; gap: 15px;">
                        <div class="contact-icon" style="flex-shrink: 0; width: 24px; height: 24px; color: var(--primary-color);">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
                        </div>
                        <div class="contact-details">
                            <h3 style="margin: 0 0 5px 0; font-size: 1.2rem; color: var(--color-text); font-weight: 600;">Call Us</h3>
                            <p style="margin: 0; color: var(--color-text-light); font-size: 1rem;"><a href="tel:7165892665" style="color: inherit; text-decoration: none;">(716) 589-2665</a></p>
                        </div>
                    </div>
                    
                    <div class="contact-info-item" style="display: flex; align-items: flex-start; gap: 15px;">
                        <div class="contact-icon" style="flex-shrink: 0; width: 24px; height: 24px; color: var(--primary-color);">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>
                        </div>
                        <div class="contact-details">
                            <h3 style="margin: 0 0 5px 0; font-size: 1.2rem; color: var(--color-text); font-weight: 600;">Mail</h3>
                            <p style="margin: 0; color: var(--color-text-light); font-size: 1rem;"><a href="mailto:sales@kdaccounts.com" style="color: inherit; text-decoration: none;">sales@kdaccounts.com</a></p>
                        </div>
                    </div>
                    
                    <div class="contact-info-item" style="display: flex; align-items: flex-start; gap: 15px;">
                        <div class="contact-icon" style="flex-shrink: 0; width: 24px; height: 24px; color: var(--primary-color);">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
                        </div>
                        <div class="contact-details">
                            <h3 style="margin: 0 0 5px 0; font-size: 1.2rem; color: var(--color-text); font-weight: 600;">Location</h3>
                            <p style="margin: 0; color: var(--color-text-light); font-size: 1rem;"><a href="https://maps.app.goo.gl/6ZUSDpMDwzuPC92t8" target="_blank" rel="noopener noreferrer" style="color: inherit; text-decoration: none;">162 Woodlawn Ave, Buffalo, NY 14208</a></p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Right Side: GHL Form Only -->
            <div class="contactsec-right">
                
                <!-- GHL Form -->
                <div class="ghl-form-wrapper">
                    <?php get_template_part('partials/form/form'); ?>
                </div>
                
            </div>
            
        </div>
    </div>
</section>

