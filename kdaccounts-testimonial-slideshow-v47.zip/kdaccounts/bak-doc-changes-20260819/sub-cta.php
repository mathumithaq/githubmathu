<?php
/**
 * Sub Service CTA Section
 * 
 * Features a fixed background with a glassmorphism overlay.
 */

$page_id = get_queried_object_id();

// Dynamic Fields
$cta_subtitle = '';
$cta_text = '';
$cta_btn_text = '';
$cta_btn_link = '';

if ( function_exists('get_field') ) {
    $cta_subtitle = get_field('sub_cta_subtitle', $page_id);
    $cta_text = get_field('sub_cta_text', $page_id);
    $cta_btn_text = get_field('sub_cta_btn_text', $page_id);
    $cta_btn_link = get_field('sub_cta_btn_link', $page_id);
}

if ( empty( $cta_subtitle ) ) { $cta_subtitle = get_post_meta( $page_id, 'sub_cta_subtitle', true ); }
if ( empty( $cta_text ) )     { $cta_text = get_post_meta( $page_id, 'sub_cta_text', true ); }
if ( empty( $cta_btn_text ) ) { $cta_btn_text = get_post_meta( $page_id, 'sub_cta_btn_text', true ); }
if ( empty( $cta_btn_link ) ) { $cta_btn_link = get_post_meta( $page_id, 'sub_cta_btn_link', true ); }

// Optional fallback for the link only, so the button isn't completely broken if they forget it
if ( empty( $cta_btn_link ) ) {
    $cta_btn_link = home_url( '/contact' );
}

// Background image (Generated WebP < 100kb)
$bg_image_url = get_template_directory_uri() . '/assets/images/footer-bg.webp';
?>

<section class="sub-cta-section" style="background-image: url('<?php echo esc_url( $bg_image_url ); ?>');">
    <!-- Dark Glassmorphism overlay for contrast -->
    <div class="sub-cta-glass-overlay"></div>
    
    <div class="container sub-cta-container">
        <div class="sub-cta-text-content">
            <?php if ( ! empty( $cta_subtitle ) ) : ?>
                <span class="section-subtitle"><?php echo esc_html( $cta_subtitle ); ?></span>
            <?php endif; ?>
            
            <h2 class="sub-cta-title"><?php echo wp_kses_post( $cta_text ); ?></h2>
        </div>
        
        <a href="<?php echo esc_url( $cta_btn_link ); ?>" class="btn">
            <?php echo esc_html( $cta_btn_text ); ?>
            <svg style="margin-left:8px;" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
        </a>
    </div>
</section>
