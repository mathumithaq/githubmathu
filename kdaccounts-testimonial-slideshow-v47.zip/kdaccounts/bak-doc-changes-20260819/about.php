<section class="about-section">
    <div class="container about-single-content">
        <span class="section-subtitle">About Us</span>
        <h2 class="about-title">Where You Get Professional Guidance With Care Beyond Numbers</h2>

        <p class="about-text-lead">
            We are your trusted financial partner dedicated to creating a clean financial flow. We offer stress-free taxing, accurate bookkeeping & accounting, and simplified business registration services to individuals and businesses of any size in any industry for more than 10 years. Experience with us
        </p>
        
        <div class="about-bottom-grid">
            <div class="about-bottom-left">
                <ul class="about-features-list">
                    <li>
                        <span class="icon">
                            <?php echo file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg'); ?>
                        </span> 
                        Tax accuracy & compliance
                    </li>
                    <li>
                        <span class="icon">
                            <?php echo file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg'); ?>
                        </span> 
                        Expert finance & tax advisor in Buffalo
                    </li>
                    <li>
                        <span class="icon">
                            <?php echo file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg'); ?>
                        </span> 
                        Financial confidence
                    </li>
                    <li>
                        <span class="icon">
                            <?php echo file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg'); ?>
                        </span> 
                        Personalized business growth
                    </li>
                    <li>
                        <span class="icon">
                            <?php echo file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg'); ?>
                        </span> 
                        Ethical & transparent finances
                    </li>
                    <li>
                        <span class="icon">
                            <?php echo file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg'); ?>
                        </span> 
                        Stress-free financial life
                    </li>
                </ul>
            </div>
            
            <div class="about-bottom-right">
                <p class="about-text-secondary">
                    Sit back and relax with simplified taxes, accounting services, and cash flow management. Our accounting firm handles every service with high standards, so you can focus on sound financial decision-making towards your goals while ensuring legal compliance.
                </p>
                
                <a href="<?php echo esc_url(home_url('/about/')); ?>" class="btn btn-about">More About Us</a>
            </div>
        </div>
    </div>
</section>

