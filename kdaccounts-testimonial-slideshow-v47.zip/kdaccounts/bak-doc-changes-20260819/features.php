<?php
/**
 * Features Section
 */
?>
<section class="features-section">
    <div class="container">
        <!-- Moved Title to the Top -->
        <div class="features-section-header" style="text-align: left; max-width: 800px; margin-bottom: 50px;">
            <span class="section-subtitle" style="display: inline-block;">Target Audience</span>
            <h2 class="section-title" style="margin-top: 15px;">COMPREHENSIVE, SMART FINANCIAL SERVICES IN BUFFALO FOR BUSINESSES, INDIVIDUALS & MORE</h2>
        </div>

        <div class="features-grid">
            
            <!-- Row 1: Left Colored Box 1, Right Image 1 (Adjusted flow since Title moved) -->
            <div class="feature-box feature-colored box-01">
                <div class="feature-icon">
                    <?php echo file_get_contents(get_template_directory() . '/assets/icons/business.svg'); ?>
                </div>
                <div class="feature-title-wrapper" style="display: flex; flex-direction: column; align-items: flex-start; gap: 5px; margin-bottom: 15px;">
                    <div class="feature-number" style="font-family: var(--font-heading); font-size: 1.5rem; font-weight: 700; opacity: 0.6;">01</div>
                    <h3 class="feature-title" style="margin: 0;">FOR BUSINESSES</h3>
                </div>
                <p class="feature-text">We are the top Buffalo accounting firm ready to help businesses achieve their financial objectives. We have years of experience in helping businesses grow by providing the financial foundation they need to grow and succeed in the industry.</p>
            </div>
            
            <!-- Row 2: Left Image 1, Right Colored Box 2 -->
            <div class="feature-box feature-image img-01">
                <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/feature-business.webp'); ?>" alt="For Businesses" loading="lazy">
            </div>
            
            <div class="feature-box feature-colored box-02">
                <div class="feature-icon">
                    <?php echo file_get_contents(get_template_directory() . '/assets/icons/individual.svg'); ?>
                </div>
                <div class="feature-title-wrapper" style="display: flex; flex-direction: column; align-items: flex-start; gap: 5px; margin-bottom: 15px;">
                    <div class="feature-number" style="font-family: var(--font-heading); font-size: 1.5rem; font-weight: 700; opacity: 0.6;">02</div>
                    <h3 class="feature-title" style="margin: 0;">FOR INDIVIDUALS</h3>
                </div>
                <p class="feature-text">We are the top Buffalo accounting firm ready to help businesses achieve their financial objectives. We have years of experience in helping businesses grow by providing the financial foundation they need to grow and succeed in the industry.</p>
            </div>
            
            <!-- Row 3: Left Image 2, Right Colored Box 3 -->
            <div class="feature-box feature-image img-02">
                <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/feature-individual.webp'); ?>" alt="For Individuals" loading="lazy">
            </div>
            
            <div class="feature-box feature-colored box-03" style="grid-column: 1 / -1;">
                <div class="feature-icon">
                    <?php echo file_get_contents(get_template_directory() . '/assets/icons/resources.svg'); ?>
                </div>
                <div class="feature-title-wrapper" style="display: flex; flex-direction: column; align-items: flex-start; gap: 5px; margin-bottom: 15px;">
                    <div class="feature-number" style="font-family: var(--font-heading); font-size: 1.5rem; font-weight: 700; opacity: 0.6;">03</div>
                    <h3 class="feature-title" style="margin: 0;">RESOURCES</h3>
                </div>
                <p class="feature-text">We strongly believe that financial success can only be achieved if you're well-informed about financial strategies and investments in all operations. Our full services, advice, tips, and tools will help you achieve high revenue in every step you take.</p>
            </div>

        </div>
    </div>
</section>

