<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 */

get_header(); ?>

<main id="primary" class="site-main">

    <!-- Blog Hero Section -->
    <?php get_template_part('template-parts/sub-services/sub-hero'); ?>

    <!-- Blog Listing Section -->
    <section class="blog-listing-section">
        <div class="container">
            <?php if ( have_posts() ) : ?>
                <div class="blog-listing-grid">
                    <?php while ( have_posts() ) : the_post(); ?>
                        <article id="post-<?php the_ID(); ?>" <?php post_class('blog-card'); ?>>
                            
                            <div class="blog-card-image">
                                <?php if ( has_post_thumbnail() ) : ?>
                                    <a href="<?php the_permalink(); ?>" aria-label="<?php echo esc_attr( 'Read more about ' . get_the_title() ); ?>">
                                        <?php the_post_thumbnail('medium_large'); ?>
                                    </a>
                                <?php else : ?>
                                    <a href="<?php the_permalink(); ?>" class="blog-placeholder-img" aria-label="<?php echo esc_attr( 'Read more about ' . get_the_title() ); ?>">
                                        <!-- Fallback color block -->
                                    </a>
                                <?php endif; ?>
                            </div>

                            <div class="blog-card-content">
                                <div class="blog-card-meta">
                                    <span class="blog-date">
                                        <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/calendar.svg" alt="Date" width="16" height="16">
                                        <?php echo get_the_date(); ?>
                                    </span>
                                    <span class="blog-author">
                                        <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/user.svg" alt="Author" width="16" height="16">
                                        <?php the_author(); ?>
                                    </span>
                                </div>
                                
                                <h2 class="blog-card-title">
                                    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                </h2>
                                

                                
                                <a href="<?php the_permalink(); ?>" class="btn">
                                    View Post
                                </a>
                            </div>
                            
                        </article>
                    <?php endwhile; ?>
                </div>

                <div class="blog-pagination">
                    <?php 
                        the_posts_pagination( array(
                            'mid_size'  => 2,
                            'prev_text' => __( 'Previous', 'kdaccounts-theme' ),
                            'next_text' => __( 'Next', 'kdaccounts-theme' ),
                            'screen_reader_text' => ' ',
                        ) );
                    ?>
                </div>

            <?php else : ?>
                <div class="no-posts-found">
                    <p><?php esc_html_e( 'Sorry, no posts matched your criteria.', 'kdaccounts-theme' ); ?></p>
                </div>
            <?php endif; ?>
        </div>
    </section>

</main>

<?php get_footer(); ?>
