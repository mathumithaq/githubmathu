<?php
/**
 * FAQ Section (Chat Bubble Layout)
 */
?>
<section id="faq" class="faq-section">
    <div class="container">
        
        <div class="faq-header">
            <span class="section-subtitle">FAQS</span>
            <h2 class="faq-main-title">FREQUENTLY ASKED QUESTIONS</h2>
        </div>
        
        <div class="faq-chat-container">
            
            <!-- FAQ 1 -->
            <div class="faq-item active">
                <div class="faq-bubble-row faq-row-question">
                    <div class="faq-icon-wrapper faq-icon-question">
                        <?php echo file_get_contents(get_template_directory() . '/assets/icons/faq-question.svg'); ?>
                    </div>
                    <div class="faq-bubble faq-bubble-question">
                        <p>HOW DO I GET STARTED WITH KD ACCOUNTING & TAX?</p>
                        <div class="faq-toggle-icon">
                            <svg class="icon-plus" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                            <svg class="icon-minus" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                        </div>
                    </div>
                </div>
                
                <div class="faq-bubble-row faq-row-answer">
                    <div class="faq-bubble faq-bubble-answer">
                        <p>You can contact us by phone, via our website form, or by visiting our head office.</p>
                    </div>
                    <div class="faq-icon-wrapper faq-icon-answer">
                        <?php echo file_get_contents(get_template_directory() . '/assets/icons/faq-user.svg'); ?>
                    </div>
                </div>
            </div>
            
            <!-- FAQ 2 -->
            <div class="faq-item">
                <div class="faq-bubble-row faq-row-question">
                    <div class="faq-icon-wrapper faq-icon-question">
                        <?php echo file_get_contents(get_template_directory() . '/assets/icons/faq-question.svg'); ?>
                    </div>
                    <div class="faq-bubble faq-bubble-question">
                        <p>WHY SHOULD I CHOOSE KD ACCOUNTING & TAX'S OUTSOURCED ACCOUNTING SERVICES?</p>
                        <div class="faq-toggle-icon">
                            <svg class="icon-plus" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                            <svg class="icon-minus" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                        </div>
                    </div>
                </div>
                
                <div class="faq-bubble-row faq-row-answer">
                    <div class="faq-bubble faq-bubble-answer">
                        <p>Our CPA outsourcing services ensure accuracy, compliance, and efficiency â€” without the cost or hassle of managing full time accounting staff.</p>
                    </div>
                    <div class="faq-icon-wrapper faq-icon-answer">
                        <?php echo file_get_contents(get_template_directory() . '/assets/icons/faq-user.svg'); ?>
                    </div>
                </div>
            </div>
            
            <!-- FAQ 3 -->
            <div class="faq-item">
                <div class="faq-bubble-row faq-row-question">
                    <div class="faq-icon-wrapper faq-icon-question">
                        <?php echo file_get_contents(get_template_directory() . '/assets/icons/faq-question.svg'); ?>
                    </div>
                    <div class="faq-bubble faq-bubble-question">
                        <p>DO YOU PROVIDE VIRTUAL ACCOUNTING AND BOOKKEEPING SERVICES?</p>
                        <div class="faq-toggle-icon">
                            <svg class="icon-plus" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                            <svg class="icon-minus" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                        </div>
                    </div>
                </div>
                
                <div class="faq-bubble-row faq-row-answer">
                    <div class="faq-bubble faq-bubble-answer">
                        <p>Our CPA outsourcing services ensure accuracy, compliance, and efficiency â€” without the cost or hassle of managing full time accounting staff.</p>
                    </div>
                    <div class="faq-icon-wrapper faq-icon-answer">
                        <?php echo file_get_contents(get_template_directory() . '/assets/icons/faq-user.svg'); ?>
                    </div>
                </div>
            </div>
            
            <!-- FAQ 4 -->
            <div class="faq-item">
                <div class="faq-bubble-row faq-row-question">
                    <div class="faq-icon-wrapper faq-icon-question">
                        <?php echo file_get_contents(get_template_directory() . '/assets/icons/faq-question.svg'); ?>
                    </div>
                    <div class="faq-bubble faq-bubble-question">
                        <p>HOW DO I CONTACT QUICKBOOKS PAYROLL SUPPORT?</p>
                        <div class="faq-toggle-icon">
                            <svg class="icon-plus" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                            <svg class="icon-minus" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                        </div>
                    </div>
                </div>
                
                <div class="faq-bubble-row faq-row-answer">
                    <div class="faq-bubble faq-bubble-answer">
                        <p>Our CPA outsourcing services ensure accuracy, compliance, and efficiency â€” without the cost or hassle of managing full time accounting staff.</p>
                    </div>
                    <div class="faq-icon-wrapper faq-icon-answer">
                        <?php echo file_get_contents(get_template_directory() . '/assets/icons/faq-user.svg'); ?>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const faqItems = document.querySelectorAll('.faq-item');
    faqItems.forEach(item => {
        const questionRow = item.querySelector('.faq-row-question');
        questionRow.addEventListener('click', () => {
            const isActive = item.classList.contains('active');
            
            // Close all items
            faqItems.forEach(otherItem => {
                otherItem.classList.remove('active');
            });
            
            // If it wasn't active before, open it (toggle behavior)
            if (!isActive) {
                item.classList.add('active');
            }
        });
    });
});
</script>

