<?php
/**
 * Dynamic Sub Service Content Section
 */

// Get queried object to ensure we get custom fields outside the main loop
$page_id = get_queried_object_id();

// Dynamic Fields
$subtitle = '';
$title = '';
$desc = '';
$features_raw = '';

if ( function_exists('get_field') ) {
    $subtitle = get_field('sub_about_subtitle', $page_id);
    $title = get_field('sub_about_title', $page_id);
    $desc = get_field('sub_about_desc', $page_id);
    $features_raw = get_field('sub_about_features', $page_id);
}

if ( empty( $subtitle ) ) { $subtitle = get_post_meta( $page_id, 'sub_about_subtitle', true ); }
if ( empty( $title ) )    { $title = get_post_meta( $page_id, 'sub_about_title', true ); }
if ( empty( $desc ) )     { $desc = get_post_meta( $page_id, 'sub_about_desc', true ); }
if ( empty( $features_raw ) ) { $features_raw = get_post_meta( $page_id, 'sub_about_features', true ); }

// Process features (newline separated)
$features = [];
if ( ! empty( $features_raw ) ) {
    $features = array_filter( array_map( 'trim', explode( "\n", $features_raw ) ) );
}

// Image
$image_url = get_template_directory_uri() . '/assets/images/sub-content.webp';

// If title is completely empty, fallback to the page title so it's not totally blank
if ( empty( $title ) ) {
    $title = get_the_title( $page_id );
}
?>

<section class="sub-content-section">
    <div class="container">
        <div class="sub-content-banner">
            
            <!-- Left Side: Content -->
            <div class="sub-content-banner-text">
                
                <div class="banner-text-content">
                    <?php if ( ! empty( $subtitle ) ) : ?>
                        <span class="banner-subtitle"><?php echo esc_html( $subtitle ); ?></span>
                    <?php endif; ?>
                    
                    <h2 class="banner-title"><?php echo wp_kses_post( $title ); ?></h2>
                    
                    <?php if ( ! empty( $desc ) ) : ?>
                        <div class="banner-desc">
                            <?php echo wpautop( wp_kses_post( $desc ) ); ?>
                        </div>
                    <?php endif; ?>

                    <?php if ( ! empty( $features ) ) : ?>
                        <ul class="banner-features">
                            <?php foreach ( $features as $feature ) : ?>
                                <li>
                                    <span class="feature-icon">
                                        <?php echo file_get_contents( get_template_directory() . '/assets/icons/icon-check.svg' ); ?>
                                    </span>
                                    <span class="feature-text"><?php echo esc_html( $feature ); ?></span>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Right Side: Image -->
            <div class="sub-content-banner-image">
                <img src="<?php echo esc_url( $image_url ); ?>" alt="<?php echo esc_attr( strip_tags( $title ) ); ?>" loading="lazy">
                <!-- Gradient to blend the image into the left solid color -->
                <div class="banner-image-gradient"></div>
            </div>

        </div>
    </div>
</section>
