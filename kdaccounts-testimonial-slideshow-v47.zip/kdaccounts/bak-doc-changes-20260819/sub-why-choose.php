<?php
/**
 * Dynamic Sub Service Why Choose Section
 */

$page_id = get_queried_object_id();

// Fetch native custom fields
$subtitle = get_post_meta($page_id, 'sub_why_subtitle', true);
$title = get_post_meta($page_id, 'sub_why_title', true);
$cards_json = get_post_meta($page_id, 'sub_why_cards_data', true);

// Fallbacks
if (empty($subtitle)) { $subtitle = 'Why Choose Us'; }
if (empty($title)) { $title = 'Why Choose KD Accounting and Tax?'; }

$cards = [];

// Check for individual card fields (why_card_1_title, why_card_2_title, etc.)
for ($i = 1; $i <= 3; $i++) {
    $card_title = get_post_meta($page_id, "why_card_{$i}_title", true);
    if (!empty($card_title)) {
        $card_image = get_post_meta($page_id, "why_card_{$i}_image", true);
        $card_text = get_post_meta($page_id, "why_card_{$i}_text", true);
        
        // Card 1 is usually a list, others are paragraphs by default
        $card_type = ($i == 1) ? 'list' : 'paragraph';
        
        $content = $card_text;
        if ($card_type === 'list') {
            $content = array_filter(array_map('trim', explode("\n", $card_text)));
        }

        $cards[] = [
            'number' => '0' . $i . '.',
            'title' => $card_title,
            'image' => !empty($card_image) ? $card_image : get_template_directory_uri() . "/assets/images/why-choose-{$i}.webp",
            'type' => $card_type,
            'content' => $content
        ];
    }
}

// Fallback to JSON if individual fields aren't used
if (empty($cards) && !empty($cards_json)) {
    $cards = json_decode($cards_json, true);
}

if (empty($cards) || !is_array($cards)) {
    $cards = [
        [
            'number' => '01.',
            'title' => 'Experienced Professionals',
            'image' => get_template_directory_uri() . '/assets/images/why-choose-1.webp',
            'type' => 'list',
            'content' => [
                'Experienced Professionals an old-world glowing key aian enaperement.',
                'Ficerires custom glowing gold bullet crtperatoy, and onmer process.',
                'Our tristaline appendent glowing gold custom glowing sertiarts.'
            ]
        ],
        [
            'number' => '02.',
            'title' => 'Accuracy &\nCompliance',
            'image' => get_template_directory_uri() . '/assets/images/why-choose-2.webp',
            'type' => 'paragraph',
            'content' => 'MoreInter is provides the best of to envon-adination businesss aut foas and promote consistencr and complict sumpisaene compliance. with more interlivesigned is accuracy & Compliance, for our compliation and accuriance process.'
        ],
        [
            'number' => '03.',
            'title' => 'Industry-Leading\nSoftware',
            'image' => get_template_directory_uri() . '/assets/images/why-choose-3.webp',
            'type' => 'paragraph',
            'content' => 'InterInter to Industry-leading software the best accounting systemes customnize process, tnodding frogradaions to QuickBooks, and Xero can expherse KD accounting and Tax vare glowing tools to data matranalive.'
        ]
    ];
}

?>

<section class="sub-why-choose-section">
    <div class="container">
        <div class="why-choose-header text-center">
            <?php if (!empty($subtitle)) : ?>
                <span class="section-subtitle"><?php echo esc_html($subtitle); ?></span>
            <?php endif; ?>
            <h2 class="why-choose-main-title"><?php echo wp_kses_post($title); ?></h2>
        </div>

        <div class="why-choose-grid">
            <?php foreach ($cards as $card) : ?>
                <div class="why-card">
                    <div class="why-card-inner">
                        <div class="why-card-top">
                            <div class="why-card-header">
                                <span class="why-card-num"><?php echo esc_html($card['number']); ?></span>
                            </div>
                            <h3 class="why-card-title"><?php echo nl2br(esc_html(str_replace('\n', "\n", $card['title']))); ?></h3>
                        </div>
                        
                        <div class="why-card-image">
                            <img src="<?php echo esc_url($card['image']); ?>" alt="<?php echo esc_attr(str_replace('\n', ' ', $card['title'])); ?>" loading="lazy">
                        </div>
                        
                        <div class="why-card-body">
                            <?php if ($card['type'] === 'list' && is_array($card['content'])) : ?>
                                <ul class="why-card-list">
                                    <?php foreach ($card['content'] as $item) : ?>
                                        <li>
                                            <p><?php echo esc_html($item); ?></p>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php else : ?>
                                <p class="why-card-text"><?php echo esc_html($card['content']); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
