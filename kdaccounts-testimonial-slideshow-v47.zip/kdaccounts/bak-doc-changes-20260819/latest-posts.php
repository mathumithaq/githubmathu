<?php
/**
 * Latest Posts / Article Section
 */
?>
<section class="latest-posts-section">
    <div class="container">
        
        <div class="posts-header">
            <span class="section-subtitle">BLOG</span>
            <h2 class="posts-main-title">LATEST ARTICLE</h2>
        </div>
        
        <div class="posts-grid">
            <?php
            $latest_posts = new WP_Query([
                'post_type' => 'post',
                'posts_per_page' => 3,
                'post_status' => 'publish'
            ]);
            
            if ($latest_posts->have_posts()) :
                while ($latest_posts->have_posts()) : $latest_posts->the_post();
            ?>
                <!-- Article -->
                <div class="post-card">
                    <div class="post-image-wrapper">
                        <a href="<?php the_permalink(); ?>" aria-label="<?php echo esc_attr(sprintf(__('Read more about %s', 'kdaccounts'), get_the_title())); ?>">
                            <?php if (has_post_thumbnail()) : ?>
                                <?php the_post_thumbnail('medium_large', ['loading' => 'lazy']); ?>
                            <?php else : ?>
                                <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/about-2.webp'); ?>" alt="<?php the_title_attribute(); ?>" loading="lazy">
                            <?php endif; ?>
                        </a>
                    </div>
                    <div class="post-content" style="display: flex; flex-direction: column; justify-content: flex-start; align-items: flex-start;">
                        <div class="post-meta">
                            <span><?php echo get_the_date('M j, Y'); ?></span>
                        </div>
                        <h3 class="post-title">
                            <a href="<?php the_permalink(); ?>" style="color: inherit; text-decoration: none;"><?php the_title(); ?></a>
                        </h3>

                        <a href="<?php the_permalink(); ?>" class="btn" style="margin-top: auto; align-self: flex-start;">View Post</a>
                    </div>
                </div>
            <?php
                endwhile;
                wp_reset_postdata();
            else :
            ?>
                <p>No recent articles found.</p>
            <?php endif; ?>
        </div>
    </div>
</section>

