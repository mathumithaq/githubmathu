<?php
/**
 * Dynamic Sub Service Pricing Section
 * 
 * Optionally accepts $args['service_id'] (1 to 4)
 * If not provided, it looks for 'pricing_service_id' post meta.
 * If not set, it skips rendering.
 */

$page_id = get_queried_object_id();
$service_id = isset($args['service_id']) ? $args['service_id'] : get_post_meta($page_id, 'pricing_service_id', true);

// If no service_id is found, do not render anything
if (empty($service_id) || $service_id < 1 || $service_id > 4) {
    return;
}

$services = [
    1 => "Bookkeeping Services",
    2 => "Accounting Services",
    3 => "Taxation Services",
    4 => "Business Formation Services"
];
$service_name = $services[$service_id];

// Dynamic title and subtitle (can be overridden by args)
$subtitle = isset($args['subtitle']) ? $args['subtitle'] : get_post_meta($page_id, 'pricing_subtitle', true);
$title = isset($args['title']) ? $args['title'] : get_post_meta($page_id, 'pricing_title', true);

$hide_subtitle = isset($args['hide_subtitle']) ? $args['hide_subtitle'] : false;

// Fallbacks
if (empty($subtitle) && !$hide_subtitle) { $subtitle = strtoupper($service_name); }
if (empty($title)) { $title = 'Our Pricing Plans'; }

$tiers = ['Bronze', 'Silver', 'Gold', 'Platinum'];

$cards = [];

// Load the 4 tiers for the chosen service
for ($i = 1; $i <= 4; $i++) {
    $tier_name = $tiers[$i - 1];
    
    $card_price = get_theme_mod("pricing_svc_{$service_id}_tier_{$i}_price");
    $card_desc = get_theme_mod("pricing_svc_{$service_id}_tier_{$i}_desc");
    
    $card_link = get_theme_mod("pricing_svc_{$service_id}_tier_{$i}_link");
    if (empty($card_link) || $card_link === '#') {
        $card_link = home_url('/contact/');
    }

    $cards[] = [
        'number' => '0' . $i,
        'title' => $tier_name,
        'price' => $card_price,
        'desc' => $card_desc,
        'link' => $card_link
    ];
}
// Removed old loop

// Only render if we have cards to show
if (!empty($cards)) :
?>

<section class="pricing-plans-section">
    
    <div class="container">
        <div class="pricing-header">
            <?php if (!empty($subtitle) && !$hide_subtitle) : ?>
                <span class="section-subtitle pricing-subtitle"><?php echo esc_html($subtitle); ?></span>
            <?php endif; ?>
            <h2><?php echo wp_kses_post($title); ?></h2>
        </div>

        <div class="pricing-grid">
            <?php foreach ($cards as $index => $card) : ?>
                <div class="pricing-card">
                    <div class="pricing-card-inner">
                        <span class="pricing-num"><?php echo esc_html($card['number']); ?></span>
                        <h3 class="pricing-card-title"><?php echo esc_html($card['title']); ?></h3>
                        
                        <div class="pricing-price-box">
                            <span class="pricing-amount"><?php echo esc_html($card['price']); ?></span>
                        </div>
                        
                        <div class="pricing-desc-box">
                            <p><?php echo esc_html($card['desc']); ?></p>
                        </div>
                        
                        <a href="<?php echo esc_url($card['link']); ?>" class="pricing-btn">GET STARTED</a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>
