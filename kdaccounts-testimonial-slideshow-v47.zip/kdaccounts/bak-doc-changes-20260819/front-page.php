<?php get_header(); ?>

<main id="primary" class="site-main">

    <?php get_template_part( 'template-parts/sections/hero' ); ?>
    <?php get_template_part( 'template-parts/sections/about' ); ?>
    <?php get_template_part( 'template-parts/sections/services' ); ?>
    <?php get_template_part( 'template-parts/sections/features' ); ?>
    <?php get_template_part( 'template-parts/sections/who-we-are' ); ?>
    <?php get_template_part( 'template-parts/sections/solutions' ); ?>
    <?php get_template_part( 'template-parts/sections/testimonials' ); ?>
    <?php get_template_part( 'template-parts/sections/financial-support' ); ?>
    <?php get_template_part( 'template-parts/sections/faq' ); ?>
    <?php get_template_part( 'template-parts/sections/contact' ); ?>
    <?php get_template_part( 'template-parts/sections/latest-posts' ); ?>

</main>

<?php get_footer(); ?>
