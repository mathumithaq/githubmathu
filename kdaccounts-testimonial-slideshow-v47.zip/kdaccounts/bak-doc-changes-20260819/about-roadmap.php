<?php
/**
 * About Roadmap Section
 */
?>
<section class="about-roadmap-section">
    <div class="container">
        <div class="roadmap-header">
            <span class="section-subtitle">ROADMAP</span>
            <h2 class="roadmap-main-title">BUFFALO, NY'S SIMPLIFIED OUTSOURCED ACCOUNTING & TAX ROADMAP TOWARDS SUCCESS IN FINANCES</h2>
        </div>
        
        <div class="roadmap-grid">
            
            <!-- Left Side: Image -->
            <div class="roadmap-image-col">
                <div class="roadmap-image-wrapper">
                    <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/about-roadmap.webp'); ?>" alt="Financial Roadmap Strategy" loading="lazy">
                </div>
            </div>
            
            <!-- Right Side: Timeline -->
            <div class="roadmap-timeline-col">
                <div class="roadmap-timeline">
                    
                    <!-- Step 1 -->
                    <div class="timeline-item">
                        <div class="timeline-icon">
                            <?php echo file_get_contents(get_template_directory() . '/assets/icons/icon-discover.svg'); ?>
                        </div>
                        <div class="timeline-content">
                            <h3>DISCOVERING</h3>
                            <p>We take the time to understand your goals, challenges, and priorities to gain a complete picture of your financial situation.</p>
                        </div>
                    </div>
                    
                    <!-- Step 2 -->
                    <div class="timeline-item">
                        <div class="timeline-icon">
                            <?php echo file_get_contents(get_template_directory() . '/assets/icons/icon-plan.svg'); ?>
                        </div>
                        <div class="timeline-content">
                            <h3>PLAN & CUSTOMIZE</h3>
                            <p>Our team develops customized financial strategies tailored to your unique needs.</p>
                        </div>
                    </div>
                    
                    <!-- Step 3 -->
                    <div class="timeline-item">
                        <div class="timeline-icon">
                            <?php echo file_get_contents(get_template_directory() . '/assets/icons/icon-implement.svg'); ?>
                        </div>
                        <div class="timeline-content">
                            <h3>IMPLEMENT & REVIEW</h3>
                            <p>We implement solutions with precision, regularly review performance, and ensure your complete satisfaction.</p>
                        </div>
                    </div>
                    
                </div>
            </div>
            
        </div>
    </div>
</section>
