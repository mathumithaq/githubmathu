<?php
/**
 * Contact Section
 */
?>
<section class="contact-section">
    <div class="container">
        
        <div class="contact-header">
            <span class="section-subtitle">CONTACT US</span>
            <h2 class="contact-main-title">GET IN TOUCH WITH US</h2>
        </div>
        
        <div class="contact-grid">
            
            <!-- Left Column: Map -->
            <div class="contact-map-col">
                <div class="contact-map-wrapper">
                    <!-- Google Maps Embed for Buffalo, NY -->
                    <iframe class="lazy-map" title="Google Maps Location" data-src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2225.7768014476023!2d-78.85885549999999!3d42.9140826!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89d313ce1bc950a3%3A0xd84ceefc1440ddfe!2sKD%20Accounting%20%26%20Tax!5e1!3m2!1sen!2slk!4v1785943552631!5m2!1sen!2slk" width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="strict-origin-when-cross-origin"></iframe>
                </div>
            </div>
            
            <!-- Right Column: GHL Form -->
            <div class="contact-form-col">
                <?php get_template_part('partials/form/form'); ?>
            </div>
            
        </div>
    </div>
</section>

