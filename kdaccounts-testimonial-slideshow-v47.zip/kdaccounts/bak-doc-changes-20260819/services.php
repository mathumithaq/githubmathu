<?php
/**
 * Services Section
 */
?>
<section class="services-section">
    <div class="container">
        <div class="services-header">
            <span class="section-subtitle">OUR SERVICES</span>
            <?php if ( is_page('about') ) : ?>
                <h2 class="services-title" style="text-transform: uppercase; font-size: 2.2rem;">GROW EFFICIENTLY AND MANAGE MONEY WITH COMPREHENSIVE ACCOUNTING SERVICES IN BUFFALO, NY</h2>
            <?php else : ?>
                <h2 class="services-title">Buffalo's Trusted Home for All Your Accounting & Tax Needs</h2>
            <?php endif; ?>
        </div>

        <div class="services-grid">
            <?php
            $services = [
                [
                    'title' => 'Accounting Services',
                    'image' => 'service-accounting.webp',
                    'icon'  => 'accounting.svg',
                    'text'  => 'From startups to corporations, we improve your financial status with our strategic accounting services. Everything from financial statements preparation, managing cash flows, budgeting, to financial analytics and advisory.',
                    'link'  => home_url('/accounting-services/')
                ],
                [
                    'title' => 'Tax Services',
                    'image' => 'service-tax.webp',
                    'icon'  => 'tax.svg',
                    'text'  => 'Simplify your tax burden with tax prep in Buffalo. Whether you’re an individual or a business, we help you with accurate tax planning and preparation, filings, solving tax and IRS issues, and legal compliance.',
                    'link'  => home_url('/tax-filing-services/')
                ],
                [
                    'title' => 'Bookkeeping Services',
                    'image' => 'service-bookkeeping.webp',
                    'icon'  => 'bookkeeping.svg',
                    'text'  => 'Keep tabs on your finances with our bookkeeping in Buffalo, NY. We help you keep up to date and precise financial records, handle payroll accurately, reconcile accounts, and use accounting software easily.',
                    'link'  => home_url('/bookkeeping-services/')
                ],
                [
                    'title' => 'Tax Planning Services',
                    'image' => 'service-tax-planning.webp',
                    'icon'  => 'tax-planning.svg',
                    'text'  => 'Our tax planning services cover retirement tax planning, business tax planning, and IRS tax planning. Reduce liabilities, maximize savings, and ensure compliance and long-term financial stability with us.',
                    'link'  => home_url('/tax-planning-services/')
                ],
                [
                    'title' => 'Payroll Services',
                    'image' => 'service-payroll.webp',
                    'icon'  => 'payroll.svg',
                    'text'  => 'Trustworthy payroll management, which is designed to provide on-time, accurate payroll services for small businesses. Save time and focus on your growth; we’ll manage employee payroll for you.',
                    'link'  => home_url('/#/')
                ],
                [
                    'title' => 'Business Registration',
                    'image' => 'service-registration.webp',
                    'icon'  => 'registration.svg',
                    'text'  => 'Start your business stress-free and legally compliant. We help you get a smooth launch from choosing a business structure, business registration, handling paperwork, to providing advisory services at every step.',
                    'link'  => home_url('/business-registration-services/')
                ]
            ];

            foreach ($services as $service) :
            ?>
            <div class="service-card">
                <div class="service-image-wrapper">
                    <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/' . $service['image'] . '?v=2'); ?>" alt="<?php echo esc_attr($service['title']); ?>" loading="lazy" width="600" height="600">
                </div>
                <div class="service-content">
                    <div class="service-content-header">
                        <div class="service-icon">
                            <?php echo file_get_contents(get_template_directory() . '/assets/icons/' . $service['icon']); ?>
                        </div>
                        <h3 class="service-title"><?php echo esc_html($service['title']); ?></h3>
                    </div>
                    <p class="service-text"><?php echo esc_html($service['text']); ?></p>
                    <a href="<?php echo esc_url($service['link']); ?>" class="btn">VIEW SERVICE</a>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

