<?php
/**
 * Inner Hero Section for standard pages.
 * Two-column: page title/subtitle/CTA left, consultation form right,
 * CSS-only crossfading background photos (no JS).
 * Previous version backed up in inner-hero.php.bak-20260819.
 */

// Get custom fields or fallback to default page title
$hero_title = get_post_meta( get_the_ID(), 'inner_hero_title', true );
if ( empty( $hero_title ) ) {
    $hero_title = get_the_title(); // Fallback to page title
}

$hero_subtitle = get_post_meta( get_the_ID(), 'inner_hero_text', true );
$hero_btn_text = get_post_meta( get_the_ID(), 'inner_hero_btn_text', true );
$hero_btn_url = get_post_meta( get_the_ID(), 'inner_hero_btn_url', true );

if ( empty( $hero_btn_text ) ) {
    $hero_btn_text = 'Schedule an Appointment';
}
if ( empty( $hero_btn_url ) ) {
    $hero_btn_url = home_url('/contact/');
}

$kda_img = get_template_directory_uri() . '/assets/images/';
?>
<section class="kda-hero kda-hero--inner">

    <div class="kda-hero-slides" aria-hidden="true">
        <img class="kda-hero-slide" src="<?php echo esc_url($kda_img . 'hero-slide-1.webp'); ?>" alt="" width="1920" height="1080" fetchpriority="high" decoding="async">
        <img class="kda-hero-slide" src="<?php echo esc_url($kda_img . 'hero-slide-2.webp'); ?>" alt="" width="1920" height="1080" loading="lazy" decoding="async">
        <img class="kda-hero-slide" src="<?php echo esc_url($kda_img . 'hero-slide-3.webp'); ?>" alt="" width="1920" height="1080" loading="lazy" decoding="async">
    </div>
    <div class="kda-hero-scrim"></div>

    <div class="container kda-hero-inner">

        <div class="kda-hero-left">
            <div class="kda-hero-crumbs">
                <a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a>
                <span class="sep" aria-hidden="true">&rsaquo;</span>
                <span><?php echo esc_html( get_the_title() ); ?></span>
            </div>
            <h2 class="kda-hero-title"><?php echo esc_html( $hero_title ); ?></h2>

            <?php if ( ! empty( $hero_subtitle ) ) : ?>
                <p class="kda-hero-sub"><?php echo esc_html( $hero_subtitle ); ?></p>
            <?php endif; ?>

            <div class="kda-hero-ctas">
                <a href="<?php echo esc_url( $hero_btn_url ); ?>" class="btn"><?php echo wp_kses_post( $hero_btn_text ); ?></a>
            </div>
        </div>

        <aside class="kda-hero-form">
            <?php get_template_part('partials/form/hero-form'); ?>
        </aside>

    </div>
</section>
