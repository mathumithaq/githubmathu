<?php
/**
 * Sub Services Hero Section.
 * Blog listing (is_home) keeps the original simple hero; every other page
 * gets the two-column hero with the consultation form.
 * Previous version backed up in sub-hero.php.bak-20260819.
 */

// Get custom fields or fallback to default page title
$page_id = get_queried_object_id();
$hero_title = '';

if ( function_exists('get_field') ) {
    $hero_title = get_field('sub_hero_title', $page_id);
    if ( empty( $hero_title ) ) {
        $hero_title = get_field('sub-hero-title', $page_id);
    }
}

if ( empty( $hero_title ) ) {
    $hero_title = get_post_meta( $page_id, 'sub_hero_title', true );
}
if ( empty( $hero_title ) ) {
    $hero_title = get_post_meta( $page_id, 'sub-hero-title', true ); // Added hyphen version just in case
}
if ( empty( $hero_title ) ) {
    $hero_title = get_post_meta( $page_id, 'inner_hero_title', true );
}
if ( empty( $hero_title ) ) {
    if ( is_home() ) {
        $posts_page_id = get_option( 'page_for_posts' );
        if ( $posts_page_id ) {
            $hero_title = get_the_title( $posts_page_id );
        } else {
            $hero_title = 'Our Blog';
        }
    } else {
        $hero_title = get_the_title( $page_id ); // Fallback to page title
    }
}

$hero_subtitle = '';

if ( function_exists('get_field') ) {
    $hero_subtitle = get_field('sub_hero_text', $page_id);
    if ( empty( $hero_subtitle ) ) {
        $hero_subtitle = get_field('sub-hero-text', $page_id);
    }
}

if ( empty( $hero_subtitle ) ) {
    $hero_subtitle = get_post_meta( $page_id, 'sub_hero_text', true );
}
if ( empty( $hero_subtitle ) ) {
    $hero_subtitle = get_post_meta( $page_id, 'sub-hero-text', true );
}
if ( empty( $hero_subtitle ) ) {
    $hero_subtitle = get_post_meta( $page_id, 'inner_hero_text', true );
}

if ( is_home() ) :
    // Blog listing keeps the original simple hero (no form / slider).
    $bg_image_url = get_template_directory_uri() . '/assets/images/sub-hero-bg.webp';
?>
<section class="sub-hero-section">
    <img class="sub-hero-bg"
         src="<?php echo esc_url( $bg_image_url ); ?>"
         alt="<?php echo esc_attr( $hero_title ); ?> Background"
         fetchpriority="high"
         decoding="async"
         width="1600"
         height="900">
    <div class="sub-hero-overlay"></div>

    <div class="container sub-hero-content">
        <h1 class="sub-hero-title"><?php echo wp_kses_post( $hero_title ); ?></h1>

        <?php if ( ! empty( $hero_subtitle ) ) : ?>
            <p class="sub-hero-subtitle"><?php echo wp_kses_post( $hero_subtitle ); ?></p>
        <?php endif; ?>

        <div class="sub-hero-breadcrumbs">
            <a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a>
            <span class="breadcrumb-separator">
                <svg viewBox="0 0 24 24" fill="none" stroke="var(--color-primary)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="16" height="16"><polyline points="9 18 15 12 9 6"></polyline></svg>
            </span>
            <span><?php echo esc_html( $hero_title ); ?></span>
        </div>
    </div>
</section>
<?php else :
    $kda_img = get_template_directory_uri() . '/assets/images/';
?>
<section class="kda-hero kda-hero--inner">

    <div class="kda-hero-slides" aria-hidden="true">
        <img class="kda-hero-slide" src="<?php echo esc_url($kda_img . 'hero-slide-1.webp'); ?>" alt="" width="1920" height="1080" fetchpriority="high" decoding="async">
        <img class="kda-hero-slide" src="<?php echo esc_url($kda_img . 'hero-slide-2.webp'); ?>" alt="" width="1920" height="1080" loading="lazy" decoding="async">
        <img class="kda-hero-slide" src="<?php echo esc_url($kda_img . 'hero-slide-3.webp'); ?>" alt="" width="1920" height="1080" loading="lazy" decoding="async">
    </div>
    <div class="kda-hero-scrim"></div>

    <div class="container kda-hero-inner">

        <div class="kda-hero-left">
            <div class="kda-hero-crumbs">
                <a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a>
                <span class="sep" aria-hidden="true">&rsaquo;</span>
                <span><?php echo esc_html( get_the_title( $page_id ) ); ?></span>
            </div>

            <h1 class="kda-hero-title"><?php echo wp_kses_post( $hero_title ); ?></h1>

            <?php if ( ! empty( $hero_subtitle ) ) : ?>
                <p class="kda-hero-sub"><?php echo wp_kses_post( $hero_subtitle ); ?></p>
            <?php endif; ?>

            <div class="kda-hero-ctas">
                <a href="<?php echo esc_url( home_url('/contact/') ); ?>" class="btn">Schedule an Appointment</a>
            </div>
        </div>

        <aside class="kda-hero-form">
            <?php get_template_part('partials/form/hero-form'); ?>
        </aside>

    </div>
</section>
<?php endif; ?>
