<?php
/**
 * Who We Are Section
 */
?>
<section class="who-we-are-section">
    <div class="container">
        <div class="who-we-are-header" style="margin-bottom: 40px;">
            <span class="section-subtitle">WHO WE ARE</span>
            <h2 class="who-main-title">SIMPLIFY FINANCES WITH TRUSTED & RELIABLE CPA ACCOUNTING SOLUTIONS IN BUFFALO, NY</h2>
        </div>
        
        <div class="who-we-are-grid">
            
            <!-- Right Column: Content -->
            <div class="who-content-col">
                
                <p class="who-text">Stress free financing solutions from KD Accounting and Tax, a trusted CPA firm in Buffalo, NY. We provide all financial services under one roof, from premium consulting and tax services to accounting and financial planning.</p>
                
                <p class="who-text">From individuals to startups, businesses to cooperatives, our services are extended to you. You can get outsourced accounting and bookkeeping to improve accuracy and simplify finances, business tax preparation and planning to maximize tax returns, and business registration services designed to eliminate errors.</p>
                
                <p class="who-text">Our experienced CPA Accountants ensure your legal compliance while fueling financial growth. With us, finances will no longer be a headache!</p>
                
                <div class="who-cta">
                    <a href="<?php echo esc_url(home_url('/contact/')); ?>" class="btn btn-primary">Contact Us</a>
                </div>
            </div>

        </div>
    </div>
</section>

