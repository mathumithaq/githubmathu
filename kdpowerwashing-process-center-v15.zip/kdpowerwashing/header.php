<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    
    <!-- KD Power Washing favicon -->
    <link rel="icon" href="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/kd-site-icon-192.png" type="image/png">
    <link rel="shortcut icon" href="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/kd-site-icon-32.png" type="image/png">

    <!-- Preconnect to third-party domains to improve LCP and reduce critical path latency -->
    <link rel="preconnect" href="https://app.kdpowerwashing.com" crossorigin>
    <link rel="dns-prefetch" href="https://app.kdpowerwashing.com">
    <link rel="preconnect" href="https://widgets.leadconnectorhq.com" crossorigin>
    <link rel="dns-prefetch" href="https://widgets.leadconnectorhq.com">

    <?php wp_head(); ?>

    <!-- LCP Preload for Single Posts -->
    <?php if ( is_single() ) : ?>
        <?php 
        $preload_img = get_the_post_thumbnail_url(get_the_ID(), 'full');
        if (!$preload_img) {
            $preload_img = get_template_directory_uri() . '/assets/images/inner-hero2.webp';
        }
        ?>
        <link rel="preload" as="image" href="<?php echo esc_url($preload_img); ?>" fetchpriority="high">
    <?php endif; ?>

    <!-- SEO Meta Description Fallback -->
    <?php
    $meta_desc = get_bloginfo('description');
    if (is_single() || is_page()) {
        global $post;
        if (!empty($post->post_excerpt)) {
            $meta_desc = strip_tags($post->post_excerpt);
        } elseif (!empty($post->post_content)) {
            $meta_desc = wp_trim_words(strip_tags($post->post_content), 25, '...');
        }
    }
    if (empty(trim($meta_desc))) {
        $meta_desc = "KD Power Washing provides professional, affordable, and reliable cleaning services in Buffalo. We specialize in making homes and businesses look spotless.";
    }
    ?>
    <meta name="description" content="<?php echo esc_attr(str_replace(array("\r", "\n"), '', $meta_desc)); ?>">
</head>

<body <?php body_class(); ?>>
    <?php wp_body_open(); ?>

    <header id="masthead" class="site-header">
        <?php get_template_part('template-parts/header/navbar'); ?>
    </header>
    <?php get_template_part('template-parts/header/mobile-menu'); ?>