<?php
/**
 * Template Name: Blog Page Fallback
 * 
 * Automatically loads if the slug is 'blog'
 */
get_header();
get_template_part('template-parts/header/inner-hero');
// We want 6 posts per page for a 3-column layout
$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
$args = array(
    'post_type'      => 'post',
    'post_status'    => 'publish',
    'posts_per_page' => 6,
    'paged'          => $paged,
);

$blog_query = new WP_Query( $args );
?>



<!-- Blog Listing Section (3-Column Layout) -->
<main id="primary" class="site-main">
<div class="kd-blog-listing-page">
    <div class="container">
        <?php if ( $blog_query->have_posts() ) : ?>
            <div class="blog-grid-3col">
                <?php while ( $blog_query->have_posts() ) : $blog_query->the_post(); ?>
                    <article class="blog-card-clean">
                        <div class="blog-card-inner">
                            <div class="blog-card-image">
                                <a href="<?php echo esc_url( get_permalink() ); ?>" aria-label="Read more about <?php echo esc_attr( get_the_title() ); ?>">
                                    <?php if ( has_post_thumbnail() ) : ?>
                                        <?php the_post_thumbnail( 'large' ); ?>
                                    <?php else : ?>
                                        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/placeholder-blog.jpg" alt="Blog Image" onerror="this.src='https://images.unsplash.com/photo-1584820927498-cafe4c120bf4?q=80&w=1000&auto=format&fit=crop'">
                                    <?php endif; ?>
                                </a>
                            </div>
                            <div class="blog-card-content">
                                <h2 class="blog-card-title"><a href="<?php echo esc_url( get_permalink() ); ?>"><?php echo wp_trim_words( get_the_title(), 10, '...' ); ?></a></h2>
                                <div class="blog-card-excerpt">
                                    <?php echo wp_trim_words( get_the_excerpt(), 15, '...' ); ?>
                                </div>
                                <div class="blog-card-date">
                                    <?php echo get_the_date( 'D M j Y' ); ?>
                                </div>
                                <div class="blog-read-more-wrapper">
                                    <a href="<?php echo esc_url( get_permalink() ); ?>" class="btn blog-read-more-btn">Read More<span class="screen-reader-text"> about <?php echo esc_html( get_the_title() ); ?></span></a>
                                </div>
                            </div>
                        </div>
                    </article>
                <?php endwhile; ?>
            </div> <!-- .blog-grid-3col -->

            <!-- Custom Pagination -->
            <div class="blog-pagination-wrapper">
                <?php 
                if ( function_exists('kd_powerwashing_pagination') ) {
                    kd_powerwashing_pagination( $blog_query->max_num_pages );
                }
                ?>
            </div>
            
            <?php wp_reset_postdata(); ?>

        <?php else : ?>
            <div class="no-posts-found">
                <h2 class="text-center">No posts found.</h2>
            </div>
        <?php endif; ?>
    </div>
</div>
</main>

<?php get_footer(); ?>
