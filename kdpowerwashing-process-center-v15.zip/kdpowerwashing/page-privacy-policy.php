<?php
/**
 * Template Name: Privacy Policy Page
 */

get_header();
get_template_part('template-parts/header/inner-hero');
?>
<main id="primary" class="site-main">
<section class="privacy-policy-section">
    <div class="container">
        <div class="privacy-content">
            <p><strong>Effective Date:</strong> 19/03/2025<br>
            <strong>Last Updated:</strong> 22/08/2025</p>
            
            <p>KD Power Washing is committed to protecting your privacy and personal data. This Privacy Policy outlines how we collect, use, and protect your information in compliance with applicable U.S. data privacy laws, including the California Consumer Privacy Act (CCPA), the New York SHIELD Act, and other relevant state and federal regulations. For users based in the European Union (EU) or European Economic Area (EEA), we also adhere to the General Data Protection Regulation (GDPR) where applicable.</p>
            
            <p>This notice provides you with the necessary information regarding your rights, our obligations, and explains why, when, and how we process your personal data.</p>
            
            <h3>The Information That We Collect From You</h3>
            <p>We process your personal information to meet our legal, contractual, and business obligations. We will never collect unnecessary personal data or process your information in ways other than those specified in this notice.</p>
            
            <p>The personal data we collect includes:</p>
            <ul class="privacy-list">
                <li>Name</li>
                <li>Address</li>
                <li>Email</li>
                <li>Telephone Number</li>
                <li>Mobile Telephone Number</li>
                <li>Contact person(s) contact information</li>
                <li>Our correspondence and communications with you</li>
            </ul>
            
            <h3>How Your Personal Data May Be Used</h3>
            <p>KD Power Washing respects your privacy and will never disclose, share, or sell your data without your consent, unless required to do so by law. We retain your data only for as long as is necessary for the purposes specified in this notice.</p>
            
            <p>We use your personal data to:</p>
            <ul class="privacy-list">
                <li>Provide services and ensure that all requirements are completed</li>
                <li>Occasionally send marketing information when beneficial and of interest to you as a customer, processed under legitimate interests</li>
                <li>Share necessary information with independent contractors or subcontractors for performing services related to our business</li>
            </ul>
            
            <p>Providing your personal information is voluntary; however, without it, we may not be able to offer some or all of our services.</p>
            
            <h3>Your Rights In Relation to Your Information</h3>
            <p>Depending on your location, you have certain rights regarding your personal information:</p>
            
            <h4>Under U.S. State Laws (e.g., CCPA):</h4>
            <ul class="privacy-list">
                <li>The right to know what personal data we collect and why</li>
                <li>The right to request access to your data</li>
                <li>The right to request deletion of your data (subject to certain legal exceptions)</li>
                <li>The right to opt out of the sale of personal data (if applicable)</li>
            </ul>
            
            <h4>Under GDPR (for EU/EEA users):</h4>
            <ul class="privacy-list">
                <li>The right to access your personal data</li>
                <li>The right to rectify or delete your data</li>
                <li>The right to restrict processing or object to its use</li>
                <li>The right to data portability</li>
            </ul>
            
            <p>If you wish to exercise any of these rights, we may ask you to verify your identity to ensure your data is protected and secure.</p>
            
            <h3>Sharing and Disclosing Your Personal Information</h3>
            <p>We do not share or disclose your personal information without your consent, except for the purposes specified in this notice or as required by law. We may use third-party service providers, but they process your data only under our instructions and comply fully with this Privacy Policy and applicable laws.</p>
            
            <h3>Safeguarding Measures</h3>
            <p>We take every reasonable measure to protect your personal data from unauthorized access, alteration, disclosure, or destruction.</p>
            
            <h3>Transfers Outside the U.S. or EU</h3>
            <p>If your data is transferred outside the U.S. or EU, we ensure it is protected by appropriate safeguards in compliance with applicable laws.</p>
            
            <h3>How Long We Keep Your Data</h3>
            <p>We retain personal information only as long as necessary for the purposes outlined in this Privacy Policy. If you consent to receive marketing communications, we retain your data until you withdraw your consent.</p>
            
            <h3>Use of Cookies</h3>
            <p>This website uses cookies to enhance your experience. The cookies used on this site do not store personal data but instead collect anonymous tracking information.</p>
            
            <h3>Grievance</h3>
            <p>We process your personal information in compliance with this Privacy Policy and applicable laws. If you have any concerns or wish to lodge a complaint, you may contact us directly. For unresolved complaints, you can contact the New York Attorney General’s Office or other relevant regulatory authorities in your jurisdiction.</p>
            
            <h3>Linking to Other Sites from Our Website</h3>
            <p>Our website contains links to other sites not managed by KD Power Washing. We are not responsible for the privacy practices of these sites. We encourage users to read the privacy statements of all linked websites.</p>
        </div>
    </div>
</section>

<?php get_template_part('template-parts/sections/quoate'); ?>
</main>
<?php
get_footer();
?>
