<?php
/**
 * Template Name: Blog Page
 * 
 * The template for displaying the custom blog listing page.
 */
get_header();

// We want 5 posts per page
$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
$args = array(
    'post_type'      => 'post',
    'post_status'    => 'publish',
    'posts_per_page' => 5,
    'paged'          => $paged,
);

$blog_query = new WP_Query( $args );
?>

<!-- Blog Page Header (Inner Hero Style) -->
<section class="kd-inner-hero">
    <div class="inner-hero-bg">
        <div class="circle-top"></div>
        <div class="circle-bottom"></div>
    </div>
    <div class="container relative">
        <h1 class="inner-hero-title">Our Latest <span>News & Tips</span></h1>
        <p class="inner-hero-desc">Discover the best practices, tips, and updates about power washing and maintaining your property.</p>
    </div>
</section>

<!-- Blog Listing Section -->
<div class="kd-blog-listing-page">
    <div class="container">
        <?php if ( $blog_query->have_posts() ) : ?>
            <div class="blog-grid-wrapper">
                <?php
                $post_count = 0;
                while ( $blog_query->have_posts() ) : $blog_query->the_post();
                    $post_count++;
                    
                    // First post is featured
                    if ( $post_count === 1 ) :
                ?>
                        <article class="blog-card blog-card-featured">
                            <a href="<?php echo esc_url( get_permalink() ); ?>" class="blog-card-link">
                                <div class="blog-card-image">
                                    <?php if ( has_post_thumbnail() ) : ?>
                                        <?php the_post_thumbnail( 'large' ); ?>
                                    <?php else : ?>
                                        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/placeholder-blog.jpg" alt="Blog Featured Image" onerror="this.src='https://images.unsplash.com/photo-1584820927498-cafe4c120bf4?q=80&w=2070&auto=format&fit=crop'">
                                    <?php endif; ?>
                                    
                                    <div class="blog-card-category">
                                        <?php
                                        $categories = get_the_category();
                                        if ( ! empty( $categories ) ) {
                                            echo esc_html( $categories[0]->name );
                                        } else {
                                            echo 'News';
                                        }
                                        ?>
                                    </div>
                                </div>
                                <div class="blog-card-content">
                                    <div class="blog-card-meta">
                                        <span class="blog-card-date">
                                            <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M19 4H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 16H5V10h14v10zM5 8V6h14v2H5zm2-6h2v2H7V2zm8 0h2v2h-2V2z" fill="currentColor"/></svg>
                                            <?php echo get_the_date( 'M j, Y' ); ?>
                                        </span>
                                    </div>
                                    <h2 class="blog-card-title"><?php the_title(); ?></h2>
                                    <div class="blog-card-excerpt">
                                        <?php echo wp_trim_words( get_the_excerpt(), 25, '...' ); ?>
                                    </div>
                                    <span class="blog-read-more">Read Full Article <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M5 12h14M12 5l7 7-7 7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></span>
                                </div>
                            </a>
                        </article>
                        
                        <!-- Open standard grid for remaining posts -->
                        <div class="blog-standard-grid">
                <?php
                    else : // Standard Grid Posts
                ?>
                        <article class="blog-card blog-card-standard">
                            <a href="<?php echo esc_url( get_permalink() ); ?>" class="blog-card-link">
                                <div class="blog-card-image">
                                    <?php if ( has_post_thumbnail() ) : ?>
                                        <?php the_post_thumbnail( 'medium_large' ); ?>
                                    <?php else : ?>
                                        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/placeholder-blog.jpg" alt="Blog Image" onerror="this.src='https://images.unsplash.com/photo-1527515637462-cff94eecc1ac?q=80&w=1974&auto=format&fit=crop'">
                                    <?php endif; ?>
                                </div>
                                <div class="blog-card-content">
                                    <div class="blog-card-meta">
                                        <div class="blog-card-category">
                                            <?php
                                            $categories = get_the_category();
                                            if ( ! empty( $categories ) ) {
                                                echo esc_html( $categories[0]->name );
                                            } else {
                                                echo 'News';
                                            }
                                            ?>
                                        </div>
                                        <span class="blog-card-date">
                                            <?php echo get_the_date( 'M j, Y' ); ?>
                                        </span>
                                    </div>
                                    <h3 class="blog-card-title"><?php echo wp_trim_words( get_title(), 10, '...' ); ?></h3>
                                    <div class="blog-card-excerpt">
                                        <?php echo wp_trim_words( get_the_excerpt(), 15, '...' ); ?>
                                    </div>
                                    <span class="blog-read-more" aria-label="Read more about <?php echo esc_attr( get_the_title() ); ?>">Read More <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M5 12h14M12 5l7 7-7 7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></span>
                                </div>
                            </a>
                        </article>
                <?php
                    endif;
                endwhile;
                
                // Close standard grid if it was opened (i.e. more than 1 post existed)
                if ( $post_count > 1 ) {
                    echo '</div>'; 
                }
                ?>
            </div> <!-- .blog-grid-wrapper -->

            <!-- Custom Pagination -->
            <div class="blog-pagination-wrapper">
                <?php 
                if ( function_exists('kd_powerwashing_pagination') ) {
                    kd_powerwashing_pagination( $blog_query->max_num_pages );
                }
                ?>
            </div>
            
            <?php wp_reset_postdata(); ?>

        <?php else : ?>
            <div class="no-posts-found">
                <h2>No posts found.</h2>
                <p>Check back later for exciting news and updates!</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php
get_footer();
