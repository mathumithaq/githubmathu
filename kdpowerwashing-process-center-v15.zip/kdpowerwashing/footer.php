<?php get_template_part('template-parts/footer/site-footer'); ?>

<!-- Back to Top Button -->
<a href="#" id="back-to-top" class="back-to-top" aria-label="Back to top">
    <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/arrow-up.svg" alt="Up">
    <span>Back to top</span>
</a>

<!-- Delayed 3rd Party Scripts (Chatbot, Forms, Maps) -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    let scriptsLoaded = false;
    function loadDelayedResources() {
        if (scriptsLoaded) return;
        scriptsLoaded = true;
        
        // 1. Load Chat Widget
        let chatScript = document.createElement('script');
        chatScript.src = 'https://widgets.leadconnectorhq.com/loader.js';
        chatScript.setAttribute('data-resources-url', 'https://widgets.leadconnectorhq.com/chat-widget/loader.js');
        chatScript.setAttribute('data-widget-id', '690b81717907ec354e0b4010');
        chatScript.defer = true;
        document.body.appendChild(chatScript);
        
        // 2. Load Form Embed
        let formScript = document.createElement('script');
        formScript.src = 'https://app.kdpowerwashing.com/js/form_embed.js';
        formScript.defer = true;
        document.body.appendChild(formScript);
        
        // 3. Load Maps
        let lazyIframes = document.querySelectorAll('.lazy-iframe');
        lazyIframes.forEach(function(iframe) {
            if(iframe.hasAttribute('data-src')) {
                iframe.src = iframe.getAttribute('data-src');
            }
        });
    }
    
    // Trigger on first interaction or after a short delay
    let events = ['mouseover', 'keydown', 'touchmove', 'touchstart', 'scroll'];
    events.forEach(function(e) {
        window.addEventListener(e, loadDelayedResources, { once: true, passive: true });
    });
    
    // Fallback if no interaction
    setTimeout(loadDelayedResources, 5000);
});
</script>

<?php wp_footer(); ?>
</body>
</html>
