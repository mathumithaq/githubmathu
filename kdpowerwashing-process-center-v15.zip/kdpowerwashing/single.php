<?php
/**
 * Single Blog Post Template
 */

get_header();
?>

<?php while (have_posts()):
    the_post(); ?>

    <!-- Blog Post Hero Section -->
    <?php
    $featured_img_url = get_the_post_thumbnail_url(get_the_ID(), 'full');
    if (!$featured_img_url) {
        // Fallback image if no featured image is set
        $featured_img_url = get_template_directory_uri() . '/assets/images/inner-hero2.webp';
    }
    ?>
    <section class="single-blog-hero" style="background-image: url('<?php echo esc_url($featured_img_url); ?>');">
        <div class="single-hero-overlay"></div>
        <div class="container single-hero-content">

            <!-- Category Badge -->
            <div class="single-post-categories">
                <?php
                $categories = get_the_category();
                if (!empty($categories)) {
                    foreach ($categories as $category) {
                        echo '<a href="' . esc_url(get_category_link($category->term_id)) . '" class="post-cat-badge">' . esc_html($category->name) . '</a>';
                    }
                }
                ?>
            </div>

            <!-- Post Title -->
            <h1 class="single-post-title"><?php the_title(); ?></h1>

            <!-- Post Meta -->
            <div class="single-post-meta">
                <span class="meta-item">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                        stroke-linejoin="round">
                        <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                        <circle cx="12" cy="7" r="4"></circle>
                    </svg>
                    <?php echo get_the_author(); ?>
                </span>
                <span class="meta-item">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                        stroke-linejoin="round">
                        <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                        <line x1="16" y1="2" x2="16" y2="6"></line>
                        <line x1="8" y1="2" x2="8" y2="6"></line>
                        <line x1="3" y1="10" x2="21" y2="10"></line>
                    </svg>
                    <?php echo get_the_date(); ?>
                </span>
            </div>

        </div>
    </section>

    <!-- Main Content Area -->
    <main class="single-blog-content-area">
        <div class="container">
            <div class="single-post-wrapper">

                <!-- Post Content -->
                <article class="single-post-article">
                    <?php the_content(); ?>
                </article>

                <!-- Simple Post FAQs -->
                <div class="simple-post-faqs">
                    <span class="faqs-title">Frequently Asked Questions</span>
                    <div class="accordion-container">
                        <!-- FAQ 1 -->
                        <div class="accordion-item">
                            <button class="accordion-header">
                                Does power washing increase the value of a home?
                                <span class="accordion-icon"></span>
                            </button>
                            <div class="accordion-body">
                                <div class="accordion-content">
                                    Washing of the exteriors with high pressure increases the appeal of the property from
                                    the street, which attracts more buyers and enhances the value the buyers see.
                                </div>
                            </div>
                        </div>

                        <!-- FAQ 2 -->
                        <div class="accordion-item">
                            <button class="accordion-header">
                                Is professional power washing better than DIY?
                                <span class="accordion-icon"></span>
                            </button>
                            <div class="accordion-body">
                                <div class="accordion-content">
                                    Professional cleaning also brings the use of better, even more specialized equipment,
                                    and safety that ensures long-term results.
                                </div>
                            </div>
                        </div>

                        <!-- FAQ 3 -->
                        <div class="accordion-item">
                            <button class="accordion-header">
                                How often should I power wash my house?
                                <span class="accordion-icon"></span>
                            </button>
                            <div class="accordion-body">
                                <div class="accordion-content">
                                    Professional power washing is recommended for most homes once a year, though it might be
                                    more frequently done for homes with high temperatures or areas with shade.
                                </div>
                            </div>
                        </div>

                        <!-- FAQ 4 -->
                        <div class="accordion-item">
                            <button class="accordion-header">
                                Is power washing safe to use on all exterior surfaces?
                                <span class="accordion-icon"></span>
                            </button>
                            <div class="accordion-body">
                                <div class="accordion-content">
                                    Absolutely, as long as you employ a qualified professional who knows exactly how much
                                    pressure to apply to any specific surface without hurting it.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Post Footer: Tags -->
                <?php $tags = get_the_tags();
                if ($tags): ?>
                    <div class="single-post-tags">
                        <span class="tags-label">Tags:</span>
                        <div class="tags-list">
                            <?php foreach ($tags as $tag): ?>
                                <a
                                    href="<?php echo esc_url(get_tag_link($tag->term_id)); ?>"><?php echo esc_html($tag->name); ?></a>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>

            </div>
        </div>
    </main>

    <!-- Popular / Recent Posts Section -->
    <section class="popular-posts-section">
        <div class="container">
            <h2 class="popular-posts-title">Popular Posts</h2>
            <div class="popular-posts-grid">
                <?php
                $popular_args = array(
                    'posts_per_page' => 3,
                    'post__not_in' => array(get_the_ID()),
                    'orderby' => 'comment_count', // Order by comments for "popular"
                    'order' => 'DESC'
                );
                $popular_query = new WP_Query($popular_args);
                if ($popular_query->have_posts()):
                    while ($popular_query->have_posts()):
                        $popular_query->the_post();
                        $pop_img = get_the_post_thumbnail_url(get_the_ID(), 'medium');
                        if (!$pop_img)
                            $pop_img = get_template_directory_uri() . '/assets/images/about 1.webp';
                        ?>
                        <div class="popular-post-card">
                            <a href="<?php the_permalink(); ?>" class="pop-post-img-link">
                                <img src="<?php echo esc_url($pop_img); ?>" alt="<?php the_title_attribute(); ?>">
                            </a>
                            <div class="pop-post-content">
                                <span class="pop-post-date"><?php echo get_the_date(); ?></span>
                                <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                                <a href="<?php the_permalink(); ?>" class="pop-read-more">Read Article<span
                                        class="screen-reader-text"> about <?php echo esc_html(get_the_title()); ?></span>
                                    &rarr;</a>
                            </div>
                        </div>
                        <?php
                    endwhile;
                    wp_reset_postdata();
                else:
                    echo '<p>No popular posts found.</p>';
                endif;
                ?>
            </div>
        </div>
    </section>

    <!-- Previous / Next Post Navigation -->
    <section class="single-post-navigation">
        <div class="container">
            <div class="post-nav-grid">

                <!-- Previous Post -->
                <div class="post-nav-item prev-post">
                    <?php
                    $prev_post = get_previous_post();
                    if (!empty($prev_post)):
                        ?>
                        <span class="nav-label">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                stroke-linejoin="round">
                                <line x1="19" y1="12" x2="5" y2="12"></line>
                                <polyline points="12 19 5 12 12 5"></polyline>
                            </svg>
                            Previous Post
                        </span>
                        <a href="<?php echo esc_url(get_permalink($prev_post->ID)); ?>" class="nav-title">
                            <?php echo esc_html($prev_post->post_title); ?>
                        </a>
                    <?php else: ?>
                        <span class="nav-label empty">No Previous Post</span>
                    <?php endif; ?>
                </div>

                <!-- Next Post -->
                <div class="post-nav-item next-post">
                    <?php
                    $next_post = get_next_post();
                    if (!empty($next_post)):
                        ?>
                        <span class="nav-label">
                            Next Post
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                stroke-linejoin="round">
                                <line x1="5" y1="12" x2="19" y2="12"></line>
                                <polyline points="12 5 19 12 12 19"></polyline>
                            </svg>
                        </span>
                        <a href="<?php echo esc_url(get_permalink($next_post->ID)); ?>" class="nav-title">
                            <?php echo esc_html($next_post->post_title); ?>
                        </a>
                    <?php else: ?>
                        <span class="nav-label empty">No Next Post</span>
                    <?php endif; ?>
                </div>

            </div>
        </div>
    </section>

<?php endwhile; ?>

<?php get_footer(); ?>