<?php
/** Automatically renders the shared contact layout for this page slug. */
require get_template_directory() . '/page-contact.php';
