/**
 * Font Optimizer
 * Intercepts dynamically injected Google and Bunny font stylesheets
 * and appends &display=swap to fix PageSpeed warnings.
 */
(function() {
    var originalInsertBefore = Node.prototype.insertBefore;
    var originalAppendChild = Node.prototype.appendChild;
    
    function interceptFontLink(element) {
        if (element && element.tagName === 'LINK' && element.href && (element.href.includes('fonts.bunny.net') || element.href.includes('fonts.googleapis.com'))) {
            if (!element.href.includes('display=')) {
                element.href = element.href + (element.href.includes('?') ? '&' : '?') + 'display=swap';
            }
        }
        return element;
    }

    Node.prototype.appendChild = function(child) {
        return originalAppendChild.call(this, interceptFontLink(child));
    };
    
    Node.prototype.insertBefore = function(newNode, referenceNode) {
        return originalInsertBefore.call(this, interceptFontLink(newNode), referenceNode);
    };
})();
