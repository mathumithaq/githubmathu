document.addEventListener('DOMContentLoaded', function() {
    const mobileMenuOpen = document.getElementById('mobileMenuOpen');
    const mobileMenuClose = document.getElementById('mobileMenuClose');
    const mobileMenuSidebar = document.getElementById('mobileMenuSidebar');
    const mobileMenuOverlay = document.getElementById('mobileMenuOverlay');

    function openMobileMenu() {
        if(mobileMenuSidebar && mobileMenuOverlay) {
            mobileMenuSidebar.classList.add('is-active');
            mobileMenuOverlay.classList.add('is-active');
            document.body.style.overflow = 'hidden'; // Prevent background scrolling
        }
    }

    function closeMobileMenu() {
        if(mobileMenuSidebar && mobileMenuOverlay) {
            mobileMenuSidebar.classList.remove('is-active');
            mobileMenuOverlay.classList.remove('is-active');
            document.body.style.overflow = '';
        }
    }

    if(mobileMenuOpen) {
        mobileMenuOpen.addEventListener('click', openMobileMenu);
    }

    if(mobileMenuClose) {
        mobileMenuClose.addEventListener('click', closeMobileMenu);
    }

    // Close menu when clicking outside on the overlay
    if(mobileMenuOverlay) {
        mobileMenuOverlay.addEventListener('click', closeMobileMenu);
    }

    // Sticky Glassy Navbar
    const navbar = document.querySelector('.main-navbar');
    if (navbar) {
        window.addEventListener('scroll', function() {
            if (window.scrollY > 40) {
                navbar.classList.add('is-scrolled');
            } else {
                navbar.classList.remove('is-scrolled');
            }
        });
    }

    // Mobile Submenu toggles using event delegation (Bulletproof)
    document.addEventListener('click', function(e) {
        const toggle = e.target.closest('.mobile-dropdown-toggle');
        if(toggle) {
            e.preventDefault();
            toggle.classList.toggle('is-open');
            const submenu = toggle.nextElementSibling;
            if(submenu && submenu.classList.contains('mobile-sub-menu')) {
                submenu.classList.toggle('is-open');
            }
        }
    });
});
