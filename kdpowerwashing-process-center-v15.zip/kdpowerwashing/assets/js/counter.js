document.addEventListener('DOMContentLoaded', () => {
    const marqueeTrack = document.getElementById('statsMarqueeTrack');
    if (!marqueeTrack) return;

    const statNumbers = document.querySelectorAll('.stat-number');
    let hasStarted = false;

    const observer = new IntersectionObserver((entries) => {
        if (entries[0].isIntersecting && !hasStarted) {
            hasStarted = true;
            startCounters();
        }
    }, { threshold: 0.5 });

    observer.observe(document.querySelector('.stats-marquee-wrapper'));

    function startCounters() {
        const duration = 2000; // 2 seconds
        const steps = 60;
        const interval = duration / steps;
        
        let currentStep = 0;

        const timer = setInterval(() => {
            currentStep++;
            let progress = currentStep / steps;
            
            // easeOutQuad
            progress = progress * (2 - progress);

            statNumbers.forEach(el => {
                const target = parseInt(el.getAttribute('data-target'));
                const suffix = el.getAttribute('data-suffix');
                
                let current = Math.floor(target * progress);
                
                if (currentStep >= steps) {
                    current = target;
                }
                
                // Format with commas if > 1000
                let formatted = current.toLocaleString();
                
                el.innerText = formatted + suffix;
            });

            if (currentStep >= steps) {
                clearInterval(timer);
                // Start the marquee after counter finishes
                setTimeout(() => {
                    marqueeTrack.classList.add('is-scrolling');
                }, 500); // 500ms delay before moving
            }
        }, interval);
    }
});
