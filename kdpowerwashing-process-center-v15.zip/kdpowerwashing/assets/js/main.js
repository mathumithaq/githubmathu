document.addEventListener('DOMContentLoaded', function() {
    // Back to top button functionality
    const backToTopButton = document.getElementById('back-to-top');
    
    if (backToTopButton) {
        window.addEventListener('scroll', function() {
            if (window.scrollY > 300) {
                backToTopButton.classList.add('show');
            } else {
                backToTopButton.classList.remove('show');
            }
        });
        
        backToTopButton.addEventListener('click', function(e) {
            e.preventDefault();
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }

    // WordPress navigation helpers own active state for desktop and mobile.
    // Preserve their section highlighting on posts, archives and service pages.

    // Scroll Animation (Fade Up)
    const fadeElements = document.querySelectorAll('section h2, section p, .service-card, .feature-item, .about-img-1, .about-img-2, .about-content, .why-mini-card, .process-item, .faq-item, .testi-card, .location-exp-img-wrapper, .location-exp-list li, .location-hero-content, .location-shape');
    
    // Add base class to all selected elements
    fadeElements.forEach((el, index) => {
        el.classList.add('animate-on-scroll');
        
        // Add slight stagger to elements that are likely in a grid
        if (el.classList.contains('service-card') || el.classList.contains('feature-item') || el.classList.contains('why-mini-card') || el.classList.contains('location-exp-list li')) {
            const delay = (index % 4) + 1;
            el.classList.add('animate-delay-' + delay);
        }
    });

    const observerOptions = {
        root: null,
        rootMargin: '0px 0px -50px 0px',
        threshold: 0.1
    };

    const fadeObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('is-visible');
                observer.unobserve(entry.target); // Only animate once
            }
        });
    }, observerOptions);

    fadeElements.forEach(el => {
        fadeObserver.observe(el);
    });

});
