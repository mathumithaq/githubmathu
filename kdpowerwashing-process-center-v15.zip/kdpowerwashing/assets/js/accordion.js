document.addEventListener('DOMContentLoaded', function() {
    const accordions = document.querySelectorAll('.accordion-header');
    
    accordions.forEach(acc => {
        acc.addEventListener('click', function() {
            const currentItem = this.parentElement;
            const isActive = currentItem.classList.contains('active');
            
            // Close all items
            document.querySelectorAll('.accordion-item').forEach(item => {
                item.classList.remove('active');
                item.querySelector('.accordion-body').style.maxHeight = null;
            });
            
            // If the clicked item wasn't active, open it
            if (!isActive) {
                currentItem.classList.add('active');
                const body = currentItem.querySelector('.accordion-body');
                body.style.maxHeight = body.scrollHeight + "px";
            }
        });
    });
    
    // Open the first accordion by default to match design
    const firstAcc = document.querySelector('.accordion-item');
    if (firstAcc) {
        firstAcc.classList.add('active');
        const firstBody = firstAcc.querySelector('.accordion-body');
        firstBody.style.maxHeight = firstBody.scrollHeight + "px";
    }
});
