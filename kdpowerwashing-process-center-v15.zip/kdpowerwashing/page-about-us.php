<?php
/**
 * Template Name: About Us Page
 */

get_header();
get_template_part('template-parts/header/inner-hero');
?>
<main id="primary" class="site-main">
<!-- Journey Section -->
<?php get_template_part('template-parts/sections/journey'); ?>

<!-- Vision & Mission Section -->
<?php get_template_part('template-parts/sections/vision-mission'); ?>

<!-- Benefits Section -->
<?php get_template_part('template-parts/sections/benefits'); ?>

<!--last section-->
<?php get_template_part('template-parts/sections/quoate'); ?>

<?php
get_footer();
?>
</main>
