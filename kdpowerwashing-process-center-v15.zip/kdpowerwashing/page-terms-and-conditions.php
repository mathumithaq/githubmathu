<?php
/**
 * Template Name: Terms and Conditions Page
 */

get_header();
get_template_part('template-parts/header/inner-hero');
?>
<main id="primary" class="site-main">
<section class="privacy-policy-section">
    <div class="container">
        <div class="privacy-content">
            <p><strong>Welcome to KD Power Washing!</strong></p>
            <p>These terms and conditions outline the rules and regulations for the use of KD Power Washing's Website, located at <a href="https://kdpowerwashing.com/">https://kdpowerwashing.com/</a>.</p>
            
            <p>By accessing this website we assume you accept these terms and conditions. Do not continue to use KD Power Washing if you do not agree to take all of the terms and conditions stated on this page.</p>
            
            <p>The following terminology applies to these Terms and Conditions, Privacy Statement and Disclaimer Notice, and all Agreements: “Client”, “You” and “Your” refers to you, the person who logs on this website and is compliant with the Company’s terms and conditions...</p>

            <h3>Cookies</h3>
            <p>We employ the use of cookies. By accessing KD Power Washing, you agreed to use cookies in agreement with KD Power Washing’s Privacy Policy.</p>
            <p>Most interactive websites use cookies to let us retrieve the user’s details for each visit...</p>

            <h3>License</h3>
            <p>Unless otherwise stated, KD Power Washing and/or its licensors own the intellectual property rights for all material on KD Power Washing...</p>
            
            <p>You must not:</p>
            <ul class="privacy-list">
                <li>Republish material from KD Power Washing</li>
                <li>Sell, rent, or sub-license material from KD Power Washing</li>
                <li>Reproduce, duplicate or copy material from KD Power Washing</li>
                <li>Redistribute content from KD Power Washing</li>
            </ul>

            <h3>Comments and User Content</h3>
            <p>Parts of this website offer an opportunity for users to post and exchange opinions and information...</p>
            
            <p>You warrant and represent that:</p>
            <ul class="privacy-list">
                <li>You are entitled to post the Comments on our website...</li>
                <li>The Comments do not invade any intellectual property right...</li>
                <li>The Comments do not contain any defamatory, libelous, offensive material...</li>
                <li>The Comments will not be used to promote business or commercial activities unlawfully.</li>
            </ul>
            <p>You hereby grant KD Power Washing a non-exclusive license to use, reproduce, and edit your Comments in any and all forms, formats, or media.</p>

            <h3>Hyperlinking to our Content</h3>
            <p>The following organizations may link to our Website without prior written approval:</p>
            <ul class="privacy-list">
                <li>Government agencies</li>
                <li>Search engines</li>
                <li>News organizations</li>
                <li>Online directories, and more...</li>
            </ul>
            <p>We may also approve link requests from other organizations if we find they benefit our visibility and do not reflect negatively on us...</p>

            <h3>iFrames</h3>
            <p>Without prior approval and written permission, you may not create frames around our Web Pages...</p>

            <h3>Content Liability</h3>
            <p>We shall not be held responsible for any content that appears on your Website...</p>

            <h3>Your Privacy</h3>
            <p>Please read our <a href="<?php echo esc_url(site_url('/privacy-policy/')); ?>" class="text-green-link">Privacy Policy</a>.</p>

            <h3>Reservation of Rights</h3>
            <p>We reserve the right to request that you remove all links or any particular link to our Website...</p>

            <h3>Disclaimer</h3>
            <p>To the maximum extent permitted by applicable law, we exclude all representations, warranties, and conditions...</p>
        </div>
    </div>
</section>

<?php get_template_part('template-parts/sections/quoate'); ?>
</main>
<?php
get_footer();
?>
