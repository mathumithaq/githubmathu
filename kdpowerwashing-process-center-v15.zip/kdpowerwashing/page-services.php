<?php
/**
 * Template Name: Services Page
 */

get_header();
get_template_part('template-parts/header/inner-hero');
?>
<main id="primary" class="site-main">
<!-- Service Intro Section -->
<?php get_template_part('template-parts/sections/service-intro'); ?>

<!-- services Section -->
<?php get_template_part('template-parts/sections/services'); ?>

<!-- Journey Section -->
<?php get_template_part('template-parts/sections/process'); ?>

<!-- Vision & Mission Section -->
<?php get_template_part('template-parts/sections/why-choose-us'); ?>

<!-- faq Section -->
<?php get_template_part('template-parts/sections/faq'); ?>

<!--last section-->
<?php get_template_part('template-parts/sections/quoate'); ?>
</main>
<?php
get_footer();
