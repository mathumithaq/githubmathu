<?php
/**
 * KD Power Washing Theme functions and definitions
 */

if (!function_exists('powerwashing_setup')) {
    function powerwashing_setup()
    {
        // Add default posts and comments RSS feed links to head.
        add_theme_support('automatic-feed-links');

        // Let WordPress manage the document title.
        add_theme_support('title-tag');
    }
}
add_action('after_setup_theme', 'powerwashing_setup');

/* ==========================================================
   Active Navigation Helpers
   ========================================================== */
if (!function_exists('kd_nav_is_active')) {
    function kd_nav_is_active($item)
    {
        // The front page takes precedence, even when WordPress also calls it the posts index.
        if (is_front_page()) {
            return $item === 'home';
        }

        $service_pages = array(
            'services',
            'roof-cleaning',
            'gutter-cleaning',
            'house-power-washing',
            'window-cleaning',
            'commercial-office-cleaning',
            'power-washing-and-pressure-washing',
        );

        $location_pages = array('syracuse', 'rochester');

        switch ($item) {
            case 'home':
                return is_front_page();
            case 'about-us':
                return is_page('about-us');
            case 'services':
                return is_page($service_pages);
            case 'blog':
                return is_home() || is_singular('post') || is_page('blog') || is_category() || is_tag() || is_author() || is_date();
            case 'location':
                return is_page($location_pages);
            case 'contact':
                return is_page(array('contact', 'syracuse-contact-us', 'rocheter-contact-us'));
            default:
                return is_page($item);
        }
    }
}

if (!function_exists('kd_nav_class')) {
    function kd_nav_class($item, $base_class = '')
    {
        $classes = array_filter(array($base_class, kd_nav_is_active($item) ? 'active' : ''));
        return implode(' ', $classes);
    }
}

if (!function_exists('kd_nav_aria_current')) {
    function kd_nav_aria_current($item)
    {
        if (is_front_page()) {
            return $item === 'home' ? ' aria-current="page"' : '';
        }

        $is_current = ($item === 'home' && is_front_page())
            || ($item === 'blog' && kd_nav_is_active('blog'))
            || ($item === 'contact' && is_page(array('syracuse-contact-us', 'rocheter-contact-us')))
            || (!in_array($item, array('home', 'blog', 'location'), true) && is_page($item));

        return $is_current ? ' aria-current="page"' : '';
    }
}

// Google Fonts preconnect removed as requested.

if (!function_exists('powerwashing_enqueue_scripts')) {
    function powerwashing_enqueue_scripts()
    {
        $theme_uri = get_template_directory_uri();
        $theme_dir = get_template_directory();

        /* ==========================================================
           1. ENQUEUE CSS FILES
           ========================================================== */

        // Google fonts removed as requested.

        // We removed the individual CSS enqueues to inline them and stop render-blocking!

        /* ==========================================================
           2. ENQUEUE JS FILES
           ========================================================== */

        // Font optimizer (loads in head to intercept 3rd party scripts)
        wp_enqueue_script('pw-font-optimizer', $theme_uri . '/assets/js/font-optimizer.js', array(), filemtime($theme_dir . '/assets/js/font-optimizer.js'), false);

        // AOS Animation Library
        wp_enqueue_style('aos-css', 'https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css', array(), '2.3.4');
        wp_enqueue_script('aos-js', 'https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js', array(), '2.3.4', true);
        wp_add_inline_script('aos-js', 'document.addEventListener("DOMContentLoaded", function() { AOS.init({ duration: 800, once: true, offset: 100 }); });');

        // Footer Scripts
        $js_files = array('navigation', 'counter', 'accordion', 'main');

        foreach ($js_files as $js) {
            $file_path = '/assets/js/' . $js . '.js';
            // Enqueue JS in the footer (true flag) and dependent on jQuery
            if (file_exists($theme_dir . $file_path)) {
                wp_enqueue_script('theme-' . $js . '-script', $theme_uri . $file_path, array('jquery'), filemtime($theme_dir . $file_path), true);
            }
        }
    }
}
add_action('wp_enqueue_scripts', 'powerwashing_enqueue_scripts');



/* ==========================================================
   Defer JavaScript Loading for Better Performance
   ========================================================== */
if (!function_exists('powerwashing_defer_scripts')) {
    function powerwashing_defer_scripts($tag, $handle, $src)
    {
        // Don't defer scripts in the WordPress admin area
        if (is_admin()) {
            return $tag;
        }

        // Add defer attribute if not already present
        if (strpos($tag, 'defer') === false) {
            $tag = str_replace(' src', ' defer="defer" src', $tag);
        }

        return $tag;
    }
}
add_filter('script_loader_tag', 'powerwashing_defer_scripts', 10, 3);

/* ==========================================================
   Defer All Non-Critical CSS (Eliminate Render Blocking)
   ========================================================== */
if (!function_exists('powerwashing_defer_css')) {
    function powerwashing_defer_css($html, $handle, $href, $media)
    {
        // Do not defer CSS in the WordPress admin dashboard
        if (is_admin()) {
            return $html;
        }

        // Exclude the admin bar and dashicons so logged-in admins don't see a broken top bar
        $excluded_handles = array('admin-bar', 'dashicons');
        if (in_array($handle, $excluded_handles)) {
            return $html;
        }

        // Convert the standard stylesheet link to an async loading one
        $deferred_html = '<link rel="preload" href="' . esc_url($href) . '" as="style" onload="this.onload=null;this.rel=\'stylesheet\'">' . "\n";
        $deferred_html .= '<noscript><link rel="stylesheet" href="' . esc_url($href) . '"></noscript>' . "\n";

        return $deferred_html;
    }
}
add_filter('style_loader_tag', 'powerwashing_defer_css', 10, 4);

/* ==========================================================
   Custom Pagination
   ========================================================== */
if (!function_exists('kd_powerwashing_pagination')) {
    function kd_powerwashing_pagination($max_num_pages = null)
    {
        if (!$max_num_pages) {
            global $wp_query;
            $max_num_pages = $wp_query->max_num_pages;
        }

        if ($max_num_pages <= 1) {
            return;
        }

        $paged = get_query_var('paged') ? absint(get_query_var('paged')) : 1;

        echo '<div class="kd-pagination">';

        echo paginate_links(array(
            'base' => str_replace(999999999, '%#%', esc_url(get_pagenum_link(999999999))),
            'format' => '?paged=%#%',
            'current' => $paged,
            'total' => $max_num_pages,
            'prev_text' => '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M15 18l-6-6 6-6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg> Prev',
            'next_text' => 'Next <svg viewBox="0 0 24 24" width="20" height="20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M9 18l6-6-6-6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
            'type' => 'list',
            'end_size' => 1,
            'mid_size' => 2,
        ));

        echo '</div>';
    }
}

/* ==========================================================
   Auto Clear Caches (For Popular Caching Plugins)
   ========================================================== */
if (!function_exists('kd_powerwashing_auto_clear_cache')) {
    function kd_powerwashing_auto_clear_cache()
    {
        // Clear our custom inline CSS transient
        delete_transient('powerwashing_css_v32');

        // WP Super Cache
        if (function_exists('wp_cache_clear_cache')) {
            wp_cache_clear_cache();
        }
        // W3 Total Cache
        if (function_exists('w3tc_flush_all')) {
            w3tc_flush_all();
        }
        // WP Rocket
        if (function_exists('rocket_clean_domain')) {
            rocket_clean_domain();
        }
        // LiteSpeed Cache
        if (class_exists('LiteSpeed\Purge')) {
            LiteSpeed\Purge::purge_all();
        }
        // Autoptimize
        if (class_exists('autoptimizeCache')) {
            autoptimizeCache::clearall();
        }
    }
}
// Clear cache whenever a post/page is saved or updated
add_action('save_post', 'kd_powerwashing_auto_clear_cache');
add_action('wp_update_nav_menu', 'kd_powerwashing_auto_clear_cache');

/* ==========================================================
   Inline Critical CSS for Extreme Performance (0 Render Blocking)
   ========================================================== */
if (!function_exists('powerwashing_inline_critical_css')) {
    function powerwashing_inline_critical_css()
    {
        $theme_uri = get_template_directory_uri();
        $theme_dir = get_template_directory();

        // TEMPORARILY DISABLED CACHE FOR DEVELOPMENT
        $cached_css = false; // get_transient('powerwashing_css_v32');

        if (false === $cached_css || isset($_GET['nocache'])) {
            $all_css_files = array('global', 'header', 'topbar', 'footer', 'hero', 'services', 'service-intro', 'about', 'about-us', 'why-choose-us', 'gallery', 'process', 'quoate', 'faq', 'testimonials', 'blog', 'responsive', 'inner-hero', 'sub-hero', 'sub-intro', 'sub-about', 'contact', 'location-hero', 'location-about', 'location-experience', 'single-blog', 'privacy', 'qa-fixes');

            $combined_css = '';
            foreach ($all_css_files as $css) {
                $file_path = $theme_dir . '/assets/css/' . $css . '.css';
                if (file_exists($file_path)) {
                    $combined_css .= file_get_contents($file_path) . "\n";
                }
            }

            // Fix relative paths so they work when inlined in the head
            $combined_css = str_replace('../images/', $theme_uri . '/assets/images/', $combined_css);
            $combined_css = str_replace('../icons/', $theme_uri . '/assets/icons/', $combined_css);
            $combined_css = str_replace('../fonts/', $theme_uri . '/assets/fonts/', $combined_css);

            // Simple minification
            $combined_css = preg_replace('!/\*[^*]*\*+([^/][^*]*\*+)*/!', '', $combined_css);
            $combined_css = str_replace(array("\r\n", "\r", "\n", "\t", '  ', '    ', '    '), '', $combined_css);

            $cached_css = $combined_css;
            set_transient('powerwashing_css_v32', $cached_css, 24 * HOUR_IN_SECONDS);
        }

        echo '<style id="powerwashing-inline-css">' . $cached_css . '</style>' . "\n";
    }
}
add_action('wp_head', 'powerwashing_inline_critical_css', 10);

//-----------------
function custom_google_analytics() {
    ?>
    <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}

    window.addEventListener('load', function () {
        setTimeout(function () {

            var script = document.createElement('script');
            script.src = 'https://www.googletagmanager.com/gtag/js?id=G-910GNZ0GP2';
            script.async = true;

            script.onload = function () {
                gtag('js', new Date());
                gtag('config', 'G-910GNZ0GP2');
            };

            document.head.appendChild(script);

        }, 1500);
    });
    </script>
    <?php
}
add_action('wp_head', 'custom_google_analytics');

/* ==========================================================
   Dynamic FAQ Meta Box for Pages & Posts
   ========================================================== */
if (!function_exists('kd_add_faq_meta_box')) {
    function kd_add_faq_meta_box() {
        $screens = array('page', 'post');
        foreach ($screens as $screen) {
            add_meta_box(
                'kd_faq_meta_box',
                __('FAQ Section - Custom Questions & Answers', 'kdpowerwashing'),
                'kd_render_faq_meta_box',
                $screen,
                'normal',
                'high'
            );
        }
    }
    add_action('add_meta_boxes', 'kd_add_faq_meta_box');
}

if (!function_exists('kd_render_faq_meta_box')) {
    function kd_render_faq_meta_box($post) {
        wp_nonce_field('kd_save_faq_meta', 'kd_faq_nonce');
        $faq_title = get_post_meta($post->ID, 'faq_section_title', true);
        $faq_subtitle = get_post_meta($post->ID, 'faq_section_subtitle', true);
        ?>
        <div style="margin-bottom: 20px;">
            <p style="color: #64748b; font-size: 13px;"><em>Add questions and answers to customize this page. The homepage shows its five built-in questions until custom FAQs are saved; other pages hide the section when these fields are empty.</em></p>
            <div style="display: flex; gap: 20px; margin-bottom: 15px;">
                <div style="flex: 1;">
                    <label style="font-weight: 600; display: block; margin-bottom: 5px;">Section Subtitle (e.g., FAQ):</label>
                    <input type="text" name="faq_section_subtitle" value="<?php echo esc_attr($faq_subtitle); ?>" style="width: 100%;" placeholder="FAQ">
                </div>
                <div style="flex: 2;">
                    <label style="font-weight: 600; display: block; margin-bottom: 5px;">Section Heading Title:</label>
                    <input type="text" name="faq_section_title" value="<?php echo esc_attr($faq_title); ?>" style="width: 100%;" placeholder="Frequently Asked Questions">
                </div>
            </div>
        </div>
        <div id="kd-faq-fields-wrapper">
            <?php for ($i = 1; $i <= 8; $i++): 
                $q = get_post_meta($post->ID, "faq_{$i}_question", true);
                $a = get_post_meta($post->ID, "faq_{$i}_answer", true);
            ?>
            <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 15px; margin-bottom: 15px;">
                <h4 style="margin: 0 0 10px 0; color: #1475b3; font-size: 14px;">FAQ #<?php echo $i; ?></h4>
                <div style="margin-bottom: 10px;">
                    <label style="font-weight: 600; display: block; margin-bottom: 5px;">Question <?php echo $i; ?>:</label>
                    <input type="text" name="faq_<?php echo $i; ?>_question" value="<?php echo esc_attr($q); ?>" style="width: 100%;" placeholder="Enter Question <?php echo $i; ?>">
                </div>
                <div>
                    <label style="font-weight: 600; display: block; margin-bottom: 5px;">Answer <?php echo $i; ?>:</label>
                    <textarea name="faq_<?php echo $i; ?>_answer" rows="3" style="width: 100%;" placeholder="Enter Answer <?php echo $i; ?>"><?php echo esc_textarea($a); ?></textarea>
                </div>
            </div>
            <?php endfor; ?>
        </div>
        <?php
    }
}

if (!function_exists('kd_save_faq_meta_box')) {
    function kd_save_faq_meta_box($post_id) {
        if (!isset($_POST['kd_faq_nonce']) || !wp_verify_nonce($_POST['kd_faq_nonce'], 'kd_save_faq_meta')) {
            return;
        }
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }

        if (isset($_POST['faq_section_title'])) {
            update_post_meta($post_id, 'faq_section_title', sanitize_text_field($_POST['faq_section_title']));
        }
        if (isset($_POST['faq_section_subtitle'])) {
            update_post_meta($post_id, 'faq_section_subtitle', sanitize_text_field($_POST['faq_section_subtitle']));
        }

        for ($i = 1; $i <= 8; $i++) {
            if (isset($_POST["faq_{$i}_question"])) {
                update_post_meta($post_id, "faq_{$i}_question", sanitize_text_field($_POST["faq_{$i}_question"]));
            }
            if (isset($_POST["faq_{$i}_answer"])) {
                update_post_meta($post_id, "faq_{$i}_answer", sanitize_textarea_field($_POST["faq_{$i}_answer"]));
            }
        }
    }
    add_action('save_post', 'kd_save_faq_meta_box');
}

/* ==========================================================
   Dynamic Contact URL Helper
   Returns the correct contact page URL based on the current
   sub-location context:
     - /syracuse/          → /syracuse-contact-us/
     - /rochester/         → /rocheter-contact-us/
     - everywhere else     → /contact/
   ========================================================== */
if (!function_exists('kd_contact_url')) {
    function kd_contact_url()
    {
        if (is_page('syracuse')) {
            return home_url('/syracuse-contact-us/');
        }

        if (is_page('rochester')) {
            return home_url('/rocheter-contact-us/');
        }

        return home_url('/contact/');
    }
}

// Use the theme favicon consistently instead of an older WordPress Site Icon.
add_action('after_setup_theme', function () { remove_action('wp_head', 'wp_site_icon', 99); });
