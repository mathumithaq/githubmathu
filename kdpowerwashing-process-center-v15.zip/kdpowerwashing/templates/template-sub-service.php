<?php
/**
 * Template Name: Sub Service Page
 */

get_header();

echo '<main id="primary" class="site-main kd-sub-services-page">';
get_template_part('template-parts/sub-services/sub-hero');
get_template_part('template-parts/sub-services/sub-intro');
get_template_part('template-parts/sub-services/sub-about');
get_template_part('template-parts/sections/process');
get_template_part('template-parts/sections/faq');
get_template_part('template-parts/sections/quoate');
echo '</main>';

get_footer();