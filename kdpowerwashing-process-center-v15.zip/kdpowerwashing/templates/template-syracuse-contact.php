<?php
/**
 * Template Name: Syracuse Contact Page
 * Uses the shared contact layout.
 */
require get_template_directory() . '/page-contact.php';
