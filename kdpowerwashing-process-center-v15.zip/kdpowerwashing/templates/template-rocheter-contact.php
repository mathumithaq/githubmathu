<?php
/**
 * Template Name: Rochester Contact Page
 * Uses the shared contact layout.
 */
require get_template_directory() . '/page-contact.php';
