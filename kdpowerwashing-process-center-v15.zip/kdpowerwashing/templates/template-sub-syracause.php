<?php
/**
 * Template Name: Syracuse Location Page
 */

get_header();
get_template_part('template-parts/sub-location/location-hero');
?>
<main id="primary" class="site-main">
<!-- Location About Section -->
<?php get_template_part('template-parts/sub-location/location-about'); ?>


<!-- services Section -->
<?php get_template_part('template-parts/sections/services'); ?>

<!-- Experience Section -->
<?php get_template_part('template-parts/sub-location/location-experience'); ?>

<!-- Journey Section -->
<?php get_template_part('template-parts/sections/process'); ?>

<!-- faq Section -->
<?php get_template_part('template-parts/sections/faq'); ?>

<!--last section-->
<?php get_template_part('template-parts/sections/quoate'); ?>
</main>
<?php get_footer(); ?>
