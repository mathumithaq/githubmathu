<?php
/**
 * Template Name: Contact Page
 */
get_header();
get_template_part('template-parts/header/inner-hero');
?>
<?php
// ── Dynamic Location Detection by Current Page Slug ─────────────────────────
// Checks which contact page is being viewed and sets the city accordingly.
// Default: Buffalo, NY (main /contact/ page)
$location_name     = 'Buffalo';
$location_maps_url = 'https://www.google.com/maps/place/KD+Power+Washing+and+Cleaning/@42.9584163,-78.8272796,17z/data=!3m1!4b1!4m6!3m5!1s0x89d373bbe41e3617:0xeb41528802cb9123!8m2!3d42.9584163!4d-78.8272796!16s%2Fg%2F11j3r48c7r?hl=en&entry=ttu&g_ep=EgoyMDI2MDcxMy4wIKXMDSoASAFQAw%3D%3D';

$contact_slug = get_post_field( 'post_name', get_queried_object_id() );
if ( in_array( $contact_slug, array( 'rocheter-contact-us', 'rochester-contact-us' ), true ) ) {
    $location_name     = 'Rochester';
    $location_maps_url = 'https://www.google.com/maps/search/KD+Power+Washing+Rochester+NY';
} elseif ( 'syracuse-contact-us' === $contact_slug ) {
    $location_name     = 'Syracuse';
    $location_maps_url = 'https://www.google.com/maps/search/KD+Power+Washing+Syracuse+NY';
}
?>
<main id="primary" class="site-main">
<div class="kd-contact-page">
    <div class="container">
        <div class="contact-grid">
            <!-- Left Side -->
            <div class="contact-left">
                <!-- Large Ringing Phone SVG (clickable link to call) -->
                <div class="contact-mobile-img">
                    <a href="tel:+17164007016" aria-label="Call KD Power Washing at (716) 400-7016" class="big-phone-link">
                        <div class="big-phone-wrapper">
                            <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="big-phone-icon">
                                <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </div>
                    </a>
                </div>
                
                <!-- 3 Contact Details Boxes -->
                <div class="contact-details-list">
                    
                    <a href="tel:+17164007016" class="contact-info-item">
                        <!-- Banner Shape Background -->
                        <svg class="banner-bg" preserveAspectRatio="none" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
                            <defs>
                                <linearGradient id="bannerGrad1" x1="0%" y1="0%" x2="100%" y2="0%">
                                    <stop offset="0%" style="stop-color: var(--primary-blue, #1475B3)" />
                                    <stop offset="60%" style="stop-color: var(--secondary-blue, #1F88CC)" />
                                    <stop offset="100%" style="stop-color: var(--primary-green, #8ABD49)" />
                                </linearGradient>
                            </defs>
                            <path d="M 4,0 L 96,0 C 98,0 96,20 100,50 C 96,80 98,100 96,100 L 4,100 C 2,100 4,80 0,50 C 4,20 2,0 4,0 Z" fill="url(#bannerGrad1)"/>
                        </svg>
                        
                        <div class="info-icon">
                            <!-- Phone Icon -->
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/phone-white.svg" alt="Phone" onerror="this.src='data:image/svg+xml;utf8,<svg viewBox=\'0 0 24 24\' fill=\'none\' xmlns=\'http://www.w3.org/2000/svg\'><path d=\'M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z\' stroke=\'white\' stroke-width=\'2\' stroke-linecap=\'round\' stroke-linejoin=\'round\'/></svg>'">
                        </div>
                        <div class="info-text">
                            <span>(716) 400-7016</span>
                        </div>
                    </a>
                    
                    <a href="mailto:sales@kdpowerwashing.com" class="contact-info-item">
                        <svg class="banner-bg" preserveAspectRatio="none" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
                            <defs>
                                <linearGradient id="bannerGrad2" x1="0%" y1="0%" x2="100%" y2="0%">
                                    <stop offset="0%" style="stop-color: var(--primary-blue, #1475B3)" />
                                    <stop offset="60%" style="stop-color: var(--secondary-blue, #1F88CC)" />
                                    <stop offset="100%" style="stop-color: var(--primary-green, #8ABD49)" />
                                </linearGradient>
                            </defs>
                            <path d="M 4,0 L 96,0 C 98,0 96,20 100,50 C 96,80 98,100 96,100 L 4,100 C 2,100 4,80 0,50 C 4,20 2,0 4,0 Z" fill="url(#bannerGrad2)"/>
                        </svg>

                        <div class="info-icon">
                            <!-- Email Icon -->
                            <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M22 6l-10 7L2 6" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </div>
                        <div class="info-text">
                            <span>sales@kdpowerwashing.com</span>
                        </div>
                    </a>

                    <a href="<?php echo esc_url( $location_maps_url ); ?>" target="_blank" rel="noopener noreferrer" class="contact-info-item">
                        <svg class="banner-bg" preserveAspectRatio="none" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
                            <defs>
                                <linearGradient id="bannerGrad3" x1="0%" y1="0%" x2="100%" y2="0%">
                                    <stop offset="0%" style="stop-color: var(--primary-blue, #1475B3)" />
                                    <stop offset="60%" style="stop-color: var(--secondary-blue, #1F88CC)" />
                                    <stop offset="100%" style="stop-color: var(--primary-green, #8ABD49)" />
                                </linearGradient>
                            </defs>
                            <path d="M 4,0 L 96,0 C 98,0 96,20 100,50 C 96,80 98,100 96,100 L 4,100 C 2,100 4,80 0,50 C 4,20 2,0 4,0 Z" fill="url(#bannerGrad3)"/>
                        </svg>

                        <div class="info-icon">
                            <!-- Location Icon -->
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/menu-location.svg" alt="Location" onerror="this.src='data:image/svg+xml;utf8,<svg viewBox=\'0 0 24 24\' fill=\'none\' xmlns=\'http://www.w3.org/2000/svg\'><path d=\'M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z\' stroke=\'white\' stroke-width=\'2\' stroke-linecap=\'round\' stroke-linejoin=\'round\'/><circle cx=\'12\' cy=\'10\' r=\'3\' stroke=\'white\' stroke-width=\'2\' stroke-linecap=\'round\' stroke-linejoin=\'round\'/></svg>'">
                        </div>
                        <div class="info-text">
                            <span><?php echo esc_html( $location_name ); ?>, NY</span>
                        </div>
                    </a>
                </div>
            </div>
            
            <!-- Right Side -->
            <div class="contact-right">
                <h2 class="contact-heading">Get In Touch With KD Powerwashing</h2>
                <p class="contact-description">
                    Have questions or need a quote? We’re here to help! Whether it’s residential or commercial cleaning, our team is ready to assist you. With over 10 years of trusted service in <?php echo esc_html( $location_name ); ?>, KD Powerwashing is your reliable partner for expert, affordable, and timely cleaning solutions.
                </p>
            </div>
        </div>

        <!-- Form Iframe Section -->
        <div class="contact-form-section">
            <?php get_template_part('partials/forms/contact-form'); ?>
        </div>
    </div>
</div>
</main>
<?php
get_footer();
