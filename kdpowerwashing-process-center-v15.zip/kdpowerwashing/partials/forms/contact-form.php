<?php
/**
 * Contact Form Iframe Component
 */
?>
<iframe
    data-src="https://app.kdpowerwashing.com/widget/form/RFBhPvoXkLQ2DA0oySVz"
    class="kd-contact-iframe lazy-iframe"
    id="inline-RFBhPvoXkLQ2DA0oySVz" 
    data-layout="{'id':'INLINE'}"
    data-trigger-type="alwaysShow"
    data-trigger-value=""
    data-activation-type="alwaysActivated"
    data-activation-value=""
    data-deactivation-type="neverDeactivate"
    data-deactivation-value=""
    data-form-name="Optin Claim"
    data-height="911"
    data-layout-iframe-id="inline-RFBhPvoXkLQ2DA0oySVz"
    data-form-id="RFBhPvoXkLQ2DA0oySVz"
    title="Optin Claim"
></iframe>
<!-- Form embed script is loaded globally via delayed script in footer -->
