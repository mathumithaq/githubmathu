<?php
/**
 * Sub Service Intro Section
 */

$intro_heading = get_post_meta(get_the_ID(), 'intro_heading', true);
$intro_desc = get_post_meta(get_the_ID(), 'intro_description', true);

$features = [];
for ($i = 1; $i <= 3; $i++) {
    $title = get_post_meta(get_the_ID(), 'intro_feature_' . $i . '_title', true);
    $desc = get_post_meta(get_the_ID(), 'intro_feature_' . $i . '_desc', true);
    if (!empty($title) || !empty($desc)) {
        $features[] = ['title' => $title, 'desc' => $desc];
    }
}

// Default placeholder text if meta is empty
if (empty($intro_desc)) {
    $intro_desc = "There are many variations of passages of Lorem Ipsum available, but the majority have suffered humour, or randomised words which don't look even slightly believable. If you are going to use a passage need of the sure.";
}
if (empty($intro_heading)) {
    $intro_heading = "Aynal hoque";
}
$author_title = "CEO, Black Forest";
?>
<section class="sub-intro-section">
    <div class="container">
        <div class="sub-intro-wrapper">
            <!-- Left Image Side -->
            <div class="sub-intro-image-col">
                <div class="sub-intro-image-wrapper">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/about 1.webp" alt="Sub Intro Image" class="sub-intro-img" fetchpriority="high" loading="eager" decoding="sync">
                </div>
            </div>

            <!-- Right Content Side -->
            <div class="sub-intro-content-col">
                <div class="sub-intro-quote-card">

                    <div class="section-subtitle">
                        <?php 
                            $intro_subtitle = get_post_meta(get_the_ID(), 'intro_subtitle', true);
                            echo esc_html(!empty($intro_subtitle) ? $intro_subtitle : 'OVERVIEW'); 
                        ?>
                    </div>
                    <h2 class="sub-intro-heading">
                        <?php echo esc_html($intro_heading); ?>
                    </h2>
                    
                    <p class="quote-text">
                        <?php echo wp_kses_post($intro_desc); ?>
                    </p>
                </div>
            </div>
        </div>
        
        <?php if (!empty($features)): ?>
            <div class="sub-intro-features-grid">
                <div class="sub-intro-features">
                    <?php foreach ($features as $feature): ?>
                        <div class="feature-item">
                            <div class="feature-icon">
                                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <circle cx="12" cy="12" r="11" fill="#1475B3" />
                                    <path d="M7 12.5L10.5 16L17 8.5" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" />
                                </svg>
                            </div>
                            <div class="feature-text">
                                <?php if (!empty($feature['title'])): ?>
                                    <h3 class="feature-title"><?php echo esc_html($feature['title']); ?></h3>
                                <?php endif; ?>
                                <?php if (!empty($feature['desc'])): ?>
                                    <p class="feature-desc"><?php echo wp_kses_post($feature['desc']); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
    <!-- Stats Marquee Bar from Why Choose Us -->
    <div class="stats-marquee-wrapper">
        <div class="stats-marquee-track" id="statsMarqueeTrack">
            <!-- Items (Duplicated 3 times for seamless scrolling) -->
            <?php for ($i = 0; $i < 3; $i++): ?>
                <div class="stat-item">
                    <span class="stat-number" data-target="500" data-suffix="+">0+</span>
                    <span class="stat-label">5-Star Reviews</span>
                </div>
                <div class="stat-item">
                    <span class="stat-number" data-target="24" data-suffix="hr">0hr</span>
                    <span class="stat-label">Response Guarantee</span>
                </div>
                <div class="stat-item">
                    <span class="stat-number" data-target="1200" data-suffix="+">0+</span>
                    <span class="stat-label">Properties Cleaned</span>
                </div>
                <div class="stat-item">
                    <span class="stat-number" data-target="100" data-suffix="%">0%</span>
                    <span class="stat-label">Satisfied Clients</span>
                </div>
            <?php endfor; ?>
        </div>
    </div>
</section>