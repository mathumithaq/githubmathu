<?php
/**
 * Sub-Hero Section (Animated Paper Reveal)
 * Dynamic implementation using default WordPress Custom Fields.
 */

$bg_image = get_the_post_thumbnail_url(get_the_ID(), 'full');
if (!$bg_image) {
    // Check if a custom field for background image URL exists
    $bg_image_meta = get_post_meta(get_the_ID(), 'hero_background_image_url', true);
    $bg_image = !empty($bg_image_meta) ? esc_url($bg_image_meta) : get_template_directory_uri() . '/assets/images/inner-hero2.webp';
}
$subtitle = get_post_meta(get_the_ID(), 'hero_subtitle', true);
if (empty($subtitle)) {
    $subtitle = get_the_title();
}
$title_meta = get_post_meta(get_the_ID(), 'hero_title', true);
$title = !empty($title_meta) ? $title_meta : get_the_title();
?>
<!-- Preload the background image to fix LCP discoverability warning -->
<link rel="preload" as="image" href="<?php echo esc_url($bg_image); ?>" fetchpriority="high">
<section class="sub-hero-animation-section">
    <div class="container">
        <div class="paper-container">
            <!-- The background texture that acts as the paper -->
            <div class="paper-texture" style="background-image: url('<?php echo esc_url($bg_image); ?>');">
                <div class="paper-overlay"></div>
            </div>
            
            <!-- The content that reveals after the paper unfolds -->
            <div class="paper-content">
                <?php if (!empty($subtitle)) : ?>
                    <div class="section-subtitle"><?php echo esc_html($subtitle); ?></div>
                <?php endif; ?>
                
                <h1 class="text-white"><?php echo $title ? esc_html($title) : 'Power Washing Excellence'; ?></h1>
            </div>
        </div>
    </div>
</section>
