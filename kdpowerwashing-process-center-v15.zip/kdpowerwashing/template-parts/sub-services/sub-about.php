<?php
/**
 * Sub Service About Section
 */

$about_heading = get_post_meta(get_the_ID(), 'about_heading', true);
if (empty($about_heading)) {
    $about_heading = 'Why Choose Us';
}
$about_desc = get_post_meta(get_the_ID(), 'about_description', true);

$about_image_url = get_post_meta(get_the_ID(), 'about_image_url', true);
if (empty($about_image_url)) {
    $about_image_url = get_the_post_thumbnail_url(get_the_ID(), 'large');
    if (empty($about_image_url)) {
        $about_image_url = get_template_directory_uri() . '/assets/images/about image.webp'; // fallback
    }
}

$features = [];
for ($i = 1; $i <= 3; $i++) {
    $title = get_post_meta(get_the_ID(), 'about_feature_' . $i . '_title', true);
    if (!empty($title)) {
        $features[] = ['title' => $title];
    }
}

// Fallback features if none provided
if (empty($features)) {
    $features = [
        ['title' => 'Experienced & Certified Team'],
        ['title' => '100% Satisfaction Guaranteed'],
        ['title' => 'Safe & Eco-Friendly Methods']
    ];
}
?>
<section class="sub-about-section">
    <div class="container">
        <div class="sub-about-grid">
            <div class="sub-about-image-col">
                <img src="<?php echo esc_url($about_image_url); ?>" alt="<?php echo esc_attr($about_heading); ?>" class="about-image">
            </div>

            <div class="sub-about-content-col">
                <div class="section-subtitle">
                    <?php
                    $about_subtitle = get_post_meta(get_the_ID(), 'about_subtitle', true);
                    echo esc_html(!empty($about_subtitle) && strtolower(trim($about_subtitle)) !== 'about us' ? $about_subtitle : 'WHY CHOOSE US');
                    ?>
                </div>
                <h2 class="sub-about-heading"><?php echo esc_html($about_heading); ?></h2>

                <?php if (!empty($about_desc)): ?>
                    <div class="sub-about-desc"><?php echo wp_kses_post($about_desc); ?></div>
                <?php endif; ?>

                <?php if (!empty($features)): ?>
                    <div class="features-pie-chart">
                        <?php if (isset($features[0])): ?>
                            <div class="pie-text pie-text-1"><span><?php echo esc_html($features[0]['title']); ?></span></div>
                        <?php endif; ?>
                        <?php if (isset($features[1])): ?>
                            <div class="pie-text pie-text-2"><span><?php echo esc_html($features[1]['title']); ?></span></div>
                        <?php endif; ?>
                        <?php if (isset($features[2])): ?>
                            <div class="pie-text pie-text-3"><span><?php echo esc_html($features[2]['title']); ?></span></div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
