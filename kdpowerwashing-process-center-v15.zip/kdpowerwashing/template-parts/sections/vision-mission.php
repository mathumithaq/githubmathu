<?php
/**
 * Vision and Mission Section Template for About Us Page
 */
?>
<section class="vision-mission-section">
    <div class="container">
        
        <div class="vm-header">
            <span class="section-subtitle">Vision and Mission</span>
            <h2>Power Washing with Purpose</h2>
        </div>

        <div class="vm-wrapper">
            <!-- Vision Card (First) -->
            <div class="vm-card vision-card">
                <div class="vm-image-box">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/vision.webp?v=<?php echo time(); ?>" alt="Power Washing Vision">
                    <div class="vm-image-overlay"></div>
                </div>
                <div class="vm-content-box">
                    <div class="vm-icon">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/service-house.svg" alt="Vision Icon">
                    </div>
                    <div class="vm-text">
                        <h3>Our Vision</h3>
                        <p>Our vision is to become Buffalo's most trusted name in cleaning by setting new standards in quality, professionalism, and customer care.</p>
                        <div class="vm-highlight">
                            <p>We strive to protect and preserve every property we service, revitalizing spaces through expert cleaning while ensuring long-term beauty, safety, and durability.</p>
                        </div>
                        <ul class="vm-list">
                            <li>Redefining cleaning through reliability and innovation.</li>
                            <li>Enhancing curb appeal and property value with every wash.</li>
                        </ul>
                    </div>
                </div>
            </div>

            <!-- Mission Card (Second) -->
            <div class="vm-card mission-card">
                <div class="vm-content-box">
                    <div class="vm-icon">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/service-commercial.svg" alt="Mission Icon">
                    </div>
                    <div class="vm-text">
                        <h3>Our Mission</h3>
                        <p>Our mission is to deliver affordable, high-quality power washing solutions for homes and businesses across Buffalo, tailored to each property’s unique needs.</p>
                        <div class="vm-highlight">
                            <p>We're committed to using eco-friendly methods, advanced tools, and a customer-first approach to provide spotless results and total satisfaction, every time.</p>
                        </div>
                        <ul class="vm-list">
                            <li>Personalized care backed by expert craftsmanship</li>
                            <li>Powerful, sustainable cleaning with lasting results</li>
                        </ul>
                    </div>
                </div>
                <div class="vm-image-box">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/mission.webp?v=<?php echo time(); ?>" alt="Power Washing Mission">
                    <div class="vm-image-overlay"></div>
                </div>
            </div>
        </div>

    </div>
</section>
