<?php
/**
 * Benefits Section Template (3-column layout)
 */
?>
<section class="benefits-section">
    <div class="container">
        
        <div class="benefits-header">
            <span class="section-subtitle">Real Benefits</span>
            <h2>Real Benefits That Make A Difference</h2>
            <p>Our deep cleaning services quickly enhance your property's look, making it stand out beautifully in the neighborhood. By regularly maintaining your property, you protect your investment, increase its market value, and create a healthier environment free from harmful buildup and allergens. This proactive care also helps prevent costly repairs and extends the lifespan of your surfaces.</p>
        </div>

        <div class="benefits-grid">
            
            <!-- Left Column: Cards 1 & 2 -->
            <div class="benefits-col">
                <!-- Card 1 -->
                <div class="benefit-card">
                    <div class="benefit-card-header">
                        <div class="benefit-icon">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/benefit-home.svg" alt="Curb Appeal">
                        </div>
                        <div class="benefit-arrow">↗</div>
                    </div>
                    <h3>Curb Appeal</h3>
                    <p>Instantly boost your home's appearance with deep, effective exterior cleaning.</p>
                </div>
                
                <!-- Card 2 -->
                <div class="benefit-card">
                    <div class="benefit-card-header">
                        <div class="benefit-icon">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/benefit-value.svg" alt="Property Value">
                        </div>
                        <div class="benefit-arrow">↗</div>
                    </div>
                    <h3>Property Value</h3>
                    <p>Increase resale value by maintaining a clean and well-kept property exterior.</p>
                </div>
            </div>
            
            <!-- Center Column: Tall Image -->
            <div class="benefits-center-img-wrapper">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/images/1.webp" alt="Powerwashing Benefits" class="benefits-center-img">
            </div>

            <!-- Right Column: Cards 3 & 4 -->
            <div class="benefits-col">
                <!-- Card 3 -->
                <div class="benefit-card">
                    <div class="benefit-card-header">
                        <div class="benefit-icon">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/benefit-time.svg" alt="Longer Lifespan">
                        </div>
                        <div class="benefit-arrow">↗</div>
                    </div>
                    <h3>Longer Lifespan</h3>
                    <p>Prevent damage and decay to surfaces by removing harmful buildup early.</p>
                </div>
                
                <!-- Card 4 -->
                <div class="benefit-card">
                    <div class="benefit-card-header">
                        <div class="benefit-icon">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/benefit-health.svg" alt="Healthier Spaces">
                        </div>
                        <div class="benefit-arrow">↗</div>
                    </div>
                    <h3>Healthier Spaces</h3>
                    <p>Eliminate mold, mildew, and allergens for a cleaner, safer environment.</p>
                </div>
            </div>

        </div>
    </div>
</section>
