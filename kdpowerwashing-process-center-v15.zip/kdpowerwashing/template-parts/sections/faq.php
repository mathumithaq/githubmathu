<?php
/**
 * Dynamic FAQ Section Template
 */

// 1. Dynamic Section Subtitle & Heading Title
$page_id = get_queried_object_id();
$faq_subtitle = get_post_meta($page_id, 'faq_section_subtitle', true);
if (empty($faq_subtitle)) {
    $faq_subtitle = 'FAQ';
}

$faq_title = get_post_meta($page_id, 'faq_section_title', true);
if (empty($faq_title)) {
    $faq_title = 'Frequently Asked Questions';
}

// 2. Fetch Custom FAQs from Page Meta (up to 15 items)
$faq_items = array();

for ($i = 1; $i <= 15; $i++) {
    $q = get_post_meta($page_id, "faq_{$i}_question", true);
    if (empty($q)) {
        $q = get_post_meta($page_id, "faq_question_{$i}", true);
    }
    if (empty($q)) {
        $q = get_post_meta($page_id, "faq_q{$i}", true);
    }
    
    $a = get_post_meta($page_id, "faq_{$i}_answer", true);
    if (empty($a)) {
        $a = get_post_meta($page_id, "faq_answer_{$i}", true);
    }
    if (empty($a)) {
        $a = get_post_meta($page_id, "faq_a{$i}", true);
    }

    if (!empty($q) && !empty($a)) {
        $faq_items[] = array(
            'question' => $q,
            'answer'   => $a,
        );
    }
}

// The homepage has its own FAQs until its fields are customized in the editor.
if (empty($faq_items) && is_front_page()) {
    $faq_items = array(
        array(
            'question' => 'DO YOU SERVE ALL OF BUFFALO?',
            'answer' => 'Yes, we proudly serve Buffalo and surrounding areas with residential and commercial services.',
        ),
        array(
            'question' => 'ARE YOUR CLEANING SOLUTIONS ECO-FRIENDLY?',
            'answer' => 'Absolutely! We use biodegradable, safe products that are tough on grime, not nature.',
        ),
        array(
            'question' => 'HOW OFTEN SHOULD I POWER WASH?',
            'answer' => 'Most homes benefit from a cleaning once a year, more often for high-traffic or shaded areas.',
        ),
        array(
            'question' => 'DO YOU CLEAN MULTI-STORY HOMES?',
            'answer' => 'Yes, we’re equipped and trained to handle all home sizes, including multi-story properties.',
        ),
        array(
            'question' => 'WHAT PAYMENT METHODS DO YOU ACCEPT?',
            'answer' => 'We accept cash, credit/debit cards, and most mobile payment apps for your convenience.',
        ),
    );
}

// On other pages, hide the section when no complete question and answer is saved.
if (empty($faq_items)) {
    return;
}
?>
<section class="faq-section">
    <!-- Water Wave Background -->
    <div class="faq-wave-bg">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320" preserveAspectRatio="none">
            <path fill="#1475b3" fill-opacity="0.1" d="M0,96L48,112C96,128,192,160,288,160C384,160,480,128,576,112C672,96,768,96,864,112C960,128,1056,160,1152,160C1248,160,1344,128,1392,112L1440,96L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path>
            <path fill="#1475b3" fill-opacity="1" d="M0,128L48,149.3C96,171,192,213,288,213.3C384,213,480,171,576,144C672,117,768,107,864,128C960,149,1056,203,1152,208C1248,213,1344,171,1392,149.3L1440,128L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path>
        </svg>
        <div class="faq-bottom-solid"></div>
    </div>

    <div class="container faq-container">
        <!-- Left Side: Header and CTA -->
        <div class="faq-left">
            <div class="faq-header">
                <span class="section-subtitle"><?php echo esc_html($faq_subtitle); ?></span>
                <h2><?php echo esc_html($faq_title); ?></h2>
            </div>
        </div>
        
        <!-- Right Side: Accordion -->
        <div class="faq-right">
            <div class="accordion-container">
                <?php if (!empty($faq_items)): ?>
                    <?php foreach ($faq_items as $index => $item): ?>
                        <div class="accordion-item<?php echo $index === 0 ? ' active' : ''; ?>">
                            <button class="accordion-header" type="button" aria-expanded="<?php echo $index === 0 ? 'true' : 'false'; ?>">
                                <?php echo esc_html($item['question']); ?>
                                <span class="accordion-icon"></span>
                            </button>
                            <div class="accordion-body" style="<?php echo $index === 0 ? 'max-height: 500px;' : ''; ?>">
                                <div class="accordion-content">
                                    <?php echo wp_kses_post(wpautop($item['answer'])); ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
