<section class="about-section">
    <div class="container about-grid">
        
        <!-- Left Side: Images with specific border-radius shapes -->
        <div class="about-left">
            <div class="about-images-container">
                <!-- Large Image (Shape 1) -->
                <div class="about-img-1">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/about%201.webp" alt="About KD Powerwashing" class="about-img">
                </div>
                
                <!-- Small Overlapping Image (Shape 2) -->
                <div class="about-img-2">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/about%202.webp" alt="KD Powerwashing Team" class="about-img">
                </div>
                
                <!-- Overlapping Button (Like Call Button Position) -->
                <a href="<?php echo esc_url(home_url('/about-us/')); ?>" class="about-overlap-btn btn">About Our Company</a>
            </div>
        </div>

        <!-- Right Side: Content with opposite border-radius shape -->
        <div class="about-right">
            <div class="about-content">
                <span class="section-subtitle">About Us</span>
                <h2>Who We Are at KD Powerwashing</h2>
                <p>KD Powerwashing proudly delivers reliable, affordable, and professional cleaning services. We treat your property like our own, guaranteeing spotless results and complete satisfaction every time. With years of hands-on experience, our team understands the importance of quality, safety, and attention to detail. Whether it’s residential or commercial, we’re committed to restoring and protecting the beauty of your surfaces.</p>
            </div>
        </div>
        
    </div>

    <!-- Features Bottom Row -->
    <div class="container">
        <div class="features-grid">
            <!-- Feature 1 -->
            <div class="feature-item">
                <div class="feature-icon-wrapper">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/feature-spotless.svg" alt="Spotless Finish">
                </div>
                <h3 class="feature-title">Spotless Finish</h3>
            </div>

            <!-- Feature 2 -->
            <div class="feature-item">
                <div class="feature-icon-wrapper">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/feature-damage-free.svg" alt="Damage-Free">
                </div>
                <h3 class="feature-title">Damage-Free</h3>
            </div>

            <!-- Feature 3 -->
            <div class="feature-item">
                <div class="feature-icon-wrapper">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/feature-on-time.svg" alt="On-Time Work">
                </div>
                <h3 class="feature-title">On-Time Work</h3>
            </div>

            <!-- Feature 4 -->
            <div class="feature-item">
                <div class="feature-icon-wrapper">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/feature-reliable.svg" alt="Reliable Service">
                </div>
                <h3 class="feature-title">Reliable Service</h3>
            </div>
        </div>
    </div>
</section>
