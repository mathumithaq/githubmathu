<section class="hero-section">
    <div class="container hero-grid">
        
        <!-- Left Column: Title -->
        <div class="hero-col hero-left">
            <span class="section-subtitle">KD Power Washing</span>
            <h1>Professional Power Washing</h1>
        </div>
        
        <!-- Center Column: Visual Shape & Button -->
        <div class="hero-col hero-center">
            <div class="hero-shape-container">
                <!-- Decorative Side Brackets -->
                <div class="shape-bracket shape-bracket-left"></div>
                <div class="shape-bracket shape-bracket-right"></div>
                
                <!-- Main Pill Shape -->
                <div class="hero-pill-shape">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/hero1.webp" alt="KD Power Washing Team" class="hero-team-img" fetchpriority="high" loading="eager" decoding="sync">
                </div>
            </div>
            
            <div class="hero-center-action">
                <a href="<?php echo esc_url(kd_contact_url()); ?>" class="btn hero-cta-btn">Get Started &rarr;</a>
            </div>
        </div>
        
        <!-- Right Column: Description -->
        <div class="hero-col hero-right">
            <p class="hero-description">With over 10 years of experience, KD Powerwashing delivers expert cleaning services in Buffalo. We specialize in making homes and businesses look spotless, safe, and beautifully maintained year-round.</p>
        </div>
        
    </div>
</section>
