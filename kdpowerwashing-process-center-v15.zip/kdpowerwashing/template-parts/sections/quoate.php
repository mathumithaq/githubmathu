<?php
/**
 * Quote / Call to Action Section Template
 */
?>
<section class="quoate-section quoate-bg">
    <div class="quoate-overlay"></div>
    <div class="container quoate-container">
        <!-- Left Side: Text Content -->
        <div class="quoate-left">
            <span class="section-subtitle">Need a free quote?</span>
            <h2>Book Your Service Today</h2>
        </div>
        
        <!-- Right Side: Contact Info -->
        <div class="quoate-right">
            <div class="quoate-contact-info">
                <a href="tel:7164007016" class="quoate-phone-link"><span class="quoate-phone">(716) 400-7016 </span></a>
                <span class="quoate-or">or</span>
                <a href="<?php echo esc_url(kd_contact_url()); ?>" class="btn">Contact Us</a>
            </div>
        </div>
    </div>
</section>
