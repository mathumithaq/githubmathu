<?php
/**
 * Services Section Template
 */
?>
<section class="services-section">
    <div class="container">
        <!-- Section Header -->
        <div class="services-header">
            <span class="section-subtitle">Our Services</span>
            <h2>Cleaning Services We Offer</h2>
            <p>At KD Powerwashing, we offer a full range of expert cleaning services to restore and maintain your property’s exterior. From homes to businesses, our team ensures spotless, long-lasting results you can trust.</p>
        </div>

        <!-- Services Grid -->
        <div class="services-grid">
            <!-- Service 1 -->
            <div class="service-card">
                <div class="service-card-bg"></div>
                <div class="service-card-fold-tr"></div>
                <div class="service-card-fold-bl"></div>
                <div class="service-card-content">
                    <h3>Power Washing & Pressure Washing</h3>
                    <p>Powerful and precise washing solutions that remove grime, mold, and surface buildup fast.</p>
                    <a href="<?php echo esc_url(site_url('/power-washing/')); ?>" class="btn card-btn">See Details</a>
                </div>
            </div>
            
            <!-- Service 2 -->
            <div class="service-card">
                <div class="service-card-bg"></div>
                <div class="service-card-fold-tr"></div>
                <div class="service-card-fold-bl"></div>
                <div class="service-card-content">
                    <h3>Commercial & Office Cleaning</h3>
                    <p>Keep your business exterior spotless and professional with our reliable commercial cleaning.</p>
                    <a href="<?php echo esc_url(site_url('/commercial-office-cleaning/')); ?>" class="btn card-btn">See Details</a>
                </div>
            </div>
            
            <!-- Service 3 -->
            <div class="service-card">
                <div class="service-card-bg"></div>
                <div class="service-card-fold-tr"></div>
                <div class="service-card-fold-bl"></div>
                <div class="service-card-content">
                    <h3>House Power Washing</h3>
                    <p>Revive your home’s exterior and boost curb appeal with deep-clean house washing.</p>
                    <a href="<?php echo esc_url(site_url('/house-power-washing/')); ?>" class="btn card-btn">See Details</a>
                </div>
            </div>
            
            <!-- Service 4 -->
            <div class="service-card">
                <div class="service-card-bg"></div>
                <div class="service-card-fold-tr"></div>
                <div class="service-card-fold-bl"></div>
                <div class="service-card-content">
                    <h3>Window Cleaning Service</h3>
                    <p>Crystal-clear windows using streak-free, eco-friendly techniques that brighten any space.</p>
                    <a href="<?php echo esc_url(site_url('/window-cleaning/')); ?>" class="btn card-btn">See Details</a>
                </div>
            </div>
            
            <!-- Service 5 -->
            <div class="service-card">
                <div class="service-card-bg"></div>
                <div class="service-card-fold-tr"></div>
                <div class="service-card-fold-bl"></div>
                <div class="service-card-content">
                    <h3>Gutter Cleaning</h3>
                    <p>Protect your property with safe, thorough gutter cleaning that prevents
clogs and overflow.</p>
                    <a href="<?php echo esc_url(site_url('/gutter-cleaning/')); ?>" class="btn card-btn">See Details</a>
                </div>
            </div>
            
            <!-- Service 6 -->
            <div class="service-card">
                <div class="service-card-bg"></div>
                <div class="service-card-fold-tr"></div>
                <div class="service-card-fold-bl"></div>
                <div class="service-card-content">
                    <h3>Roof Cleaning</h3>
                    <p>Remove unsightly algae, moss, and stains to significantly extend the life of your roof safely.</p>
                    <a href="<?php echo esc_url(site_url('/roof-cleaning/')); ?>" class="btn card-btn">See Details</a>
                </div>
            </div>
</div>
    </div>
</section>
