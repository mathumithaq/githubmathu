<?php
/**
 * Service Intro Section
 */
?>
<section class="service-intro-section">
    <div class="container">
        <div class="service-intro-grid">
            <h2 class="service-intro-title">Who We Are &amp; What We Do</h2>
            
            <!-- Left Side: Image -->
            <div class="service-intro-image">
                <div class="si-img-wrapper">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/we.webp" alt="Who We Are & What We Do">
                    <!-- Unique Design Element (e.g., shape behind) -->
                    <div class="si-img-shape"></div>
                </div>
            </div>

            <!-- Right Side: Content -->
            <div class="service-intro-content">
                <p class="si-desc">KD Powerwashing is Buffalo's go-to expert in power washing and cleaning. With 10+ years of experience, we proudly deliver professional, reliable, and affordable services that exceed expectations every time, restoring homes, brightening businesses, and ensuring every surface shines with care, precision, and long-lasting results. Our skilled team uses safe, eco-friendly methods to protect your property while enhancing its curb appeal and overall value.</p>
                
                <div class="si-features">
                    <div class="si-feature">
                        <div class="si-icon">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/check.svg" alt="Check">
                        </div>
                        <div class="si-feature-text">
                            <h3>Reliable Roots, Local Trust</h3>
                            <p>Built from the ground up, our reputation is based on dependable service and customer-first cleaning solutions.</p>
                        </div>
                    </div>
                    
                    <div class="si-feature">
                        <div class="si-icon">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/check.svg" alt="Check">
                        </div>
                        <div class="si-feature-text">
                            <h3>Driven by Quality Results</h3>
                            <p>We bring precision and pride to every job, ensuring consistent, high-quality outcomes our clients can count on.</p>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>
