<?php
/**
 * Process Section Template
 */
$process_descriptions = array(
    'roof-cleaning' => 'We make roof cleaning safe and hassle-free, handling everything from initial inspection to the final check to ensure your roof looks great and stays protected.',
    'gutter-cleaning' => 'We’ve made gutter cleaning easy and efficient. From inspection to cleanup, we ensure your gutters are cleared, flowing, and protecting your home from water damage.',
    'house-power-washing' => 'We’ve designed a stress-free power washing process to restore your home’s beauty with minimal disruption. Just book, sit back, and enjoy a cleaner, brighter exterior.',
    'window-cleaning' => 'We’ve streamlined our window cleaning process for maximum convenience and quality. From the first quote to the final inspection, your windows are in expert hands.',
    'commercial-office-cleaning' => 'Our commercial cleaning process is efficient and discreet. We adapt to your business hours, ensuring a clean work environment without disruption to your operations.',
    'power-washing-and-pressure-washing' => 'We’ve made our power washing process simple, fast, and hassle-free. From requesting a quote to final inspection, we handle everything so you can sit back and enjoy spotless results.',
);
$process_description = get_post_meta(get_the_ID(), 'process_description', true);
if (empty($process_description)) {
    $process_description = $process_descriptions[get_post_field('post_name', get_queried_object_id())] ?? 'We’ve made our power washing process simple, fast, and hassle-free. From requesting a quote to final inspection, we handle everything so you can sit back and enjoy spotless results.';
}
?>
<section class="process-section">
    <div class="container">
        <div class="process-header">
            <div class="process-header-text">
                <span class="section-subtitle">Our Working Process</span>
                <h2>Our Simple Cleaning Process</h2>
                <p><?php echo esc_html($process_description); ?></p>
            </div>
            <div class="process-header-btn">
                <a href="<?php echo esc_url(kd_contact_url()); ?>" class="btn">Get Started</a>
            </div>
        </div>

        <div class="process-steps-container">
            <!-- Step 1 -->
            <div class="process-step">
                <div class="step-number">01</div>
                <div class="step-icon-wrapper">
                    <div class="step-icon">
                        <!-- Free Quote Icon -->
                        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>
                    </div>
                </div>
                <h3 class="step-title">Free Quote</h3>
                <p class="step-desc">Get a fast, accurate estimate for your cleaning needs.</p>
            </div>

            <div class="step-divider">
                <svg width="40" height="20" viewBox="0 0 40 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M2 10C12 10 15 2 20 2C25 2 28 10 38 10" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                    <path d="M34 6L38 10L34 14" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </div>

            <!-- Step 2 -->
            <div class="process-step">
                <div class="step-number">02</div>
                <div class="step-icon-wrapper">
                    <div class="step-icon">
                        <!-- Schedule Icon -->
                        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
                    </div>
                </div>
                <h3 class="step-title">Schedule</h3>
                <p class="step-desc">We book your service at your preferred time.</p>
            </div>

            <div class="step-divider">
                <svg width="40" height="20" viewBox="0 0 40 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M2 10C12 10 15 2 20 2C25 2 28 10 38 10" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                    <path d="M34 6L38 10L34 14" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </div>

            <!-- Step 3 -->
            <div class="process-step">
                <div class="step-number">03</div>
                <div class="step-icon-wrapper">
                    <div class="step-icon">
                        <!-- Cleaning Icon (Droplet) -->
                        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z"></path></svg>
                    </div>
                </div>
                <h3 class="step-title">Cleaning</h3>
                <p class="step-desc">Our team arrives ready to deliver spotless results.</p>
            </div>

            <div class="step-divider">
                <svg width="40" height="20" viewBox="0 0 40 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M2 10C12 10 15 2 20 2C25 2 28 10 38 10" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                    <path d="M34 6L38 10L34 14" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </div>

            <!-- Step 4 -->
            <div class="process-step">
                <div class="step-number">04</div>
                <div class="step-icon-wrapper">
                    <div class="step-icon">
                        <!-- Final Check Icon -->
                        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
                    </div>
                </div>
                <h3 class="step-title">Final Check</h3>
                <p class="step-desc">We walk through the job to ensure you're happy.</p>
            </div>
        </div>
    </div>
</section>
