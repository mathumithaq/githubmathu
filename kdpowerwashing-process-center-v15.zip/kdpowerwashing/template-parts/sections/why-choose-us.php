<?php
/**
 * Why Choose Us Section Template
 */
?>
<section class="why-section">
    <div class="container why-grid">
        <!-- Left Side: Frame Image -->
        <div class="why-left">
            <div class="why-frame-wrapper">
                <div class="why-frame">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/why.webp" alt="Why Choose Us"
                        class="why-img">
                    <div class="why-overlay-text">
                        <span>THE</span>
                        <span class="highlight">PERFECT</span>
                        <span>CHOICE</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Right Side: Content & Cards -->
        <div class="why-right">
            <div class="why-header">
                <span class="section-subtitle">Why Choose Us</span>
                <h2>Why Choose Us</h2>
                <p>At KD Powerwashing, we offer a full range of expert cleaning services to restore and maintain your
                    property’s exterior. From homes to businesses, our team ensures spotless, long-lasting results you
                    can trust.</p>
                <div class="why-btn-wrapper">
                    <a href="<?php echo esc_url(site_url('/about-us/')); ?>" class="btn"
                        aria-label="Read more about KD Power Washing">More About Us</a>
                </div>
            </div>

            <!-- 3 Small Cards -->
            <div class="why-cards-row">
                <!-- Card 1 -->
                <div class="why-mini-card">
                    <div class="mini-card-icon">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/thumbs-up.svg"
                            alt="Thumbs Up">
                    </div>
                    <h3>Experienced & Certified Team</h3>
                </div>

                <!-- Card 2 -->
                <div class="why-mini-card">
                    <div class="mini-card-icon">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/thumbs-up.svg"
                            alt="Thumbs Up">
                    </div>
                    <h3>100% Satisfaction Guaranteed</h3>
                </div>

                <!-- Card 3 -->
                <div class="why-mini-card">
                    <div class="mini-card-icon">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/thumbs-up.svg"
                            alt="Thumbs Up">
                    </div>
                    <h3>Safe & Eco-Friendly Methods</h3>
                </div>
            </div>
        </div>
    </div>

    <!-- New Full Width Stats Marquee Bar -->
    <div class="stats-marquee-wrapper">
        <div class="stats-marquee-track" id="statsMarqueeTrack">
            <!-- Items (Duplicated 3 times for seamless scrolling) -->
            <?php for ($i = 0; $i < 3; $i++): ?>
                <div class="stat-item">
                    <span class="stat-number" data-target="100" data-suffix="%">0%</span>
                    <span class="stat-label">Satisfied Clients</span>
                </div>
                <div class="stat-item">
                    <span class="stat-number" data-target="500" data-suffix="+">0+</span>
                    <span class="stat-label">5-Star Reviews</span>
                </div>
                <div class="stat-item">
                    <span class="stat-number" data-target="24" data-suffix="hr">0hr</span>
                    <span class="stat-label">Response Guarantee</span>
                </div>
                <div class="stat-item">
                    <span class="stat-number" data-target="1200" data-suffix="+">0+</span>
                    <span class="stat-label">Properties Cleaned</span>
                </div>
            <?php endfor; ?>
        </div>
    </div>
</section>