<?php
/**
 * Journey Section Template for About Us Page
 */
?>
<section class="journey-section">
    <div class="container">
        
        <div class="journey-grid">
            <!-- Left Side: Main Text -->
            <div class="journey-content-left">
                <span class="section-subtitle">Our Story</span>
                <h2 class="journey-title">Our Journey to Buffalo’s Best</h2>
                <p class="journey-description">What started as a small operation in Buffalo grew into a trusted name in cleaning. With over 10 years of experience, KD Powerwashing is built on reliable service, real results, and happy customers.</p>
                
                <div class="journey-image-wrapper">
                     <img
                         src="<?php echo get_template_directory_uri(); ?>/assets/images/journey.webp"
                         alt="KD Powerwashing Journey"
                         class="journey-main-img"
                         width="640"
                         height="427"
                         loading="lazy"
                         decoding="async">
                     <div class="experience-badge">
                         <span class="exp-number">10+</span>
                         <span class="exp-text">Years of<br>Experience</span>
                     </div>
                </div>
            </div>

            <!-- Right Side: Journey Steps / Features -->
            <div class="journey-content-right">
                <div class="journey-timeline">
                    
                    <!-- Step 1 -->
                    <div class="journey-step card">
                        <div class="step-icon-box">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/service-house.svg" alt="Trust Icon" width="35" height="35">
                        </div>
                        <div class="step-content">
                            <h3>Reliable Roots, Local Trust</h3>
                            <p>Built from the ground up, our reputation is based on dependable service and customer-first cleaning solutions.</p>
                        </div>
                    </div>
                    
                    <!-- Step 2 -->
                    <div class="journey-step card">
                        <div class="step-icon-box">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/service-window.svg" alt="Quality Icon" width="35" height="35">
                        </div>
                        <div class="step-content">
                            <h3>Driven by Quality Results</h3>
                            <p>We bring precision and pride to every job, ensuring consistent, high-quality outcomes our clients can count on.</p>
                        </div>
                    </div>

                </div>
            </div>
        </div>

    </div>
</section>
