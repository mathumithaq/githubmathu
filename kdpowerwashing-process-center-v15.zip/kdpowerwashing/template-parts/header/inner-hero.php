<?php
/**
 * Dynamic Inner Hero Title & Breadcrumb Generator
 */
$page_title = '';

// 1. Check for custom meta title if defined for this post/page in WP Admin
$custom_hero_title = get_post_meta(get_the_ID(), 'hero_title', true);
if (empty($custom_hero_title)) {
    $custom_hero_title = get_post_meta(get_the_ID(), 'inner_hero_title', true);
}

if (!empty($custom_hero_title)) {
    $page_title = $custom_hero_title;
} elseif (is_404()) {
    $page_title = 'Page Not Found';
} elseif (is_search()) {
    $page_title = 'Search Results for: ' . get_search_query();
} elseif (is_archive()) {
    $page_title = get_the_archive_title();
} elseif (is_home() && !is_front_page()) {
    $page_title = single_post_title('', false) ? single_post_title('', false) : 'Blog';
} elseif (is_front_page()) {
    $page_title = 'Home';
} else {
    // Get WordPress page or post title dynamically
    $raw_title = get_the_title(get_the_ID());
    
    // If title is empty, fallback to post slug
    if (empty($raw_title)) {
        global $post;
        if (!empty($post->post_name)) {
            $raw_title = $post->post_name;
        }
    }
    
    // Convert hyphenated or underscore slugs to readable title (e.g. "about-us" -> "About Us")
    if (strpos($raw_title, '-') !== false && strpos($raw_title, ' ') === false) {
        $raw_title = ucwords(str_replace('-', ' ', $raw_title));
    } elseif (strpos($raw_title, '_') !== false && strpos($raw_title, ' ') === false) {
        $raw_title = ucwords(str_replace('_', ' ', $raw_title));
    }
    
    $page_title = $raw_title;
}

// Ensure first letter capitalization if title is all lowercase
if ($page_title === strtolower($page_title)) {
    $page_title = ucwords($page_title);
}
?>

<section class="inner-hero-section">
    <div class="container">
        <div class="inner-hero-grid">
            
            <!-- Left Frame: Image 1 -->
            <div class="inner-hero-col left-col">
                <div class="inner-frame-box image-frame">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/iner-hero1.webp" alt="Power Washing Services" width="640" height="427" fetchpriority="high" decoding="sync">
                </div>
            </div>

            <!-- Center Frame: Content -->
            <div class="inner-hero-col center-col">
                <div class="inner-frame-box content-frame">
                    <h1 class="inner-page-title"><?php echo esc_html($page_title); ?></h1>
                    
                    <div class="inner-breadcrumb-container">
                        <a href="<?php echo esc_url(home_url('/')); ?>" class="inner-breadcrumb home-btn">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                                <polyline points="9 22 9 12 15 12 15 22"></polyline>
                            </svg>
                            <span>Home</span>
                        </a>
                    </div>
                </div>
            </div>

            <!-- Right Frame: Image 2 -->
            <div class="inner-hero-col right-col">
                <div class="inner-frame-box image-frame">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/inner-hero2.webp" alt="Commercial Power Washing" width="640" height="427" fetchpriority="high" decoding="sync">
                </div>
            </div>
            
        </div>
    </div>
</section>
