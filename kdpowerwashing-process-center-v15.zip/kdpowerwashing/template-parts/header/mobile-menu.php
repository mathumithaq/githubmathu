<!-- Mobile Menu Overlay -->
<div class="mobile-menu-overlay" id="mobileMenuOverlay"></div>

<!-- Mobile Menu Sidebar -->
<div class="mobile-menu-sidebar" id="mobileMenuSidebar">
    <div class="mobile-menu-header">
        <a href="<?php echo esc_url(home_url('/')); ?>">
            <img src="<?php echo get_template_directory_uri(); ?>/assets/images/powerwashing fav.webp" alt="KD Power Washing" class="mobile-logo">
        </a>
        <button class="mobile-menu-close" id="mobileMenuClose" aria-label="Close Menu">
            <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/close.svg" alt="Close">
        </button>
    </div>
    
    <div class="mobile-menu-body">
        <ul class="mobile-nav-list">
            <li><a href="<?php echo esc_url(home_url('/')); ?>" class="<?php echo esc_attr(kd_nav_class('home')); ?>"<?php echo kd_nav_aria_current('home'); ?>><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/menu-home.svg" alt="Home" class="menu-icon"> Home</a></li>
            <li><a href="<?php echo esc_url(home_url('/about-us/')); ?>" class="<?php echo esc_attr(kd_nav_class('about-us')); ?>"<?php echo kd_nav_aria_current('about-us'); ?>><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/menu-about.svg" alt="About" class="menu-icon"> About Us</a></li>
            <li class="mobile-has-dropdown">
                <a href="<?php echo esc_url(site_url('/services/')); ?>" class="<?php echo esc_attr(kd_nav_class('services', 'mobile-main-link')); ?>"<?php echo kd_nav_aria_current('services'); ?>><span class="menu-item-with-icon"><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/menu-services.svg" alt="Services" class="menu-icon"> Services</span></a>
                <span class="mobile-dropdown-toggle">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/dropdown-arrow.svg" alt="Dropdown">
                </span>
                <ul class="mobile-sub-menu">
                    <li><a href="<?php echo esc_url(home_url('/roof-cleaning/')); ?>" class="<?php echo esc_attr(kd_nav_class('roof-cleaning')); ?>"<?php echo kd_nav_aria_current('roof-cleaning'); ?>><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/service-roof.svg" alt="Roof Cleaning" class="menu-icon"> Roof Cleaning</a></li>
                    <li><a href="<?php echo esc_url(home_url('/gutter-cleaning/')); ?>" class="<?php echo esc_attr(kd_nav_class('gutter-cleaning')); ?>"<?php echo kd_nav_aria_current('gutter-cleaning'); ?>><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/service-gutter.svg" alt="Gutter Cleaning" class="menu-icon"> Gutter Cleaning</a></li>
                    <li><a href="<?php echo esc_url(home_url('/house-power-washing/')); ?>" class="<?php echo esc_attr(kd_nav_class('house-power-washing')); ?>"<?php echo kd_nav_aria_current('house-power-washing'); ?>><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/service-house.svg" alt="House Washing" class="menu-icon"> House Power Washing</a></li>
                    <li><a href="<?php echo esc_url(home_url('/window-cleaning/')); ?>" class="<?php echo esc_attr(kd_nav_class('window-cleaning')); ?>"<?php echo kd_nav_aria_current('window-cleaning'); ?>><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/service-window.svg" alt="Window Cleaning" class="menu-icon"> Window Cleaning Service</a></li>
                    <li><a href="<?php echo esc_url(home_url('/commercial-office-cleaning/')); ?>" class="<?php echo esc_attr(kd_nav_class('commercial-office-cleaning')); ?>"<?php echo kd_nav_aria_current('commercial-office-cleaning'); ?>><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/service-commercial.svg" alt="Commercial Cleaning" class="menu-icon"> Commercial & Office Cleaning</a></li>
                    <li><a href="<?php echo esc_url(home_url('/power-washing-and-pressure-washing/')); ?>" class="<?php echo esc_attr(kd_nav_class('power-washing-and-pressure-washing')); ?>"<?php echo kd_nav_aria_current('power-washing-and-pressure-washing'); ?>><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/service-pressure.svg" alt="Pressure Washing" class="menu-icon"> Power Washing And Pressure Washing</a></li>
                </ul>
            </li>
            <li><a href="<?php echo esc_url(site_url('/blog/')); ?>" class="<?php echo esc_attr(kd_nav_class('blog')); ?>"<?php echo kd_nav_aria_current('blog'); ?>><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/menu-blog.svg" alt="Blog" class="menu-icon"> Blog</a></li>
            <li class="mobile-has-dropdown">
                <a href="#" class="<?php echo esc_attr(kd_nav_class('location', 'mobile-main-link')); ?>"<?php echo kd_nav_aria_current('location'); ?> onclick="event.preventDefault(); this.nextElementSibling.click();"><span class="menu-item-with-icon"><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/menu-location.svg" alt="Location" class="menu-icon"> Location</span></a>
                <span class="mobile-dropdown-toggle">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/dropdown-arrow.svg" alt="Dropdown">
                </span>
                <ul class="mobile-sub-menu">
                    <li><a href="<?php echo esc_url(site_url('/syracuse/')); ?>" class="<?php echo esc_attr(kd_nav_class('syracuse')); ?>"<?php echo kd_nav_aria_current('syracuse'); ?>><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/menu-location.svg" alt="Icon" class="menu-icon"> SYRACUSES</a></li>
                    <li><a href="<?php echo esc_url(site_url('/rochester/')); ?>" class="<?php echo esc_attr(kd_nav_class('rochester')); ?>"<?php echo kd_nav_aria_current('rochester'); ?>><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/menu-location.svg" alt="Icon" class="menu-icon"> ROCHESTER</a></li>
                </ul>
            </li>
            <li><a href="<?php echo esc_url(kd_contact_url()); ?>" class="<?php echo esc_attr(kd_nav_class('contact')); ?>"<?php echo kd_nav_aria_current('contact'); ?>><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/menu-contact.svg" alt="Contact Us" class="menu-icon"> Contact Us</a></li>
        </ul>
        
        <div class="mobile-contact-info">
            <a href="tel:+17164007016" class="btn mobile-quote-btn">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/phone-white.svg" alt="Phone" class="btn-icon">
                (716) 400-7016
            </a>
            <div class="mobile-icons mobile-social-icons">
                <a href="https://web.facebook.com/KDbuffalocleaning/?_rdc=1&_rdr#" aria-label="Facebook" target="_blank" rel="noopener noreferrer"><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/social-fb.svg?v=2" alt="Facebook"></a>
                <a href="https://www.instagram.com/kd_pressure_washing" aria-label="Instagram" target="_blank" rel="noopener noreferrer"><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/social-ig.svg?v=2" alt="Instagram"></a>
                <a href="https://de.pinterest.com/kd_powerwashing/" aria-label="Pinterest" target="_blank" rel="noopener noreferrer"><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/social-pin.svg?v=3" alt="Pinterest"></a>
                <a href="https://www.tiktok.com/@kdpowerwashing" aria-label="TikTok" target="_blank" rel="noopener noreferrer"><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/social-tk.svg?v=2" alt="TikTok"></a>
                <a href="https://x.com/kd_powerwash?s=21" aria-label="X" target="_blank" rel="noopener noreferrer"><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/social-x.svg?v=2" alt="X"></a>
            </div>
        </div>
    </div>
</div>
