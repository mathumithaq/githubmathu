<div class="top-bar">
    <div class="container">
        <div class="top-bar-left">
            <ul class="top-bar-features">
                <li><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/check.svg" alt="Check" width="16" height="16"> Licensed
                    & Insured</li>
                <li><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/leaf.svg" alt="Leaf" width="16" height="16">
                    Eco-Friendly Solutions</li>
                <li><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/star.svg" alt="Star" width="16" height="16"> 100%
                    Satisfaction Guaranteed</li>
            </ul>
        </div>
        <div class="top-bar-right">
            <div class="top-bar-contact">
                <a href="mailto:sales@kdpowerwashing.com" class="topbar-email-link"><img
                        src="<?php echo get_template_directory_uri(); ?>/assets/icons/envelope.svg" alt="Email" width="16" height="16">
                    sales@kdpowerwashing.com</a>
            </div>
            <div class="top-bar-social">
                <a href="https://web.facebook.com/KDbuffalocleaning/?_rdc=1&_rdr#" aria-label="Facebook" target="_blank" rel="noopener noreferrer"><img
                        src="<?php echo get_template_directory_uri(); ?>/assets/icons/social-fb.svg?v=2" alt="Facebook" width="18" height="18"></a>
                <a href="https://www.instagram.com/kd_pressure_washing" aria-label="Instagram" target="_blank" rel="noopener noreferrer"><img
                        src="<?php echo get_template_directory_uri(); ?>/assets/icons/social-ig.svg?v=2"
                        alt="Instagram" width="18" height="18"></a>
                <a href="https://de.pinterest.com/kd_powerwashing/" aria-label="Pinterest" target="_blank" rel="noopener noreferrer"><img
                        src="<?php echo get_template_directory_uri(); ?>/assets/icons/social-pin.svg?v=3"
                        alt="Pinterest" width="18" height="18"></a>
                <a href="https://www.tiktok.com/@kdpowerwashing" aria-label="TikTok" target="_blank" rel="noopener noreferrer"><img
                        src="<?php echo get_template_directory_uri(); ?>/assets/icons/social-tk.svg?v=2" alt="TikTok" width="18" height="18"></a>
                <a href="https://x.com/kd_powerwash?s=21" aria-label="X" target="_blank" rel="noopener noreferrer"><img
                        src="<?php echo get_template_directory_uri(); ?>/assets/icons/social-x.svg?v=2" alt="X" width="18" height="18"></a>
            </div>
        </div>
    </div>
</div>