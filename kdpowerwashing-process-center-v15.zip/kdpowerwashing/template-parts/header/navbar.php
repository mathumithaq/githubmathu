<nav class="main-navbar">
    <div class="container">
        <!-- Left Menu -->
        <div class="nav-left">
            <ul class="nav-menu">
                <li><a href="<?php echo esc_url(home_url('/')); ?>" class="<?php echo esc_attr(kd_nav_class('home')); ?>"<?php echo kd_nav_aria_current('home'); ?>><img
                            src="<?php echo get_template_directory_uri(); ?>/assets/icons/menu-home.svg" alt="Home"
                            class="menu-icon"> Home</a></li>
                <li><a href="<?php echo esc_url(home_url('/about-us/')); ?>" class="<?php echo esc_attr(kd_nav_class('about-us')); ?>"<?php echo kd_nav_aria_current('about-us'); ?>><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/menu-about.svg"
                            alt="About" class="menu-icon"> About</a></li>
                <li class="has-dropdown">
                    <a href="<?php echo esc_url(site_url('/services/')); ?>" class="<?php echo esc_attr(kd_nav_class('services')); ?>"<?php echo kd_nav_aria_current('services'); ?>><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/menu-services.svg"
                            alt="Services" class="menu-icon"> Services <img
                            src="<?php echo get_template_directory_uri(); ?>/assets/icons/dropdown-arrow.svg"
                            alt="Dropdown" class="icon-dropdown"></a>
                    <ul class="sub-menu">
                        <li><a href="<?php echo esc_url(home_url('/roof-cleaning/')); ?>" class="<?php echo esc_attr(kd_nav_class('roof-cleaning')); ?>"<?php echo kd_nav_aria_current('roof-cleaning'); ?>><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/service-roof.svg" alt="Roof Cleaning" class="menu-icon"> Roof Cleaning</a></li>
                        <li><a href="<?php echo esc_url(home_url('/gutter-cleaning/')); ?>" class="<?php echo esc_attr(kd_nav_class('gutter-cleaning')); ?>"<?php echo kd_nav_aria_current('gutter-cleaning'); ?>><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/service-gutter.svg" alt="Gutter Cleaning" class="menu-icon"> Gutter Cleaning</a></li>
                        <li><a href="<?php echo esc_url(home_url('/house-power-washing/')); ?>" class="<?php echo esc_attr(kd_nav_class('house-power-washing')); ?>"<?php echo kd_nav_aria_current('house-power-washing'); ?>><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/service-house.svg" alt="House Washing" class="menu-icon"> House Power Washing</a></li>
                        <li><a href="<?php echo esc_url(home_url('/window-cleaning/')); ?>" class="<?php echo esc_attr(kd_nav_class('window-cleaning')); ?>"<?php echo kd_nav_aria_current('window-cleaning'); ?>><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/service-window.svg" alt="Window Cleaning" class="menu-icon"> Window Cleaning Service</a></li>
                        <li><a href="<?php echo esc_url(home_url('/commercial-office-cleaning/')); ?>" class="<?php echo esc_attr(kd_nav_class('commercial-office-cleaning')); ?>"<?php echo kd_nav_aria_current('commercial-office-cleaning'); ?>><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/service-commercial.svg" alt="Commercial Cleaning" class="menu-icon"> Commercial & Office Cleaning</a></li>
                        <li><a href="<?php echo esc_url(home_url('/power-washing-and-pressure-washing/')); ?>" class="<?php echo esc_attr(kd_nav_class('power-washing-and-pressure-washing')); ?>"<?php echo kd_nav_aria_current('power-washing-and-pressure-washing'); ?>><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/service-pressure.svg" alt="Pressure Washing" class="menu-icon"> Power Washing And Pressure Washing</a></li>
                    </ul>
                </li>
            </ul>
        </div>

        <!-- Center Logo with Swoosh Border -->
        <div class="nav-center-logo">
            <a href="<?php echo esc_url(home_url('/')); ?>" class="logo-wrapper" aria-label="KD Power Washing Home">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/logo-border-swoosh.svg" alt=""
                    class="logo-swoosh-border">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/images/powerwashing fav.webp"
                    alt="KD Power Washing Logo" class="center-logo-img">
            </a>
        </div>

        <!-- Right Menu & Icons -->
        <div class="nav-right">
            <ul class="nav-menu">
                <li><a href="<?php echo esc_url(site_url('/blog/')); ?>" class="<?php echo esc_attr(kd_nav_class('blog')); ?>"<?php echo kd_nav_aria_current('blog'); ?>><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/menu-blog.svg"
                            alt="Blog" class="menu-icon"> Blog</a></li>
                <li class="has-dropdown">
                    <a href="#" class="<?php echo esc_attr(kd_nav_class('location')); ?>"<?php echo kd_nav_aria_current('location'); ?>><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/menu-location.svg"
                            alt="Location" class="menu-icon"> Location <img
                            src="<?php echo get_template_directory_uri(); ?>/assets/icons/dropdown-arrow.svg"
                            alt="Dropdown" class="icon-dropdown"></a>
                    <ul class="sub-menu">
                        <li><a href="<?php echo esc_url(site_url('/syracuse/')); ?>" class="<?php echo esc_attr(kd_nav_class('syracuse')); ?>"<?php echo kd_nav_aria_current('syracuse'); ?>><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/menu-location.svg" alt="Icon" class="menu-icon"> Syracuses</a></li>
                        <li><a href="<?php echo esc_url(site_url('/rochester/')); ?>" class="<?php echo esc_attr(kd_nav_class('rochester')); ?>"<?php echo kd_nav_aria_current('rochester'); ?>><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/menu-location.svg" alt="Icon" class="menu-icon"> Rochester</a></li>
                    </ul>
                </li>
                <li><a href="<?php echo esc_url(kd_contact_url()); ?>" class="<?php echo esc_attr(kd_nav_class('contact')); ?>"<?php echo kd_nav_aria_current('contact'); ?>><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/menu-contact.svg"
                            alt="Contact Us" class="menu-icon"> Contact</a></li>
            </ul>

            <div class="nav-icons">
                <a href="tel:+17164007016" class="icon-phone" aria-label="Call Us">
                    <div class="phone-circle">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/phone-white.svg" alt="Phone">
                    </div>
                </a>
            </div>
        </div>

        <!-- Mobile Actions -->
        <div class="mobile-actions">
            <div class="tablet-social-icons">
                <a href="https://web.facebook.com/KDbuffalocleaning/?_rdc=1&_rdr#" aria-label="Facebook" target="_blank" rel="noopener noreferrer"><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/social-fb.svg?v=2" alt="Facebook"></a>
                <a href="https://www.instagram.com/kd_pressure_washing" aria-label="Instagram" target="_blank" rel="noopener noreferrer"><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/social-ig.svg?v=2" alt="Instagram"></a>
                <a href="https://de.pinterest.com/kd_powerwashing/" aria-label="Pinterest" target="_blank" rel="noopener noreferrer"><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/social-pin.svg?v=3" alt="Pinterest"></a>
                <a href="https://www.tiktok.com/@kdpowerwashing" aria-label="TikTok" target="_blank" rel="noopener noreferrer"><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/social-tk.svg?v=2" alt="TikTok"></a>
                <a href="https://x.com/kd_powerwash?s=21" aria-label="X" target="_blank" rel="noopener noreferrer"><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/social-x.svg?v=2" alt="X"></a>
            </div>
            
            <a href="tel:+17164007016" class="mobile-call-btn" aria-label="Call Us">
                <div class="phone-circle">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/phone-white.svg" alt="Phone">
                </div>
            </a>
            <button type="button" class="mobile-menu-toggle" id="mobileMenuOpen" aria-label="Open Mobile Menu">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/mobile-menu.svg" alt="Menu">
            </button>
        </div>
    </div>
</nav>
