<footer class="site-footer">
    <!-- SVG Open Book Shape with Gradient Border -->
    <div class="footer-shape">
        <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/footer-shape.svg" alt="Footer Border Shape"
            class="shape-svg">
    </div>

    <!-- Watermark Background -->
    <div class="footer-watermark"></div>

    <div class="container footer-content-wrapper">
        <!-- Floating Center Map -->
        <div class="footer-floating-map">
            <iframe
                data-src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2224.1749447471866!2d-78.8272796!3d42.958416299999996!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89d373bbe41e3617%3A0xeb41528802cb9123!2sKD%20Power%20Washing%20and%20Cleaning!5e1!3m2!1sen!2slk!4v1790087697998!5m2!1sen!2slk"
                width="100%" height="100%" class="footer-map-iframe lazy-iframe" allowfullscreen="" loading="lazy"
                referrerpolicy="strict-origin-when-cross-origin"
                title="KD Power Washing Location Map"></iframe>
        </div>

        <div class="footer-grid">
            <div class="footer-col brand-col">
                <a href="<?php echo esc_url(home_url('/')); ?>">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/powerwashing fav.webp"
                        alt="KD Power Washing" class="footer-logo">
                </a>
                <p>Trusted by Buffalo for 10+ years, KD Powerwashing delivers expert, affordable, and reliable cleaning
                    services, safely, professionally, every time.</p>
            </div>

            <div class="footer-col links-col">
                <h3>Quick Links</h3>
                <ul>
                    <li><a href="<?php echo esc_url(site_url('/about-us/')); ?>">About Us</a></li>
                    <li><a href="<?php echo esc_url(site_url('/services/')); ?>">Services</a></li>
                    <li><a href="<?php echo esc_url(kd_contact_url()); ?>">Contact Us</a></li>
                    <li><a href="<?php echo esc_url(site_url('/privacy-policy/')); ?>">Privacy Policy</a></li>
                    <li><a href="<?php echo esc_url(site_url('/terms-and-conditions/')); ?>">Terms and Conditions</a></li>
                </ul>
            </div>

            <div class="footer-col links-col">
                <h3>Services Links</h3>
                <ul>
                    <li><a href="<?php echo esc_url(site_url('/roof-cleaning/')); ?>">Roof Cleaning</a></li>
                    <li><a href="<?php echo esc_url(site_url('/gutter-cleaning/')); ?>">Gutter Cleaning</a></li>
                    <li><a href="<?php echo esc_url(site_url('/window-cleaning/')); ?>">Window Cleaning</a></li>
                    <li><a href="<?php echo esc_url(site_url('/house-power-washing/')); ?>">House Power Washing</a></li>
                    <li><a href="<?php echo esc_url(site_url('/commercial-office-cleaning/')); ?>">Commercial & Office Cleaning</a></li>
                    <li><a href="<?php echo esc_url(site_url('/power-washing-and-pressure-washing/')); ?>">Power Washing & Pressure Washing</a></li>
                </ul>
            </div>

            <div class="footer-col contact-col">
                <h3>Contact Details</h3>
                <ul>
                    <li><a href="tel:+17164007016"><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/phone.svg" alt="Phone"
                            class="contact-icon"> <span>(716) 400-7016</span></a></li>
                    <li><a href="mailto:sales@kdpowerwashing.com"><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/envelope.svg" alt="Email"
                            class="contact-icon contact-icon-green"> <span>sales@kdpowerwashing.com</span></a></li>
                    <li><a href="https://maps.app.goo.gl/rHYCjowj6gvMQDf17"
                            target="_blank" rel="noopener noreferrer"><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/menu-location.svg"
                            alt="Address" class="contact-icon contact-icon-green"> <span>257 Kenmore Ave, Buffalo, NY 14223, United
                            States</span></a></li>
                </ul>
            </div>
        </div>
    </div>

    <div class="footer-bottom">
        <div class="container">
            <p>&copy; <?php echo date('Y'); ?> <a href="<?php echo esc_url(home_url('/')); ?>" class="footer-highlight">KD Power Washing</a> All Rights
                Reserved | Designed & Develop By <a href="https://kdmarketinggroup.com/" target="_blank"
                    rel="noopener noreferrer" class="footer-highlight">KD Marketing Group INC.</a></p>
        </div>
    </div>
</footer>