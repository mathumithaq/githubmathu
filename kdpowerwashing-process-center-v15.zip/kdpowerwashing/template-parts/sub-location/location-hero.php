<?php
/**
 * Location Hero Section
 * Uses Native Custom Fields
 */

// Fetch Native Custom Fields
$subtitle = get_post_meta(get_the_ID(), 'loc_hero_subtitle', true);
$title = get_post_meta(get_the_ID(), 'loc_hero_title', true);
$desc = get_post_meta(get_the_ID(), 'loc_hero_desc', true);
$image = get_post_meta(get_the_ID(), 'loc_hero_image', true);

// Fallbacks
if (empty($subtitle)) {
    $subtitle = 'KD Power Washing';
}
if (empty($title)) {
    $title = get_the_title();
}
if (empty($desc)) {
    $desc = 'Get the best professional power washing services to keep your property looking pristine and spotless.';
}
if (empty($image)) {
    $image = get_template_directory_uri() . '/assets/images/loc-hero.webp';
}
?>

<section class="location-hero-section">
    <div class="container location-hero-container">
        <!-- Left Side: Text Content -->
        <div class="location-hero-content">
            <span class="section-subtitle"><?php echo esc_html($subtitle); ?></span>
            <h1 class="location-hero-title"><?php echo esc_html($title); ?></h1>
            <p class="location-hero-desc"><?php echo esc_html($desc); ?></p>
            <a href="<?php echo esc_url(kd_contact_url()); ?>" class="btn">Get Started</a>
        </div>
        
        <!-- Right Side: Shaped Image -->
        <div class="location-hero-image-wrapper">
            <div class="location-shape">
                <img src="<?php echo esc_url($image); ?>" alt="<?php echo esc_attr($title); ?>" fetchpriority="high" loading="eager" decoding="sync">
            </div>
        </div>
    </div>
</section>
