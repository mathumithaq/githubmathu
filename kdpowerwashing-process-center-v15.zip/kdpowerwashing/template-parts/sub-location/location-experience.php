<?php
/**
 * Location Experience Section Template
 * Matches the reference design with dynamic custom fields.
 */

// Fetch Native Custom Fields
$exp_title    = get_post_meta(get_the_ID(), 'loc_exp_title', true);
$exp_desc     = get_post_meta(get_the_ID(), 'loc_exp_desc', true);
$exp_img      = get_post_meta(get_the_ID(), 'loc_exp_img', true);
$exp_btn_text = get_post_meta(get_the_ID(), 'loc_exp_btn_text', true);
$exp_btn_link = get_post_meta(get_the_ID(), 'loc_exp_btn_link', true);

// Fetch List Items
$list_items = [];
for ($i = 1; $i <= 4; $i++) {
    $item = get_post_meta(get_the_ID(), 'loc_exp_list_' . $i, true);
    if (!empty($item)) {
        $list_items[] = $item;
    }
}

// Fallbacks
if (empty($exp_title)) {
    $exp_title = 'Experience You Can Count On';
}
if (empty($exp_desc)) {
    $exp_desc = 'At KD Powerwashing, we offer a full range of expert cleaning services to restore and maintain your property’s exterior. From homes to businesses, our team ensures spotless, long-lasting results you can trust.';
}
if (empty($exp_img)) {
    $exp_img = get_template_directory_uri() . '/assets/images/about 1.webp';
}
if (empty($exp_btn_text)) {
    $exp_btn_text = 'READ MORE';
}
if (empty($exp_btn_link)) {
    $exp_btn_link = site_url('/about');
}
if (empty($list_items)) {
    $list_items = [
        'PROFESSIONAL RESULTS',
        'SAFE FOR EVERY SURFACE',
        'TIMELY & EFFICIENT SERVICE',
        'TRUSTED LOCAL EXPERTS'
    ];
}
?>

<section class="location-exp-section">
    <div class="container location-exp-grid">
        
        <!-- Left Side: Image -->
        <div class="location-exp-left">
            <div class="location-exp-img-wrapper">
                <img src="<?php echo esc_url($exp_img); ?>" alt="Experience you can count on" class="location-exp-img">
            </div>
        </div>

        <!-- Right Side: Content -->
        <div class="location-exp-right">
            <h2 class="location-exp-title"><?php echo esc_html($exp_title); ?></h2>
            <p class="location-exp-desc"><?php echo esc_html($exp_desc); ?></p>
            
            <ul class="location-exp-list">
                <?php foreach($list_items as $item): ?>
                    <li>
                        <!-- Blue circle right arrow SVG -->
                        <span class="exp-list-icon">
                            <svg viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                <circle cx="12" cy="12" r="10"/>
                                <path d="M10 8l4 4-4 4" stroke="#ffffff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </span>
                        <?php echo esc_html($item); ?>
                    </li>
                <?php endforeach; ?>
            </ul>

            <div class="location-exp-btn-wrap">
                <a href="<?php echo esc_url($exp_btn_link); ?>" class="btn"><?php echo esc_html($exp_btn_text); ?><span class="screen-reader-text"> about <?php echo esc_html($exp_title); ?></span></a>
            </div>
        </div>
        
    </div>
</section>
