<?php
/**
 * Location About Section Template
 * Matches front page About structure but uses dynamic Native Custom Fields.
 */

// Fetch Native Custom Fields
$about_subtitle = get_post_meta(get_the_ID(), 'loc_about_subtitle', true);
$about_title    = get_post_meta(get_the_ID(), 'loc_about_title', true);
$about_desc     = get_post_meta(get_the_ID(), 'loc_about_desc', true);
$about_img_1    = get_post_meta(get_the_ID(), 'loc_about_img_1', true);
$about_img_2    = get_post_meta(get_the_ID(), 'loc_about_img_2', true);
$about_btn_text = get_post_meta(get_the_ID(), 'loc_about_btn_text', true);
$about_btn_link = get_post_meta(get_the_ID(), 'loc_about_btn_link', true);

// Feature Titles (Dynamic with Fallbacks)
$feat_1_title = get_post_meta(get_the_ID(), 'loc_feat_1_title', true);
$feat_2_title = get_post_meta(get_the_ID(), 'loc_feat_2_title', true);
$feat_3_title = get_post_meta(get_the_ID(), 'loc_feat_3_title', true);
$feat_4_title = get_post_meta(get_the_ID(), 'loc_feat_4_title', true);

// Fallbacks for main content
$about_subtitle = !empty($about_subtitle) ? $about_subtitle : 'About Us';
$about_title    = !empty($about_title) ? $about_title : 'Who We Are';
$about_desc     = !empty($about_desc) ? $about_desc : 'We deliver reliable, affordable, and professional cleaning services tailored to your specific location. We treat your property like our own, guaranteeing spotless results and complete satisfaction every time.';
$about_img_1    = !empty($about_img_1) ? $about_img_1 : get_template_directory_uri() . '/assets/images/about 1.webp';
$about_img_2    = !empty($about_img_2) ? $about_img_2 : get_template_directory_uri() . '/assets/images/about 2.webp';
$about_btn_text = !empty($about_btn_text) ? $about_btn_text : 'About Our Company';
$about_btn_link = !empty($about_btn_link) ? $about_btn_link : site_url('/about-us/');

// Fallbacks for feature titles
$feat_1_title = !empty($feat_1_title) ? $feat_1_title : 'Power Wash Spray';
$feat_2_title = !empty($feat_2_title) ? $feat_2_title : 'Advanced Machine';
$feat_3_title = !empty($feat_3_title) ? $feat_3_title : 'House Washing';
$feat_4_title = !empty($feat_4_title) ? $feat_4_title : 'Expert Worker';
?>

<section class="about-section">
    <div class="container about-grid">
        
        <!-- Left Side: Images with specific border-radius shapes -->
        <div class="about-left">
            <div class="about-images-container">
                <!-- Large Image (Shape 1) -->
                <div class="about-img-1">
                    <img src="<?php echo esc_url($about_img_1); ?>" alt="About large image" class="about-img">
                </div>
                
                <!-- Small Overlapping Image (Shape 2) -->
                <div class="about-img-2">
                    <img src="<?php echo esc_url($about_img_2); ?>" alt="About small image" class="about-img">
                </div>
                
                <!-- Overlapping Button (Like Call Button Position) -->
                <a href="<?php echo esc_url($about_btn_link); ?>" class="about-overlap-btn btn"><?php echo esc_html($about_btn_text); ?></a>
            </div>
        </div>

        <!-- Right Side: Content with opposite border-radius shape -->
        <div class="about-right">
            <div class="about-content">
                <span class="section-subtitle"><?php echo esc_html($about_subtitle); ?></span>
                <h2><?php echo esc_html($about_title); ?></h2>
                <p><?php echo esc_html($about_desc); ?></p>
            </div>
        </div>
        
    </div>

    <!-- Features Bottom Row (Using dynamic titles and custom SVGs) -->
    <div class="container">
        <div class="features-grid">
            <!-- Feature 1 -->
            <div class="feature-item">
                <div class="feature-icon-wrapper">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/loc-feat-gun.svg" alt="Feature 1">
                </div>
                <h3 class="feature-title"><?php echo esc_html($feat_1_title); ?></h3>
            </div>

            <!-- Feature 2 -->
            <div class="feature-item">
                <div class="feature-icon-wrapper">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/loc-feat-machine.svg" alt="Feature 2">
                </div>
                <h3 class="feature-title"><?php echo esc_html($feat_2_title); ?></h3>
            </div>

            <!-- Feature 3 -->
            <div class="feature-item">
                <div class="feature-icon-wrapper">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/loc-feat-house.svg" alt="Feature 3">
                </div>
                <h3 class="feature-title"><?php echo esc_html($feat_3_title); ?></h3>
            </div>

            <!-- Feature 4 -->
            <div class="feature-item">
                <div class="feature-icon-wrapper">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/loc-feat-worker.svg" alt="Feature 4">
                </div>
                <h3 class="feature-title"><?php echo esc_html($feat_4_title); ?></h3>
            </div>
        </div>
    </div>
</section>
