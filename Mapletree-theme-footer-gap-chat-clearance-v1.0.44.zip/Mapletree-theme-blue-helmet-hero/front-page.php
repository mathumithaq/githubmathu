<?php
/**
 * The front page template file
 */

get_header();
?>

    <main id="primary" class="site-main">
        <?php get_template_part('template-parts/sections/hero'); ?>
        <div class="section-divider"></div>
        <?php get_template_part('template-parts/sections/about'); ?>
        <?php get_template_part('template-parts/sections/services'); ?>
        <?php get_template_part('template-parts/sections/why-choose-us'); ?>
        <?php get_template_part('template-parts/sections/project-gallery'); ?>
        <?php get_template_part('template-parts/sections/how-it-works'); ?>
        <?php get_template_part('template-parts/sections/pricing'); ?>
        <?php get_template_part('template-parts/sections/service-areas'); ?>
        <?php get_template_part('template-parts/sections/faqs'); ?>
        <?php get_template_part('template-parts/sections/latest-blogs'); ?>
        <?php get_template_part('template-parts/sections/emergency-services'); ?>
        <?php get_template_part('template-parts/sections/contact'); ?>
    </main>

<?php
get_footer();

