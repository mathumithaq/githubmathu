<?php
/**
 * The header for our theme
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <?php
    $mm_theme_dir = get_template_directory();
    $mm_theme_uri = get_template_directory_uri();
    foreach (array('global', 'section') as $mm_sheet) {
        $mm_css_path = '/assets/css/' . $mm_sheet . '.min.css';
        if (!file_exists($mm_theme_dir . $mm_css_path)) {
            $mm_css_path = '/assets/css/' . $mm_sheet . '.css';
        }
        $mm_css_url = add_query_arg('ver', filemtime($mm_theme_dir . $mm_css_path), $mm_theme_uri . $mm_css_path);
        echo '<link rel="preload" as="style" href="' . esc_url($mm_css_url) . '">' . "\n";
    }
    ?>

    <!-- Preload critical heading font to prevent CLS from font-swap -->
    <link
        rel="preload"
        href="<?php echo get_template_directory_uri(); ?>/assets/fonts/montserrat-800.woff2"
        as="font"
        type="font/woff2"
        crossorigin
    >

    <!-- Preload LCP Hero Background & Image for PageSpeed LCP Optimization -->
    <?php if (is_front_page() || is_home()) : ?>
    <link rel="preload" href="<?php echo get_template_directory_uri(); ?>/assets/images/hero-arborist-orange-v2.webp" imagesrcset="<?php echo get_template_directory_uri(); ?>/assets/images/hero-arborist-orange-mobile.webp 480w, <?php echo get_template_directory_uri(); ?>/assets/images/hero-arborist-orange-v2.webp 920w" imagesizes="100vw" as="image" type="image/webp" fetchpriority="high">
    <?php endif; ?>
    <?php if (is_page(array('contact', 'about-us'))) : ?>
    <link rel="preload" href="<?php echo get_template_directory_uri(); ?>/assets/images/stump-bg.webp" as="image" type="image/webp" fetchpriority="high">
    <?php endif; ?>
    <?php if (is_page('blog')) : ?>
    <link rel="preload" href="<?php echo get_template_directory_uri(); ?>/assets/images/stump-bg.webp" as="image" type="image/webp" fetchpriority="high">
    <?php endif; ?>
    <!-- Critical Above-the-Fold CSS to prevent Flash of Unstyled Content (FOUC) -->
    <style>
        html, body { margin: 0; padding: 0; background: #173C25; }
        main { display: block; }
        .site-header {
            background: #BF360C !important;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-sizing: border-box;
            height: 110px;
            min-height: 110px;
            margin-top: -8px;
            margin-bottom: 8px;
        }
        .site-logo-img { max-width: 200px; height: auto; max-height: 50px; }
        .mobile-sidebar-logo-img { max-width: 155px; height: auto; max-height: 40px; }
        .menu-toggle { display: none; }
        .mobile-menu-header { display: none; }
        .mobile-menu-backdrop { display: none; }
        @media (max-width: 768px) {
            .site-header { height: 66px; min-height: 66px; margin-top: -8px; margin-bottom: 8px; }
            .menu-toggle { display: flex !important; }
            #primary-menu:not(.is-open) { display: none !important; }
        }
        /* Critical Hero Above-the-Fold Layout */
        .hero-section {
            position: relative;
            overflow: hidden;
            background-color: #173C25 !important;
            color: #ffffff;
            padding: calc(105px + 3.5rem) 0 4rem 0 !important;
            margin: 0 !important;
            margin-top: -105px !important;
            width: 100%;
            height: 800px;
            min-height: 800px;
            box-sizing: border-box;
        }
        .hero-bg-img {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
            object-position: center;
            z-index: 0;
            pointer-events: none;
        }
        .hero-bg-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, rgba(8, 10, 9, 0.72) 0%, rgba(8, 10, 9, 0.46) 52%, rgba(8, 10, 9, 0.20) 100%);
            -webkit-backdrop-filter: blur(3px) saturate(0.95);
            backdrop-filter: blur(3px) saturate(0.95);
            z-index: 1;
            pointer-events: none;
        }
        .hero-container {
            position: relative;
            z-index: 2;
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 3rem;
            align-items: center;
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            padding-left: var(--global-padding-x, 20px);
            padding-right: var(--global-padding-x, 20px);
            box-sizing: border-box;
        }
        .hero-content { max-width: 600px; }
        .hero-heading {
            color: #ffffff;
            font-size: 3.1rem;
            line-height: 1.1;
            margin-top: 0 !important;
            margin-bottom: 1.25rem;
            font-weight: var(--font-weight-extrabold);
        }
        .hero-subtext {
            font-size: 1.15rem;
            color: rgba(255, 255, 255, 0.9);
            margin-bottom: 1.5rem;
            line-height: 1.5;
            min-height: 4rem;
        }
        .trust-signals {
            display: flex;
            flex-wrap: wrap;
            gap: 0.75rem;
            align-content: flex-start;
        }
        .trust-item {
            min-height: 34px;
            box-sizing: border-box;
        }
        .hero-image-wrapper { aspect-ratio: 1000 / 746; contain: layout; }
        .hero-image { width: 100%; height: 100%; object-fit: cover; display: block; }
        .hero-actions {
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
        }
        .hero-actions > a {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            box-sizing: border-box;
            min-height: 56px;
        }
        .inner-hero-section,
        .sub-service-hero-section {
            position: relative;
            height: 620px;
            min-height: 620px;
            box-sizing: border-box;
            background-color: #173C25;
            padding-top: 140px !important;
        }
        .inner-hero-container {
            position: relative;
            z-index: 2;
            min-height: 360px;
            box-sizing: border-box;
        }
        .inner-hero-title {
            color: #ffffff;
            font-family: 'Montserrat', sans-serif;
            font-size: 3.5rem;
            line-height: 1.1;
            min-height: 77px;
            margin: 0 0 1.5rem;
        }
        .inner-hero-description {
            min-height: 62px;
            margin: 0 auto;
        }
        .sub-service-hero-section {
            display: flex;
            align-items: center;
            overflow: hidden;
            background-color: #315239;
            color: #ffffff;
        }
        .sub-service-hero-image {
            position: absolute;
            inset: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
            opacity: 0.15;
            z-index: 0;
        }
        .sub-service-hero-section .inner-hero-container {
            height: 100%;
            min-height: 0;
            display: flex;
            align-items: center;
            box-sizing: border-box;
        }
        .sub-service-hero-section .inner-hero-content-col {
            width: 100%;
            box-sizing: border-box;
        }
        .simple-toc-section {
            display: block;
            min-height: 220px;
            box-sizing: border-box;
            background-color: #f4effa;
        }
        .simple-toc-section .toc-container {
            min-height: 160px;
            box-sizing: border-box;
        }
        .inner-hero-wave { position: absolute; left: 0; right: 0; bottom: 0; height: 60px; overflow: hidden; }
        .inner-hero-wave svg { display: block; width: 100%; height: 60px; }
        @media (max-width: 992px) {
            .hero-container { display: flex; flex-direction: column; gap: 1.5rem; }
            .hero-section { padding: 140px 0 3.5rem 0 !important; margin-top: -95px !important; text-align: center; }
            .hero-content { display: contents; }
            .hero-heading { order: 1; font-size: 2.8rem; margin-bottom: 0.5rem; }
            .hero-subtext { order: 2; margin-bottom: 1rem; }
            .hero-image-wrapper { order: 3; max-width: 500px; width: 100%; padding-top: 1rem; padding-right: 1rem; margin: 1rem auto; }
            .trust-signals { order: 4; margin-bottom: 1rem; justify-content: center; }
            .hero-actions { order: 5; justify-content: center; }
            .hero-section { height: 980px; min-height: 980px; box-sizing: border-box; }
            .inner-hero-section,
            .sub-service-hero-section { height: 660px; min-height: 660px; }
        }
        @media (max-width: 768px) {
            .hero-section { padding: 160px 0 2.5rem 0 !important; margin-top: -105px !important; text-align: left !important; }
            .hero-heading { font-size: 2.2rem; text-align: left !important; }
            .hero-subtext { font-size: 1.05rem; text-align: left !important; }
            .trust-signals { justify-content: flex-start !important; align-items: flex-start !important; }
            .hero-actions { flex-direction: column; width: 100%; justify-content: flex-start !important; align-items: flex-start !important; }
            .hero-image-wrapper { padding: 0; margin: 1rem 0 0 0 !important; }
            .hero-section { height: auto; min-height: 780px; box-sizing: border-box; }
            .inner-hero-section,
            .sub-service-hero-section { height: auto; min-height: 520px; overflow: visible; padding-top: 160px !important; margin-top: -105px !important; }
        }
    </style>

    <style id="maple-mobile-hero-header">
/* Mobile hero header uses the solid brand colour from initial load. */
@media (max-width: 768px) {
  .site-header.has-page-hero {
    position: fixed !important;
    top: 0 !important;
    left: 0 !important;
    right: 0 !important;
    width: 100% !important;
    max-width: none !important;
    margin: 0 !important;
    border-radius: 0 !important;
  }
  .site-header.has-page-hero:not(.past-page-hero) {
    background: #BF360C !important;
    border: 0 !important;
    border-bottom: 1px solid rgba(255,255,255,.28) !important;
    box-shadow: none !important;
    animation: none !important;
  }
  .site-header.has-page-hero.past-page-hero {
    background: var(--color-brand-purple, #bf360c) !important;
  }
  body.admin-bar .site-header.has-page-hero { top: 46px !important; }
  .site-main > .hero-section:first-child {
    margin-top: 0 !important;
    padding-top: calc(66px + 2.5rem) !important;
  }
  .site-main > .inner-hero-section:first-child {
    margin-top: 0 !important;
    padding-top: calc(66px + 2.75rem) !important;
  }
  .site-main > .inner-hero-section.sub-service-hero-section:first-child {
    padding-top: calc(66px + 145px) !important;
  }
}

@media (max-width: 768px) {
  body.home .site-main > .hero-section:first-child,
  body.page-template-default .site-main > .hero-section:first-child { margin-top: 0 !important; }
}
</style>
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
    <?php wp_body_open(); ?>

    <!-- Include our Neumorphic Navigation Bar -->
    <style id="maple-solid-header">
/* Uniform solid orange header on all templates, before and after scrolling. */
body header.site-header,
body header.site-header.has-page-hero,
body header.site-header.has-page-hero:not(.past-page-hero),
body header.site-header.has-page-hero.past-page-hero,
body header.site-header.has-page-hero.sub-service-page-header:not(.past-page-hero),
body header.site-header.has-page-hero.sub-service-page-header.past-page-hero {
  background: #BF360C !important;
  background-image: none !important;
  opacity: 1 !important;
  backdrop-filter: none !important;
  -webkit-backdrop-filter: none !important;
}

/* Keep the reference orange header visible from the first paint on every page. */
header.site-header,
header.site-header.has-page-hero:not(.past-page-hero),
header.site-header.has-page-hero.past-page-hero {
  background: #BF360C !important;
  backdrop-filter: none !important;
  -webkit-backdrop-filter: none !important;
}
</style>
    <?php get_template_part('template-parts/header/nav'); ?>
