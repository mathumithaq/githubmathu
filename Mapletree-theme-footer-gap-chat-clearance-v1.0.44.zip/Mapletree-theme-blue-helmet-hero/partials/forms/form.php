<div class="lead-form-container" style="width: 100%; min-height: 550px; position: relative;">
    <iframe
        data-src="https://link.kdlead.com/widget/form/FBycuV6jiv0yhEDYH0AY"
        style="width: 100%; height: 750px; min-height: 550px; border: none; border-radius: 8px; display: block;"
        loading="lazy"
        id="inline-FBycuV6jiv0yhEDYH0AY"
        data-layout="{'id':'INLINE'}"
        data-trigger-type="alwaysShow"
        data-trigger-value=""
        data-activation-type="alwaysActivated"
        data-activation-value=""
        data-deactivation-type="neverDeactivate"
        data-deactivation-value=""
        data-form-name="Maple Majesty Tree Care Form"
        data-height="749"
        data-layout-iframe-id="inline-FBycuV6jiv0yhEDYH0AY"
        data-form-id="FBycuV6jiv0yhEDYH0AY"
        title="Maple Majesty Tree Care Form"
    >
    </iframe>
    <script>
    (function() {
        var iframe = document.getElementById('inline-FBycuV6jiv0yhEDYH0AY');
        if (!iframe) return;

        function loadForm() {
            if (iframe.src) return;
            iframe.src = iframe.dataset.src;
            var script = document.createElement('script');
            script.src = 'https://link.kdlead.com/js/form_embed.js';
            script.async = true;
            document.body.appendChild(script);
        }

        if ('IntersectionObserver' in window) {
            var observer = new IntersectionObserver(function(entries) {
                if (entries[0].isIntersecting) {
                    observer.disconnect();
                    loadForm();
                }
            }, { rootMargin: '0px' });
            observer.observe(iframe);
        } else {
            loadForm();
        }
    })();
    </script>
</div>
