<?php
/**
 * The template for displaying the footer
 */
?>
    <?php get_template_part('template-parts/footer/sitefooter'); ?>

    <!-- Back to Top Button -->
    <button id="back-to-top" aria-label="Back to Top">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
            <polyline points="18 15 12 9 6 15"></polyline>
        </svg>
    </button>

    <!-- Back to Top Direct Logic -->
    <script>
    (function() {
        var btn = document.getElementById('back-to-top');
        if (!btn) return;

        function handleScroll() {
            var scrollY = window.pageYOffset || document.documentElement.scrollTop || window.scrollY || 0;
            if (scrollY > 150) {
                btn.classList.add('show');
            } else {
                btn.classList.remove('show');
            }
        }

        window.addEventListener('scroll', handleScroll, { passive: true });
        window.addEventListener('DOMContentLoaded', handleScroll);
        handleScroll();

        btn.addEventListener('click', function(e) {
            e.preventDefault();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    })();
    </script>

    <!-- Start chat after the visitor interacts with the page. -->
    <script>
    (function () {
        var started = false;
        function startChat() {
            if (started) return;
            started = true;
            ['pointerdown', 'keydown', 'scroll', 'touchstart'].forEach(function (eventName) {
                window.removeEventListener(eventName, startChat);
            });
            var script = document.createElement('script');
            script.src = 'https://widgets.leadconnectorhq.com/loader.js';
            script.dataset.resourcesUrl = 'https://widgets.leadconnectorhq.com/chat-widget/loader.js';
            script.dataset.widgetId = '6a57db281d0acd9a8e993343';
            script.async = true;
            document.body.appendChild(script);
        }
        ['pointerdown', 'keydown', 'scroll', 'touchstart'].forEach(function (eventName) {
            window.addEventListener(eventName, startChat, { passive: true, once: true });
        });
    })();
    </script>

    <?php wp_footer(); ?>
</body>
</html>
