<?php
/**
 * Floating Interactive Chat Widget for Maple Majesty Tree Care
 */
$icon_path = get_template_directory() . '/assets/icons/';
?>

<!-- Floating Chat Trigger Button -->
<div class="maple-chat-widget" id="maple-chat-widget">
    <!-- Trigger Button -->
    <button class="chat-trigger-btn" id="chat-trigger-btn" aria-label="Open Tree Care Chat" aria-expanded="false">
        <span class="chat-icon-open">
            <?php echo file_exists($icon_path . 'chat.svg') ? file_get_contents($icon_path . 'chat.svg') : '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>'; ?>
        </span>
        <span class="chat-icon-close" style="display: none;">
            <?php echo file_exists($icon_path . 'close.svg') ? file_get_contents($icon_path . 'close.svg') : '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>'; ?>
        </span>
        <span class="chat-badge-dot"></span>
        <span class="chat-tooltip">Need Help? Chat with us!</span>
    </button>

    <!-- Chat Box Window -->
    <div class="chat-box-window" id="chat-box-window" role="dialog" aria-modal="true" aria-hidden="true">
        <!-- Chat Header -->
        <div class="chat-header">
            <div class="chat-header-info">
                <div class="chat-avatar-wrapper">
                    <span class="chat-avatar-icon">
                        <?php echo file_exists($icon_path . 'leaf.svg') ? file_get_contents($icon_path . 'leaf.svg') : '🍁'; ?>
                    </span>
                    <span class="chat-online-indicator"></span>
                </div>
                <div class="chat-header-text">
                    <h4 class="chat-title">Maple Majesty Tree Care</h4>
                    <p class="chat-status">🟢 Online • Buffalo, NY</p>
                </div>
            </div>
            <button class="chat-close-btn" id="chat-close-btn" aria-label="Close Chat">&times;</button>
        </div>

        <!-- Chat Body / Messages -->
        <div class="chat-body">
            <div class="chat-message-bubble arborist-msg">
                <div class="msg-author">Maple Majesty Arborist Team</div>
                <p>👋 Hello! Welcome to Maple Majesty Tree Care. How can we help protect and maintain your trees today?</p>
                <span class="msg-time">Just now</span>
            </div>

            <!-- Quick Action Prompts -->
            <div class="chat-quick-actions">
                <p class="quick-actions-label">Quick options to connect with us:</p>
                
                <a href="tel:+17164000763" class="chat-action-btn chat-action-call">
                    <span class="action-icon">
                        <?php echo file_exists($icon_path . 'phone-call.svg') ? file_get_contents($icon_path . 'phone-call.svg') : '📞'; ?>
                    </span>
                    <div class="action-text">
                        <strong>Call Now</strong>
                        <small>Speak with a certified arborist now</small>
                    </div>
                </a>

                <a href="<?php echo site_url('/contact/'); ?>" class="chat-action-btn chat-action-quote">
                    <span class="action-icon">
                        <?php echo file_exists($icon_path . 'step-quote.svg') ? file_get_contents($icon_path . 'step-quote.svg') : '📝'; ?>
                    </span>
                    <div class="action-text">
                        <strong>Request a Free Estimate</strong>
                        <small>Fast, upfront & no-obligation pricing</small>
                    </div>
                </a>

                <a href="<?php echo site_url('/emergency-tree/'); ?>" class="chat-action-btn chat-action-emergency">
                    <span class="action-icon">
                        <?php echo file_exists($icon_path . 'alert.svg') ? file_get_contents($icon_path . 'alert.svg') : '🚨'; ?>
                    </span>
                    <div class="action-text">
                        <strong>24/7 Emergency Service</strong>
                        <small>Hazardous storm or fallen tree response</small>
                    </div>
                </a>
            </div>
        </div>

        <!-- Chat Footer with Direct Message Link -->
        <div class="chat-footer">
            <a href="<?php echo site_url('/contact/'); ?>" class="chat-footer-cta">
                <span>Send us a direct message</span> &rarr;
            </a>
        </div>
    </div>
</div>
