<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Mapletree
 */

?>
<style>
    /* ==========================================================================
   CUSTOM FOOTER REDESIGN
   ========================================================================== */
    .custom-footer {
        padding-bottom: 0 !important;
        background-color: #a93808;
        /* Top section orange */
        color: #fff;
        font-family: inherit;
        padding-top: 40px;
    }

    .custom-footer p,
    .custom-footer a,
    .custom-footer span,
    .custom-footer h3 {
        color: #fff;
    }

    .custom-footer a {
        text-decoration: none;
        transition: opacity 0.3s ease;
    }

    .custom-footer a:hover {
        opacity: 0.8;
    }

    .custom-footer-grid {
        display: grid;
        grid-template-columns: 1.5fr 1fr 1fr 1fr 1.5fr;
        gap: 30px;
        padding-bottom: 40px;
    }

    .footer-logo-img {
        max-width: 200px;
        margin-bottom: 15px;
    }

    .footer-desc {
        font-size: 14px;
        line-height: 1.6;
    }

    .footer-heading {
        font-size: 16px;
        font-weight: bold;
        margin-bottom: 20px;
        text-transform: uppercase;
        position: relative;
        padding-bottom: 10px;
    }

    .footer-heading::after {
        content: '';
        position: absolute;
        left: 0;
        bottom: 0;
        width: 40px;
        height: 2px;
        background-color: #ffffff50;
    }

    .footer-list {
        list-style: none !important;
        padding: 0 !important;
        margin: 0 !important;
    }

    .footer-list li {
        margin-bottom: 12px;
    }

    .footer-list li a,
    .footer-list li span {
        font-size: 14px;
        color: #fff !important;
        text-decoration: none !important;
    }

    .view-all-areas {
        color: #ffffff !important;
        font-weight: bold;
        font-size: 14px;
        display: inline-block;
        margin-top: 15px;
    }

    .company-name {
        font-weight: bold;
        font-size: 16px;
        margin-bottom: 5px;
    }

    .company-address {
        font-size: 14px;
        line-height: 1.6;
        margin-bottom: 15px;
    }

    .company-phone {
        font-size: 14px;
        margin-bottom: 5px;
    }

    .company-phone a,
    .company-hours span {
        color: #ffffff !important;
        font-weight: bold;
    }

    .company-hours {
        font-size: 14px;
        margin-bottom: 15px;
    }

    .footer-map-container {
        position: relative;
        border-radius: 8px;
        overflow: hidden;
        height: 120px;
    }

    .map-overlay-btn {
        position: absolute;
        top: 10px;
        left: 10px;
        background: #fff;
        color: #000 !important;
        padding: 5px 10px;
        font-size: 12px;
        font-weight: bold;
        border-radius: 4px;
        display: flex;
        align-items: center;
        gap: 5px;
        z-index: 10;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
    }

    .map-overlay-btn svg {
        width: 14px;
        height: 14px;
        stroke: #000;
    }

    .custom-footer-trust-bar {
        background-color: #923202;
        padding: 15px 0;
    }

    .custom-footer-trust-items {
        display: flex;
        justify-content: center;
        align-items: center;
        flex-wrap: wrap;
        gap: 20px;
    }

    .custom-footer-trust-item {
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 14px;
        font-weight: bold;
        color: #fff;
        background: transparent !important;
        padding: 0 !important;
        border: none !important;
        box-shadow: none !important;
    }

    .custom-footer-trust-icon svg {
        width: 18px;
        height: 18px;
        fill: #fff;
        stroke: #fff;
    }

    .custom-footer-trust-dot {
        display: flex;
        align-items: center;
        color: #ffffff50;
        font-size: 12px;
    }

    .footer-bottom-bar {
        background-color: #652302;
        padding: 20px 0;
        font-size: 12px;
    }

    .bottom-bar-flex {
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 20px;
    }

    .bottom-left p {
        margin: 0;
    }

    .custom-footer .bottom-left a {
        color: #FDE047 !important;
        font-weight: 700;
    }

    .bottom-center {
        display: flex;
        align-items: center;
        gap: 10px;
        flex-wrap: wrap;
    }

    .bottom-center .sep {
        color: #ffffff50;
    }

    .bottom-right.payments {
        display: flex;
        gap: 10px;
        align-items: center;
    }

    .bottom-right.payments svg {
        height: 24px;
        width: auto;
    }

    @media (max-width: 1024px) {
        .custom-footer-grid {
            grid-template-columns: repeat(3, 1fr);
        }

        .bottom-bar-flex {
            flex-direction: column;
            text-align: center;
        }
    }

    @media (max-width: 768px) {
        .custom-footer-grid {
            grid-template-columns: repeat(2, 1fr);
        }

        .custom-footer-trust-items {
            gap: 10px;
            flex-direction: column;
            align-items: flex-start;
            justify-content: flex-start;
        }

        .custom-footer-trust-item {
            text-align: left;
        }

        .bottom-bar-flex {
            align-items: flex-start;
            text-align: left;
        }

        .bottom-center,
        .bottom-right.payments {
            justify-content: flex-start;
        }

        .custom-footer-trust-dot {
            display: none;
        }
    }

    @media (max-width: 480px) {
        .custom-footer-grid {
            grid-template-columns: 1fr;
        }
    }

@media (max-width: 768px) {
  footer.site-footer.custom-footer { padding-bottom: 0 !important; margin-bottom: 0 !important; min-height: 0 !important; }
  .custom-footer .mobile-footer-copyright { min-height: 52px !important; padding-top: 10px !important; padding-bottom: 10px !important; }
}
@media (max-width: 991px) {
  .mobile-sticky-bar { z-index: 2147483000 !important; }
}
</style>

<footer class="site-footer custom-footer">
    <!-- Top Footer Section (5 Columns) -->
    <div class="footer-top">
        <div class="footer-container custom-footer-grid">
            <!-- Column 1: Brand & Description -->
            <div class="footer-col brand-col">
                <a href="<?php echo esc_url(home_url('/')); ?>" class="footer-logo">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo.webp"
                        alt="Maple Majesty Tree Care Logo" class="footer-logo-img">
                </a>
                <p class="footer-desc">
                    Maple Majesty Tree Care delivers expert, ISA-certified tree removal, pruning, and emergency tree
                    services across Buffalo and Western New York. Fully insured and committed to total customer
                    satisfaction.
                </p>
            </div>

            <!-- Column 2: Our Services -->
            <div class="footer-col links-col">
                <h3 class="footer-heading">OUR SERVICES</h3>
                <ul class="footer-list">
                    <li><a href="<?php echo site_url('/tree-removal/'); ?>">Tree Removal</a></li>
                    <li><a href="<?php echo site_url('/tree-pruning/'); ?>">Tree Pruning</a></li>
                    <li><a href="<?php echo site_url('/tree-trimming/'); ?>">Tree Trimming</a></li>
                    <li><a href="<?php echo site_url('/stump-removal/'); ?>">Stump Removal</a></li>
                    <li><a href="<?php echo site_url('/stump-grinding/'); ?>">Stump Grinding</a></li>
                    <li><a href="<?php echo site_url('/arborist-service/'); ?>">Arborist Service</a></li>
                    <li><a href="<?php echo site_url('/tree-crown-reduction/'); ?>">Tree Crown Reduction</a></li>
                    <li><a href="<?php echo site_url('/land-brush-clearing/'); ?>">Land & Brush Clearing</a></li>
                    <li><a href="<?php echo site_url('/emergency-tree/'); ?>">Emergency Tree Service</a></li>
                </ul>
            </div>

            <!-- Column 3: Main Areas -->
            <div class="footer-col links-col">
                <h3 class="footer-heading">MAIN AREAS</h3>
                <ul class="footer-list">
                    <li><a href="<?php echo home_url('/#service-areas'); ?>">Buffalo</a></li>
                    <li><a href="<?php echo home_url('/#service-areas'); ?>">Amherst</a></li>
                    <li><a href="<?php echo home_url('/#service-areas'); ?>">Clarence</a></li>
                    <li><a href="<?php echo home_url('/#service-areas'); ?>">Tonawanda</a></li>
                    <li><a href="<?php echo home_url('/#service-areas'); ?>">Cheektowaga</a></li>
                    <li><a href="<?php echo home_url('/#service-areas'); ?>">Lockport</a></li>
                </ul>
                <a href="<?php echo home_url('/#service-areas'); ?>" class="view-all-areas">View All Service Areas &rarr;</a>
            </div>

            <!-- Column 4: Company -->
            <div class="footer-col links-col">
                <h3 class="footer-heading">COMPANY</h3>
                <ul class="footer-list">
                    <li><a href="<?php echo site_url('/about-us/'); ?>">About Us</a></li>
                    <li><a href="<?php echo site_url('/blog/'); ?>">Blogs & News</a></li>
                    <li><a href="<?php echo site_url('/contact/'); ?>">Contact Us</a></li>
                    <li><a href="#">Find Us On Web</a></li>
                </ul>
            </div>

            <!-- Column 5: Contact Info -->
            <div class="footer-col contact-col">
                <h3 class="footer-heading">CONTACT INFO</h3>
                <div class="footer-contact-details">
                    <p class="company-name">MAPLE MAJESTY TREE CARE</p>
                    <p class="company-address"><a href="https://maps.app.goo.gl/hFNjfQ1Nd3BXyw5u5" target="_blank" rel="noopener noreferrer" aria-label="View Maple Majesty Tree Care on Google Maps">19 EUCLID PL, BUFFALO,<br>NY 14210, UNITED STATES</a></p>
                    <p class="company-phone">Phone: <a href="tel:+17164000763">(716) 400-0763</a></p>
                    <p class="company-hours">Hours: <span>Open 24/7</span></p>
                </div>

                <div class="footer-map-container">
                    <a href="https://www.google.com/maps/place/Maple+Majesty+Tree+Care/@42.8673026,-78.8484952,17z/data=!3m1!4b1!4m6!3m5!1s0x89d313b51997ac31:0x4b51265ea9899a04!8m2!3d42.8673026!4d-78.8484952!16s%2Fg%2F11wsp0b0_f"
                        target="_blank" class="map-overlay-btn">
                        Maps
                        <?php echo file_exists(get_template_directory() . '/assets/icons/external-link.svg') ? file_get_contents(get_template_directory() . '/assets/icons/external-link.svg') : ''; ?>
                    </a>
                    <iframe title="Google Maps Location"
                        src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d17817.93873640658!2d-78.8469841!3d42.8734893!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89d313b51997ac31%3A0x4b51265ea9899a04!2sMaple%20Majesty%20Tree%20Care!5e1!3m2!1sen!2slk!4v1787951035609!5m2!1sen!2slk"
                        width="100%" height="120" style="border:0;" allowfullscreen="" loading="lazy"
                        referrerpolicy="strict-origin-when-cross-origin"></iframe>
                </div>
            </div>
        </div>
    </div>

    <!-- Middle Trust Bar -->
    <div class="custom-footer-trust-bar">
        <div class="footer-container custom-footer-trust-items">
            <div class="custom-footer-trust-item">
                <span
                    class="custom-footer-trust-icon"><?php echo file_exists(get_template_directory() . '/assets/icons/clock.svg') ? file_get_contents(get_template_directory() . '/assets/icons/clock.svg') : ''; ?></span>
                <span class="trust-text" style="color: #fff !important;">Open 24/7</span>
            </div>
            <span class="custom-footer-trust-dot"><svg width="4" height="4" viewBox="0 0 4 4">
                    <circle cx="2" cy="2" r="2" fill="#ffffff50" />
                </svg></span>
            <div class="custom-footer-trust-item">
                <span
                    class="custom-footer-trust-icon"><?php echo file_exists(get_template_directory() . '/assets/icons/badge.svg') ? file_get_contents(get_template_directory() . '/assets/icons/badge.svg') : ''; ?></span>
                <span class="trust-text" style="color: #fff !important;">ISA-Certified Arborists</span>
            </div>
            <span class="custom-footer-trust-dot"><svg width="4" height="4" viewBox="0 0 4 4">
                    <circle cx="2" cy="2" r="2" fill="#ffffff50" />
                </svg></span>
            <div class="custom-footer-trust-item">
                <span
                    class="custom-footer-trust-icon"><?php echo file_exists(get_template_directory() . '/assets/icons/check.svg') ? file_get_contents(get_template_directory() . '/assets/icons/check.svg') : ''; ?></span>
                <span class="trust-text" style="color: #fff !important;">Licensed & Insured</span>
            </div>
            <span class="custom-footer-trust-dot"><svg width="4" height="4" viewBox="0 0 4 4">
                    <circle cx="2" cy="2" r="2" fill="#ffffff50" />
                </svg></span>
            <div class="custom-footer-trust-item">
                <span
                    class="custom-footer-trust-icon"><?php echo file_exists(get_template_directory() . '/assets/icons/siren.svg') ? file_get_contents(get_template_directory() . '/assets/icons/siren.svg') : ''; ?></span>
                <span class="trust-text" style="color: #fff !important;">24/7 Emergency Service</span>
            </div>
            <span class="custom-footer-trust-dot"><svg width="4" height="4" viewBox="0 0 4 4">
                    <circle cx="2" cy="2" r="2" fill="#ffffff50" />
                </svg></span>
            <div class="custom-footer-trust-item">
                <span
                    class="custom-footer-trust-icon"><?php echo file_exists(get_template_directory() . '/assets/icons/leaf-solid.svg') ? file_get_contents(get_template_directory() . '/assets/icons/leaf-solid.svg') : ''; ?></span>
                <span class="trust-text" style="color: #fff !important;">Local Buffalo Experts</span>
            </div>
        </div>
    </div>

    <!-- Bottom Copyright Bar -->
    <div class="footer-bottom-bar">
        <div class="footer-container bottom-bar-flex">
            <div class="bottom-left">
                <p>&copy; <?php echo date('Y'); ?> <a href="<?php echo esc_url(home_url('/')); ?>">MAPLE MAJESTY TREE CARE</a> | ALL RIGHTS RESERVED</p>
            </div>
            <div class="bottom-center">
                <a href="tel:+17164000763">(716) 400-0763</a>
                <span class="sep">|</span>
                <a href="<?php echo esc_url(site_url('/terms-and-conditions/')); ?>">TERMS & CONDITIONS</a>
                <span class="sep">|</span>
                <a href="<?php echo esc_url(site_url('/privacy-policy/')); ?>">PRIVACY POLICY</a>
                <span class="sep">|</span>
                <a href="<?php echo esc_url(site_url('/sitemap/')); ?>">SITEMAP</a>
            </div>
            <div class="bottom-right payments">
                <?php echo file_exists(get_template_directory() . '/assets/icons/visa.svg') ? file_get_contents(get_template_directory() . '/assets/icons/visa.svg') : ''; ?>
                <?php echo file_exists(get_template_directory() . '/assets/icons/mc.svg') ? file_get_contents(get_template_directory() . '/assets/icons/mc.svg') : ''; ?>
                <?php echo file_exists(get_template_directory() . '/assets/icons/amex.svg') ? file_get_contents(get_template_directory() . '/assets/icons/amex.svg') : ''; ?>
                <?php echo file_exists(get_template_directory() . '/assets/icons/disc.svg') ? file_get_contents(get_template_directory() . '/assets/icons/disc.svg') : ''; ?>
            </div>
        </div>
    </div>
    <div class="mobile-footer-copyright">
        <p>&copy; <?php echo date('Y'); ?> <a href="<?php echo esc_url(home_url('/')); ?>">MAPLE MAJESTY TREE CARE</a> | ALL RIGHTS RESERVED</p>
    </div>
</footer>

<a class="desktop-floating-call<?php echo is_front_page() ? ' waits-for-hero' : ''; ?>" href="tel:+17164000763" aria-label="Call Maple Majesty Tree Care at (716) 400-0763">
    <?php echo file_exists(get_template_directory() . '/assets/icons/phone-call.svg') ? file_get_contents(get_template_directory() . '/assets/icons/phone-call.svg') : ''; ?>
</a>
<script>
(function () {
    var call = document.querySelector('.desktop-floating-call.waits-for-hero');
    var hero = document.querySelector('.hero-section');
    if (!call) return;
    if (!hero) { call.classList.remove('waits-for-hero'); return; }
    function update() {
        call.classList.toggle('waits-for-hero', hero.getBoundingClientRect().bottom > 0);
    }
    if ('IntersectionObserver' in window) {
        new IntersectionObserver(function () { update(); }, { threshold: 0 }).observe(hero);
    }
    window.addEventListener('scroll', update, { passive: true });
    update();
})();
</script>

<div class="mobile-sticky-bar">
    <a href="tel:+17164000763" class="sticky-btn sticky-call">
        <div class="icon-svg">
            <?php echo file_exists(get_template_directory() . '/assets/icons/phone-call.svg') ? file_get_contents(get_template_directory() . '/assets/icons/phone-call.svg') : ''; ?>
        </div>
        Call Now
    </a>
    <a href="<?php echo site_url('/contact/'); ?>" class="sticky-btn sticky-quote">
        <div class="icon-svg">
            <?php echo file_exists(get_template_directory() . '/assets/icons/message.svg') ? file_get_contents(get_template_directory() . '/assets/icons/message.svg') : ''; ?>
        </div>
        Get Quote
    </a>
</div>
