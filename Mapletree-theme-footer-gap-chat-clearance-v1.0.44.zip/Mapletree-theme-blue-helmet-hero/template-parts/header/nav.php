<?php
// Determine active states
$is_home = is_front_page() || (is_home() && !is_page('blog'));
$services_pages = array('services', 'emergency-tree', 'land-brush-clearing', 'tree-removal', 'tree-trimming', 'tree-pruning', 'stump-grinding', 'stump-removal', 'tree-crown-reduction', 'arborist-service');
$is_services = is_page($services_pages);
$is_about = is_page('about-us');
$is_blog = is_page('blog') || is_home() || is_singular('post') || is_category() || is_archive();
// Ensure blog isn't highlighted on home if home is blog (though usually it's separate)
if (is_front_page()) {
    $is_blog = false;
}
$is_contact = is_page('contact');
?>
<header class="site-header<?php echo (is_front_page() || is_page()) ? ' has-page-hero' : ''; ?><?php echo is_page_template('templates/template-sub-service.php') ? ' sub-service-page-header' : ''; ?>">
  <!-- Left: Logo -->
  <a href="<?php echo esc_url(home_url('/')); ?>" class="site-logo">
    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo.webp" alt="Maple Majesty Logo" class="site-logo-img" width="200" height="56" fetchpriority="high" decoding="async">
  </a>

  <!-- Mobile Toggle Button -->
  <button type="button" class="menu-toggle" aria-controls="primary-menu" aria-expanded="false" aria-label="Toggle navigation">
    <span class="icon-menu" style="display: flex;"><?php echo file_get_contents(get_template_directory() . '/assets/icons/menu.svg'); ?></span>
    <span class="icon-close" style="display: none;"><?php echo file_get_contents(get_template_directory() . '/assets/icons/close.svg'); ?></span>
  </button>

  <!-- Mobile Menu Backdrop Overlay -->
  <div class="mobile-menu-backdrop" id="mobile-menu-backdrop" aria-hidden="true"></div>

  <!-- Right: Glowing Nav Links / Mobile Sidebar Drawer -->
  <nav id="primary-menu" aria-label="Main Navigation">
    <div class="mobile-menu-header">
      <a href="<?php echo esc_url(home_url('/')); ?>" class="mobile-sidebar-logo" aria-label="Maple Majesty Home">
        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo.webp" alt="Maple Majesty Logo" class="mobile-sidebar-logo-img" width="155" height="44" decoding="async">
      </a>
      <button type="button" class="mobile-close-btn" aria-label="Close menu">&times;</button>
    </div>
    <ul class="icon-nav">
      <li>
        <a href="<?php echo home_url('/'); ?>" class="nav-item">
          <div class="nav-icon-btn <?php echo $is_home ? 'active' : ''; ?>">
            <?php echo file_get_contents(get_template_directory() . '/assets/icons/home.svg'); ?>
          </div>
          <span class="nav-text">Home</span>
        </a>
      </li>
      <li class="has-dropdown">
        <button type="button" class="nav-item dropdown-toggle-btn" aria-expanded="false" style="cursor: default;">
          <div class="nav-icon-btn <?php echo $is_services ? 'active' : ''; ?>">
            <?php echo file_get_contents(get_template_directory() . '/assets/icons/services.svg'); ?>
          </div>
          <div class="nav-text-row">
            <span class="nav-text">SERVICES</span>
            <span class="dropdown-chevron">
              <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
            </span>
          </div>
        </button>
        <!-- Mega Menu for Services -->
        <div class="mega-menu">
            <ul class="mega-menu-list">
                <li><a href="<?php echo site_url('/tree-removal/'); ?>" class="<?php echo is_page('tree-removal') ? 'active-sub-link' : ''; ?>">Tree Removal</a></li>
                <li><a href="<?php echo site_url('/tree-pruning/'); ?>" class="<?php echo is_page('tree-pruning') ? 'active-sub-link' : ''; ?>">Tree Pruning</a></li>
                <li><a href="<?php echo site_url('/tree-trimming/'); ?>" class="<?php echo is_page('tree-trimming') ? 'active-sub-link' : ''; ?>">Tree Trimming</a></li>
                <li><a href="<?php echo site_url('/stump-removal/'); ?>" class="<?php echo is_page('stump-removal') ? 'active-sub-link' : ''; ?>">Stump Removal</a></li>
                <li><a href="<?php echo site_url('/stump-grinding/'); ?>" class="<?php echo is_page('stump-grinding') ? 'active-sub-link' : ''; ?>">Stump Grinding</a></li>
                <li><a href="<?php echo site_url('/arborist-service/'); ?>" class="<?php echo is_page('arborist-service') ? 'active-sub-link' : ''; ?>">Arborist Service</a></li>
                <li><a href="<?php echo site_url('/tree-crown-reduction/'); ?>" class="<?php echo is_page('tree-crown-reduction') ? 'active-sub-link' : ''; ?>">Tree Crown Reduction</a></li>
                <li><a href="<?php echo site_url('/land-brush-clearing/'); ?>" class="<?php echo is_page('land-brush-clearing') ? 'active-sub-link' : ''; ?>">Land & Brush Clearing</a></li>
                <li><a href="<?php echo site_url('/emergency-tree/'); ?>" class="<?php echo is_page('emergency-tree') ? 'active-sub-link' : ''; ?>">Emergency Tree Service</a></li>
            </ul>
        </div>
      </li>
      <li>
        <a href="<?php echo site_url('/about-us/'); ?>" class="nav-item">
          <div class="nav-icon-btn <?php echo $is_about ? 'active' : ''; ?>">
            <?php echo file_get_contents(get_template_directory() . '/assets/icons/about.svg'); ?>
          </div>
          <span class="nav-text">About Us</span>
        </a>
      </li>
      <li>
        <a href="<?php echo site_url('/blog/'); ?>" class="nav-item">
          <div class="nav-icon-btn <?php echo $is_blog ? 'active' : ''; ?>">
            <?php echo file_get_contents(get_template_directory() . '/assets/icons/blogs.svg'); ?>
          </div>
          <span class="nav-text">Blogs</span>
        </a>
      </li>
      <li>
        <a href="<?php echo site_url('/contact/'); ?>" class="nav-item">
          <div class="nav-icon-btn <?php echo $is_contact ? 'active' : ''; ?>">
            <?php echo file_get_contents(get_template_directory() . '/assets/icons/contact.svg'); ?>
          </div>
          <span class="nav-text">Contact Us</span>
        </a>
      </li>
    </ul>
  </nav>
</header>
