<?php
/**
 * Template Part: Tree Removal Sub-Service Page Content (Buffalo, NY)
 * Contains 100% verbatim content for all sections requested by the user.
 */

// Helper to safely render inline SVGs
if (!function_exists('tr_render_svg')) {
    function tr_render_svg($filename, $fallback = '') {
        $path = get_template_directory() . '/assets/icons/' . $filename;
        if (file_exists($path)) {
            return file_get_contents($path);
        }
        return $fallback;
    }
}
?>


<!-- =========================================================================
     SECTION 1: TREE REMOVAL IN BUFFALO, NY & PROFESSIONAL OVERVIEW
     ========================================================================= -->
<section class="tr-content-section">
    <div class="tr-container">
        <div class="tr-content-col">
            <span class="global-subtitle">
                BUFFALO TREE REMOVAL
            </span>
            <h2 class="global-section-title">Tree Removal in Buffalo, NY</h2>
            <div class="section-divider"></div>

            <!-- Key Takeaway Box -->
            <div class="tr-takeaway-box">
                <div class="tr-takeaway-icon">
                    <?php echo tr_render_svg('info-circle.svg', 'ℹ️'); ?>
                </div>
                <p class="tr-takeaway-text">
                Tree removal is appropriate when a tree is dead, structurally unsafe, severely damaged, or cannot be safely preserved through pruning or other treatments.
                </p>
            </div>

            <h3 style="font-size: 1.6rem; color: var(--color-brand-purple); margin-top: 2rem; margin-bottom: 1.25rem;">Professional Tree Removal Overview</h3>
            <p>Tree removal is the safe, proper and legal removal of a tree that has become hazardous, unhealthy, damaged or unsuitable due to its location. We have highly trained arborists, state-of-the-art equipment, and meticulous removal techniques to ensure the safe and efficient removal of the tree. At Maple Majesty Tree Care, we provide professional tree removal in Buffalo City using experienced arborists, specialized equipment, and carefully planned removal methods.</p>
            
            <p>Tree removal Buffalo New York services are hired by many homeowners when they notice their trees are becoming unhealthy, being damaged by storms, suffering disease or have structural issues. The early removal of an unsafe tree can prevent property damage and reduce safety risks.</p>
            
            <p>Our ISA-Certified Arborists assess the tree, the surrounding area, and then decide on the best course of action for removing the tree. Various methods of removal, such as sectional, climbing techniques, bucket trucks, cranes, and advanced rigging systems, are used depending on the situation.</p>
            
            <p>The removal of large trees close to homes, driveways, fences, and utility areas is particularly crucial. If you're not trained to do it, it can be dangerous to attempt a DIY removal. Predicting the weight of a tree, the manner in which the branches move, and the direction in which the tree falls is difficult.</p>
        </div>
    </div>
</section>

<!-- =========================================================================
     SECTION 2: HOW IT WORKS
     ========================================================================= -->
<section class="tr-how-it-works-section" style="padding: 5rem 0;">
    <div class="tr-container">
        <div class="text-center" style="max-width: 850px; margin: 0 auto 3rem auto;">
            <span class="global-subtitle">
                SIMPLE & RELIABLE PROCESS
            </span>
            <h2 class="global-section-title">How It Works</h2>
            <div class="section-divider" style="margin: 1rem auto 1.5rem auto;"></div>
            <p style="font-size: 1.15rem; color: var(--color-text-gray); line-height: 1.7;">
                We start with a tree risk assessment on your property to determine the best way to remove the tree. We develop a removal plan, then remove the tree with professional equipment and clean up following the job.
            </p>
        </div>

        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 2rem;">
            <!-- Step 1 -->
            <div style="background: var(--color-white); padding: 2.5rem 2rem; border-radius: 16px; box-shadow: 0 8px 25px rgba(0,0,0,0.04); border-top: 4px solid var(--color-brand-purple); text-align: center;">
                <h3 style="font-size: 1.3rem; color: var(--color-brand-purple); margin-bottom: 0.75rem;">Request a Free Quote</h3>
                <p style="font-size: 1.05rem; color: var(--color-text-gray); margin: 0; line-height: 1.6;">Call or fill out our online form in minutes</p>
            </div>

            <!-- Step 2 -->
            <div style="background: var(--color-white); padding: 2.5rem 2rem; border-radius: 16px; box-shadow: 0 8px 25px rgba(0,0,0,0.04); border-top: 4px solid var(--color-warm-gold); text-align: center;">
                <h3 style="font-size: 1.3rem; color: var(--color-brand-purple); margin-bottom: 0.75rem;">Schedule Your Service</h3>
                <p style="font-size: 1.05rem; color: var(--color-text-gray); margin: 0; line-height: 1.6;">Pick a date that works for you — same-day available</p>
            </div>

            <!-- Step 3 -->
            <div style="background: var(--color-white); padding: 2.5rem 2rem; border-radius: 16px; box-shadow: 0 8px 25px rgba(0,0,0,0.04); border-top: 4px solid var(--color-brand-purple); text-align: center;">
                <h3 style="font-size: 1.3rem; color: var(--color-brand-purple); margin-bottom: 0.75rem;">ISA-Certified Arborists Arrive</h3>
                <p style="font-size: 1.05rem; color: var(--color-text-gray); margin: 0; line-height: 1.6;">Our pros handle everything — safely and efficiently</p>
            </div>

            <!-- Step 4 -->
            <div style="background: var(--color-white); padding: 2.5rem 2rem; border-radius: 16px; box-shadow: 0 8px 25px rgba(0,0,0,0.04); border-top: 4px solid var(--color-forest-green); text-align: center;">
                <h3 style="font-size: 1.3rem; color: var(--color-brand-purple); margin-bottom: 0.75rem;">Enjoy Your Clean Property</h3>
                <p style="font-size: 1.05rem; color: var(--color-text-gray); margin: 0; line-height: 1.6;">100% satisfaction guaranteed, every time</p>
            </div>
        </div>
    </div>
</section>

<!-- =========================================================================
     SECTION 3: WHEN REMOVAL IS NECESSARY
     ========================================================================= -->
<section class="tr-necessary-section">
    <div class="tr-necessary-container">
        <div class="tr-necessary-header">
            <span class="global-subtitle">
                SAFETY FIRST
            </span>
            <h2 class="global-section-title">When Removal Is Necessary</h2>
            <div class="section-divider"></div>

            <div class="tr-takeaway-box" style="margin-top: 1.5rem; margin-bottom: 2.5rem;">
                <div class="tr-takeaway-icon">
                    <?php echo tr_render_svg('info-circle.svg', 'ℹ️'); ?>
                </div>
                <p class="tr-takeaway-text">
                 Removal is generally considered when a tree creates an unacceptable safety risk, has severe structural or root damage, or conflicts with buildings, utilities, or planned property improvements.
                </p>
            </div>
        </div>

        <div class="tr-necessary-content">
            <h3 style="font-size: 1.5rem; color: var(--color-brand-purple); margin-bottom: 1rem;">When Should You Consider Tree Removal?</h3>
            <p>Sometimes trees need to be removed because they are unsafe, unhealthy, or if they pose a serious threat to property. Some common circumstances are:</p>
            
            <ul class="tr-necessary-list" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 1.5rem; list-style: none; padding: 0;">
                <li style="display: flex; align-items: center; background: var(--color-soft-lilac); padding: 1.25rem 1.5rem; border-radius: 12px; border-left: 4px solid var(--color-brand-purple); font-size: 1.05rem; color: var(--color-text-gray); line-height: 1.6;">
                    <div>Trees that have been severely storm-damaged or have broken trunks.</div>
                </li>
                <li style="display: flex; align-items: center; background: var(--color-soft-lilac); padding: 1.25rem 1.5rem; border-radius: 12px; border-left: 4px solid var(--color-brand-purple); font-size: 1.05rem; color: var(--color-text-gray); line-height: 1.6;">
                    <div>Large dead branches pose an impact risk to people.</div>
                </li>
                <li style="display: flex; align-items: center; background: var(--color-soft-lilac); padding: 1.25rem 1.5rem; border-radius: 12px; border-left: 4px solid var(--color-brand-purple); font-size: 1.05rem; color: var(--color-text-gray); line-height: 1.6;">
                    <div>Diseased or heavily decayed trees</div>
                </li>
                <li style="display: flex; align-items: center; background: var(--color-soft-lilac); padding: 1.25rem 1.5rem; border-radius: 12px; border-left: 4px solid var(--color-brand-purple); font-size: 1.05rem; color: var(--color-text-gray); line-height: 1.6;">
                    <div>Trees that are leaning and have weak root systems.</div>
                </li>
                <li style="display: flex; align-items: center; background: var(--color-soft-lilac); padding: 1.25rem 1.5rem; border-radius: 12px; border-left: 4px solid var(--color-brand-purple); font-size: 1.05rem; color: var(--color-text-gray); line-height: 1.6;">
                    <div>Trees that are too close to buildings or utility lines</div>
                </li>
                <li style="display: flex; align-items: center; background: var(--color-soft-lilac); padding: 1.25rem 1.5rem; border-radius: 12px; border-left: 4px solid var(--color-brand-purple); font-size: 1.05rem; color: var(--color-text-gray); line-height: 1.6;">
                    <div>Trees with roots that damage foundations, sidewalks or driveways.</div>
                </li>
            </ul>

            <p style="margin-top: 2rem;">Tree problems can be aggravated by the variability in weather conditions in Buffalo. Extreme weather conditions, such as heavy snow loads, freezing temperatures and strong winds, can make already weakened trees more susceptible to failure.</p>
            <p>Sometimes, by removing the dangerous tree at the right time, you can save yourself from expensive emergency repairs, and save your family, your customers and your property.</p>
        </div>
    </div>
</section>

<!-- =========================================================================
     SECTION 4: WHY LOCAL EXPERTISE MATTERS
     ========================================================================= -->
<section class="tr-expertise-section" style="padding: 5rem 0;">
    <div class="tr-expertise-container">
        <div class="tr-expertise-content">
            <span class="global-subtitle">
                WESTERN NY SPECIALISTS
            </span>
            <h2 class="global-section-title">Why Local Expertise Matters</h2>
            <div class="section-divider"></div>

            <h3 style="font-size: 1.5rem; color: var(--color-brand-purple); margin: 1.5rem 0 1rem;">Why Local Expertise Matters for Tree Removal in Buffalo</h3>
            <p>Buffalo trees must deal with different environmental conditions at various times of the year, including: lake effect snow, ice storms, strong winds, and seasonal temperature fluctuations. The regional knowledge possessed by arborists enables them to understand the common tree species, hazards to look out for and conditions found in the property.</p>

            <p>Before cutting down a tree, a professional tree service in Buffalo considers the health of the tree, its surroundings, weather conditions, and soil conditions. This local decision-making process will help you to make a safer decision and better protect your landscape.</p>
        </div>
    </div>
</section>

<!-- =========================================================================
     SECTION 5: WHAT'S INCLUDED IN OUR TREE REMOVAL SERVICE
     ========================================================================= -->
<section class="tr-included-section">
    <div class="tr-included-container">
        <div class="tr-included-header">
            <span class="global-subtitle">
                FULL SERVICE
            </span>
            <h2 class="global-section-title">What's Included in Tree Removal Service</h2>
            <div class="section-divider" style="margin: 1rem auto 1.5rem auto;"></div>
            <p class="tr-included-intro">We offer full tree removal service with the following:</p>
        </div>

        <div class="tr-included-grid">
            <div class="tr-included-card">
                <p>Risk assessment and removal plans for trees</p>
            </div>
            <div class="tr-included-card">
                <p>Identifies safe cutting and dismantling techniques.</p>
            </div>
            <div class="tr-included-card">
                <p>Professional climbing and rigging techniques</p>
            </div>
            <div class="tr-included-card">
                <p>Set up and prepare equipment for safety.</p>
            </div>
            <div class="tr-included-card">
                <p>Branch and trunk removal</p>
            </div>
            <div class="tr-included-card">
                <p>Property protection during removal</p>
            </div>
            <div class="tr-included-card">
                <p>Basic cleanup of wood debris and branches</p>
            </div>
            <div class="tr-included-card">
                <p>Optional stump removal and stump grinding services</p>
            </div>
        </div>

        <div class="tr-included-footer">
            <p>Each removal project is tailored to the size, location, condition and accessibility of the trees to be removed.</p>
        </div>
    </div>
</section>

<!-- =========================================================================
     SECTION 6: OUR TREE REMOVAL SERVICES IN BUFFALO, NY
     ========================================================================= -->
<section class="tr-services-section">
    <div class="tr-services-container">
        <div class="text-center" style="max-width: 850px; margin: 0 auto 3rem auto;">
            <span class="global-subtitle">
                COMPREHENSIVE SOLUTIONS
            </span>
            <h2 class="global-section-title">Our Tree Removal Services in Buffalo, NY</h2>
            <div class="section-divider" style="margin: 1rem auto 1.5rem auto;"></div>
            <p style="font-size: 1.15rem; color: var(--color-text-gray); line-height: 1.7;">
                Maple Majesty Tree Care offers residential Tree Removal Buffalo NY, commercial, and emergency solutions. Each removal project starts with a professional evaluation that will identify the safest way to remove the tree based on the condition, size, location and the surrounding dangers.
            </p>
        </div>

        <div class="tr-services-grid">
            <!-- 1. Residential -->
            <div class="tr-services-card">
                <div class="tr-services-content">
                    <h3>Residential Tree Removal Buffalo NY</h3>
                    <p>Some of the most common reasons for homeowners to require residential tree removal Buffalo NY services are when trees become unsafe, overgrown, damaged, or hard to care for. Our arborists meticulously prune unwanted trees with attention to the safety of your home, landscaping, fences and outdoor environment. Whether it's a shade tree, property damage, or safety concerns, we offer a controlled removal process for residential areas.</p>
                </div>
            </div>

            <!-- 2. Emergency -->
            <div class="tr-services-card">
                <div class="tr-services-content">
                    <h3>Emergency Tree Removal Buffalo NY</h3>
                    <p>Sudden tree failures can be caused by storms, high winds, heavy snow or ice accumulation. Our emergency tree removal Buffalo NY service rushes to the home to quickly resolve falling trees, broken limbs, and hazardous leaning trees. We assess immediate hazards, secure the area, and safely remove hazardous trees that pose a threat to homes, vehicles, driveways and other structures.</p>
                </div>
            </div>

            <!-- 3. Dead & Diseased -->
            <div class="tr-services-card">
                <div class="tr-services-content">
                    <h3>Dead & Diseased Tree Removal Buffalo NY</h3>
                    <p>Over time, dead or diseased trees can deteriorate and pose a hazard to others. Trees that are dead, dying, or infested with decay, fungus, insects, or other serious conditions are removed as part of our dead & diseased tree removal Buffalo NY services. Tree care prevents the spread of disease to other trees, buildings and people, and enhances landscape safety.</p>
                </div>
            </div>

            <!-- 4. Hazardous -->
            <div class="tr-services-card">
                <div class="tr-services-content">
                    <h3>Hazardous Trees Removal Buffalo NY</h3>
                    <p>Even though a tree looks stable, it could have underlying problems like root failure, internal decay, cracks, or structural weakness. Our hazardous tree removal Buffalo NY services are dedicated to identifying and safely removing trees that pose a potential risk. Before deciding on the safest approach to tree removal, our arborists employ professional methods of tree evaluation.</p>
                </div>
            </div>

            <!-- 5. Large Tree -->
            <div class="tr-services-card">
                <div class="tr-services-content">
                    <h3>Large Tree Removal Buffalo NY</h3>
                    <p>Specialized knowledge, equipment, and planning are required for large trees. For large trees near buildings, roads, and landscaped areas, we have large tree removal Buffalo NY services. With professional rigging systems, bucket trucks, and advanced tree removal methods, our crew ensures safe complex tree removals with minimal impact on your property.</p>
                </div>
            </div>

            <!-- 6. Stump Removal -->
            <div class="tr-services-card">
                <div class="tr-services-content">
                    <h3>Stump Removal</h3>
                    <p>Removing a tree can leave a stump that can be a barrier and provide a place for insects and fungal growth. Stump removal services will get rid of unwanted stumps and enhance the look and use of your landscape. We prepare sites for new plantings, construction, lawn improvements or other landscaping.</p>
                </div>
            </div>

            <!-- 7. Land Clearing -->
            <div class="tr-services-card">
                <div class="tr-services-content">
                    <h3>Land Clearing Buffalo NY</h3>
                    <p>Our land clearing Buffalo NY services help property owners prepare land for construction, development, landscaping, or outdoor improvements. Trees, brush and vegetation that may not be desired are removed with consideration for the surrounding environment. From a small residential clearing project to a larger property area, our team offers efficient and organized solutions.</p>
                </div>
            </div>

            <!-- 8. Commercial -->
            <div class="tr-services-card">
                <div class="tr-services-content">
                    <h3>Commercial Tree Removal Buffalo NY</h3>
                    <p>Tree care is essential for businesses, property managers and organizations to make their environments safe. Our commercial tree removal Buffalo NY services work for both office buildings, apartment communities, schools, retail properties and other commercial properties. We operate with property owners to safely finish removals with minimal disruption to daily operations.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- =========================================================================
     SECTION 7: TREE REMOVAL NEAR ME — BUFFALO & SURROUNDING AREAS
     ========================================================================= -->
<section class="tr-near-me-section">
    <div class="tr-near-me-container">
        <div class="tr-near-me-grid">
            <div>
                <span class="global-subtitle">
                    LOCAL SERVICE
                </span>
                <h2 class="global-section-title">Tree Removal Near Me — Buffalo & Surrounding Areas</h2>
                <div class="section-divider"></div>
                
                <h3 style="font-size: 1.35rem; color: var(--color-brand-purple); margin: 1.5rem 0 1rem;">Reliable Tree Removal Near Me for Buffalo Properties</h3>
                <p style="color: var(--color-text-gray); line-height: 1.7; font-size: 1.05rem;">
                    Property owners should look for a tree removal near me that is knowledgeable about the area and offers reliable service. Maple Majesty Tree Care is a tree removal company for Buffalo and its neighboring Western New York communities.
                </p>
                <p style="color: var(--color-text-gray); line-height: 1.7; font-size: 1.05rem;">
                    Our staff can assist homeowners and businesses with a variety of common issues faced in the region: storm-damaged trees, old trees, breakage of branches due to snow, and trees too close to structures.
                </p>
                <p style="color: var(--color-text-gray); line-height: 1.7; font-size: 1.05rem;">
                    Tree risks are different in Buffalo in each season of the year. Strong winds during seasonal weather events can break branches that are already weak and heavy snow loads on branches can cause unexpected breakage during winter storms. The regular assessments and timely removal can minimize the risk of emergencies.
                </p>
            </div>

            <div class="tr-near-me-list-box">
                <h3 style="font-size: 1.3rem; color: var(--color-brand-purple); margin-bottom: 1.5rem;">We offer authentic tree services in Buffalo NY, for the following trees:</h3>
                <ul class="tr-near-me-list">
                    <li><span class="list-icon"><?php echo tr_render_svg('check-circle.svg', '✓'); ?></span> Residential properties</li>
                    <li><span class="list-icon"><?php echo tr_render_svg('check-circle.svg', '✓'); ?></span> Commercial buildings</li>
                    <li><span class="list-icon"><?php echo tr_render_svg('check-circle.svg', '✓'); ?></span> Rental properties</li>
                    <li><span class="list-icon"><?php echo tr_render_svg('check-circle.svg', '✓'); ?></span> Property management companies</li>
                    <li><span class="list-icon"><?php echo tr_render_svg('check-circle.svg', '✓'); ?></span> Construction sites</li>
                    <li><span class="list-icon"><?php echo tr_render_svg('check-circle.svg', '✓'); ?></span> Municipal and community spaces</li>
                </ul>
            </div>
        </div>

        <div class="tr-near-me-footer">
            <p>Our service area extends beyond Buffalo to nearby communities throughout Western New York. If you are looking for reliable tree services near me, our experienced team can evaluate your property and recommend the safest solution.</p>
        </div>
    </div>
</section>

<!-- =========================================================================
     SECTION 8: WE SERVE ALL BUFFALO COMMUNITIES
     ========================================================================= -->
<section class="tr-communities-section">
    <div class="tr-communities-container">
        <div class="text-center" style="max-width: 850px; margin: 0 auto 3rem auto;">
            <span class="global-subtitle">
               
                REGIONAL COVERAGE
            </span>
            <h2 class="global-section-title">We Serve All Buffalo Communities</h2>
            <div class="section-divider" style="margin: 1rem auto 1.5rem auto;"></div>
            <p style="font-size: 1.15rem; color: var(--color-text-gray); line-height: 1.7; margin-bottom: 1rem;">
            Maple Majesty Tree Care is a proud service provider for tree removal Buffalo and the surrounding areas. With our local experience, we know the property layouts, tree condition and seasonal challenges across Western NY.
            </p>
            <p style="font-size: 1.1rem; color: var(--color-text-gray); line-height: 1.7;">
                Our arborists can safely and efficiently remove trees of any size, from historic homes to suburban homes, commercial buildings or larger lots.
            </p>
        </div>

        <div class="tr-communities-grid">
            <div class="tr-community-card">
                <h3>Downtown Buffalo</h3>
                <p>We help downtown property owners manage trees near buildings, sidewalks, parking areas, and commercial spaces where careful removal planning is essential.</p>
            </div>
            <div class="tr-community-card">
                <h3>Elmwood Village</h3>
                <p>Historic properties and mature landscapes often require careful tree management to protect older structures and surrounding gardens.</p>
            </div>
            <div class="tr-community-card">
                <h3>North Buffalo</h3>
                <p>Our team assists homeowners with aging trees, storm damage, and landscape improvements in established residential neighborhoods.</p>
            </div>
            <div class="tr-community-card">
                <h3>South Buffalo</h3>
                <p>We provide tree removal solutions for properties affected by seasonal weather, aging trees, and changing landscape needs.</p>
            </div>
            <div class="tr-community-card">
                <h3>Allentown</h3>
                <p>Urban properties often require precise removal techniques due to limited space and nearby structures.</p>
            </div>
            <div class="tr-community-card">
                <h3>West Side Buffalo</h3>
                <p>We help homeowners maintain safe outdoor areas by removing damaged, unhealthy, or unwanted trees.</p>
            </div>
            <div class="tr-community-card">
                <h3>Riverside</h3>
                <p>Properties near waterways and changing weather conditions may experience unique tree health challenges requiring professional assessment.</p>
            </div>
            <div class="tr-community-card">
                <h3>University Heights</h3>
                <p>We provide safe tree removal services for residential properties, rental homes, and community areas.</p>
            </div>
        </div>

        <!-- Coverage & Landmarks Grid -->
        <div class="tr-coverage-grid" style="background: var(--color-white); border-radius: 16px; box-shadow: 0 8px 25px rgba(0,0,0,0.04);">
            <div class="tr-coverage-box">
                <h3>Nearby Areas We Serve</h3>
                <p style="color: var(--color-text-gray); margin-bottom: 1rem;">Our tree removal services extend throughout:</p>
                <ul class="tr-coverage-list" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 0.75rem;">
                    <li><span class="list-icon"><?php echo tr_render_svg('map-pin.svg', '📍'); ?></span> Amherst</li>
                    <li><span class="list-icon"><?php echo tr_render_svg('map-pin.svg', '📍'); ?></span> Cheektowaga</li>
                    <li><span class="list-icon"><?php echo tr_render_svg('map-pin.svg', '📍'); ?></span> Tonawanda</li>
                    <li><span class="list-icon"><?php echo tr_render_svg('map-pin.svg', '📍'); ?></span> West Seneca</li>
                    <li><span class="list-icon"><?php echo tr_render_svg('map-pin.svg', '📍'); ?></span> Lackawanna</li>
                    <li><span class="list-icon"><?php echo tr_render_svg('map-pin.svg', '📍'); ?></span> Hamburg</li>
                    <li><span class="list-icon"><?php echo tr_render_svg('map-pin.svg', '📍'); ?></span> Williamsville</li>
                    <li><span class="list-icon"><?php echo tr_render_svg('map-pin.svg', '📍'); ?></span> Kenmore</li>
                    <li><span class="list-icon"><?php echo tr_render_svg('map-pin.svg', '📍'); ?></span> Orchard Park</li>
                    <li><span class="list-icon"><?php echo tr_render_svg('map-pin.svg', '📍'); ?></span> Clarence</li>
                </ul>
            </div>

            <div class="tr-coverage-box">
                <h3>Buffalo Landmarks & Local Service Coverage</h3>
                <ul class="tr-coverage-list" style="display: grid; grid-template-columns: 1fr; gap: 0.75rem;">
                    <li><span class="list-icon"><?php echo tr_render_svg('map-pin.svg', '📍'); ?></span> Delaware Park</li>
                    <li><span class="list-icon"><?php echo tr_render_svg('map-pin.svg', '📍'); ?></span> Buffalo Zoo area</li>
                    <li><span class="list-icon"><?php echo tr_render_svg('map-pin.svg', '📍'); ?></span> Canalside</li>
                    <li><span class="list-icon"><?php echo tr_render_svg('map-pin.svg', '📍'); ?></span> Buffalo Waterfront</li>
                    <li><span class="list-icon"><?php echo tr_render_svg('map-pin.svg', '📍'); ?></span> University at Buffalo campuses</li>
                    <li><span class="list-icon"><?php echo tr_render_svg('map-pin.svg', '📍'); ?></span> Buffalo Niagara Medical Campus</li>
                    <li><span class="list-icon"><?php echo tr_render_svg('map-pin.svg', '📍'); ?></span> Forest Lawn Memorial Park</li>
                </ul>
            </div>
        </div>
    </div>
</section>

<!-- =========================================================================
     SECTION 9: WARNING SIGNS — WHEN TO REMOVE A TREE
     ========================================================================= -->
<section class="warning-signs-section">
    <div class="tr-container">
        <div class="text-center" style="max-width: 850px; margin: 0 auto 3rem auto;">
            <span class="global-subtitle">
                HAZARD RECOGNITION
            </span>
            <h2 class="global-section-title">Warning Signs — When to Remove a Tree</h2>
            <div class="section-divider" style="margin: 1rem auto 1.5rem auto;"></div>
            <p style="font-size: 1.15rem; color: var(--color-text-gray); line-height: 1.7; margin-bottom: 1rem;">
                It may appear to be a healthy tree from afar, but it may have internal structural issues that cause it to be more prone to failure. The early detection of signs of warning can avert damage to property, injury to persons, and expensive emergencies.
            </p>
            <p style="font-size: 1.1rem; font-weight: bold; color: var(--color-brand-purple);">
                Tree removal may be recommended when a tree can no longer be safely maintained through other techniques such as tree trimming or pruning.
            </p>
        </div>

        <div class="warning-signs-grid">
            <!-- 1 -->
            <div class="warning-card">
                <div class="warning-content">
                    <h3>1. Severe Leaning or Structural Instability</h3>
                    <p>Trees that suddenly start leaning may have issues with their roots, soil, or internal tree structure. Trees growing in proximity to homes, driveways or walkways must be evaluated by a licensed arborist right away, as they could fall unexpectedly.</p>
                </div>
            </div>

            <!-- 2 -->
            <div class="warning-card">
                <div class="warning-content">
                    <h3>2. Large Dead or Broken Branches</h3>
                    <p>During Buffalo's rough winds, winter storms, and heavy snow, the limbs of trees can fall. As large branches hang above roofs, vehicles, or outdoor spaces, there are significant safety concerns.</p>
                </div>
            </div>

            <!-- 3 -->
            <div class="warning-card">
                <div class="warning-content">
                    <h3>3. Extensive Disease or Decay</h3>
                    <p>Trees with advanced disease, fungus, and woody rot can become structurally unsound. If the trunk or main branches are involved, it may be safer to remove the tree than to try to treat it.</p>
                </div>
            </div>

            <!-- 4 -->
            <div class="warning-card">
                <div class="warning-content">
                    <h3>4. Root System Problems</h3>
                    <p>A damaged root system can cause the entire tree to be weakened. Symptoms are soil heaving around the trunk, exposed roots, molds around the base, or wobbling or unsteadiness.</p>
                </div>
            </div>

            <!-- 5 -->
            <div class="warning-card">
                <div class="warning-content">
                    <h3>5. Storm Damage</h3>
                    <p>Buffalo is affected by seasonal weather that can cause tree damage, such as ice buildup, heavy snow or strong winds. Trees that have split trunks, broken leaders or are severely damaged by a storm might need to be removed.</p>
                </div>
            </div>

            <!-- 6 -->
            <div class="warning-card">
                <div class="warning-content">
                    <h3>6. Tree Damage to Property</h3>
                    <p>Trees too near buildings, foundations, fences or utility areas can pose long-term problems. Roots and branches may start to cause damage to structures, requiring removal.</p>
                </div>
            </div>

            <!-- 7 -->
            <div class="warning-card">
                <div class="warning-content">
                    <h3>7. Poor Tree Location</h3>
                    <p>Occasionally, a tree is in the wrong place, even though it is healthy. If trees are planted too close to each other, interfering with construction plans, or interfering with property improvement, they may require professional removal services.</p>
                </div>
            </div>

            <!-- 8 -->
            <div class="warning-card">
                <div class="warning-content">
                    <h3>8. Multiple Failed Repairs</h3>
                    <p>If the tree continues to have recurring issues after pruning and treatment, removing the tree may be the most cost-effective and safest choice.</p>
                </div>
            </div>
        </div>

        <!-- Assessment CTA Box -->
        <div class="tr-assessment-cta">
            <h2 style="font-size: 1.8rem; color: var(--color-brand-purple); margin-bottom: 1rem; font-family: var(--font-heading);">Get a Free Tree Removal Assessment</h2>
            <p style="font-size: 1.15rem; color: var(--color-text-gray); margin-bottom: 2rem;">Our ISA Certified Arborists can conduct a tree survey to verify if removal is the best option for trees on your property.</p>
            <a href="tel:+17164000763" class="btn-primary" style="display: inline-flex; align-items: center; gap: 0.75rem; padding: 1.25rem 2.5rem; font-size: 1.1rem;">
                <?php echo tr_render_svg('phone-call.svg', '📞'); ?>
                Call Now 
            </a>
        </div>
    </div>
</section>

<!-- =========================================================================
     SECTION 10: HOW TREE REMOVAL PROCESS WORKS IN BUFFALO, NY (6 DETAILED STEPS)
     ========================================================================= -->
<section class="tr-process-section" style="padding: 6rem 0;">
    <div class="tr-container">
        <div class="text-center" style="max-width: 850px; margin: 0 auto 3.5rem auto;">
            <span class="global-subtitle">
                PRECISION & SAFETY
            </span>
            <h2 class="global-section-title">How Tree Removal Process Works in Buffalo, NY</h2>
            <div class="section-divider" style="margin: 1rem auto 1.5rem auto;"></div>
            <p style="font-size: 1.15rem; color: var(--color-text-gray); line-height: 1.7;">
                Tree removal is a job that must be done with meticulous planning, specialized equipment, and experienced arborists. We have a procedure for safely cutting down trees while keeping you and your property safe and protecting your landscape.
            </p>
        </div>

        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 2.5rem;">
            <!-- Step 1 -->
            <div class="process-step-card">
                <h3>Step 1: Tree Inspection and Risk Assessment</h3>
                <p>All removal projects start with a detailed inspection. Our arborists evaluate:</p>
                <ul>
                    <li>The number of lightning strikes on trees</li>
                    <li>Overall health condition</li>
                    <li>Structural stability</li>
                    <li>Root system condition</li>
                    <li>Buildings and objects nearby</li>
                    <li>Potential hazards</li>
                </ul>
                <p class="small-text">This evaluation can help decide if removal is needed and the safest way to remove it.</p>
            </div>

            <!-- Step 2 -->
            <div class="process-step-card">
                <h3>Step 2: Creating a Safe Removal Plan</h3>
                <p>We assess your situation, then create a personalized removal plan. Factors considered include:</p>
                <ul>
                    <li>Tree height and weight</li>
                    <li>Falling direction</li>
                    <li>Property layout</li>
                    <li>Access limitations</li>
                    <li>Weather conditions</li>
                    <li>Required equipment</li>
                </ul>
                <p class="small-text">Some techniques like sectional dismantling and professional rigging, bucket trucks and crane assistance may be necessary for large or complex trees.</p>
            </div>

            <!-- Step 3 -->
            <div class="process-step-card">
                <h3>Step 3: Preparing the Work Area</h3>
                <p>Our personnel safeguard people and property around the area before the removal process starts. Preparation may include:</p>
                <ul>
                    <li>Establishing safety zones</li>
                    <li>Moving vehicles or outdoor items</li>
                    <li>Protecting landscaping features</li>
                    <li>Setting up equipment</li>
                    <li>Checking environmental conditions</li>
                </ul>
                <p class="small-text">Risk is minimized if proper preparations are made before the removal process.</p>
            </div>

            <!-- Step 4 -->
            <div class="process-step-card">
                <h3>Step 4: Controlled Tree Removal</h3>
                <p>We have highly qualified staff who are trained and experienced in removing trees in a way that is suitable for the industry. Depending on the situation, we may use:</p>
                <ul>
                    <li>Climbing techniques</li>
                    <li>Chainsaws</li>
                    <li>Rigging systems</li>
                    <li>Bucket trucks</li>
                    <li>Crane equipment for large trees</li>
                </ul>
                <p class="small-text">Branches and sections are lowered in a controlled way and are not let fall freely this minimises potential damage.</p>
            </div>

            <!-- Step 5 -->
            <div class="process-step-card">
                <h3>Step 5: Removing Wood and Debris</h3>
                <p>Once the tree is gone, our team removes branches, logs and debris from the work area. The proper cleaning restores the appearance and safety of your property. Other choices are:</p>
                <ul>
                    <li>Firewood preparation</li>
                    <li>Brush removal</li>
                    <li>Wood hauling</li>
                    <li>Stump grinding</li>
                    <li>Stump removal</li>
                </ul>
            </div>

            <!-- Step 6 -->
            <div class="process-step-card">
                <h3>Step 6: Final Inspection and Property Cleanup</h3>
                <p>Before the completion of the project, we survey the area to make sure that the area has been cleared of material correctly. We review:</p>
                <ul>
                    <li>Remaining debris</li>
                    <li>Property condition</li>
                    <li>Safety concerns</li>
                    <li>Future tree care recommendations</li>
                </ul>
                <p class="small-text">We want your property to be clean, safe and prepared for future landscaping projects.</p>
            </div>
        </div>
    </div>
</section>

<!-- =========================================================================
     SECTION 11: WHY TRUST US WITH YOUR TREE REMOVAL? (WHY CHOOSE US)
     ========================================================================= -->
<section class="tr-trust-section">
    <div class="tr-container">
        <div class="text-center" style="max-width: 850px; margin: 0 auto 3rem auto;">
            <span class="global-subtitle">
                WHY CHOOSE US
            </span>
            <h2 class="global-section-title">Why Trust Us With Your Tree Removal?</h2>
            <div class="section-divider" style="margin: 1rem auto 1.5rem auto;"></div>
            <h3 style="font-size: 1.35rem; color: var(--color-brand-purple); margin-bottom: 1rem;">Experienced Tree Service in Buffalo, New York</h3>
            <p style="font-size: 1.1rem; color: var(--color-text-gray); line-height: 1.7; margin-bottom: 1rem;">
                Tree removal can be hazardous, require specialized knowledge and equipment; hence, the choice of a tree removal company is important. With a team of seasoned arborists and local expertise, Maple Majesty Tree Care offers professional solutions.
            </p>
            <p style="font-size: 1.1rem; color: var(--color-text-gray); line-height: 1.7;">
                We bring a wealth of experience, meticulous planning, and a commitment to customer satisfaction to ensure your tree care needs are met effectively, no matter where you live in Buffalo and Western New York.
            </p>
        </div>

        <div class="tr-trust-grid">
            <!-- 1 -->
            <div class="trust-card">
                <h3>1. ISA-Certified Arborist Expertise</h3>
                <p>Tree experts understand the nature of trees and how they can pose a risk, what diseases they might have, and how to safely remove trees. Professional evaluation will be used to determine the best remedy for each tree.</p>
            </div>

            <!-- 2 -->
            <div class="trust-card">
                <h3>2. Safety-Focused Removal Methods</h3>
                <p>The risk of falling branches, heavy equipment and unstable trees can be dangerous when cutting trees. Safety procedures and appropriate protection equipment are followed to minimise hazards.</p>
            </div>

            <!-- 3 -->
            <div class="trust-card">
                <h3>3. Local Buffalo Tree Knowledge</h3>
                <p>The following are some special risks in Buffalo properties: Heavy snowfall, Ice storms, Strong winds, Seasonal temperature changes. Through the experience we have in Western New York, we know what trees are likely to encounter in our area.</p>
            </div>

            <!-- 4 -->
            <div class="trust-card">
                <h3>4. Professional Equipment and Techniques</h3>
                <p>Specialized tools and techniques may be needed to safely remove some items such as: Rigging equipment, Bucket trucks, Professional chainsaws, Safety gear, Crane services for complex projects. Removals can be controlled and efficient using the correct equipment.</p>
            </div>

            <!-- 5 -->
            <div class="trust-card">
                <h3>5. Complete Tree Care Solutions</h3>
                <p>In addition to removal, we are available to offer other tree services to your property, such as: Emergency tree services, Stump removal, Land clearing, Hazard assessments, Tree maintenance solutions.</p>
            </div>

            <!-- 6 -->
            <div class="trust-card">
                <h3>6. Customer-Focused Service</h3>
                <p>Our focus is on communicating, giving honest recommendations and working safely. Our staff describes the removal process, answers questions and assists customers in making informed decisions about their trees</p>
            </div>
        </div>
    </div>
</section>

<!-- =========================================================================
     SECTION 12: TREE REMOVAL COST IN BUFFALO, NY?
     ========================================================================= -->
<section class="tr-cost-section">
    <div class="tr-container">
        <div>
            <span class="global-subtitle">
                TRANSPARENT PRICING
            </span>
            <h2 class="global-section-title">Tree Removal Cost in Buffalo, NY?</h2>
            <div class="section-divider"></div>

            <div class="tr-takeaway-box" style="margin-top: 1.5rem; margin-bottom: 2rem;">
                <div class="tr-takeaway-icon"><?php echo tr_render_svg('info-circle.svg', 'ℹ️'); ?></div>
                <p class="tr-takeaway-text">
                Tree removal costs vary primarily by size, condition, access, nearby structures, equipment requirements, stump work, and whether emergency service is needed.
                </p>
            </div>

            <h3 style="font-size: 1.35rem; color: var(--color-brand-purple); margin-bottom: 1rem;">How much does tree removal cost in Buffalo NY</h3>
            <p style="font-size: 1.05rem; color: var(--color-text-gray); line-height: 1.7;">
                Factors such as tree size, location, condition, accessibility, and equipment needs all impact the cost of professional tree removal. No prices are set in stone because each tree removal project has its own set of safety issues. The best way to determine how much tree removal costs in Buffalo NY is to have them come out to examine your tree.
            </p>
        </div>

        <div class="tr-cost-content-grid">
            <div>
                <table class="styled-table">
                    <thead>
                        <tr>
                            <th>Tree Size</th>
                            <th>Typical Cost Range</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Small Tree (under 25 ft)</td>
                            <td>$200 – $500</td>
                        </tr>
                        <tr>
                            <td>Medium Tree (25–50 ft)</td>
                            <td>$500 – $1,000</td>
                        </tr>
                        <tr>
                            <td>Large Tree (50–80 ft)</td>
                            <td>$1,000 – $2,000</td>
                        </tr>
                        <tr>
                            <td>Very Large Tree (80 ft+)</td>
                            <td>$2,000 – $4,500+</td>
                        </tr>
                        <tr>
                            <td>Stump Grinding (add-on)</td>
                            <td>$100 – $400 / stump</td>
                        </tr>
                        <tr>
                            <td>Emergency After-Hours Removal</td>
                            <td>Surcharge may apply</td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <div class="factors-card">
                <h3 style="font-size: 1.3rem; color: var(--color-brand-purple); margin-bottom: 1.5rem;">Factors that affect your total cost:</h3>
                <ul class="cost-factors-list">
                    <li>
                        <strong>Proximity to Structures:</strong>
                        <p style="margin: 0.25rem 0 0.75rem 0;">Trees near homes, garages, fences, or power lines require more precise rigging and additional safety measures, increasing labor time.</p>
                    </li>
                    <li>
                        <strong>Accessibility:</strong>
                        <p style="margin: 0.25rem 0 0.75rem 0;">If heavy equipment or cranes cannot easily reach the tree, the removal becomes more labor-intensive and may increase the overall cost.</p>
                    </li>
                    <li>
                        <strong>Tree Condition:</strong>
                        <p style="margin: 0.25rem 0 0.75rem 0;">Dead, rotted, or storm-damaged trees are often more unpredictable and may require specialized safety procedures.</p>
                    </li>
                    <li>
                        <strong>Permit Requirements:</strong>
                        <p style="margin: 0.25rem 0 0.75rem 0;">Some Buffalo-area municipalities require permits for tree removal. Our team researches and handles this process when applicable.</p>
                    </li>
                    <li>
                        <strong>Stump Treatment:</strong>
                        <p style="margin: 0.25rem 0 0 0;">Adding stump grinding at the time of removal is typically the most cost-effective option compared to scheduling it later.</p>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</section>

<!-- =========================================================================
     SECTION 13: TREE REMOVAL SERVICE IN WESTERN NEW YORK
     ========================================================================= -->
<section class="tr-wny-section">
    <div class="tr-container text-center">
        <span class="global-subtitle">
            SERVING ALL OF WNY
        </span>
        <h2 class="global-section-title">Tree Removal Service in Western New York</h2>
        <div class="section-divider" style="margin: 1rem auto 1.5rem auto;"></div>
        
        <p class="wny-text" style="margin-bottom: 1rem;">
            As a professional tree removal company in Buffalo and Western New York, Maple Majesty Tree Care offers tree removal services. We handle residential and commercial needs for properties in Amherst, Cheektowaga, Williamsville, Hamburg, Hamburg Heights, Tonawanda, West Seneca, and other areas.
        </p>
        <p class="wny-text">
            We know the local tree problems that occur as a result of snow, ice, storm and weather changes.
        </p>
    </div>
</section>

