
<!-- SECTION 1: What Is Brush Clearing? -->
<section id="what-is-brush-clearing" class="lc-what-is-section">
    <div class="lc-what-is-container">
        <div class="lc-what-is-content">
            <span class="global-subtitle">LAND MANAGEMENT</span>
            <h2 class="global-section-title">What Is Brush Clearing?</h2>
            <div class="section-divider"></div>
            
            <p class="font-montserrat-extrabold" style="margin-bottom: 1.5rem; font-size: 1.1rem; color: var(--color-forest-green);">
            Brush clearing removes unwanted vegetation, saplings, invasive shrubs, and selected root systems to restore usable land and prepare property for landscaping, fencing, construction, or maintenance.
            </p>
            
            <p>Brush clearing works involve clearing overgrown vegetation, saplings, invasive shrubs and root systems from a property so that it can be used for building a house or landscaping it.</p>
            
            <p>Brush clearing involves removing unwanted brush, small trees, invasive shrubs, and root systems all way down to the "usable grade", whereas tree removal deals with individual mature trees.</p>
            
            <p>Buckthorn, multiflora rose and other fast-growing invasives that take root quickly in the clay-heavy soil of Western New York are common issues in brush clearing in the Buffalo area. When left unchecked, these species invade fence lines, yard spaces and plantings of native plants, and if the visible growth is cut off without removing the root system, it will grow back within a season.</p>
        </div>

    </div>
</section>

<!-- SECTION 2: Types of Land & Brush Clearing We Offer -->
<section id="types-of-clearing" class="lc-types-section">
    <div class="lc-types-container">
        <div class="text-center" style="margin-bottom: 3rem;">
            <span class="global-subtitle">OUR SERVICES</span>
            <h2 class="global-section-title">Types of Land & Brush Clearing We Offer</h2>
            <div class="section-divider" style="margin: 1rem auto;"></div>
            <p style="max-width: 800px; margin: 0 auto;">Every clearing job is different – here are how we tackle the most popular property types right here in Buffalo.</p>
        </div>


        <div class="lc-types-grid">
            <div class="lc-type-card">
                <div class="type-icon">
                    <?php echo file_exists(get_template_directory() . '/assets/icons/residential.svg') ? file_get_contents(get_template_directory() . '/assets/icons/residential.svg') : ''; ?>
                </div>
                <div class="lc-type-content">
                    <h3>Residential Lot Clearing</h3>
                    <p>Years of volunteer sapling, brush and weed growth in backyard or side lots where these areas have been cleared to a usable landscaping, fencing or maintenance grade.</p>
                </div>
            </div>
            
            <div class="lc-type-card">
                <div class="type-icon">
                    <?php echo file_exists(get_template_directory() . '/assets/icons/construction.svg') ? file_get_contents(get_template_directory() . '/assets/icons/construction.svg') : ''; ?>
                </div>
                <div class="lc-type-content">
                    <h3>Construction Prep Clearing</h3>
                    <p>Lots that are being prepared for new construction or additions, or driveways, that have been cleared and grubbed down to the grade to allow the contractors to excavate without any roots or brush blocking the way.</p>
                </div>
            </div>

            <div class="lc-type-card">
                <div class="type-icon">
                    <?php echo file_exists(get_template_directory() . '/assets/icons/overgrown.svg') ? file_get_contents(get_template_directory() . '/assets/icons/overgrown.svg') : ''; ?>
                </div>
                <div class="lc-type-content">
                    <h3>Overgrown Land Clearing</h3>
                    <p>Properties that have not been properly cared for for years, and may have a variety of invasive species, fallen timber and very thick brush that will be more difficult to remove, needing heavier equipment.</p>
                </div>
            </div>

            <div class="lc-type-card">
                <div class="type-icon">
                    <?php echo file_exists(get_template_directory() . '/assets/icons/fence.svg') ? file_get_contents(get_template_directory() . '/assets/icons/fence.svg') : ''; ?>
                </div>
                <div class="lc-type-content">
                    <h3>Fence Line Clearing</h3>
                    <p>Fences with brush and root systems that have grown into and around the fence were carefully removed to restore the fence line without damaging posts or panels in any fences.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- SECTION 3: Top Benefits of Brush Clearing -->
<section id="benefits-of-brush-clearing" class="lc-benefits-section">
    <div class="lc-benefits-container">

        <div class="lc-benefits-content">
            <span class="global-subtitle">WHY IT MATTERS</span>
            <h2 class="global-section-title">Top Benefits of Brush Clearing</h2>
            <div class="section-divider"></div>
            
            <p class="font-montserrat-extrabold" style="margin-bottom: 1.5rem; font-size: 1.1rem; color: var(--color-forest-green);">
                Professional brush clearing can reclaim usable space, reduce pest habitat, improve access, prepare land for future projects, and control invasive vegetation before it spreads further.
            </p>
            
            <p>In addition to making a property look better, brush clearing addresses practical issues with a property such as drainage, pest harborage and reclaiming yard space.</p>
            
            <h3 style="margin-top: 2rem; font-size: 1.5rem;">Why It's Worth Doing</h3>
            <ul class="lc-benefits-list">
                <li>
                    <span class="check-icon"><?php echo file_exists(get_template_directory() . '/assets/icons/check-circle.svg') ? file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg') : ''; ?></span>
                    <span><strong>Reclaims usable land</strong> - years of volunteer development can slowly take up lots of yard space; clearing can reveal fencing, drainage, or square footage that homeowners were unaware they had in their yard.</span>
                </li>
                <li>
                    <span class="check-icon"><?php echo file_exists(get_template_directory() . '/assets/icons/check-circle.svg') ? file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg') : ''; ?></span>
                    <span><strong>Reduces pest and rodent activity</strong> - thick brush provides habitat for pests and rodents with access to covered foundation; removal of brush reduces harborage areas.</span>
                </li>
                <li>
                    <span class="check-icon"><?php echo file_exists(get_template_directory() . '/assets/icons/check-circle.svg') ? file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg') : ''; ?></span>
                    <span><strong>Improve drainage</strong> - unmanaged brush root systems can pull surface water to other areas and cause standing water or wet basement areas.</span>
                </li>
                <li>
                    <span class="check-icon"><?php echo file_exists(get_template_directory() . '/assets/icons/check-circle.svg') ? file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg') : ''; ?></span>
                    <span><strong>Prepares land for construction or landscaping</strong> - a newly prepared lot with no roots in the way and levelled with a rake or similar tool for sod or new landscaping to be installed.</span>
                </li>
                <li>
                    <span class="check-icon"><?php echo file_exists(get_template_directory() . '/assets/icons/check-circle.svg') ? file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg') : ''; ?></span>
                    <span><strong>Prevents structural moisture damage</strong> - moisture against the fence or siding with brush will lead to rot over time.</span>
                </li>
                <li>
                    <span class="check-icon"><?php echo file_exists(get_template_directory() . '/assets/icons/check-circle.svg') ? file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg') : ''; ?></span>
                    <span><strong>Stops invasive species from spreading further</strong> - root removal, including root, prevents the spread of the species to other properties.</span>
                </li>
            </ul>
        </div>
    </div>
</section>

<!-- SECTION 4: How Land & Brush Clearing Service Works -->
<section id="how-it-works" class="lc-process-section">
    <div class="lc-process-container">
        <div class="text-center" style="margin-bottom: 3rem;">
            <span class="global-subtitle">OUR PROCESS</span>
            <h2 class="global-section-title">How Land & Brush Clearing Service Works</h2>
            <div class="section-divider" style="margin: 1rem auto;"></div>
            
            <p class="font-montserrat-extrabold" style="max-width: 800px; margin: 1.5rem auto; font-size: 1.1rem; color: var(--color-forest-green);">
                A professional clearing project begins with a site assessment and written scope, followed by vegetation removal, appropriate root treatment, debris handling, and a final walkthrough.
            </p>
            
            <p style="max-width: 800px; margin: 0 auto;">From your first call to a cleared, usable lot, here's what to expect when Maple Majesty handles your land and brush clearing project.</p>
        </div>

        <div class="lc-process-grid">
            <div class="lc-process-step">
                <div class="step-number">1</div>
                Call & Schedule
                <p>Contact us for a free evaluation – we will ask a few questions regarding your lot and what type of vegetation you have.</p>
            </div>
            
            <div class="lc-process-step">
                <div class="step-number">2</div>
                On-Site Walkthrough
                <p>We evaluate vegetation density, root depth, soil conditions, access points, and anything that you would like to preserve (mature trees, fencing, existing landscaping).</p>
            </div>

            <div class="lc-process-step">
                <div class="step-number">3</div>
                Written Scope & Estimate
                <p>You receive an itemized, written estimate before they move in. No verbal estimates that change later.</p>
            </div>

            <div class="lc-process-step">
                <div class="step-number">4</div>
                Systematic Clearing
                <p>Using equipment matched to your lot size and terrain, our crew clears brush, saplings, and root systems, working the site methodically.</p>
            </div>
            
            <div class="lc-process-step">
                <div class="step-number">5</div>
                Debris Removal
                <p>debris removed and hauled away or chipped onsite, depending on circumstances.</p>
            </div>
            
            <div class="lc-process-step">
                <div class="step-number">6</div>
                Final Walkthrough
                <p>We do a walk-through with you to ensure all is good before we leave.</p>
            </div>
        </div>
        
        <div class="text-center" style="margin-top: 4rem;">
            <a href="<?php echo site_url('/contact/'); ?>" class="btn-primary">Get a Free Estimate</a>
        </div>
    </div>
</section>

<!-- SECTION 5: Land Clearing Services in Your Buffalo Neighborhood -->
<section id="buffalo-neighborhood" class="lc-neighborhood-section">
    <div class="lc-neighborhood-container">
        <div class="lc-neighborhood-content">
            <span class="global-subtitle">LOCAL EXPERTS</span>
            <h2 class="global-section-title">Land Clearing Services in Your Buffalo Neighborhood</h2>
            <div class="section-divider"></div>
            
            <p>Looking for land and brush removal services near me? Our Buffalo crews clear lots in Buffalo's neighborhoods and suburbs regularly.</p>
            
            <p>The crews at Maple Majesty understand how to remove trees in neighborhoods such as Elmwood Village, North Buffalo, South Buffalo, and Allentown, where side yards are often too small for mowing or overgrown lots are in their rear yards and have been neglected for years.</p>
            
            <p>We have removed thick hedgerows from small lots in Elmwood Village, mowed backyards in North Buffalo before planting projects, and mowed brush lines to grade on the smaller residential lot boundaries in South Buffalo. By knowing the typical lot sizes, soil conditions and access restrictions in each neighborhood, we can bring the right equipment to the site on the first day, rather than finding an unexpected mismatch.</p>
        </div>

    </div>
</section>

<!-- SECTION 6: What Makes Us Different -->
<section id="why-choose-us" class="lc-why-choose-section">
    <div class="lc-why-choose-container">
        <div class="text-center" style="margin-bottom: 3rem;">
            <span class="global-subtitle">WHY CHOOSE US</span>
            <h2 class="global-section-title">What Makes Us Different &mdash; Land Clearing Experts</h2>
            <div class="section-divider" style="margin: 1rem auto;"></div>
            <p style="max-width: 800px; margin: 0 auto;">When homeowners look for a land clearing Buffalo NY service, they choose Maple Majesty because we deal with the root system as well as the top growth, not just the visible growth, meaning no repeat work.</p>
        </div>

        <h3 class="text-center" style="margin-top: 2rem; margin-bottom: 2rem; font-size: 1.5rem; color: var(--color-brand-purple);">Why It Matters</h3>
        
        <div class="lc-why-choose-grid">
            <div class="lc-why-card">
                <div class="why-icon">
                    <?php echo file_exists(get_template_directory() . '/assets/icons/roots.svg') ? file_get_contents(get_template_directory() . '/assets/icons/roots.svg') : ''; ?>
                </div>
                <div class="lc-why-content">
                    <h3>We clear roots, not just brush.</h3>
                    <p>When we cut vegetation to grade, we are dealing with the root system, which is right for the type of vegetation. All Maple Majesty clearing projects focus on the root system accordingly, according to the vegetation type.</p>
                </div>
            </div>
            
            <div class="lc-why-card">
                <div class="why-icon">
                    <?php echo file_exists(get_template_directory() . '/assets/icons/equipment.svg') ? file_get_contents(get_template_directory() . '/assets/icons/equipment.svg') : ''; ?>
                </div>
                <div class="lc-why-content">
                    <h3>Equipment matched to your lot</h3>
                    <p>Smaller, more compact equipment for small city plots, larger equipment for larger parcels, chosen during the on-site evaluation process, rather than standard-sized equipment.</p>
                </div>
            </div>

            <div class="lc-why-card">
                <div class="why-icon">
                    <?php echo file_exists(get_template_directory() . '/assets/icons/leaf.svg') ? file_get_contents(get_template_directory() . '/assets/icons/leaf.svg') : ''; ?>
                </div>
                <div class="lc-why-content">
                    <h3>We know Buffalo's clay soil and invasive species</h3>
                    <p>Buckthorn, multiflora rose, and similar species spread fast across Western New York and require full root removal to prevent regrowth in our clay-heavy ground.</p>
                </div>
            </div>

            <div class="lc-why-card">
                <div class="why-icon">
                    <?php echo file_exists(get_template_directory() . '/assets/icons/document.svg') ? file_get_contents(get_template_directory() . '/assets/icons/document.svg') : ''; ?>
                </div>
                <div class="lc-why-content">
                    <h3>Straight, written estimates</h3>
                    <p>The scope and cost is documented before equipment moves; we do not add cost mid-job without talking to you first.</p>
                </div>
            </div>

            <div class="lc-why-card">
                <div class="why-icon">
                    <?php echo file_exists(get_template_directory() . '/assets/icons/truck.svg') ? file_get_contents(get_template_directory() . '/assets/icons/truck.svg') : ''; ?>
                </div>
                <div class="lc-why-content">
                    <h3>Full debris removal</h3>
                    <p>Cleared brush and timber are either hauled or processed on your property.</p>
                </div>
            </div>

            <div class="lc-why-card">
                <div class="why-icon">
                    <?php echo file_exists(get_template_directory() . '/assets/icons/shield.svg') ? file_get_contents(get_template_directory() . '/assets/icons/shield.svg') : ''; ?>
                </div>
                <div class="lc-why-content">
                    <h3>Fully licensed and insured</h3>
                    <p>With 5+ years of experience working all land clearing jobs in Buffalo and Western New York, as a brush clearing company designed specifically for the region's conditions.</p>
                </div>
            </div>
        </div>
        
        <div class="text-center" style="margin-top: 4rem;">
            <a href="<?php echo site_url('/contact/'); ?>" class="btn-primary">Book Your Land Clearing</a>
        </div>
    </div>
</section>
<!-- SECTION 7: Brush Clearing Near Me -->
<section id="areas-served" class="lc-areas-section">
    <div class="lc-areas-container">
        <div class="lc-areas-content text-center" style="margin-bottom: 3rem;">
            <span class="global-subtitle">SERVICE AREA</span>
            <h2 class="global-section-title">Brush Clearing Near Me &mdash; Buffalo & Western New York</h2>
            <div class="section-divider" style="margin: 1rem auto;"></div>
            <p style="max-width: 800px; margin: 0 auto;">Searching for land clearing in Buffalo, NY or brush clearing near me? Maple Majesty clears lots throughout the city and surrounding Erie County communities.</p>
        </div>

        <div class="lc-areas-grid">
            <div class="lc-areas-list-box">
                <h3 style="color: var(--color-forest-green); margin-bottom: 1.5rem; font-size: 1.3rem;">Areas We Serve</h3>
                <ul class="lc-custom-list">
                    <li><span class="list-icon"><?php echo file_exists(get_template_directory() . '/assets/icons/check-circle.svg') ? file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg') : ''; ?></span> Delaware Park Area</li>
                    <li><span class="list-icon"><?php echo file_exists(get_template_directory() . '/assets/icons/check-circle.svg') ? file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg') : ''; ?></span> Elmwood Village</li>
                    <li><span class="list-icon"><?php echo file_exists(get_template_directory() . '/assets/icons/check-circle.svg') ? file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg') : ''; ?></span> North Buffalo</li>
                    <li><span class="list-icon"><?php echo file_exists(get_template_directory() . '/assets/icons/check-circle.svg') ? file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg') : ''; ?></span> South Buffalo</li>
                    <li><span class="list-icon"><?php echo file_exists(get_template_directory() . '/assets/icons/check-circle.svg') ? file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg') : ''; ?></span> Allentown</li>
                    <li><span class="list-icon"><?php echo file_exists(get_template_directory() . '/assets/icons/check-circle.svg') ? file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg') : ''; ?></span> Black Rock & Riverside</li>
                    <li><span class="list-icon"><?php echo file_exists(get_template_directory() . '/assets/icons/check-circle.svg') ? file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg') : ''; ?></span> University Heights</li>
                    <li><span class="list-icon"><?php echo file_exists(get_template_directory() . '/assets/icons/check-circle.svg') ? file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg') : ''; ?></span> Lovejoy & Kaisertown</li>
                </ul>
            </div>
            
            <div class="lc-areas-list-box">
                <h3 style="color: var(--color-brand-purple); margin-bottom: 1.5rem; font-size: 1.3rem;">Landmarks & Areas We Work Near</h3>
                <ul class="lc-custom-list two-cols">
                    <li><span class="list-icon"><?php echo file_exists(get_template_directory() . '/assets/icons/check-circle.svg') ? file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg') : ''; ?></span> Delaware Park</li>
                    <li><span class="list-icon"><?php echo file_exists(get_template_directory() . '/assets/icons/check-circle.svg') ? file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg') : ''; ?></span> Elmwood Village</li>
                    <li><span class="list-icon"><?php echo file_exists(get_template_directory() . '/assets/icons/check-circle.svg') ? file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg') : ''; ?></span> Chestnut Ridge Park</li>
                    <li><span class="list-icon"><?php echo file_exists(get_template_directory() . '/assets/icons/check-circle.svg') ? file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg') : ''; ?></span> Niagara River Corridor</li>
                    <li><span class="list-icon"><?php echo file_exists(get_template_directory() . '/assets/icons/check-circle.svg') ? file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg') : ''; ?></span> Buffalo Outer Harbor</li>
                    <li><span class="list-icon"><?php echo file_exists(get_template_directory() . '/assets/icons/check-circle.svg') ? file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg') : ''; ?></span> UB North Campus</li>
                    <li><span class="list-icon"><?php echo file_exists(get_template_directory() . '/assets/icons/check-circle.svg') ? file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg') : ''; ?></span> Cazenovia Park</li>
                    <li><span class="list-icon"><?php echo file_exists(get_template_directory() . '/assets/icons/check-circle.svg') ? file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg') : ''; ?></span> Ellicott Creek Park</li>
                    <li><span class="list-icon"><?php echo file_exists(get_template_directory() . '/assets/icons/check-circle.svg') ? file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg') : ''; ?></span> Tifft Nature Preserve</li>
                    <li><span class="list-icon"><?php echo file_exists(get_template_directory() . '/assets/icons/check-circle.svg') ? file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg') : ''; ?></span> Letchworth State Park Area</li>
                    <li><span class="list-icon"><?php echo file_exists(get_template_directory() . '/assets/icons/check-circle.svg') ? file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg') : ''; ?></span> Grand Island Bridge Area</li>
                    <li><span class="list-icon"><?php echo file_exists(get_template_directory() . '/assets/icons/check-circle.svg') ? file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg') : ''; ?></span> Reinstein Wood</li>
                </ul>
            </div>
        </div>
    </div>
</section>

<!-- SECTION 8: Cost of Brush Clearing -->
<section id="clearing-cost" class="lc-cost-section">
    <div class="lc-cost-container">
        <div class="lc-cost-content text-center" style="margin-bottom: 3rem;">
            <span class="global-subtitle">PRICING</span>
            <h2 class="global-section-title">Cost of Brush Clearing in Buffalo, NY</h2>
            <div class="section-divider" style="margin: 1rem auto;"></div>
            <p style="max-width: 800px; margin: 0 auto 1.5rem auto;">The average cost of brush clearing in Buffalo depends on the lot size, vegetation density, and the depth of the root system. Here's what to expect by project type.</p>
            <p style="max-width: 800px; margin: 0 auto;"><strong>Brush clearing costs</strong> in Buffalo generally range from a few hundred dollars for a small residential lot to several thousand for a larger, densely overgrown parcel, with final pricing determined by vegetation density, root depth, and site access.</p>
        </div>

        <div class="lc-pricing-table-wrapper">
            <table class="lc-pricing-table">
                <thead>
                    <tr>
                        <th>Job Type</th>
                        <th>Price Range</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><strong>Small Residential Lot</strong> (under &frac14; acre)</td>
                        <td>$300 &ndash; $800</td>
                    </tr>
                    <tr>
                        <td><strong>Medium Lot Clearing</strong> (&frac14; to 1 acre)</td>
                        <td>$800 &ndash; $2,500</td>
                    </tr>
                    <tr>
                        <td><strong>Large Lot Clearing</strong> (1 to 3 acres)</td>
                        <td>$2,500 &ndash; $6,000+</td>
                    </tr>
                    <tr>
                        <td><strong>Invasive Species Removal</strong></td>
                        <td>$500 &ndash; $2,000+</td>
                    </tr>
                    <tr>
                        <td><strong>Storm Debris / Fallen Timber Clearing</strong></td>
                        <td>$400 &ndash; $1,500+</td>
                    </tr>
                    <tr>
                        <td><strong>Rural Acreage Clearing</strong></td>
                        <td>Custom Quote</td>
                    </tr>
                    <tr>
                        <td><strong>Commercial Site Clearing</strong></td>
                        <td>Custom Quote</td>
                    </tr>
                </tbody>
            </table>
        </div>
        
        <div class="lc-cost-factors">
            <h3 style="color: var(--color-forest-green); font-size: 1.5rem; margin-bottom: 1.5rem;">What Affects Your Price</h3>
            <ul class="lc-benefits-list">
                <li>
                    <span class="check-icon"><?php echo file_exists(get_template_directory() . '/assets/icons/check-circle.svg') ? file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg') : ''; ?></span>
                    <span><strong>Lot size and vegetation density</strong> - more vegetation means more time taken to clear.</span>
                </li>
                <li>
                    <span class="check-icon"><?php echo file_exists(get_template_directory() . '/assets/icons/check-circle.svg') ? file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg') : ''; ?></span>
                    <span><strong>Root system depth</strong> - Buffalo's clay-heavy soil grips root systems tightly, and deep invasive species removal adds time, regardless of how simple the surface growth looks.</span>
                </li>
                <li>
                    <span class="check-icon"><?php echo file_exists(get_template_directory() . '/assets/icons/check-circle.svg') ? file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg') : ''; ?></span>
                    <span><strong>Site access and terrain</strong> - compact equipment is necessary on tight urban lots and positioning time is considerable when the terrain is sloped or hard to reach.</span>
                </li>
                <li>
                    <span class="check-icon"><?php echo file_exists(get_template_directory() . '/assets/icons/check-circle.svg') ? file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg') : ''; ?></span>
                    <span><strong>Debris haul-away volume</strong> - more material requires more labor time, which also impacts debris haul-away volume.</span>
                </li>
            </ul>
        </div>
        
        <div class="text-center" style="margin-top: 4rem;">
            <a href="<?php echo site_url('/contact/'); ?>" class="btn-primary">Get a Custom Quote</a>
        </div>
    </div>
</section>
<!-- SECTION 9: FAQ -->







