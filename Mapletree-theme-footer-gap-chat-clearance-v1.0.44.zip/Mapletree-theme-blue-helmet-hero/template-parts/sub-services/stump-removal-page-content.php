<?php
/**
 * Template part for displaying Stump Removal page content
 */

// Helper to safely render inline SVGs
if (!function_exists('sr_render_svg')) {
    function sr_render_svg($filename, $fallback = '') {
        $path = get_template_directory() . '/assets/icons/' . $filename;
        if (file_exists($path)) {
            return file_get_contents($path);
        }
        return $fallback;
    }
}
?>

<!-- WHAT IS STUMP REMOVAL -->
<section class="sub-service-section sr-intro-section">
    <div class="container">
        <div class="sr-intro-wrap">

            <div class="sr-intro-content">
                <span class="global-subtitle">Professional Stump Removal</span>
                <h2 class="sr-h2">What Is Stump Removal?</h2>

                <div class="sr-takeaway">
                Stump removal extracts the stump and substantial root material from the ground, making it more complete but generally more disruptive than stump grinding.
                </div>

                <p class="sr-text">
                    Stump removal is the total process of eliminating an existing stump and root system after felling a tree. Stump removal differs from the process of stump grinding in that removal takes the stump and roots completely out of the ground. Old stumps bring unwanted pests, cause fungus to develop, are safety hazards, and make future landscaping difficult. At Maple Majesty Tree Care, our ISA-Certified Arborists inspect the stump size, tree type, roots, soil conditions, and access to recommend the best removal method. Using special equipment, we will remove stumps in a safe manner and remove the waste to prepare your Buffalo property for landscaping.
                </p>
            </div>

        </div>
    </div>
</section>

<!-- TYPES OF STUMP REMOVAL SERVICES -->
<section class="sub-service-section sr-types-section">
    <div class="container">

        <div class="sr-section-header">
            <span class="global-subtitle">Our Services</span>
            <h2 class="sr-h2">Types of Stump Removal Services</h2>
            <p class="sr-intro-text">
              The right stump removal method depends on stump size, root spread, location, access, and what you plan to do with the property afterward.
            </p>
        </div>

        <div class="sr-types-intro">
            <h3 class="sr-h3">What Types of Stump Removal Services Do We Offer?</h3>
            <p class="sr-text">
                Maple Majesty Tree Care offers stump removal solutions tailored to each property, given the various needs of each property. Whether the stump is small and residential or larger and commercial, our arborists will determine the type of equipment and approach needed to handle the situation, depending on the size, location and property conditions.
            </p>
        </div>

        <div class="sr-types-grid">

            <div class="sr-type-card">
                <div class="sr-type-content">
                    <h4 class="sr-h4">Large Stump Removal</h4>
                    <p class="sr-text">It is important to plan for large stump removal as mature trees have a large root system. The common causes of large stumps are:</p>
                    <ul class="sr-bullet-list">
                        <li>Mature maple trees</li>
                        <li>Oak trees</li>
                        <li>Storm-damaged trees</li>
                        <li>Removed hazardous trees</li>
                        <li>Old landscape trees</li>
                    </ul>
                    <p class="sr-text sr-text-last">Before removing, our team inspects the stump for diameter, root spread, access and surrounding structures. Cleanup of large stumps using professional equipment can be done safely to protect nearby lawns, gardens and hardscapes.</p>
                </div>
            </div>

            <div class="sr-type-card">
                <div class="sr-type-content">
                    <h4 class="sr-h4">Small Stump Removal</h4>
                    <p class="sr-text">Small stumps can seem easier to remove, but they can be problematic if not properly taken care of. Smaller stumps can still cause mowing problems, lure insects and hinder new landscaping.</p>
                    <p class="sr-text">Our stump removal services are ideal for the following:</p>
                    <ul class="sr-bullet-list">
                        <li>Recent tree removals (young trees)</li>
                        <li>Small ornamental trees</li>
                        <li>Backyard landscaping areas</li>
                        <li>Fence installation projects</li>
                        <li>Garden preparation</li>
                    </ul>
                    <p class="sr-text sr-text-last">We offer speedy removal services, ensuring your property is up for the next improvement.</p>
                </div>
            </div>

            <div class="sr-type-card">
                <div class="sr-type-content">
                    <h4 class="sr-h4">Bush Stump Removal</h4>
                    <p class="sr-text">Some bushes and shrubs will have a persistent root system that will be hard to pull up. Professional bush stump removal will get rid of the remaining roots and inhibit the regrowth of the bush.</p>
                    <p class="sr-text">This service can help with:</p>
                    <ul class="sr-bullet-list">
                        <li>Overgrown shrubs</li>
                        <li>Removed hedges</li>
                        <li>Landscaping redesign</li>
                        <li>Garden renovations</li>
                        <li>Property improvements</li>
                    </ul>
                    <p class="sr-text sr-text-last">Our staff conducts the removal of unwanted plant debris without disturbing adjacent landscape areas.</p>
                </div>
            </div>

            <div class="sr-type-card">
                <div class="sr-type-content">
                    <h4 class="sr-h4">Tree and Stump Removal</h4>
                    <p class="sr-text">If a tree has died from disease, storm damage, or structural problems, removing the tree may leave behind an unwanted stump.</p>
                    <p class="sr-text">Our tree and stump removal service offers a complete solution as it addresses the following:</p>
                    <ul class="sr-bullet-list">
                        <li>Tree removal</li>
                        <li>Stump extraction</li>
                        <li>Root removal</li>
                        <li>Debris cleanup</li>
                        <li>Landscape restoration</li>
                    </ul>
                    <p class="sr-text sr-text-last">Best for those who want their land totally clear and available for new use.</p>
                </div>
            </div>

            <div class="sr-type-card sr-type-card--wide">
                <div class="sr-type-content">
                    <h4 class="sr-h4">Emergency Stump Removal</h4>
                    <p class="sr-text">Trees may be broken, and stumps may be left dangerous after a storm event. Strong winds, heavy snow, and ice storms are common and can lead to tree failures in Buffalo.</p>
                    <p class="sr-text">In the case of an emergency stump removal, it might be necessary when:</p>
                    <ul class="sr-bullet-list sr-bullet-list--cols">
                        <li>A fallen tree leaves a dangerous stump</li>
                        <li>Storm damage blocks access areas</li>
                        <li>A stump creates a safety concern</li>
                        <li>Property repairs require immediate clearing</li>
                    </ul>
                    <p class="sr-text sr-text-last">We have solutions that can restore safe outdoor areas following identified and unforeseen tree damage.</p>
                </div>
            </div>

        </div>
    </div>
</section>

<!-- HOW OUR STUMP REMOVAL SERVICE WORKS -->
<section class="sub-service-section sr-process-section">
    <div class="container">

        <div class="text-center" style="max-width: 850px; margin: 0 auto 3.5rem auto;">
            <span class="global-subtitle">
                OUR PROCESS
            </span>
            <h2 class="global-section-title">How Our Stump Removal Service Works</h2>
            <div class="section-divider" style="margin: 1rem auto 1.5rem auto;"></div>
            
            <p style="font-size: 1.15rem; color: var(--color-brand-purple); font-weight: bold; margin-bottom: 1.5rem;">
                Professional stump removal starts with a site assessment and removal plan, followed by safe extraction, root removal when needed, debris cleanup, and site preparation.
            </p>
            
            <p style="font-size: 1.05rem; color: var(--color-text-gray); line-height: 1.7;">
                When hiring a professional stump removal near me, you have to do more than just pull out a stump. Our trained arborists at Maple Majesty Tree Care employ a methodical approach to safely and effectively remove stumps, ensuring your landscape, structures and neighboring plants are protected.
            </p>
        </div>

        <div class="sr-steps-timeline">
            <?php
            $steps = [
                ['num' => '1', 'title' => 'Property and Stump Assessment', 'desc' => 'Our Arborists are ISA-certified and inspect the stump and the surrounding area before removal. We assess size, species, roots, soil, utilities, and access points to decide on the best way to remove the tree from your property.'],
                ['num' => '2', 'title' => 'Creating a Removal Plan',        'desc' => 'Each stump-pulling job is unique. We take into account stump diameter, root spread, equipment access, landscape considerations, and plans for the property when determining the most efficient and safe removal strategy.'],
                ['num' => '3', 'title' => 'Preparing the Work Area',        'desc' => 'Our crew prepares for any site before the job begins, creates a safe work zone, safeguards neighboring landscaping, verifies equipment access, identifies obstacles, and confirms site conditions to ensure professional stump removal with minimal property disturbance.'],
                ['num' => '4', 'title' => 'Professional Stump Extraction',  'desc' => 'Our team uses special equipment and techniques to carefully harvest the stump and surrounding root material. Excavation equipment, stump grinders, and other professional cutting tools finish the job safely.'],
                ['num' => '5', 'title' => 'Removing Root Material',         'desc' => 'It may be necessary to remove large surface roots that are attached to the stump for a complete removal. Such root removal makes ground conditions better, prevents further problems, and readies the site for landscaping, building, or planting.'],
                ['num' => '6', 'title' => 'Cleanup and Landscape Preparation', 'desc' => 'Once removed, our crews remove wood debris, roots, and other waste from the area. The area can be cleared for new tree planting projects, grass, gardens, and walkways.'],
            ];
            foreach ($steps as $step) : ?>
                <div class="sr-step-card">
                    <div class="sr-step-num"><?php echo $step['num']; ?></div>
                    <div class="sr-step-body">
                        <h3 class="sr-h4"><?php echo $step['title']; ?></h3>
                        <p class="sr-text sr-text-last"><?php echo $step['desc']; ?></p>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

    </div>
</section>

<!-- DIY VS PROFESSIONAL -->
<section class="sub-service-section sr-diy-section">
    <div class="container">

        <div class="sr-section-header">
            <span class="global-subtitle">Make the Right Choice</span>
            <h2 class="sr-h2">DIY Stump Removal vs. Professional Service</h2>
            <p class="sr-intro-text">
                DIY methods may work for very small stumps, but professional removal is generally safer and more efficient for large stumps, deep roots, limited access, or areas near utilities.<br><br>
                Some homeowners look for the answer to the question, How much does stump removal cost because they are looking into doing it themselves. While self-removal can be cost-effective, stump removal is frequently a costly, complex, and physically demanding process.
            </p>
        </div>

        <div class="sr-diy-wrap">

            <div class="sr-diy-problems">
                <h3 class="sr-h3">DIY Stump Removal</h3>
                <p class="sr-text">Self-removal of stumps can be accomplished by digging, chemical treatments, burning, or hiring equipment. These can be effective on very small stumps, but sometimes present difficulties.</p>

                <h4 class="sr-h4 sr-problems-title">Common DIY Problems</h4>

                <div class="sr-problems-list">

                    <div class="sr-problem-item">
                        <div class="sr-problem-icon">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/safety.svg" alt="Labor">
                        </div>
                        <div class="sr-problem-content">
                            <strong class="sr-problem-title">Requires Significant Labor</strong>
                            <p class="sr-text sr-text-last">The roots of trees can spread far underground and be present in the stump. Hand digging can be a lengthy process, sometimes months or even years.</p>
                        </div>
                    </div>

                    <div class="sr-problem-item">
                        <div class="sr-problem-icon">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/safety.svg" alt="Safety">
                        </div>
                        <div class="sr-problem-content">
                            <strong class="sr-problem-title">Safety Risks</strong>
                            <p class="sr-text">If a large stump needs to be removed, this could include:</p>
                            <ul class="sr-sub-list">
                                <li>Heavy tools</li>
                                <li>Sharp equipment</li>
                                <li>Heavy lifting</li>
                                <li>Unstable ground conditions</li>
                            </ul>
                            <p class="sr-text sr-text-last">Without proper experience, injuries or property damage can occur.</p>
                        </div>
                    </div>

                    <div class="sr-problem-item">
                        <div class="sr-problem-icon">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/equipment.svg" alt="Equipment">
                        </div>
                        <div class="sr-problem-content">
                            <strong class="sr-problem-title">Equipment Challenges</strong>
                            <p class="sr-text sr-text-last">Rental stump removal equipment can be difficult to use. This can cause damage to the lawn, underground utilities, or neighboring structures if not used properly.</p>
                        </div>
                    </div>

                    <div class="sr-problem-item">
                        <div class="sr-problem-icon">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/complete.svg" alt="Incomplete">
                        </div>
                        <div class="sr-problem-content">
                            <strong class="sr-problem-title">Incomplete Removal</strong>
                            <p class="sr-text sr-text-last">Numerous DIY treatments only kill the above-ground part and leave behind large roots in the ground. Leaving a few roots can cause additional landscaping issues.</p>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>
</section>

<!-- BEST SEASON -->
<section class="sub-service-section sr-season-section">
    <div class="container">

        <div class="sr-section-header">
            <span class="global-subtitle">Year-Round Service</span>
            <h2 class="sr-h2">Best Season for Stump Removal in Western New York</h2>
            <p class="sr-intro-text">
            Stump removal can be completed year-round when soil and access conditions allow, though the best timing depends on weather, ground conditions, and future landscaping plans.
            </p>
        </div>

        <div class="sr-season-intro">
            <h3 class="sr-h3">When Is the Best Time for Tree Stump Removal Near Me?</h3>
            <p class="sr-text">
                Depending on your landscaping plans, weather conditions, and soil access, stump removal can be done all year round in Buffalo. Maple Majesty Tree Care offers stump removal in Western New York all year long. Seasonal weather conditions in Buffalo can pose a variety of challenges, such as lake-effect snow, freezing temperatures, rainfall in the spring, and freeze-thaw conditions.
            </p>
        </div>

        <div class="sr-seasons-grid">
            <?php
            $seasons = [
                [
                    'icon' => 'experience.svg',
                    'title' => 'Spring Stump Removal',
                    'desc' => 'Stump removal is a perfect time of year for spring, when homeowners are starting their landscaping and lawn improvement projects. Early stump removal allows for new lawns, gardens, patios and outdoor living spaces, while making a house look better following a winter.'
                ],
                [
                    'icon' => 'safety.svg',
                    'title' => 'Summer Stump Removal',
                    'desc' => 'Projects are more efficient during dry summer conditions that allow for easy access with removal equipment. Summer is the perfect time to do landscaping renovations, install fences, build patios, upgrade commercial properties and get yards ready for outdoor upgrades.'
                ],
                [
                    'icon' => 'honest.svg',
                    'title' => 'Fall Stump Removal',
                    'desc' => "The best time to cut stumps that you don't want is before Buffalo snows and freezes in the fall. Early removal removes tripping hazards, allows for preparation of landscapes for spring planting and makes winter property maintenance easier."
                ],
                [
                    'icon' => 'certified.svg',
                    'title' => 'Winter Stump Removal',
                    'desc' => 'If the weather and soil conditions allow safe operation of the equipment, stump removal can be accomplished in the winter. Useful after storms, emergency removals, construction and redevelopment, and when the ground is frozen, it may reduce lawn disturbance.'
                ],
            ];
            foreach ($seasons as $s) : ?>
                <div class="sr-season-card">
                    <h4 class="sr-h4"><?php echo $s['title']; ?></h4>
                    <p class="sr-text sr-text-last"><?php echo $s['desc']; ?></p>
                </div>
            <?php endforeach; ?>
        </div>

    </div>
</section>

<!-- LOCAL STUMP REMOVAL -->
<section class="sub-service-section sr-local-section">
    <div class="container">

        <div class="sr-section-header">
            <span class="global-subtitle">Service Areas</span>
            <h2 class="sr-h2">Local Stump Removal — Serving Buffalo Communities</h2>
            <p class="sr-intro-text">
             Local stump removal experience matters because Buffalo's freeze-thaw cycles, clay-heavy soils, mature tree species, and seasonal weather can affect both extraction and site restoration.
            </p>
        </div>

        <div class="sr-local-wrap">

            <div class="sr-local-content">
                <p class="sr-text">
                    Homeowners looking for tree stump removal near me should look for a local team that is familiar with Buffalo landscapes, weather and property issues. For residential and commercial properties, we offer a professional stump removal service in Buffalo and Western New York with Maple Majesty Tree Care. Lake-effect snow, ice accumulation, high wind, and freeze-thaw conditions can increase the decay of the stump and lead to unevenness in the ground, especially in Buffalo. Each stump is evaluated individually by our ISA-Certified Arborists, taking into account tree species, root structure and site-specific landscape conditions.
                </p>
                <p class="sr-text">
                    Whether it's a single stump from a residential yard or a larger project, our experienced team is equipped with professional tools and safe removal methods to restore your outdoor space without compromising your property.
                </p>

                <div class="sr-property-types">

                    <div class="sr-property-card">
                        <div class="sr-property-icon">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/experience.svg" alt="Residential">
                        </div>
                        <div>
                            <h3 class="sr-h4">Residential Stump Removal</h3>
                            <p class="sr-text sr-text-last">Stump removal is ideal for residential situations after tree removal, storm damage, diseased trees or landscaping upgrades. The removal of old stumps makes your yard safer, frees up yard space, adds to the curb appeal, and helps get your yard ready for future gardens, patios, or planting.</p>
                        </div>
                    </div>

                    <div class="sr-property-card">
                        <div class="sr-property-icon">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/certified.svg" alt="Commercial">
                        </div>
                        <div>
                            <h3 class="sr-h4">Commercial Stump Removal</h3>
                            <p class="sr-text sr-text-last">Commercial Stump Removal is crucial for businesses, apartments, schools, parks, retail areas and construction sites to keep their properties looking safe and professional. We strive to be efficient and do as little as possible to disrupt the property when preparing for development, maintenance, or any improvements in the landscape you want to make in the future.</p>
                        </div>
                    </div>

                </div>
            </div>

            <div class="sr-communities-box">
                <h3 class="sr-h3-white">Buffalo Communities We Serve</h3>
                <p class="sr-text-white">Maple Majesty Tree Care is a proud service provider to Buffalo and the surrounding Western New York regions.</p>
                <p class="sr-text-white">We service the following areas:</p>
                <ul class="sr-communities-list">
                    <?php
                    $areas = ['Buffalo', 'Amherst', 'Cheektowaga', 'Tonawanda', 'Williamsville', 'West Seneca', 'Hamburg', 'Orchard Park'];
                    foreach ($areas as $area) : ?>
                        <li>
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/checkmark.svg" alt="Check" class="sr-check-icon">
                            <span><?php echo $area; ?></span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>

        </div>
    </div>
</section>

<!-- WHY TRUST US -->
<section class="sub-service-section sr-trust-section">
    <div class="container">

        <div class="sr-section-header">
            <span class="global-subtitle">Our Expertise</span>
            <h2 class="sr-h2">Why Trust Us With Your Stump Removal Needs?</h2>
            <p class="sr-intro-text">
                It is crucial to hire the right one for stump removal Buffalo NY, since failing to do so can lead to possible issues in the future or affect surrounding landscaping. The combination of certified expertise, expert equipment and local experience provide Maple Majesty Tree Care with dependable stump removal solutions.
            </p>
        </div>

        <div class="sr-trust-grid">
            <?php
            $trust_items = [
                [
                    'icon' => 'certified.svg',
                    'title' => 'ISA-Certified Arborist Knowledge',
                    'desc' => 'Our ISA-Certified Arborists know the biology of trees, root systems and tree removal practices. Every stump is thoroughly evaluated to decide the most appropriate means of removal, equipment needed, safety measures and what should be done to restore your property.'
                ],
                [
                    'icon' => 'equipment.svg',
                    'title' => 'Professional Equipment and Techniques',
                    'desc' => 'Stumps of any size are removed safely with high-quality equipment. We are equipped with specialized machinery to precisely and efficiently handle deep root systems, limited access, commercial projects and emergency stump removal.'
                ],
                [
                    'icon' => 'safety.svg',
                    'title' => 'Safety-Focused Work Practices',
                    'desc' => 'On any project, safety is the primary concern. Before removal, we conduct a stump inspection, evaluate surrounding structures, underground utilities, equipment access and ground stability to safeguard your property and to ensure safe operations.'
                ],
                [
                    'icon' => 'honest.svg',
                    'title' => 'Honest Recommendations',
                    'desc' => 'All properties are unique. We are able to provide honest information and advice about the choice that best fits your landscape, future plans, and budget, ranging from stump removal to stump grinding to root removal to other landscape maintenance services.'
                ],
                [
                    'icon' => 'experience.svg',
                    'title' => 'Experience With Buffalo Conditions',
                    'desc' => 'Heavy snow, ice storms, freeze-thaw and old trees pose special challenges in Buffalo. The knowledge of our local experience enables us to suggest solutions for stump removal that will ensure the safety and usability of your property for the whole year.'
                ],
                [
                    'icon' => 'complete.svg',
                    'title' => 'Complete Tree Care Services',
                    'desc' => 'In addition to stump removal, Maple Majesty Tree Care will provide tree removal, emergency tree services, tree trimming, tree pruning, stump grinding, land clearing, and storm damage cleanup services for year-round tree care.'
                ],
            ];
            foreach ($trust_items as $item) : ?>
                <div class="sr-trust-card">
                    <div class="sr-trust-icon">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/<?php echo $item['icon']; ?>" alt="<?php echo $item['title']; ?>">
                    </div>
                    <div class="sr-trust-body">
                        <h3 class="sr-h4"><?php echo $item['title']; ?></h3>
                        <p class="sr-text sr-text-last"><?php echo $item['desc']; ?></p>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

    </div>
</section>

<!-- STUMP REMOVAL COST -->
<section class="sub-service-section sr-cost-section">
    <div class="container">

        <div class="sr-section-header">
            <span class="global-subtitle">Transparent Pricing</span>
            <h2 class="sr-h2">Stump Removal Cost in Buffalo, NY</h2>
        </div>

        <div class="sr-cost-wrap">

            <div class="sr-cost-content">
                <h3 class="sr-h3">How Much Does Stump Removal Cost?</h3>
                <p class="sr-text">
                    Stump removal prices in Buffalo, NY can vary based on the size of the stump, root system complexity, species of the tree, access to the area, soil type, equipment needed, etc. The size of a stump and the quantity and length of roots generally require more labor and specialized equipment.
                </p>
                <p class="sr-text">
                    Complete stump removal is done by removing the stump and most of the root material, and can influence the overall project cost.
                </p>
                <p class="sr-text">
                    We offer no hidden charges and give you a clear quote after an inspection at Maple Majesty Tree Care. Before our arborists start work, we assess your property and outline the best method of removal.
                </p>

                <h4 class="sr-h4 sr-factors-title">Factors That Influence Stump Removal Prices</h4>
                <ul class="sr-factors-list">
                    <li>
                        <strong>Stump Diameter:</strong> Larger stumps require more labor, time, and specialized equipment, increasing the overall removal cost.
                    </li>
                    <li>
                        <strong>Tree Species:</strong> Hardwoods like oak and maple typically have stronger wood and larger root systems, making removal more challenging.
                    </li>
                    <li>
                        <strong>Root System:</strong> Extensive underground roots require additional excavation and removal, which can increase project time and cost.
                    </li>
                    <li>
                        <strong>Accessibility:</strong> Stumps near buildings, fences, driveways, gardens, or utility lines may require specialized equipment and careful planning.
                    </li>
                    <li>
                        <strong>Number of Stumps:</strong> Removing multiple stumps during one visit is often more cost-effective than scheduling separate removal projects.
                    </li>
                    <li>
                        <strong>Cleanup &amp; Restoration:</strong> Services such as debris removal, soil replacement, grading, and landscape preparation may affect the final project estimate.
                    </li>
                </ul>
            </div>

            <div class="sr-cost-table-wrap">
                <h4 class="sr-cost-table-title">Estimated Stump Removal Pricing Table</h4>
                <table class="sr-price-table">
                    <thead>
                        <tr>
                            <th>Stump Size</th>
                            <th>Estimated Cost Range</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Small Stump (Up to 12 inches diameter)</td>
                            <td>$150 – $250</td>
                        </tr>
                        <tr>
                            <td>Medium Stump (13–24 inches diameter)</td>
                            <td>$250 – $450</td>
                        </tr>
                        <tr>
                            <td>Large Stump (25–36 inches diameter)</td>
                            <td>$450 – $700</td>
                        </tr>
                        <tr>
                            <td>Extra Large Stump (37+ inches diameter)</td>
                            <td>Custom Quote</td>
                        </tr>
                    </tbody>
                </table>
                <p class="sr-cost-note">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                    Prices are estimates only. Contact us for a free on-site assessment and accurate quote.
                </p>
            </div>

        </div>
    </div>
</section>

<!-- NEAR ME SECTION -->
<section class="sub-service-section sr-nearme-section">
    <div class="container">
        <div class="sr-nearme-wrap">

            <div class="sr-nearme-content">
                <span class="global-subtitle">Find Us Locally</span>
                <h2 class="sr-h2">Stump Removal Near Me — Buffalo &amp; Western New York</h2>
                <p class="sr-text">
                    Searching for stump removal near me means finding a local company that understands your area's landscape conditions. Maple Majesty Tree Care provides professional stump removal Buffalo NY services throughout Buffalo and surrounding Western New York communities.
                </p>
                <p class="sr-text">
                    We can safely and efficiently extract unwanted stumps from the ground for homeowners, businesses, contractors and property managers.
                </p>
                <p class="sr-text"><strong>Service Areas Include:</strong></p>
                <ul class="sr-areas-grid">
                    <?php
                    $areas = ['Buffalo', 'Amherst', 'Cheektowaga', 'Tonawanda', 'Williamsville', 'West Seneca', 'Hamburg', 'Orchard Park', 'Clarence', 'Lancaster & Depew'];
                    foreach ($areas as $area) : ?>
                        <li>
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/checkmark.svg" alt="Check" class="sr-area-check">
                            <span><?php echo $area; ?></span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>

            <div class="sr-nearme-cta">
                <div class="sr-nearme-card">
                    <div class="sr-nearme-icon">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/experience.svg" alt="Local">
                    </div>
                    <h3 class="sr-h3">Serving Western New York</h3>
                    <p class="sr-text">Our locally experienced team knows Buffalo's unique weather conditions, clay soils, and mature tree species — delivering precise, safe stump removal every time.</p>
                    <a href="tel:+17164000763" class="btn-yellow sr-nearme-btn">
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
                        Call Now
                    </a>
                </div>
            </div>

        </div>
    </div>
</section>

<!-- CALL TO ACTION CLOSING -->
<section class="sub-service-section sr-cta-section">
    <div class="container sr-cta-inner">
        <span class="sr-eyebrow sr-eyebrow--white">Get Started Today</span>
        <h2 class="sr-cta-h2">Ready to Remove That Stump?</h2>
        <p class="sr-cta-text">
            Contact Maple Majesty Tree Care today for professional stump removal services in Buffalo, NY. Let our ISA-Certified Arborists clear your property quickly and safely.
        </p>
        <div class="sr-cta-buttons">
            <a href="tel:+17164000763" class="btn-primary">
                Call Now
            </a>
            <a href="<?php echo esc_url(site_url('/contact/')); ?>" class="btn-secondary">
                Request Free Quote
            </a>
        </div>
    </div>
</section>
