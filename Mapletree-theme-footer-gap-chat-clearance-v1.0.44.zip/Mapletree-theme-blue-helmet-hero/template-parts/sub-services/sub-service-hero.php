<?php
/**
 * Sub Service Hero Section Template Part
 * Used on specific sub-service pages.
 */

// Default Fallback Data
$title = get_the_title();
$subtitle = '';
$description = 'Our emergency tree service provides fast, professional removal of fallen, damaged, and hazardous trees across Buffalo and Western New York, available 24 hours daily, year-round.';
$trust_signals = [
    'Licensed & Insured Tree Care Professionals',
    'ISA-Certified Arborists',
    '4.9<span class="star-icon">' . (file_exists(get_template_directory() . '/assets/icons/star.svg') ? file_get_contents(get_template_directory() . '/assets/icons/star.svg') : '★') . '</span> Google Rating',
    '24/7 Emergency Response',
    'Serving Buffalo and Western New York'
];
$btn_primary_text = 'Call Now';
$btn_secondary_text = 'Free Estimate';

// Check for the Master JSON Field: 'sub_service_hero_data'
$hero_json_raw = get_post_meta(get_the_ID(), 'sub_service_hero_data', true);
if (function_exists('get_field') && get_field('sub_service_hero_data')) {
    $hero_json_raw = get_field('sub_service_hero_data');
}


$json_parsed = false;
if (!empty($hero_json_raw)) {
    $hero_data = json_decode($hero_json_raw, true);
    if (is_array($hero_data)) {
        $json_parsed = true;
        if (!empty($hero_data['title']))
            $title = $hero_data['title'];
        if (!empty($hero_data['description']))
            $description = $hero_data['description'];
        if (!empty($hero_data['trust_signals']) && is_array($hero_data['trust_signals'])) {
            $trust_signals = $hero_data['trust_signals'];
        }
        if (!empty($hero_data['btn_primary_text'])) {
            $btn_primary_text = $hero_data['btn_primary_text'];
        }
        if (!empty($hero_data['btn_secondary_text'])) {
            $btn_secondary_text = $hero_data['btn_secondary_text'];
        }
    }
}

// Fallback to individual fields if JSON was not provided or failed to parse
if (!$json_parsed) {
    // Title
    $custom_title = get_post_meta(get_the_ID(), 'sub_service_title', true);
    if (function_exists('get_field') && get_field('sub_service_title')) {
        $custom_title = get_field('sub_service_title');
    }
    if (!empty($custom_title))
        $title = $custom_title;

    // Subtitle
    $custom_subtitle = get_post_meta(get_the_ID(), 'sub_service_subtitle', true);
    if (function_exists('get_field') && get_field('sub_service_subtitle')) {
        $custom_subtitle = get_field('sub_service_subtitle');
    }
    if (!empty($custom_subtitle))
        $subtitle = $custom_subtitle;

    // Description
    $custom_description = get_post_meta(get_the_ID(), 'sub_service_description', true);
    if (function_exists('get_field') && get_field('sub_service_description')) {
        $custom_description = get_field('sub_service_description');
    }
    if (!empty($custom_description)) {
        $description = $custom_description;
    } elseif (has_excerpt()) {
        $description = get_the_excerpt();
    }

    // Trust Signals
    $trust_signals_raw = get_post_meta(get_the_ID(), 'sub_service_trust_signals', true);
    if (function_exists('get_field') && get_field('sub_service_trust_signals')) {
        $trust_signals_raw = get_field('sub_service_trust_signals');
    }
    if (!empty($trust_signals_raw)) {
        $json_decoded = json_decode($trust_signals_raw, true);
        if (is_array($json_decoded)) {
            $trust_signals = $json_decoded;
        } else {
            $trust_signals = array_filter(array_map('trim', explode("\n", $trust_signals_raw)));
        }
    }
}

// Button Texts
$custom_btn_primary = get_post_meta(get_the_ID(), 'sub_service_hero_btn_primary_text', true);
if (function_exists('get_field') && get_field('sub_service_hero_btn_primary_text')) {
    $custom_btn_primary = get_field('sub_service_hero_btn_primary_text');
}
if (!empty($custom_btn_primary)) {
    $btn_primary_text = $custom_btn_primary;
}

$custom_btn_secondary = get_post_meta(get_the_ID(), 'sub_service_hero_btn_secondary_text', true);
if (function_exists('get_field') && get_field('sub_service_hero_btn_secondary_text')) {
    $custom_btn_secondary = get_field('sub_service_hero_btn_secondary_text');
}
if (!empty($custom_btn_secondary)) {
    $btn_secondary_text = $custom_btn_secondary;
}


// Use unique image if available, else fallback
$hero_image_url = '';

// Check ACF field first
if (function_exists('get_field') && get_field('sub_service_hero_image')) {
    $acf_image = get_field('sub_service_hero_image');
    if (is_array($acf_image) && !empty($acf_image['url'])) {
        $hero_image_url = $acf_image['url'];
    } elseif (is_string($acf_image) && !empty($acf_image)) {
        $hero_image_url = $acf_image;
    }
}

// Fallback to Featured Image
if (empty($hero_image_url)) {
    $hero_image_url = get_the_post_thumbnail_url(get_the_ID(), 'full');
}

// Fallback to default
if (empty($hero_image_url)) {
    $hero_image_url = get_template_directory_uri() . '/assets/images/sub_service_hero_bg.webp';
}

$icon_path = get_template_directory() . '/assets/icons/';
?>

<link rel="preload" href="<?php echo esc_url($hero_image_url); ?>" as="image" type="image/webp" fetchpriority="high">

<section class="inner-hero-section sub-service-hero-section"
    style="background-image: url('<?php echo esc_url($hero_image_url); ?>'); background-color: var(--color-forest-green); background-size: contain; background-position: right center; background-repeat: no-repeat; position: relative; isolation: isolate;">
    <div class="sub-service-hero-glass-layer" aria-hidden="true" style="position: absolute; inset: 0; z-index: 1; background: rgba(4, 20, 20, .62); -webkit-backdrop-filter: blur(2px); backdrop-filter: blur(2px); pointer-events: none;"></div>
    <div class="inner-hero-container">
        <!-- Centered Content -->
        <div class="inner-hero-content-col centered-hero">
            <h1 class="inner-hero-title"><?php echo esc_html($title); ?></h1>
            <p class="inner-hero-description"><?php echo wp_kses_post($description); ?></p>

            <?php if (!empty($trust_signals)): ?>
                <ul class="sub-service-trust-signals">
                    <?php foreach ($trust_signals as $signal): ?>
                        <li>
                            <span class="check-icon">
                                <?php
                                if (file_exists($icon_path . 'check-circle.svg')) {
                                    echo file_get_contents($icon_path . 'check-circle.svg');
                                } else {
                                    echo 'â€¢';
                                }
                                ?>
                            </span>
                            <?php echo wp_kses_post($signal); ?>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>

            <div class="hero-buttons fade-up" style="animation-delay: 0.6s;">
                <a href="tel:+17164000763" class="btn-primary">
                    <?php echo file_get_contents(get_template_directory() . '/assets/icons/phone-call.svg'); ?>
                    <?php echo esc_html($btn_primary_text); ?>
                </a>
                <a href="<?php echo site_url('/contact/'); ?>" class="btn-secondary">
                    <?php echo file_get_contents(get_template_directory() . '/assets/icons/message.svg'); ?>
                    <?php echo esc_html($btn_secondary_text); ?>
                </a>
            </div>
            <nav class="sub-service-hero-breadcrumb" aria-label="Breadcrumb">
                <a href="<?php echo esc_url(home_url('/')); ?>">Home</a>
                <span aria-hidden="true">–</span>
                <a href="<?php echo esc_url(home_url('/services/')); ?>">Tree Services Buffalo, NY</a>
                <span aria-hidden="true">–</span>
                <span aria-current="page"><?php echo esc_html(get_the_title()); ?></span>
            </nav>
        </div>
    </div>

    <!-- Bottom SVG Wave Divider -->
    <div class="inner-hero-wave">
        <svg viewBox="0 0 1440 120" preserveAspectRatio="none">
            <path fill="var(--color-soft-lilac)"
                d="M0,60 C320,120 420,0 720,60 C1020,120 1120,0 1440,60 L1440,120 L0,120 Z"></path>
        </svg>
    </div>
</section>
