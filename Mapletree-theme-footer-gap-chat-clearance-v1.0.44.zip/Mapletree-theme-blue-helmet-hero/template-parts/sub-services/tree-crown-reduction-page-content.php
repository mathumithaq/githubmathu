<?php
/**
 * Template part for displaying Tree Crown Reduction page content
 */

// Helper to safely render inline SVGs
if (!function_exists('tcr_render_svg')) {
    function tcr_render_svg($filename) {
        $path = get_template_directory() . '/assets/icons/' . $filename;
        if (file_exists($path)) {
            return file_get_contents($path);
        }
        return '';
    }
}
?>


<!-- UNDERSTANDING CROWN REDUCTION -->
<section class="sub-service-section tcr-intro-section">
    <div class="container">
        <div class="tcr-intro-wrap">

            <div class="tcr-intro-content">
                <span class="global-subtitle">Expert Crown Management</span>
                <h2 class="tcr-h2">Understanding Professional Crown Reduction</h2>

                <div class="tcr-takeaway">
                Crown reduction selectively shortens appropriate branches to reduce canopy size and weight while preserving the tree's natural form, structural integrity, and long-term health.
                </div>

                <p class="tcr-text">
                    Tree crown reduction is a professional pruning practice that involves selectively pruning a tree to make it smaller without harming the tree or altering its form. Crown reduction differs from topping in that it involves strategic cuts that are used to enhance structure, stress reduction, and better growth.
                </p>
                <p class="tcr-text">
                    Crown reduction is often a choice for many Buffalo homeowners when trees grow too large for their environment and their branches grow over roofs, block out the sunlight, or present a storm hazard. Our arborists assess tree species, health, branch structure, damage, and surrounding structures before recommending the proper course of action.
                </p>
                <p class="tcr-text">
                    Big tree canopies may be stressed by the heavy snow, ice and strong winds in Buffalo. Good pruning of the crowns contributes to stability, prevents risks of branch failure and helps to prevent property damage.
                </p>
                <p class="tcr-text">These are the trees that are regularly considered for crown reduction:</p>
                <ul class="tcr-bullet-list">
                    <li>Mature trees with excessive growth</li>
                    <li>Trees near homes or utility lines</li>
                    <li>Storm-damaged trees</li>
                    <li>Trees with uneven branch structure</li>
                </ul>
                <p class="tcr-text tcr-text-last">Safe pruning techniques that benefit the tree's health, safety and appearance are used at Maple Majesty Tree Care.</p>
            </div>
        </div>
    </div>
</section>

<!-- TOP BENEFITS -->
<section class="sub-service-section tcr-benefits-section">
    <div class="container">

        <div class="tcr-section-header">
            <span class="global-subtitle">Why It Matters</span>
            <h2 class="tcr-h2">Top Benefits of Tree Crown Reduction</h2>
            <p class="tcr-intro-text">
             Professional crown reduction can reduce excessive canopy weight, improve clearance and structural balance, and lower the risk of branch failure while maintaining the tree's natural appearance.
            </p>
        </div>

        <div class="tcr-benefits-intro-text">
            <p class="tcr-text tcr-text-last">Buffalo's snow, ice, and strong winds can put stress on large tree canopies. A professional crown reduction tree service reduces excess weight, helping improve stability and lower the risk of broken branches.</p>
        </div>

        <div class="tcr-benefits-grid">
            <?php
            $benefits = [
                [
                    'icon' => 'safety.svg',
                    'title' => 'Reduces Storm Damage Risk',
                    'desc' => "Large tree canopies may become stressed due to the snow, ice, and strong winds in Buffalo. A tree crown reduction service can help your tree avoid damage to its branches and improve its stability due to excess weight."
                ],
                [
                    'icon' => 'honest.svg',
                    'title' => 'Protects Your Property',
                    'desc' => 'Trees with overgrown branches that are close to roofs, garages, fences and walkways can be dangerous. Crown reduction provides clearance and helps to reduce the risk of damage to property.'
                ],
                [
                    'icon' => 'complete.svg',
                    'title' => 'Maintains Natural Tree Shape',
                    'desc' => 'Crown reduction services do not involve any unnatural or unprofessional techniques to the tree and will actually enhance the balance of the canopy.'
                ],
                [
                    'icon' => 'certified.svg',
                    'title' => 'Improves Tree Health and Structure',
                    'desc' => 'Thinning the excessive canopy helps develop healthier branch structure and more air circulation in the long run.'
                ],
                [
                    'icon' => 'experience.svg',
                    'title' => 'Enhances Your Landscape',
                    'desc' => 'A balanced canopy will let more sunlight into your lawn and garden, while also making it a safer and more beautiful outside area.'
                ],
            ];
            foreach ($benefits as $b) : ?>
                <div class="tcr-benefit-card">
                    <div class="tcr-benefit-body">
                        <h3 class="tcr-h4"><?php echo $b['title']; ?></h3>
                        <p class="tcr-text tcr-text-last"><?php echo $b['desc']; ?></p>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

    </div>
</section>

<!-- WHEN TO USE CROWN REDUCTION -->
<section class="sub-service-section tcr-when-section">
    <div class="container">

        <div class="tcr-section-header">
            <span class="global-subtitle">Knowing When to Act</span>
            <h2 class="tcr-h2">When to Use Crown Reduction on a Tree</h2>
            <p class="tcr-intro-text">
            Crown reduction may be appropriate when a tree has outgrown its available space, develops an unbalanced canopy, interferes with structures, or has branches that create safety or storm-related concerns.
            </p>
        </div>

        <div class="tcr-when-wrap">

            <div class="tcr-when-content">
                <p class="tcr-text">Tree service crown reduction is an excellent way to control large tree crowns, enhance safety and maintain long-term tree health. Our Maple Majesty Tree Care arborists assess each tree's condition, location and structure before suggesting the appropriate pruning method.</p>
                <p class="tcr-text">Crown reduction can be useful in the following situations:</p>

                <ul class="tcr-situation-list">
                    <?php
                    $situations = [
                        ['icon' => 'experience.svg', 'bold' => 'Trees outgrow their space', 'rest' => ': Trees\' branches reach over homes, driveways, patios or other property lines.'],
                        ['icon' => 'safety.svg',     'bold' => 'Branches create safety risks', 'rest' => ': Branches that overhang roofs or structures may become hazards in a storm.'],
                        ['icon' => 'certified.svg',  'bold' => 'Winter weather increases stress', 'rest' => ': Buffalo snow, ice and/or strong winds can put additional weight on large canopies.'],
                        ['icon' => 'equipment.svg',  'bold' => 'Trees grow near power lines', 'rest' => ': Professional pruning can help to keep trees clear of power lines.'],
                        ['icon' => 'complete.svg',   'bold' => 'Trees have uneven growth', 'rest' => ': Thin back branches to balance and stabilize the tree.'],
                        ['icon' => 'honest.svg',     'bold' => 'Trees are damaged by storms', 'rest' => ': Crown reduction can provide some stress relief after a professional assessment.'],
                        ['icon' => 'experience.svg', 'bold' => 'Large canopies block sunlight', 'rest' => ': Tree size can be controlled for improved space without removal.'],
                    ];
                    foreach ($situations as $sit) : ?>
                        <li>
                            <div><strong><?php echo $sit['bold']; ?></strong><?php echo $sit['rest']; ?></div>
                        </li>
                    <?php endforeach; ?>
                </ul>

                <p class="tcr-text tcr-text-last">Our arborists will know if crown reduction, tree trimming or some other solution is best for your property.</p>
            </div>

            <div class="tcr-signs-box">
                <h3 class="tcr-h3-white">Signs Your Tree Needs Crown Reduction</h3>
                <p class="tcr-text-white">The following are some signs that your tree needs crown reduction:</p>
                <ul class="tcr-signs-list">
                    <?php
                    $signs = [
                        'Large branches over your roof',
                        'Excessive canopy growth',
                        'Rubbing or weak branches',
                        'Heavy limbs after snowfall',
                        'Reduced sunlight in your yard',
                        'Previous storm damage',
                    ];
                    foreach ($signs as $sign) : ?>
                        <li>
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/checkmark.svg" alt="Check" class="tcr-check-icon tcr-check-white">
                            <span><?php echo $sign; ?></span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>

        </div>
    </div>
</section>

<!-- HOW CROWN REDUCTION SERVICES WORK -->
<section class="sub-service-section tcr-process-section">
    <div class="container">

        <div class="tcr-section-header">
            <span class="global-subtitle">Our Process</span>
            <h2 class="tcr-h2">How Crown Reduction Services Work</h2>
            <p class="tcr-intro-text">
                Professional crown reduction begins with a tree assessment and customized pruning plan, followed by selective branch reduction, safe pruning techniques, cleanup, and final inspection.<br><br>
                Here at Maple Majesty Tree Care, our crown reduction services are carefully performed to enhance the safety of the tree without compromising its long-term health.
            </p>
        </div>

        <div class="tcr-process-steps">
            <?php
            $steps = [
                ['num' => '1', 'title' => 'Tree Assessment',          'desc' => 'Our arborists evaluate the species, health, shape, placement, and hazard potential of the tree to decide if crown reduction is a suitable solution.'],
                ['num' => '2', 'title' => 'Customized Pruning Plan',  'desc' => "You will need to take a different approach to each tree. We develop a pruning strategy that will leave the tree in a natural form with just the required branches being cut off."],
                ['num' => '3', 'title' => 'Selective Branch Reduction','desc' => 'We carefully remove selected branches to reduce canopy size, balance, and allow for healthy growth without over-pruning.'],
                ['num' => '4', 'title' => 'Safe Tree Pruning',         'desc' => 'We employ professional equipment and numerous techniques to safely perform crown reduction in and around homes, vehicles, fences and other structures.'],
                ['num' => '5', 'title' => 'Cleanup and Final Inspection','desc' => 'Once pruned, we clean up debris and leave your property tidy and orderly while maintaining safety and appearance standards.'],
            ];
            foreach ($steps as $step) : ?>
                <div class="tcr-step-card">
                    <div class="tcr-step-num"><?php echo $step['num']; ?></div>
                    <div class="tcr-step-body">
                        <h3 class="tcr-h4"><?php echo $step['title']; ?></h3>
                        <p class="tcr-text tcr-text-last"><?php echo $step['desc']; ?></p>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

    </div>
</section>

<!-- CROWN REDUCTION SERVICES IN YOUR BUFFALO NEIGHBORHOOD -->
<section class="sub-service-section tcr-local-section">
    <div class="container">
        <div class="tcr-local-wrap">

            <div class="tcr-local-content">
                <span class="global-subtitle">Service Areas</span>
                <h2 class="tcr-h2">Crown Reduction Services in Your Buffalo Neighborhood</h2>
                <div class="tcr-takeaway">
                Buffalo trees face varying snow, ice, wind, property-space, and canopy-clearance challenges, making local knowledge important when planning safe and appropriate crown reduction.
                </div>
                <p class="tcr-text">
                    Climatic, urban and landscape conditions place unique stresses on trees throughout Buffalo. At Maple Majesty Tree Care, we offer trustworthy tree crown reduction for homeowners in Buffalo neighborhoods and nearby areas.
                </p>
                <p class="tcr-text">
                    From established home streets with old trees to new developments with newly established trees, our team is familiar with tree care needs for Western New York properties.
                </p>
                <p class="tcr-text">If you have just one tree in your backyard or several trees that need to be maintained professionally, our team is ready and waiting to help you.</p>

                <div class="tcr-local-cta-btns">
                    <a href="tel:+17164000763" class="btn-primary">
                        Call Now
                    </a>
                    <a href="<?php echo esc_url(site_url('/contact/')); ?>" class="btn-secondary">Get a Free Quote</a>
                </div>
            </div>

            <div class="tcr-neighborhoods-box">
                <h3 class="tcr-h3-white">Neighborhoods We Serve in Buffalo and Western New York</h3>
                <p class="tcr-text-white">Maple Majesty Tree Care is a proud service provider to homeowners in the surrounding areas of Buffalo, including:</p>
                <ul class="tcr-neighborhoods-list">
                    <?php
                    $hoods = ['Elmwood Village', 'North Buffalo', 'Allentown', 'Delaware District', 'South Buffalo', 'West Side', 'University Heights', 'Riverside', 'Kenmore', 'Amherst', 'Cheektowaga', 'Tonawanda', 'West Seneca', 'Hamburg', 'Williamsville'];
                    foreach ($hoods as $hood) : ?>
                        <li>
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/checkmark.svg" alt="Check" class="tcr-check-icon tcr-check-white">
                            <span><?php echo $hood; ?></span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>

        </div>
    </div>
</section>

<!-- WHY TRUST US WITH YOUR CROWN REDUCTION NEEDS -->
<section class="sub-service-section tcr-trust-section">
    <div class="container">

        <div class="tcr-section-header">
            <span class="global-subtitle">Our Expertise</span>
            <h2 class="tcr-h2">Why Trust Us With Your Crown Reduction Needs?</h2>
            <p class="tcr-intro-text">
               Proper crown reduction requires knowledge of tree biology, structural growth, pruning techniques, and site safety to reduce canopy size without unnecessarily compromising tree health.
            </p>
        </div>

        <div class="tcr-trust-wrap">

            <div class="tcr-trust-content">
                <p class="tcr-text">
                    When dealing with large trees, it's crucial to select the appropriate tree care business. For crown reduction to be done professionally, it requires an understanding of tree biology, safe pruning practices, and correct assessment of tree structure.
                </p>
                <p class="tcr-text">
                    At Maple Majesty Tree Care, we provide expert tree crown reduction Buffalo NY services focused on safety, tree health, and quality results. Our arborists carefully evaluate each tree and create a customized plan to reduce canopy size while preserving its natural beauty.
                </p>
            </div>

            <div class="tcr-trust-cards">
                <?php
                $trust_items = [
                    [
                        'icon' => 'certified.svg',
                        'title' => 'Experienced Arborists',
                        'desc' => 'Each tree will react in a different way to pruning. We know how trees grow, how to prune them safely, how to assess their structural issues and how to deal with the seasonal weather issues that happen in Buffalo.'
                    ],
                    [
                        'icon' => 'experience.svg',
                        'title' => 'Local Buffalo Tree Care Expertise',
                        'desc' => 'Mature trees may undergo stress due to heavy snow, ice storms, and strong winds in Buffalo. Western New York landscapes require the proper maintenance approach, and our local knowledge enables us to make the right recommendation.'
                    ],
                    [
                        'icon' => 'safety.svg',
                        'title' => 'Safety-Focused Service',
                        'desc' => 'Pruning trees can be dangerous, particularly if they are in contact with a house, a car or overhead power lines. We have professional equipment and proven techniques to keep you safe and secure and ensure a safe project completion.'
                    ],
                    [
                        'icon' => 'equipment.svg',
                        'title' => 'Professional Equipment',
                        'desc' => 'We use industry-standard, commercial-grade pruning tools for every job. The right equipment ensures precise, safe cuts that protect both your tree and your property.'
                    ],
                    [
                        'icon' => 'honest.svg',
                        'title' => 'Honest Recommendations',
                        'desc' => 'Not every tree needs crown reduction. We provide an honest assessment and will recommend tree trimming, crown lifting, or another approach if that\'s the better solution for your tree.'
                    ],
                    [
                        'icon' => 'complete.svg',
                        'title' => 'Complete Cleanup Included',
                        'desc' => 'After every crown reduction, we remove all branches, leaves, and debris from your property. We leave your yard clean, tidy, and ready for the next season.'
                    ],
                ];
                foreach ($trust_items as $item) : ?>
                    <div class="tcr-trust-card">
                        <div class="tcr-trust-body">
                            <h3 class="tcr-h4"><?php echo $item['title']; ?></h3>
                            <p class="tcr-text tcr-text-last"><?php echo $item['desc']; ?></p>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

        </div>
    </div>
</section>

<!-- PROTECTING TREES AND PROPERTY -->
<section class="sub-service-section tcr-protect-section">
    <div class="container">
        <h3 class="tcr-h3">Protecting Your Trees and Property</h3>
        <p class="tcr-text">
            Trees make your landscape attractive, shady, and valuable. Crown reduction benefits existing trees by decreasing stress, increasing stability, and decreasing potential hazard.
        </p>
    </div>
</section>

<!-- GET A FREE QUOTE (MID CTA) -->
<section class="sub-service-section tcr-mid-cta-section">
    <div class="container">
        <div class="tcr-mid-cta-wrap">
            <div class="tcr-mid-cta-content">
                <h2 class="tcr-h2">Get a Free Tree Crown Reduction Quote in Buffalo, NY</h2>
                <p class="tcr-text">
                    Your trees are an important part of your property, but overgrown branches can create unnecessary risks. Professional tree crown reduction Buffalo NY services from Maple Majesty Tree Care help homeowners maintain safer, healthier, and more attractive landscapes.
                </p>
                <p class="tcr-text">
                    Whether your tree has become too large for its space, has branches near your home, or needs preparation before Buffalo's harsh weather seasons, our experienced arborists are ready to help. We provide careful evaluations, professional recommendations, and reliable pruning solutions designed around your tree's specific needs.
                </p>
            </div>
            <div class="tcr-mid-cta-box">
                <h3 class="tcr-h3">Why Choose Maple Majesty Tree Care?</h3>
                <p class="tcr-text">When you choose our team, you receive:</p>
                <ul class="tcr-check-list-dark">
                    <li><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/checkmark.svg" alt="Check" class="tcr-check-icon"> Experienced Local Arborists</li>
                    <li><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/checkmark.svg" alt="Check" class="tcr-check-icon"> Safe and Professional Pruning Methods</li>
                    <li><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/checkmark.svg" alt="Check" class="tcr-check-icon"> Buffalo Weather Expertise</li>
                    <li><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/checkmark.svg" alt="Check" class="tcr-check-icon"> Residential &amp; Commercial Tree Care</li>
                    <li><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/checkmark.svg" alt="Check" class="tcr-check-icon"> Transparent Recommendations</li>
                    <li><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/checkmark.svg" alt="Check" class="tcr-check-icon"> Free Tree Assessments</li>
                    <li><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/checkmark.svg" alt="Check" class="tcr-check-icon"> Quality Workmanship</li>
                </ul>
            </div>
        </div>
    </div>
</section>

<!-- COST SECTION -->
<section class="sub-service-section tcr-cost-section">
    <div class="container">
        <h2 class="tcr-h2">Tree Crown Reduction Cost in Buffalo, NY</h2>
        <div class="tcr-cost-wrap">
            <div class="tcr-cost-content">
                <p class="tcr-text">
                    Tree crown reduction cost is variable and depends on many factors due to individual tree and property variability. At Maple Majesty Tree Care, every estimate is unique for every job and takes the size, condition and complexity of each job into account.
                </p>
                <p class="tcr-text">Several factors influence the final price, including:</p>
                <ul class="tcr-bullet-list">
                    <li>Tree height and size</li>
                    <li>Amount of canopy reduction required</li>
                    <li>Tree species</li>
                    <li>Branch accessibility</li>
                    <li>Equipment requirements</li>
                    <li>Nearby structures or obstacles</li>
                    <li>Overall tree condition</li>
                </ul>
                <p class="tcr-text">
                    The time and equipment needed will be less for a small ornamental tree that's easy to access than for a large mature tree near a residence or utility lines.
                </p>
            </div>
            <div class="tcr-cost-table-wrap">
                <h3 class="tcr-h3">Average Tree Crown Reduction Pricing</h3>
                <table class="tcr-price-table">
                    <thead>
                        <tr>
                            <th>Tree Size</th>
                            <th>Estimated Cost Range</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr><td>Small Trees (up to 25 feet)</td><td>$250 – $600</td></tr>
                        <tr><td>Medium Trees (20–40 feet)</td><td>$600 – $1,500</td></tr>
                        <tr><td>Large Trees (40+ feet)</td><td>$1,500 – $3,500+</td></tr>
                        <tr><td>Crown Thinning (per tree)</td><td>$300 – $900</td></tr>
                        <tr><td>Multi-Tree Property Reduction</td><td>Custom Quote</td></tr>
                        <tr><td>Storm-Damaged Canopy Reduction</td><td>$400 – $1,200+</td></tr>
                        <tr><td>Commercial / HOA Properties</td><td>Custom Quote</td></tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>

<!-- THROUGHOUT WNY SECTION -->
<section class="sub-service-section tcr-throughout-section">
    <div class="container">
        <div class="tcr-throughout-wrap">
            <div class="tcr-throughout-areas">
                <h3 class="tcr-h3">Professional Crown Reduction Throughout Western New York</h3>
                <p class="tcr-text">The communities we serve include those that have mature trees that are an important component of the landscape:</p>
                <ul class="tcr-areas-multi-col">
                    <?php
                    $wny_areas = ['Buffalo', 'Amherst', 'East Amherst', 'Williamsville', 'Getzville', 'Clarence', 'Clarence Center', 'Akron', 'Kenmore', 'Tonawanda', 'North Tonawanda', 'Cheektowaga', 'Lancaster', 'West Seneca', 'Orchard Park', 'Hamburg', 'Boston', 'Eden', 'Lake View', 'East Aurora', 'Elma', 'Niagara Falls', 'Lockport'];
                    foreach ($wny_areas as $a) : ?>
                        <li><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/checkmark.svg" alt="Check" class="tcr-check-icon"> <span><?php echo $a; ?></span></li>
                    <?php endforeach; ?>
                </ul>
                <p class="tcr-text" style="margin-top: 1.5rem;">
                    Our arborists offer tailored tree care services whether you own a historic home with established trees, or a newer home with growing landscaping.
                </p>
            </div>
            
            <div class="tcr-throughout-cta">
                <h3 class="tcr-h3">Schedule a Professional Crown Reduction Today</h3>
                <p class="tcr-text">Trees need expert care from professionals who are knowledgeable about the local conditions.</p>
                <p class="tcr-text">From safety to property protection to creating a beautiful landscape, Maple Majesty Tree Care offers reliable crown reduction services around Buffalo and Western New York.</p>
                <p class="tcr-text"><strong>Call today to schedule your free tree evaluation.</strong></p>
            </div>
        </div>
    </div>
</section>

<!-- WORTH THE INVESTMENT & NEAR ME SECTION -->
<section class="sub-service-section tcr-investment-section">
    <div class="container">
        <div class="tcr-investment-wrap">
            <div class="tcr-investment-left">
                <h3 class="tcr-h3">Why Professional Tree Crown Reduction Is Worth the Investment</h3>
                <p class="tcr-text">While it may cost money to have a professional prune, it can save you a lot of money in the long run.</p>
                <p class="tcr-text">Proper and consistent crown care can minimize the risk of:</p>
                <ul class="tcr-bullet-list">
                    <li>Storm-related property damage</li>
                    <li>Emergency branch removal</li>
                    <li>Structural tree failure</li>
                    <li>Expensive repairs</li>
                </ul>
                <p class="tcr-text">Proper tree care promotes safety in both the landscape and home.</p>

                <h3 class="tcr-h3" style="margin-top: 2.5rem;">Request Your Free Tree Assessment</h3>
                <p class="tcr-text">The most accurate way to determine your tree crown reduction cost is to have a consultation at your home.</p>
                <p class="tcr-text">Our arborists will assess the tree, discuss your concerns with you, and give you a clear recommendation based on your goals.</p>
                <p class="tcr-text"><strong>Contact Maple Majesty Tree Care today for a free estimate.</strong></p>
            </div>
            
            <div class="tcr-near-me-right">
                <h2 class="tcr-h2">Crown Reduction Near Me — Buffalo &amp; Western New York</h2>
                <p class="tcr-text">When it comes to tree crown reduction Buffalo NY, homeowners should look for a trusted local company that is knowledgeable about the problems the trees in Western New York face.</p>
                <p class="tcr-text">Maple Majesty Tree Care is proud to offer crown reduction and pruning services to Buffalo and the surrounding areas. Our local team works to help property owners improve their yard and landscape to be safer, healthier and more beautiful.</p>
            </div>
        </div>
    </div>
</section>

<!-- FINAL CTA -->
<section class="sub-service-section tcr-cta-section">
    <div class="tcr-cta-inner">
        <h2 class="tcr-cta-h2">Ready to Reduce Your Tree's Crown?</h2>
        <p class="tcr-cta-text">
            Contact Maple Majesty Tree Care today for a free assessment. Our ISA-Certified Arborists will evaluate your tree and recommend the safest, most effective crown reduction solution for your Buffalo property.
        </p>
        <div class="tcr-cta-buttons">
            <a href="tel:+17164000763" class="btn-primary">
                Call Now
            </a>
            <a href="<?php echo esc_url(site_url('/contact/')); ?>" class="btn-secondary">
                Request a Free Assessment
            </a>
        </div>
    </div>
</section>
