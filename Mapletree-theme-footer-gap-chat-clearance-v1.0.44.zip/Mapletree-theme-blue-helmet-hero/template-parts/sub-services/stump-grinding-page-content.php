<?php
/**
 * Template part for displaying Stump Grinding page content
 */

// Helper to safely render inline SVGs
if (!function_exists('sg_render_svg')) {
    function sg_render_svg($filename, $fallback = '') {
        $path = get_template_directory() . '/assets/icons/' . $filename;
        if (file_exists($path)) {
            return file_get_contents($path);
        }
        return $fallback;
    }
}
?>

<!-- INTRO & BENEFITS SECTION -->
<section class="sub-service-section stump-grinding-intro">
    <div class="container">
        <div class="sg-intro-wrap">

            <div class="sg-intro-content">
                <span class="global-subtitle">Complete Removal</span>
                <h2 class="sg-h2">What Is Stump Grinding?</h2>

                <div class="sg-takeaway">
                    <strong>Key Takeaway:</strong> Stump grinding uses specialized equipment to reduce a tree stump below ground level, leaving the major root system in place to decay naturally over time.
                </div>

                <p class="sg-text">
                    Stump grinding is defined by taking away tree stumps. This involves the use of equipment with a rotating cutter, unlike complete tree removal. Stump grinding does not include digging the stump; instead, it breaks it down into wood chips, allowing the roots to decay naturally in the soil. After tree removal, the stump may be left behind. A stump can attract bugs, create molding obstacles, and limit landscaping options. The specialists from Maple Majesty Tree Care will assess the size and roots of the stumps and evaluate the ground conditions and potential obstacles in the vicinity before the area's safe grind.
                </p>
                <p class="sg-text sg-text-last">
                    They use their professional devices to grind the stump under the ground level so that soil, grass, or landscaping options can be reintroduced. Stump's deterioration may worsen in Buffalo due to snow, rain, and freeze-thaw cycles. Stump grinding is a process providing a clean solution for stump processing.
                </p>
            </div>

            <div class="sg-benefits-box">
                <h3>Benefits of Professional Stump Grinding</h3>
                <ul class="sg-benefits-list">
                    <?php
                    $benefits = [
                        'Eliminates unattractive tree stumps',
                        'Eliminates tripping hazards',
                        'Improves curb appeal',
                        'Makes mowing easier',
                        'Reduces insect attraction',
                        'Repels fungus growth',
                        'Clears up space for landscaping projects',
                        'Permits new grass or plants to be put in place',
                        'Reduces the number of stumps that need to be removed',
                        'Enhances the safety of the property as a whole'
                    ];
                    foreach ($benefits as $benefit) : ?>
                        <li>
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/checkmark.svg" alt="Check">
                            <span><?php echo $benefit; ?></span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>

        </div>
    </div>
</section>

<!-- OUR STUMP GRINDING PROCESS -->
<section class="sub-service-section stump-grinding-process">
    <div class="container sg-process-container">

        <div class="sg-section-header">
            <span class="global-subtitle">How We Work</span>
            <h2 class="sg-h2">Our Stump Grinding Process</h2>
            <p class="sg-text-lg">
                <strong style="color: var(--color-forest-green);">Key Takeaway:</strong> Professional stump grinding begins with a site assessment, followed by safe preparation, controlled grinding, root-flare treatment when needed, cleanup, and site restoration.<br><br>
                <strong>How Does Our Stump Grinding Service Work?</strong><br>
                As each stump is unique, our stump grinding service near me process starts with a proper evaluation. Before safely and efficiently removing the stump using professional equipment, we assess the stump, the surrounding landscape, and property conditions. We work in a systematic way to reduce disruption and prepare for future landscaping or building.
            </p>
        </div>

        <div class="process-timeline">
            <?php
            $steps = [
                ['num' => '1', 'title' => 'On-Site Assessment', 'desc' => 'Prior to starting work, we have our ISA Certified Arborists examine the stump and the surrounding area. To calculate the best way to remove the tree, we assess the diameter at the base of the trunk, tree species, root flare, access to the tree, nearby utilities, soil conditions, landscaping features, and potential safety concerns.'],
                ['num' => '2', 'title' => 'Preparing the Work Area', 'desc' => 'We prepare the work area before any grinding is done by removing debris and if necessary, marking out underground obstacles, protecting surrounding plants and creating a safe work zone. This preparation ensures that the machine operates safely and effectively without causing any damage.'],
                ['num' => '3', 'title' => 'Professional Stump Grinding', 'desc' => 'We will use a commercial-grade stump grinding machine to slowly grind the stump down several inches below grade. The rotating cutting wheel cuts in layers of wood with minimal impact on the surrounding environment.'],
                ['num' => '4', 'title' => 'Root Collar Reduction', 'desc' => 'We also root flare the root area that is exposed, if applicable, and grind it. This will result in a more level surface, attract more attention to the area and make it easier to add landscaping features later.'],
                ['num' => '5', 'title' => 'Cleanup and Site Restoration', 'desc' => 'Once grinding, we clean the work area either by collecting or re-distributing wood chips, depending on your choice. We make a last inspection to make sure that everything is safe, clean, and ready for grass, mulch, or new landscaping.']
            ];
            foreach ($steps as $step) : ?>
                <div class="process-step">
                    <div class="step-number"><?php echo $step['num']; ?></div>
                    <div class="step-content">
                        <h3><?php echo $step['title']; ?></h3>
                        <p><?php echo $step['desc']; ?></p>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- WHAT MAKES US DIFFERENT -->
<section class="sub-service-section stump-grinding-different">
    <div class="container">

        <div class="sg-section-header">
            <span class="global-subtitle">Why Choose Us</span>
            <h2 class="sg-h2">What Makes Us Different — Stump Grinding Experts</h2>
            <p class="sg-text-lg">
                When selecting the right company for stump grinding Buffalo NY, it is important to know that using the right equipment, experience, and planning will help to protect your property and result in better outcomes. Maple Majesty Tree Care specializes in efficient and safe removal of maple stumps and provides professional, honest service.
            </p>
        </div>

        <div class="sg-features-grid">
            <?php
            $features = [
                ['icon' => 'certified.svg',  'title' => 'ISA-Certified Arborist Expertise',  'desc' => "Our ISA-Certified Arborists are knowledgeable about tree biology, root systems, soil conditions, and correct stump removal practices. We don't treat all properties the same when considering a project."],
                ['icon' => 'equipment.svg',  'title' => 'Commercial-Grade Equipment',        'desc' => 'The stump grinding machines are very effective for below-ground stump grinding. To minimize disruption to surrounding landscapes, we use professional equipment to complete projects in a timely manner.'],
                ['icon' => 'safety.svg',     'title' => 'Safety Comes First',                'desc' => 'All projects start with a comprehensive safety study. Equipment is only operated after checking the underground obstacles, nearby utilities, landscaping features, access points and surrounding structures.'],
                ['icon' => 'honest.svg',     'title' => 'Honest Recommendations',            'desc' => 'Not all projects involve a lot of digging. We clarify your choices and advise you on the most convenient solution for your needs, future landscaping plans and budget.'],
                ['icon' => 'complete.svg',   'title' => 'Complete Cleanup',                  'desc' => 'We remove or rearrange the wood chips after grinding based on your request and clean the work area in order to provide a safe and clean working environment for the next use.'],
                ['icon' => 'experience.svg', 'title' => 'Local Buffalo Experience',          'desc' => "We know the winter weather struggles brought by Buffalo's freeze-thaw seasons, the snow, the strong winds and seasonal landscaping demands. Local knowledge enables us to provide reliable services all year round."]
            ];
            foreach ($features as $f) : ?>
                <div class="sg-feature-card">
                    <div class="sg-icon-circle">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/<?php echo $f['icon']; ?>" alt="<?php echo $f['title']; ?>">
                    </div>
                    <h3 class="sg-h3-card-lg"><?php echo $f['title']; ?></h3>
                    <p class="sg-text sg-text-last"><?php echo $f['desc']; ?></p>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Complete Tree Care Services -->
        <div class="sg-complete-services-box" style="margin-top: 3.5rem; background: var(--color-white); border-radius: 12px; padding: 2.5rem; box-shadow: 0 4px 20px rgba(0,0,0,0.04); border-top: 4px solid var(--color-warm-gold);">
            <h3 class="sg-h3-card" style="font-size: 1.6rem; color: var(--color-brand-purple); margin-bottom: 0.75rem;">Complete Tree Care Services</h3>
            <p class="sg-text" style="font-size: 1.1rem; color: var(--color-brand-purple); font-weight: 600; margin-bottom: 1.5rem;">We also offer stump grinding services as well as:</p>
            <ul class="sg-services-list" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem 1.5rem; list-style: none; padding: 0; margin-bottom: 1.5rem;">
                <?php
                $services = ['Tree Removal', 'Tree Trimming', 'Tree Pruning', 'Emergency Tree Services', 'Land Clearing', 'Storm Damage Cleanup'];
                foreach ($services as $s) : ?>
                    <li class="sg-checklist-item" style="display: flex; align-items: center; gap: 0.75rem; font-size: 1.05rem; font-weight: 600; color: var(--color-brand-purple);">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/checkmark.svg" alt="Check" class="sg-checklist-icon" style="width: 18px; height: 18px; flex-shrink: 0;">
                        <span><?php echo $s; ?></span>
                    </li>
                <?php endforeach; ?>
            </ul>
            <p class="sg-text sg-text-last" style="margin: 0; font-size: 1.05rem; line-height: 1.7; color: var(--color-text-gray);">
                This enables homeowners to deal with just one reputable company to supply them with full tree treatment services.
            </p>
        </div>

    </div>
</section>

<!-- BEST TIME FOR STUMP GRINDING -->
<section class="sub-service-section stump-grinding-timing">
    <div class="container sg-timing-container">
        <div class="sg-section-header-left">
            <span class="global-subtitle">Timing Matters</span>
            <h2 class="sg-h2">When Is the Best Time to Grind a Stump in Buffalo?</h2>
            <p class="sg-text">
                The best time for stump grinding can vary depending on your landscaping objectives, the weather, and the accessibility of your property, but it can be done year-round. Maple Majesty Tree Care is a dependable stump grinding company offering services all year long to businesses and homeowners in Buffalo and Western New York.
            </p>
            <p class="sg-text sg-text-last">
                Ground conditions can be impacted by Buffalo's seasonal weather, such as lake-effect snow, freezing temperatures, spring thaw, and heavy rain. Timing stump grinding is important so that you can have your property ready for landscaping without causing any delays.
            </p>
        </div>

        <div class="sg-seasons-grid">
            <?php
            $seasons = [
                ['title' => 'Spring Stump Grinding', 'desc' => 'Spring is an ideal season for stump grinding as home prospects for landscaping begin to rise. Stump grinding can prepare the ground for laying out fresh grass and new gardens and yards, and improve the overall look of the property after winter.'],
                ['title' => 'Summer Stump Grinding', 'desc' => "The summer dryness makes it easy to get stump grinding tools out. It's the best time for landscaping renovations, patio building, and fence construction; thus, making changes to commercial properties is also possible."],
                ['title' => 'Fall Stump Grinding',   'desc' => 'Autumn time is perfect for stump removal before winter kicks in in Buffalo. Stump grinding minimizes risks, prepares the landscape for spring planting, and improves snow management.'],
                ['title' => 'Winter Stump Grinding', 'desc' => "Winter can still work for stump grinding if ground conditions allow for safe access to the equipment. Stump grinding after extreme weather's impact is an excellent opportunity for fast troubleshooting of the landscape, as well as for cases of emergency tree removal and construction clearance."],
                ['title' => 'After Tree Removal',   'desc' => 'Grinding a stump right after tree removal is good for avoiding troubles and performing finishing work swiftly.']
            ];
            foreach ($seasons as $season) : ?>
                <div>
                    <h3 class="sg-h4"><?php echo $season['title']; ?></h3>
                    <p class="sg-text sg-text-last"><?php echo $season['desc']; ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- DIY VS PRO SECTION -->
<section class="sub-service-section stump-grinding-diy-pro">
    <div class="container">

        <div class="sg-section-header">
            <span class="global-subtitle">Make the Right Choice</span>
            <h2 class="sg-h2">How to Grind Stumps — DIY vs. Hiring a Pro</h2>
            <p class="sg-text-lg">
                <strong style="color: var(--color-forest-green);">Key Takeaway:</strong> DIY stump grinding may work for very small stumps, but professional service is generally safer and more efficient for large stumps, tight spaces, multiple stumps, or areas near utilities.<br><br>
                A common question for many homeowners is — should they try to remove a stump themselves, or should they hire a stump grinding company to do the work for them? Although you might think that do-it-yourself techniques are less costly at first, they can involve a lot of time, equipment, and labor. In a lot of instances, the professional service offers better results with reduced dangers.
            </p>
        </div>

        <div class="sg-diy-cards">

            <div class="sg-diy-card sg-diy-card--neutral">
                <h3 class="sg-h3">DIY Stump Grinding</h3>
                <p class="sg-text">Stump removal is attempted by some property owners by employing stump grinders that are rented, by chemical stump removal, by burning, or by manually digging the stumps.</p>
                <h4 class="sg-h4-sm">Advantages</h4>
                <ul class="sg-list-plain">
                    <li>May be less cost-effective for very small stumps.</li>
                    <li>Flexible scheduling</li>
                    <li>Suitable for experienced equipment operators</li>
                </ul>
                <h4 class="sg-h4-sm">Challenges</h4>
                <ul class="sg-list-plain sg-list-plain-mb2">
                    <li>Safe operation of rental equipment may be challenging.</li>
                    <li>Rocks or roots underground can cause damage to equipment.</li>
                    <li>Lines that provide services may be very dangerous.</li>
                    <li>Grinding could result in an uneven finish.</li>
                    <li>It may take several hours to work on large stumps.</li>
                    <li>Additional Clean-up is typically required.</li>
                </ul>
                <p class="sg-text sg-text-last"><em>Grinding your own stumps also poses greater risks for injury due to the power of the grinders and the need for correct handling and safety measures.</em></p>
            </div>

            <div class="sg-diy-card sg-diy-card--pro">
                <h3 class="sg-h3">Professional Stump Grinding</h3>
                <p class="sg-text">Professional contractors will make sure the task is done promptly and with commercial equipment and techniques.</p>
                <h4 class="sg-h4-sm">Benefits of Professional Service</h4>
                <ul class="sg-list-plain sg-list-plain-mb2">
                    <li>Commercial-grade stump grinders</li>
                    <li>Experienced equipment operators</li>
                    <li>Faster completion times</li>
                    <li>Reduced property damage risk</li>
                    <li>Thorough cleanup</li>
                    <li>Safe work practices</li>
                    <li>Better preparation for future landscaping</li>
                    <li>Suitable for residential and commercial properties</li>
                </ul>
                <p class="sg-text sg-text-last">Our ISA-Certified Arborists also assess if any surrounding roots, trees, underground utilities, or landscaping need special attention before work.</p>
            </div>

        </div>

        <!-- Comparison Table -->
        <div class="sg-table-wrap">
            <h3 class="sg-table-title">DIY vs. Professional Comparison</h3>
            <div class="sg-table-scroll">
                <table class="sg-comparison-table">
                    <thead>
                        <tr>
                            <th>DIY Stump Grinding</th>
                            <th>Professional Stump Grinding</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr><td>Equipment rental required</td><td>Commercial equipment provided</td></tr>
                        <tr><td>Higher physical effort</td><td>Minimal homeowner involvement</td></tr>
                        <tr><td>Increased safety risks</td><td>Professional safety procedures</td></tr>
                        <tr><td>Limited experience</td><td>ISA-Certified Arborists</td></tr>
                        <tr><td>Longer completion time</td><td>Faster and more efficient</td></tr>
                        <tr><td>Basic cleanup</td><td>Complete site cleanup</td></tr>
                        <tr><td>Greater risk of property damage</td><td>Careful protection of the surrounding landscape</td></tr>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="sg-hire-myth">

            <div class="sg-hire-block">
                <h3 class="sg-h3">When Should You Hire a Professional?</h3>
                <p class="sg-text">When the following conditions occur, it is recommended to use professional stump grinding:</p>
                <ul class="sg-list-plain sg-list-plain-m0">
                    <li>The stump is large.</li>
                    <li>Multiple stumps need removal.</li>
                    <li>The stump is close to buildings.</li>
                    <li>Utility lines may be nearby.</li>
                    <li>The area will be replanted.</li>
                    <li>Heavy equipment is required.</li>
                    <li>Safety is a concern.</li>
                </ul>
            </div>

            <div class="sg-myth-box">
                <h3 class="sg-h3">Myth vs. Fact</h3>
                <p class="sg-text">
                    <strong class="sg-myth">Myth:</strong> A tree stump will vanish in no time at all if not approached.
                </p>
                <p class="sg-text sg-text-last">
                    <strong class="sg-fact">Fact:</strong> Many of the stumps will not decay on their own, and can still be a source of insects, shoots and a landscape hazard for years.
                </p>
            </div>

        </div>

    </div>
</section>

<!-- STUMP GRINDING COST -->
<section class="sub-service-section stump-grinding-cost">
    <div class="container">
        <div class="sg-cost-wrap">

            <div class="sg-cost-content">
                <span class="global-subtitle">Transparent Pricing</span>
                <h2 class="sg-h2">Stump Grinding Cost in Buffalo NY</h2>
                <p class="sg-text">
                    The cost of professional stump grinding is influenced by stump size and diameter, tree species, root flare, accessibility, location and number of stumps to be removed. The larger a hardwood stump is, the longer it will take to rot out, and it will require more specialized equipment.
                </p>
                <p class="sg-text">
                    The following table shows approximate prices. Each property is unique and therefore an accurate quote can only be achieved by arranging a free on-site assessment.
                </p>
                <h3 class="sg-h4">Factors That Affect Cost</h3>
                <ul class="sg-list-plain sg-list-plain-m0">
                    <li>Stump diameter and height</li>
                    <li>Tree species (hardwood vs. softwood)</li>
                    <li>Root flare size</li>
                    <li>Number of stumps</li>
                    <li>Accessibility for equipment</li>
                    <li>Soil conditions</li>
                    <li>Nearby landscaping or utilities</li>
                    <li>Cleanup and wood chip removal</li>
                    <li>Additional root grinding if requested</li>
                </ul>
            </div>

            <div class="sg-cost-table-wrap">
                <table class="sg-price-table">
                    <thead>
                        <tr>
                            <th>Stump Diameter</th>
                            <th>Estimated Cost</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr><td>Up to 12 inches</td><td>$100–$175</td></tr>
                        <tr><td>13–24 inches</td><td>$175–$300</td></tr>
                        <tr><td>25–36 inches</td><td>$300–$450</td></tr>
                        <tr><td>37–48 inches</td><td>$450–$650</td></tr>
                        <tr><td>49+ inches</td><td>Custom Quote</td></tr>
                    </tbody>
                </table>
            </div>

        </div>
    </div>
</section>

<!-- LOCAL STUMP GRINDING -->
<section class="sub-service-section stump-grinding-local">
    <div class="container">
        <div class="sg-local-wrap">

            <div class="sg-local-content">
                <span class="global-subtitle">Service Areas</span>
                <h2 class="sg-h2">Local Stump Grinding — Serving Buffalo Communities</h2>
                <p class="sg-text">
                    When looking for stump removal Buffalo NY or stump grinding companies near me, it's important to find a team with an understanding of the specific Buffalo landscape and seasonal needs. Stump grinding is a professional service that Maple Majesty Tree Care is proud to offer throughout Buffalo and the surrounding communities in Western New York. The Arborists in our ISA Certified membership team work with homeowners, businesses, property managers, municipalities, and contractors to safely and efficiently remove unwanted stumps.
                </p>
                <p class="sg-text sg-text-last">
                    Old tree stumps that are left from storms, disease or removal are common problems with Buffalo properties. Such obstructions may cause problems with mowing, landscaping, building projects, and outdoor safety. From one backyard stump to a commercial property with multiple stumps, we offer solutions to your problems with professional-grade equipment.
                </p>
            </div>

            <div class="sg-properties-box">
                <h3 class="sg-h3">Properties We Service</h3>
                <ul class="sg-properties-grid">
                    <?php
                    $properties = ['Residential homes', 'Commercial properties', 'Apartment communities', 'Schools', 'Parks', 'Churches', 'Municipal properties', 'HOAs', 'New construction sites', 'Vacant lots'];
                    foreach ($properties as $property) : ?>
                        <li>
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/checkmark.svg" alt="Check" class="sg-checklist-icon">
                            <span><?php echo $property; ?></span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>

        </div>

        <div class="sg-local-extra">

            <div class="sg-neighborhoods">
                <h3 class="sg-h3-card">Buffalo Neighborhoods We Serve</h3>
                <p class="sg-text">We serve the local area of:</p>
                <ul class="sg-neighborhoods-list">
                    <?php
                    $neighborhoods = ['Downtown Buffalo', 'Elmwood Village', 'North Buffalo', 'South Buffalo', 'Allentown', 'Black Rock', 'Riverside', 'University Heights', 'Delaware District'];
                    foreach ($neighborhoods as $n) : ?>
                        <li class="sg-checklist-item">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/checkmark.svg" alt="Check" class="sg-checklist-icon">
                            <span><?php echo $n; ?></span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>

        </div>
    </div>
</section>

<!-- STUMP REMOVAL NEAR ME — BUFFALO & WESTERN NEW YORK -->
<section class="sub-service-section stump-grinding-nearme">
    <div class="container">
        <div class="sg-nearme-wrap">

            <div class="sg-nearme-content">
                <span class="global-subtitle">
                    FIND US LOCALLY
                </span>
                <h2 class="sg-h2">Stump Removal Near Me — Buffalo &amp; Western New York</h2>
                <div class="section-divider" style="margin-bottom: 1.5rem;"></div>

                <p class="sg-text">
                    Looking for stump grinding near me? Maple Majesty Tree Care is proud to offer tree stump grinding and removal services in Buffalo and Western New York.
                </p>
                <p class="sg-text">
                    If you just need one stump pulled from your backyard or if you have a landscaping or construction project where several stumps need to be pulled, the professionals are ready to help you.
                </p>
                <p class="sg-text sg-text-last">
                    We provide dependable stump grinding services across Buffalo and surrounding Western New York communities using professional equipment and proven techniques.
                </p>
            </div>

            <div class="sg-areas-box">
                <h3 class="sg-h3-card" style="font-size: 1.35rem; color: var(--color-brand-purple); margin-bottom: 1.25rem;">Areas We Serve</h3>
                <ul class="sg-areas-list">
                    <?php
                    $areas = [
                        'Buffalo',
                        'Amherst',
                        'Cheektowaga',
                        'Tonawanda',
                        'Kenmore',
                        'Williamsville',
                        'West Seneca',
                        'Hamburg',
                        'Orchard Park',
                        'Clarence',
                        'Lancaster',
                        'Depew',
                        'Lackawanna'
                    ];
                    foreach ($areas as $area) : ?>
                        <li class="sg-checklist-item">
                            <span class="sg-checklist-icon"><?php echo sg_render_svg('checkmark.svg', '✓'); ?></span>
                            <span><?php echo $area; ?></span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>

        </div>
    </div>
</section>



