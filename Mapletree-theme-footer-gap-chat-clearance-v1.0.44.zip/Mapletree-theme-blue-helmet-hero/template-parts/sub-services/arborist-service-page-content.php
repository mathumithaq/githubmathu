<?php
/**
 * Template part for displaying Arborist Service page content
 */

// Helper to safely render inline SVGs
if (!function_exists('as_render_svg')) {
    function as_render_svg($filename) {
        $path = get_template_directory() . '/assets/icons/' . $filename;
        if (file_exists($path)) {
            return file_get_contents($path);
        }
        return '';
    }
}
?>



<!-- WHAT IS AN ARBORIST -->
<section class="sub-service-section as-intro-section">
    <div class="container">
        <div class="as-intro-wrap">

            <div class="as-intro-content">
                <span class="global-subtitle">Professional Expertise</span>
                <h2 class="as-h2">What Is an Arborist?</h2>

                <div class="as-takeaway">
                An arborist is a trained tree-care professional who evaluates tree health, structural safety, disease, pests, roots, and environmental stress to recommend appropriate long-term care.
                </div>

                <p class="as-text">
                    A trained tree care professional with a focus on tree health, safety, maintenance and preservation is called an arborist. An arborist tree service will specialize in diagnosing tree issues, determining structural integrity, disease prevention, and recommending appropriate tree care based on tree physiology and biology, as opposed to general landscapers.
                </p>
                <p class="as-text">
                    Our Maple Majesty Tree Care certified arborist tree service will perform comprehensive checks on tree health, canopy structure, roots, soil moisture, pests, and diseases. Very cold, lake-effect snow, ice storms and high winds are just a few of the challenges that buffalo trees must endure and why professional evaluations are crucial.
                </p>
                <p class="as-text as-text-last">
                    An ISA-Certified Arborist offers professional tree care to help maintain trees' health, safety, and longevity for a better landscape.
                </p>
            </div>

        </div>
    </div>
</section>

<!-- SERVICES WE OFFER -->
<section class="sub-service-section as-services-section">
    <div class="container">

        <div class="as-section-header">
            <span class="global-subtitle">Comprehensive Care</span>
            <h2 class="as-h2">Arborist Services We Offer in Buffalo, NY</h2>
            <p class="as-intro-text">
             Our arborist services cover tree health and risk assessments, disease and pest diagnosis, preservation planning, structural pruning recommendations, species selection, and storm-damage evaluation.
            </p>
        </div>

        <div class="as-services-wrap">
            <div class="as-services-left">
                <p class="as-text">
                    Professional trees must be cared for by professionals. Maple Majesty Tree Care provides comprehensive arborist service near me solutions designed to improve tree health, reduce safety risks, and extend the lifespan of your landscape. Our Arborist Buffalo NY staff assesses each tree on a case-by-case basis and provides services depending on the tree's condition, species, location, and overall health.
                </p>
                <p class="as-text as-text-last">
                    Every tree has different needs. Our certified arborists provide customized care plans that protect tree health while improving safety and preserving your property's landscape.
                </p>
            </div>

            <div class="as-services-grid">
                <?php
                $services = [
                    [
                        'icon' => 'health.svg',
                        'title' => 'Tree Health Assessments',
                        'desc' => 'We conduct comprehensive tree health evaluations using these criteria: species, age, canopy condition, root condition, soil condition and structural condition. Early inspections will identify potential issues before they become expensive or unsafe.'
                    ],
                    [
                        'icon' => 'safety.svg',
                        'title' => 'Tree Risk Assessments',
                        'desc' => "Some trees conceal structural issues that they don't have. Dead limbs, weak branch unions, defects in the trunks, unstable roots, and damage caused by storms are checked for potential hazard and the most suitable remedy is suggested."
                    ],
                    [
                        'icon' => 'disease.svg',
                        'title' => 'Tree Disease & Pest Diagnosis',
                        'desc' => 'Our arborists identify common tree diseases, insect infestations, fungal infections, bark damage and root decline. Early detection means early treatment and early protection of the tree and other landscape plants.'
                    ],
                    [
                        'icon' => 'complete.svg',
                        'title' => 'Tree Preservation Plans',
                        'desc' => 'We develop tailored preservation strategies, such as regular visits, preventive pruning, soil management, root protection, and long-term monitoring to ensure healthy, mature trees for years to come.'
                    ],
                    [
                        'icon' => 'equipment.svg',
                        'title' => 'Structural Pruning Recommendations',
                        'desc' => 'Structural pruning strengthens trees by rectifying poor branch development, promotes proper tree balance to reduce weak branch attachment, and promotes healthy, long-term growth by employing proper pruning techniques.'
                    ],
                    [
                        'icon' => 'experience.svg',
                        'title' => 'Planting & Species Selection',
                        'desc' => 'Tree selection is a key to success. We recommend appropriate species, optimal planting sites, soil suitability, mature size and maintenance of species for your property.'
                    ],
                    [
                        'icon' => 'safety.svg',
                        'title' => 'Storm Damage Evaluation',
                        'desc' => 'Following extreme weather events, our arborists assess trees for hidden damage as a result of heavy snow, ice, high winds, lightning or fallen limbs and advise on the most appropriate management strategy.'
                    ]
                ];
                foreach ($services as $srv) : ?>
                    <div class="as-service-card">
                        <div class="as-service-body">
                            <h3 class="as-h4"><?php echo $srv['title']; ?></h3>
                            <p class="as-text as-text-last"><?php echo $srv['desc']; ?></p>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

    </div>
</section>

<!-- CONSULTATION SECTION -->
<section class="sub-service-section as-consultation-section">
    <div class="container">
        
        <div class="as-section-header">
            <span class="global-subtitle">Expert Guidance</span>
            <h2 class="as-h2">Get Expert Advice — Arborist Consultation</h2>
            <div class="as-takeaway as-takeaway-center">
             An arborist consultation helps determine what your tree actually needs before work begins, helping you avoid unnecessary treatments or removal while making informed long-term decisions.
            </div>
        </div>

        <div class="as-consultation-wrap">
            <div class="as-consultation-left">
                <p class="as-text">
                    Homeowners may not know which of these options is the best for them. The arborist consultation service gives expert advice before significant arborist activities. During a consultation, the certified arborist service team can assess the health, safety, and long-term viability of the tree and provide you with the answers you are looking for, as well as outline the best possible solution.
                </p>
                <p class="as-text as-text-last">
                    A professional arborist consultation helps property owners make informed decisions, avoid unnecessary work, and protect valuable trees.
                </p>
            </div>

            <div class="as-consultation-grid">
                <?php
                $consultations = [
                    [
                        'icon' => 'honest.svg',
                        'title' => 'Inspect the Tree',
                        'desc' => 'We thoroughly check the trunk, canopy, branches, roots and surrounding area for indications of stress, decay, structural issues, or other health problems.'
                    ],
                    [
                        'icon' => 'disease.svg',
                        'title' => 'Identify Potential Problems',
                        'desc' => "To diagnose your tree's condition, we search for disease, pest, root and structural damage as well as storm-related issues."
                    ],
                    [
                        'icon' => 'certified.svg',
                        'title' => 'Recommend the Best Solution',
                        'desc' => 'Our findings based on what we see, we can give the best recommendation to the client, such as tree pruning, trimming, preserving, cabling, monitoring or even removal if required.'
                    ],
                    [
                        'icon' => 'experience.svg',
                        'title' => 'Answer Your Questions',
                        'desc' => 'When problems occur, our arborist will explain why, what they may mean, treatment options, and a long-term maintenance plan to help you make decisions.'
                    ]
                ];
                foreach ($consultations as $item) : ?>
                    <div class="as-consultation-card">
                        <div class="as-consultation-body">
                            <h3 class="as-h4"><?php echo $item['title']; ?></h3>
                            <p class="as-text as-text-last"><?php echo $item['desc']; ?></p>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>

<!-- EMERGENCY SECTION -->
<section class="sub-service-section as-emergency-section">
    <div class="container">
        
        <div class="as-emergency-wrap">
            <div class="as-emergency-content">
                <span class="global-subtitle">Urgent Care</span>
                <h2 class="as-h2">Emergency Arborist Service — 24/7 Response</h2>
                
                <div class="as-takeaway">
                Emergency arborist service assesses unstable or storm-damaged trees, identifies immediate hazards, and recommends the safest action to protect people, structures, vehicles, and surrounding property.
                </div>
                
                <p class="as-text">
                    The urgent cases for storm and unexpected tree failure must be attended to. Maple Majesty Tree Care offers emergency arborist service in Buffalo and Western New York for trees that pose a risk to people, homes, vehicles, or businesses. We have a well-trained staff who responds rapidly to determine safety, minimize immediate hazards, and suggest the best solution.
                </p>
                <p class="as-text">
                    Emergency arborist services focus on making hazardous trees safe after storms, accidents, or sudden structural failures while protecting people and property.
                </p>

                <div class="as-emergency-list">
                    <?php
                    $emergencies = [
                        [
                            'title' => 'Immediate Safety Assessment',
                            'desc' => 'Before making any of the following decisions, our arborists will examine the tree, surrounding structures and surrounding hazards to ensure the most effective and safest emergency response.'
                        ],
                        [
                            'title' => 'Risk Stabilization',
                            'desc' => 'If possible, we secure hazardous limbs or sections of the tree to minimize the immediate danger and potential for further property damage while removing the tree.'
                        ],
                        [
                            'title' => 'Professional Tree Care',
                            'desc' => 'We can conduct hazardous limb removal, tree removal, storm cleanup, emergency pruning, and a full tree risk assessment to restore safety, depending on the assessment.'
                        ],
                        [
                            'title' => 'Complete Site Cleanup',
                            'desc' => 'Once our emergency service is completed, your property will be cleaned up and left safe and sound for any subsequent tree care needs.'
                        ]
                    ];
                    foreach ($emergencies as $e) : ?>
                        <div class="as-emergency-item">
                            <h3 class="as-h4"><?php echo $e['title']; ?></h3>
                            <p class="as-text as-text-last"><?php echo $e['desc']; ?></p>
                        </div>
                    <?php endforeach; ?>
                </div>

                <div class="as-emergency-box">
                    <h3 class="as-h3">Why Professional Emergency Arborists Matter</h3>
                    <p class="as-text">
                        When trees undergo emergencies, they are typically prone to instability, have broken branches, and work conditions are challenging.
                    </p>
                    <p class="as-text as-text-last">
                        Our arborist tree service near me professionals have the necessary equipment, safety measures, and knowledge to handle dangerous situations in a safe manner. From storm damage to trees and limbs to downed trees to hazardous trees, we're here to protect you and your property, and we are always looking for the best solution for good long-term health.
                    </p>
                </div>
            </div>
        </div>

    </div>
</section>

<!-- WHY HIRE A CERTIFIED ARBORIST -->
<section class="sub-service-section as-why-section">
    <div class="container">

        <div class="as-why-wrap">
            <div class="as-why-content">
                <span class="global-subtitle">Professional Advantage</span>
                <h2 class="as-h2">Why Hire a Certified Arborist?</h2>
                <div class="as-takeaway">
                A certified arborist combines tree biology, risk assessment, and professional care practices to identify problems early, preserve healthy trees, and reduce avoidable safety risks.
                </div>
                <p class="as-text">
                    This is where hiring a certified arborist tree service comes in handy—you are having your trees evaluated by trained professionals in the arboriculture field, not in tree cutting. Certified arborists are professionals who recognize how trees grow, how they react to stress and how they heal when they are damaged, and can therefore recommend treatments that will help to increase their long-term health and safety.
                </p>
                <p class="as-text as-text-last">
                    Rudimentary pruning, unnecessary removal of trees, or incorrect diagnosis can cause trees to become stressed and present a future hazard. Arborists apply scientific knowledge and industry practice to make informed decisions that help to preserve your property and your landscape investment.
                </p>
            </div>
        </div>

        <div class="as-benefits-container">
            <h3 class="as-h3 as-benefits-title">Benefits of Hiring a Certified Arborist</h3>
            
            <div class="as-benefits-grid">
                <?php
                $benefits = [
                    [
                        'icon' => 'certified.svg',
                        'title' => 'Expert Tree Health Assessments',
                        'desc' => 'In addition to diagnosing tree diseases as early as possible, our arborists detect signs of infestation by insects, root damage, structural weakness, and environmental stress, all of which can contribute to costly issues and impact long-term tree health.'
                    ],
                    [
                        'icon' => 'honest.svg',
                        'title' => 'Accurate Tree Risk Evaluation',
                        'desc' => 'Potential problems such as dead limbs, weak limbs, weak branch attachments, root instability, leaning trees and storm damage are inspected to prevent hazards caused to people and property.'
                    ],
                    [
                        'icon' => 'complete.svg',
                        'title' => 'Customized Tree Care Plans',
                        'desc' => "Trees are individual and different. The unique care plan is based on tree species, age, property conditions, Buffalo's climate, and your long-term landscaping objectives."
                    ],
                    [
                        'icon' => 'experience.svg',
                        'title' => 'Professional Tree Preservation',
                        'desc' => 'We seek to save trees by using good tree pruning, tree monitoring, and preventive measures whenever possible, rather than unnecessary tree removal.'
                    ],
                    [
                        'icon' => 'safety.svg',
                        'title' => 'Compliance With Industry Standards',
                        'desc' => 'Our ISA Certified Arborists apply the standards and successfully practice tree care techniques to enhance tree health and promote safe arboricultural care.'
                    ],
                    [
                        'icon' => 'equipment.svg',
                        'title' => 'Long-Term Cost Savings',
                        'desc' => 'Preventing damage to trees and preventing costly repairs by arborist inspections and preventative maintenance can help to minimize the need for emergency tree care, storm damage and expensive repairs.'
                    ]
                ];
                foreach ($benefits as $b) : ?>
                    <div class="as-benefit-card">
                        <div class="as-benefit-body">
                            <h3 class="as-h4"><?php echo $b['title']; ?></h3>
                            <p class="as-text as-text-last"><?php echo $b['desc']; ?></p>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="as-benefits-footer">
                <p class="as-text as-text-last">
                    <strong>A certified arborist safeguards trees with their expertise in evaluation, science, and proactive care to ensure safety, tree health and long-term property value.</strong>
                </p>
            </div>
        </div>

    </div>
</section>

<!-- LOCAL ARBORISTS SECTION -->
<section class="sub-service-section as-local-section">
    <div class="container">
        
        <div class="as-local-wrap">
            <div class="as-local-content">
                <span class="global-subtitle">Local Expertise</span>
                <h2 class="as-h2">Local Certified Arborists — Serving Buffalo Communities</h2>
                
                <div class="as-takeaway">
                 Local arborist knowledge matters because Buffalo trees regularly face lake-effect snow, ice, high winds, freezing temperatures, and freeze-thaw cycles that can affect branches, roots, and structural stability.
                </div>
                
                <p class="as-text">
                    Looking for an arborist service near me? Maple Majesty Tree Care is an exclusive tree care company serving the Buffalo and Western New York areas. These ISA Certified Arborists are knowledgeable about the climate, species and seasonal conditions of the region, which enables them to provide expert care for the tree in your landscape.
                </p>
                <p class="as-text">
                    The lake-effect snow and freezing temperatures, ice, strong winds, and freeze-thaw cycles are a constant challenge to Buffalo's trees. These conditions may cause branches to bend, root damage, disease, or structural damage. Ongoing tree work by a certified arborist helps to detect problems early to prevent emergencies. We help homeowners, businesses, property managers, schools, municipalities, and HOAs to make their trees healthy and minimize risks to property. Our arborists can offer both immediate and ongoing advice on trees specific to your property.
                </p>
                <p class="as-text as-text-last">
                    Local arborists understand Buffalo's weather, soils, and common tree species, making their recommendations more accurate and effective for long-term tree health.
                </p>
            </div>
            
            <div class="as-local-boxes">
                <div class="as-local-box">
                    <h3 class="as-h4">Residential Arborist Services</h3>
                    <p class="as-text as-text-last">
                        Our arborist services come to you at your home to assist you with tree health evaluations, hazard assessments, disease diagnosis, seasonal checks, tree preservation and storm damage assessments to keep your trees in good health and your property safe.
                    </p>
                </div>
                <div class="as-local-box as-local-box-alt">
                    <h3 class="as-h4">Commercial Arborist Services</h3>
                    <p class="as-text as-text-last">
                        Our professional arborist services help enhance the safety, aesthetics and longevity of tree care for offices, apartment communities, schools, parks, retail properties, churches, industrial facilities, and municipal landscapes.
                    </p>
                </div>
            </div>
        </div>

    </div>
</section>

<!-- WHY CHOOSE SECTION -->
<section class="sub-service-section as-choose-section">
    <div class="container">

        <div class="as-section-header">
            <span class="global-subtitle">The Maple Majesty Difference</span>
            <h2 class="as-h2">Why Buffalo Homeowners Choose Our Arborist Service</h2>
            <p class="as-intro-text">
             Effective arborist care combines certified knowledge, Buffalo-specific experience, science-based recommendations, safe work practices, and a preference for preserving healthy trees whenever practical.
            </p>
        </div>

        <div class="as-choose-intro">
            <p class="as-text as-text-last">
                The certified arborist service is a good choice because they have knowledge about the growth of trees, how they will react under stress, and what will happen to them when they are exposed to their environment. Certified knowledge, local knowledge, and up-to-date tree care practices all come together to provide dependable tree care throughout Buffalo.
            </p>
        </div>

        <div class="as-choose-grid">
            <div class="as-choose-card">
                <div class="as-choose-body">
                    <h3 class="as-h4">ISA-Certified Arborists</h3>
                    <p class="as-text as-text-last">Our ISA Certified Arborists are trained in tree biology, structural integrity, tree disease diagnosis and arboricultural practice, and can provide care to trees of all sizes and species.</p>
                </div>
            </div>
            
            <div class="as-choose-card">
                <div class="as-choose-body">
                    <h3 class="as-h4">Local Buffalo Experience</h3>
                    <p class="as-text as-text-last">We know Buffalo's local challenges, such as lake-effect snow, ice storms, high winds, freeze-thaw cycles, clay-heavy soils, and frequent species of common trees, which enable us to give you practical suggestions based on local circumstances.</p>
                </div>
            </div>

            <div class="as-choose-card">
                <div class="as-choose-body">
                    <h3 class="as-h4">Science-Based Tree Care</h3>
                    <p class="as-text as-text-last">Each tree is assessed on a case-by-case basis with professional arboricultural standards. Our recommendations are based upon tree health, structural condition, safety concerns, long-term growth potential and property-specific needs.</p>
                </div>
            </div>

            <div class="as-choose-card">
                <div class="as-choose-body">
                    <h3 class="as-h4">Modern Equipment & Safe Work Practices</h3>
                    <p class="as-text as-text-last">All inspections, pruning recommendations, hazard evaluations, and emergency arborist services are performed with industry-standard equipment and safety practices to ensure safety and efficiency.</p>
                </div>
            </div>

            <div class="as-choose-card">
                <div class="as-choose-body">
                    <h3 class="as-h4">Honest Recommendations</h3>
                    <p class="as-text as-text-last">Our priority is preserving healthy trees whenever possible. Treatment, monitoring, pruning or removal is recommended only if it is the safest and most beneficial choice.</p>
                </div>
            </div>

            <div class="as-choose-card">
                <div class="as-choose-body">
                    <h3 class="as-h4">Complete Tree Care Solutions</h3>
                    <p class="as-text as-text-last">In addition to arborist consultations, we also offer tree trimming, tree removal, tree pruning, emergency tree services, stump grinding, stump removal and land clearing for tree services throughout the year.</p>
                </div>
            </div>
        </div>

    </div>
</section>

<!-- PRICING SECTION -->
<section class="sub-service-section as-pricing-section">
    <div class="container">
        
        <div class="as-pricing-wrap">
            <div class="as-pricing-content">
                <span class="global-subtitle">Fair Pricing</span>
                <h2 class="as-h2">Professional Arborist Pricing — Transparent & Fair</h2>
                <p class="as-text">
                    Tree service arborist fees vary depending on the services provided, tree size and size of the project, accessibility, and the time needed for the tree inspection or services. Giving you a fair and honest quote without surprise charges at Maple Majesty Tree Care.
                </p>
                <p class="as-text">
                    Arborist pricing varies by service type and property conditions. A professional consultation ensures accurate recommendations and fair pricing
                </p>
                <p class="as-text as-text-last">
                    The table below provides a general idea of typical arborist service charges.
                </p>
            </div>
            
            <div class="as-pricing-table-col">
                <div class="as-table-wrap">
                    <table class="as-price-table">
                        <thead>
                            <tr>
                                <th>Service</th>
                                <th>Estimated Starting Price*</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Arborist Consultation</td>
                                <td>$100–$200</td>
                            </tr>
                            <tr>
                                <td>Tree Health Assessment</td>
                                <td>$150–$250</td>
                            </tr>
                            <tr>
                                <td>Tree Risk Assessment</td>
                                <td>$200–$350</td>
                            </tr>
                            <tr>
                                <td>Disease & Pest Diagnosis</td>
                                <td>$150–$300</td>
                            </tr>
                            <tr>
                                <td>Storm Damage Assessment</td>
                                <td>$200–$400</td>
                            </tr>
                            <tr>
                                <td>Comprehensive Tree Care Plan</td>
                                <td>Custom Quote</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="as-factors-wrap">
            <h3 class="as-h3">Factors That Affect Arborist Service Costs</h3>
            <ul class="as-factors-list">
                <li><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/checkmark.svg" alt="Check"><strong>Number of Trees:</strong> More inspection time is required.</li>
                <li><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/checkmark.svg" alt="Check"><strong>Tree Size:</strong> Larger or mature trees may need more detailed evaluations.</li>
                <li><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/checkmark.svg" alt="Check"><strong>Tree Condition:</strong> Diseased or hazardous trees may require more extensive assessments.</li>
                <li><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/checkmark.svg" alt="Check"><strong>Accessibility:</strong> Trees located near buildings, utilities or limited access areas could add complexity to the services.</li>
                <li><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/checkmark.svg" alt="Check"><strong>Service Type:</strong> Consultations, risk assessments, and emergency evaluations vary in scope and cost.</li>
                <li><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/checkmark.svg" alt="Check"><strong>Emergency Response:</strong> After-hours or storm-related emergency arborist services may be subject to extra fees.</li>
            </ul>
            <p class="as-text as-text-last as-factors-outro">
                Professional evaluations can also allow for early identification of problems that can eliminate costly maintenance in the future and prevent costly emergency tree care.
            </p>
        </div>

    </div>
</section>

<!-- NEAR ME SECTION -->
<section class="sub-service-section as-areas-section">
    <div class="container">
        <div class="as-areas-wrap">
            
            <div class="as-areas-content">
                <span class="global-subtitle">Service Area</span>
                <h2 class="as-h2">Arborist Near Me — Buffalo & Western New York</h2>
                <p class="as-text">
                    When looking for an arborist service near me, you'll want to find a certified arborist who is familiar with the trees found in your area, the weather and the challenges of your property. Maple Majesty Tree Care is proud to offer Arborist Buffalo NY services to the communities around Buffalo in Western NY.
                </p>
                <p class="as-text as-text-last">
                    Our ISA-Certified Arborists collaborate with homeowners, businesses, municipalities, HOAs, schools, and property managers to enhance trees, decrease safety hazards and maintain valuable landscapes. From tree health screening and disease diagnosis to risk assessment and emergency tree care services, we offer reliable solutions with professional expertise.
                </p>
            </div>

            <div class="as-areas-box">
                <h3 class="as-h3">Areas We Serve</h3>
                <ul class="as-areas-multi-col">
                    <li><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/checkmark.svg" alt="Check"> Buffalo</li>
                    <li><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/checkmark.svg" alt="Check"> Amherst</li>
                    <li><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/checkmark.svg" alt="Check"> Williamsville</li>
                    <li><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/checkmark.svg" alt="Check"> Cheektowaga</li>
                    <li><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/checkmark.svg" alt="Check"> Tonawanda</li>
                    <li><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/checkmark.svg" alt="Check"> Kenmore</li>
                    <li><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/checkmark.svg" alt="Check"> West Seneca</li>
                    <li><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/checkmark.svg" alt="Check"> Hamburg</li>
                    <li><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/checkmark.svg" alt="Check"> Orchard Park</li>
                    <li><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/checkmark.svg" alt="Check"> Clarence</li>
                    <li><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/checkmark.svg" alt="Check"> Lancaster</li>
                    <li><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/checkmark.svg" alt="Check"> Depew</li>
                    <li><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/checkmark.svg" alt="Check"> Lackawanna</li>
                    <li><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/checkmark.svg" alt="Check"> East Aurora</li>
                    <li><img src="<?php echo get_template_directory_uri(); ?>/assets/icons/checkmark.svg" alt="Check"> North Tonawanda</li>
                </ul>
            </div>

            <div class="as-areas-footer">
                <p class="as-text">
                    Our arborists provide reliable service throughout Western New York and can be relied upon for every type of tree care service, including routine and emergency work.
                </p>
                <p class="as-text as-text-last">
                    Our local knowledge of Buffalo's climate, soils, and tree species allows us to provide customized arborist services that promote healthier, safer, and longer-lasting trees.
                </p>
            </div>
            
        </div>
    </div>
</section>
