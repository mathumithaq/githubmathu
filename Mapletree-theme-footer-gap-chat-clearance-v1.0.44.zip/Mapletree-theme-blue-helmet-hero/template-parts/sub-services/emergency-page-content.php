

<section class="emergency-cta-section">
    <div class="emergency-cta-container">
        <span class="global-subtitle">24/7 Availability</span>
        <h2>Tree Down Right Now? Call Us — We're Available 24/7</h2>
        
        <p class="description">
            A fallen or risky tree poses a major safety threat. Our emergency tree service team is available around the clock to help with all your emergency needs in Buffalo.
        </p>
        
        <div class="hotline-wrapper">
            <a href="tel:+17164000763" class="hotline-link">
                Call Now
            </a>
        </div>
        
        <div class="trust-grid">
            <div class="trust-item">
                <h3>4.9/5 Rating</h3>
                <p>Trusted by Buffalo homeowners</p>
            </div>
            <div class="trust-item">
                <h3>ISA-Certified Arborists</h3>
                <p>Professional tree assessments</p>
            </div>
            <div class="trust-item">
                <h3>Licensed & Insured</h3>
                <p>Protection for your property</p>
            </div>
            <div class="trust-item">
                <h3>24/7 Emergency Response</h3>
                <p>Fast storm damage response</p>
            </div>
        </div>
    </div>
</section>


<section class="emergency-when-to-call-section">
    <div class="emergency-when-to-call-container">
        <span class="global-subtitle">Risk Assessment</span>
        <h2>When to Call for Emergency Tree Service</h2>
        
        <div class="key-takeaway">
            <p>A tree becomes an emergency when it creates an immediate risk to people, buildings, vehicles, utilities, or property access. Fallen trees, hanging limbs, sudden leaning, and storm damage should be assessed promptly.</p>
        </div>
        
        <div class="description-area">
            <p>
                If you have a tree that is compromised in any way, you may want to hire professionals for emergency tree removal in Buffalo NY to avoid injuries, damages, and big bills.
            </p>
            <p>
Tree emergencies can occur due to situations where the delay may cause injury or data loss. Some common reasons for tree emergencies in Buffalo are storms, high snow and ice from the lake, and strong winds.            </p>
            <p class="highlight-text">
                Call Maple Majesty immediately if you notice:
            </p>
        </div>
        
        <div class="reasons-list">
            <div class="reason-item">
                <h3>
                    1. Fallen Trees
                </h3>
                <p>If your tree falls across your yard, vehicle or even home, it needs immediate assistance. Since it may move at any time, it creates hazardous conditions for anybody who comes near it.</p>
            </div>
            
            <div class="reason-item">
                <h3>
                    2. Large Broken Limbs
                </h3>
                <p>It is possible for heavy branches damaged during the storm to fall unexpectedly. Damaged parts near buildings or near the ground must be inspected immediately.</p>
            </div>
            
            <div class="reason-item">
                <h3>
                    3. Leaning or Unstable Trees
                </h3>
                <p>If the angle of the tree changes suddenly, this may indicate that either the roots have been compromised or the soil has moved.</p>
            </div>
            
            <div class="reason-item">
                <h3>
                    4. Storm Damage
                </h3>
                <p>Strong winds, ice storms, and large amounts of snow can damage the trunks and branches of trees, causing perilous hidden dangers.</p>
            </div>
            
            <div class="reason-item">
                <h3>
                    5. Trees Blocking Access
                </h3>
                <p>In case of a fallen tree obstructing a driveway, road, or entrance, a quick removal is required to ensure safety and the possibility of a quick response.</p>
            </div>
            
            <div class="reason-item">
                <h3>
                    6. Trees Near Power Lines
                </h3>
                <p>In the case of trees in contact with or threatening electrical wires that can cause insecure conditions, it is necessary to handle them carefully and implement safety measures.</p>
            </div>
        </div>
    </div>
</section>


<section class="emergency-how-it-works-section">
    <div class="emergency-how-it-works-container">
        <div class="section-header">
            <span class="global-subtitle">Our Process</span>
            <h2>How Emergency Tree Service Works</h2>
            <p class="header-desc">
                Our 24hr emergency tree services follow a structured process designed to quickly secure your property, remove hazards, and restore safety after tree damage.
            </p>
        </div>
        
        <div class="process-steps">
            <!-- Step 1 -->
            <div class="step-card">
                <div class="step-number-container">
                    <span class="step-number-badge">1</span>
                </div>
                <div class="step-content">
                    <h3>Emergency Call & Safety Assessment</h3>
                    <p>Once we receive your call at Maple Majesty, we take down all information regarding the following details:</p>
                    <ul>
                        <li>Tree location</li>
                        <li>Hazards surrounding the property</li>
                        <li>Conditions of damage due to the storm</li>
                        <li>Nearby buildings or power lines</li>
                    </ul>
                    <p class="highlight-conclusion">Based on that information, we decide on how to proceed.</p>
                </div>
            </div>
            
            <!-- Step 2 -->
            <div class="step-card">
                <div class="step-number-container">
                    <span class="step-number-badge">2</span>
                </div>
                <div class="step-content">
                    <h3>Fast Emergency Dispatch</h3>
                    <p>The situations that we give priority to are:</p>
                    <ul>
                        <li>At home</li>
                        <li>In vehicles</li>
                        <li>Blocked driveways</li>
                        <li>Hanging branches that might cause troubles</li>
                        <li>Fallen trees</li>
                    </ul>
                    <p class="highlight-conclusion">We operate in Buffalo, which means that we can react much faster to your requests across New York.</p>
                </div>
            </div>
            
            <!-- Step 3 -->
            <div class="step-card">
                <div class="step-number-container">
                    <span class="step-number-badge">3</span>
                </div>
                <div class="step-content">
                    <h3>Professional Hazard Removal</h3>
                    <p>We send the team equipped with:</p>
                    <ul>
                        <li>Professional equipment</li>
                        <li>Chainsaws for removing any obstacle</li>
                        <li>Safety clothing</li>
                        <li>Techniques for carefully carrying out the removal</li>
                    </ul>
                    <p class="highlight-conclusion">All of the removal actions are conducted with a minimum risk to the property.</p>
                </div>
            </div>
            
            <!-- Step 4 -->
            <div class="step-card">
                <div class="step-number-container">
                    <span class="step-number-badge">4</span>
                </div>
                <div class="step-content">
                    <h3>Cleanup & Property Safety Check</h3>
                    <p>When we remove possible hazards from your property, we do the following:</p>
                    <ul>
                        <li>Removing some branches and debris</li>
                        <li>Checking the surrounding area</li>
                        <li>Telling you about other conservation procedures, if necessary</li>
                    </ul>
                    <p class="highlight-conclusion">Thus, we can assure you stay safe after our work.</p>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="emergency-whats-included-section">
    <div class="emergency-whats-included-container">
        <div class="section-header">
            <span class="global-subtitle">Service Features</span>
            <h2>What's Included in Every Emergency Call</h2>
            <p class="header-desc">
                Every emergency response includes professional assessment, safe hazard removal, debris cleanup, and guidance to help protect your property after unexpected tree damage.
            </p>

        </div>
        <p class="header-desc" style="margin-top: 2rem; margin-bottom: 1.5rem;">
            Emergency Tree Service Includes:
            </p>
        <div class="features-grid">
            <div class="feature-card">
                <h3>Rapid Safety Assessment</h3>
                <p>Our arborists inspect the tree's condition and identify immediate risks.</p>
            </div>
            
            <div class="feature-card">
                <h3>Storm Damage Response</h3>
                <p>We handle trees damaged by wind, snow, and ice.</p>
            </div>
            
            <div class="feature-card">
                <h3>Emergency Tree Removal</h3>
                <p>Unsafe trees are removed using proper techniques and equipment.</p>
            </div>
            
            <div class="feature-card">
                <h3>Hazardous Limb Removal</h3>
                <p>Dangerous branches threatening structures are safely removed.</p>
            </div>
            
            <div class="feature-card">
                <h3>Debris Cleanup</h3>
                <p>Branches, logs, and storm debris are cleared after the work.</p>
            </div>
            
            <div class="feature-card">
                <h3>Property Protection Measures</h3>
                <p>Our team works carefully around homes, gardens, fences, and driveways.</p>
            </div>
        </div>
    </div>
</section>


<section class="common-emergencies-section">
    <div class="common-emergencies-container">
        <div class="section-header">
            <span class="global-subtitle">Local Expertise</span>
            <h2>Common Tree Emergencies We Handle in Buffalo, NY</h2>
            <p class="header-desc">
                Maple Majesty offers trustworthy emergency tree removal services near me, safely hauling away everything from storm-broken limbs to downed trees.
            </p>
            <p class="header-desc">
                With the extreme winter weather, hefty snowfall, and fierce winds from the Great Lakes, Buffalo area properties face tree challenges that other areas do not.
            </p>
        </div>
        
        <div class="emergencies-list">
            <div class="emergency-card">
                <div class="emergency-icon">
                    <?php echo file_exists(get_template_directory() . '/assets/icons/storm.svg') ? file_get_contents(get_template_directory() . '/assets/icons/storm.svg') : ''; ?>
                </div>
                <div class="emergency-content">
                    <h3>Storm-Damaged Trees</h3>
                    <p>Powerful winds and ice storms can cause broken and cracked branches and weakened trees.</p>
                </div>
            </div>
            
            <div class="emergency-card">
                <div class="emergency-icon">
                    <?php echo file_exists(get_template_directory() . '/assets/icons/home.svg') ? file_get_contents(get_template_directory() . '/assets/icons/home.svg') : ''; ?>
                </div>
                <div class="emergency-content">
                    <h3>Fallen Trees on Homes or Vehicles</h3>
                    <p>A tree that has fallen on a residence will require quick removal services.</p>
                </div>
            </div>
            
            <div class="emergency-card">
                <div class="emergency-icon">
                    <?php echo file_exists(get_template_directory() . '/assets/icons/broken-tree.svg') ? file_get_contents(get_template_directory() . '/assets/icons/broken-tree.svg') : ''; ?>
                </div>
                <div class="emergency-content">
                    <h3>Leaning Trees</h3>
                    <p>A leaning tree may indicate possible problems with the root structure and requires inspection.</p>
                </div>
            </div>
            
            <div class="emergency-card">
                <div class="emergency-icon">
                    <?php echo file_exists(get_template_directory() . '/assets/icons/barricade.svg') ? file_get_contents(get_template_directory() . '/assets/icons/barricade.svg') : ''; ?>
                </div>
                <div class="emergency-content">
                    <h3>Blocked Driveways and Walkways</h3>
                    <p>If the tree is blocking your path, our emergency removal service will restore access.</p>
                </div>
            </div>
            
            <div class="emergency-card">
                <div class="emergency-icon">
                    <?php echo file_exists(get_template_directory() . '/assets/icons/alert.svg') ? file_get_contents(get_template_directory() . '/assets/icons/alert.svg') : ''; ?>
                </div>
                <div class="emergency-content">
                    <h3>Dead or Diseased Hazard Trees</h3>
                    <p>Trees suffering from pests and diseases can become a danger during severe weather.</p>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="nearby-response-section">
    <div class="nearby-response-container">
        <div class="nearby-response-header">
            <span class="global-subtitle">Service Areas</span>
            <h2>Nearby Emergency Tree Removal Response</h2>
            <p>
                Searching for emergency tree services near me? Maple Majesty responds throughout Buffalo neighborhoods and Western New York communities with dependable local tree care.
            </p>
        </div>
        
        <div class="locations-grid">
            <div class="location-card">
                <h3>
                    <?php echo file_exists(get_template_directory() . '/assets/icons/map-pin.svg') ? file_get_contents(get_template_directory() . '/assets/icons/map-pin.svg') : ''; ?>
                    Delaware Park Area
                </h3>
                <p>Ice storm damage often causes mature oak and elm limbs to fail over historic homes. Maple Majesty Tree Care provides fast emergency tree removal to protect nearby structures.</p>
            </div>
            
            <div class="location-card">
                <h3>
                    <?php echo file_exists(get_template_directory() . '/assets/icons/map-pin.svg') ? file_get_contents(get_template_directory() . '/assets/icons/map-pin.svg') : ''; ?>
                    Elmwood Village
                </h3>
                <p>Storm-split parkway trees can fall onto parked vehicles and homes on narrow urban lots. Maple Majesty Tree Care responds quickly to restore safety.</p>
            </div>
            
            <div class="location-card">
                <h3>
                    <?php echo file_exists(get_template_directory() . '/assets/icons/map-pin.svg') ? file_get_contents(get_template_directory() . '/assets/icons/map-pin.svg') : ''; ?>
                    North Buffalo
                </h3>
                <p>Heavy ice accumulation frequently causes silver maple co-dominant stem failures during winter storms. Maple Majesty Tree Care offers 24/7 emergency tree services.</p>
            </div>
            
            <div class="location-card">
                <h3>
                    <?php echo file_exists(get_template_directory() . '/assets/icons/map-pin.svg') ? file_get_contents(get_template_directory() . '/assets/icons/map-pin.svg') : ''; ?>
                    South Buffalo
                </h3>
                <p>Strong winds can topple backyard trees onto fences, garages, and neighboring properties. Maple Majesty Tree Care safely removes hazardous trees with minimal disruption.</p>
            </div>
            
            <div class="location-card">
                <h3>
                    <?php echo file_exists(get_template_directory() . '/assets/icons/map-pin.svg') ? file_get_contents(get_template_directory() . '/assets/icons/map-pin.svg') : ''; ?>
                    Allentown
                </h3>
                <p>Historic neighborhoods often require emergency limb removal to protect period homes and surrounding infrastructure. Maple Majesty Tree Care uses careful techniques for sensitive properties.</p>
            </div>
            
            <div class="location-card">
                <h3>
                    <?php echo file_exists(get_template_directory() . '/assets/icons/map-pin.svg') ? file_get_contents(get_template_directory() . '/assets/icons/map-pin.svg') : ''; ?>
                    Black Rock & Riverside
                </h3>
                <p>Niagara River wind events can bring down large waterfront trees, threatening homes and structures. Maple Majesty Tree Care provides prompt emergency cleanup and removal.</p>
            </div>
            
            <div class="location-card">
                <h3>
                    <?php echo file_exists(get_template_directory() . '/assets/icons/map-pin.svg') ? file_get_contents(get_template_directory() . '/assets/icons/map-pin.svg') : ''; ?>
                    University Heights
                </h3>
                <p>Storm-damaged trees can block access and create immediate safety hazards around homes and campus-adjacent properties. Maple Majesty Tree Care is available for rapid response.</p>
            </div>
            
            <div class="location-card">
                <h3>
                    <?php echo file_exists(get_template_directory() . '/assets/icons/map-pin.svg') ? file_get_contents(get_template_directory() . '/assets/icons/map-pin.svg') : ''; ?>
                    Lovejoy & Kaisertown
                </h3>
                <p>Fallen trees frequently block driveways and residential streets after severe weather. Maple Majesty Tree Care clears debris quickly to restore safe property access.</p>
            </div>
        </div>
        
        <div class="landmarks-box">
            <h3>Landmarks & Areas We Respond To</h3>
            <ul class="landmarks-list">
                <?php 
                $landmarks = [
                    'Delaware Park', 'Elmwood Village', 'Chestnut Ridge Park', 
                    'Niagara River Corridor', 'Buffalo Outer Harbor', 'UB North Campus', 
                    'Cazenovia Park', 'Forest Lawn Cemetery', 'Ellicott Creek Park', 
                    'Buffalo Zoo Area', 'Tifft Nature Preserve', 'Times Beach Nature Preserve', 
                    'Letchworth State Park Area', 'Grand Island Bridge Area', 'Reinstein Woods'
                ];
                
                foreach ($landmarks as $landmark) {
                    echo '<li>';
                    echo file_exists(get_template_directory() . '/assets/icons/check-circle.svg') ? file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg') : '✓';
                    echo ' ' . esc_html($landmark) . '</li>';
                }
                ?>
            </ul>
        </div>
    </div>
</section>


<section class="why-choose-us-section">
    <div class="why-choose-container">
        <div class="section-header">
            <span class="global-subtitle">Why Choose Us</span>
            <h2>Why We're the #1 Choice for Tree Emergencies</h2>
            <p class="header-desc">
                Residents trust Maple Majesty for reliable emergency tree service Buffalo NY due to our local experience, certified specialists, safety measures, and rapid response times.
            </p>
        </div>
        
        <div class="reasons-grid">
            <div class="reason-card">
                <div class="reason-icon-wrap">
                    <?php echo file_exists(get_template_directory() . '/assets/icons/buffalo.svg') ? file_get_contents(get_template_directory() . '/assets/icons/buffalo.svg') : ''; ?>
                </div>
                <h3>Local Buffalo Tree Experience</h3>
                <p>We know the issues faced in Buffalo such as:</p>
                <ul>
                    <li><div class="check-icon"><?php echo file_exists(get_template_directory() . '/assets/icons/check-circle.svg') ? file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg') : ''; ?></div> Lake snow damage</li>
                    <li><div class="check-icon"><?php echo file_exists(get_template_directory() . '/assets/icons/check-circle.svg') ? file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg') : ''; ?></div> Accumulated snow</li>
                    <li><div class="check-icon"><?php echo file_exists(get_template_directory() . '/assets/icons/check-circle.svg') ? file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg') : ''; ?></div> High seasonal winds</li>
                    <li><div class="check-icon"><?php echo file_exists(get_template_directory() . '/assets/icons/check-circle.svg') ? file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg') : ''; ?></div> Soils of clay composition</li>
                    <li><div class="check-icon"><?php echo file_exists(get_template_directory() . '/assets/icons/check-circle.svg') ? file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg') : ''; ?></div> Old hardwood trees</li>
                </ul>
            </div>
            
            <div class="reason-card">
                <div class="reason-icon-wrap">
                    <?php echo file_exists(get_template_directory() . '/assets/icons/certificate.svg') ? file_get_contents(get_template_directory() . '/assets/icons/certificate.svg') : ''; ?>
                </div>
                <h3>ISA-certified Knowledge</h3>
                <p>Our specialists are knowledgeable in:</p>
                <ul>
                    <li><div class="check-icon"><?php echo file_exists(get_template_directory() . '/assets/icons/check-circle.svg') ? file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg') : ''; ?></div> Tree biology</li>
                    <li><div class="check-icon"><?php echo file_exists(get_template_directory() . '/assets/icons/check-circle.svg') ? file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg') : ''; ?></div> Roots</li>
                    <li><div class="check-icon"><?php echo file_exists(get_template_directory() . '/assets/icons/check-circle.svg') ? file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg') : ''; ?></div> Weak areas</li>
                    <li><div class="check-icon"><?php echo file_exists(get_template_directory() . '/assets/icons/check-circle.svg') ? file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg') : ''; ?></div> Safe removal methods</li>
                </ul>
            </div>
            
            <div class="reason-card">
                <div class="reason-icon-wrap">
                    <?php echo file_exists(get_template_directory() . '/assets/icons/safety-shield.svg') ? file_get_contents(get_template_directory() . '/assets/icons/safety-shield.svg') : ''; ?>
                </div>
                <h3>Safety Comes First</h3>
                <p>The tasks involved in emergency tree services include a lot of risks, hence the teams implement safety measures:</p>
                <ul>
                    <li><div class="check-icon"><?php echo file_exists(get_template_directory() . '/assets/icons/check-circle.svg') ? file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg') : ''; ?></div> Rigging</li>
                    <li><div class="check-icon"><?php echo file_exists(get_template_directory() . '/assets/icons/check-circle.svg') ? file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg') : ''; ?></div> Tree climbing</li>
                    <li><div class="check-icon"><?php echo file_exists(get_template_directory() . '/assets/icons/check-circle.svg') ? file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg') : ''; ?></div> Cutting with precautions</li>
                    <li><div class="check-icon"><?php echo file_exists(get_template_directory() . '/assets/icons/check-circle.svg') ? file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg') : ''; ?></div> Property protection</li>
                </ul>
            </div>
            
            <div class="reason-card">
                <div class="reason-icon-wrap">
                    <?php echo file_exists(get_template_directory() . '/assets/icons/handshake.svg') ? file_get_contents(get_template_directory() . '/assets/icons/handshake.svg') : ''; ?>
                </div>
                <h3>Honest Recommendations</h3>
                <p>Not every damaged tree is cut. We analyze the case and suggest the safest solution.</p>
                <div class="recommendation-badge">Safest Solution Guaranteed</div>
            </div>
        </div>
    </div>
</section>

<section class="emergency-cost-section">
    <div class="emergency-cost-container">
        <div class="cost-content">
            <div class="section-header align-left">
                <span class="global-subtitle">Transparent Pricing</span>
                <h2>Emergency Tree Service Cost in Buffalo NY</h2>
                <p class="header-desc">
                    Emergency tree service Buffalo NY pricing depends on the situation, including tree size, damage level, location, accessibility, equipment required, and urgency of the response.
                </p>
                <div class="cost-image-wrapper">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/emergency_tree_team.webp" alt="Emergency tree service team working" class="cost-feature-image">
                </div>
            </div>
            
            <div class="cost-table-wrapper">
                <table class="cost-table">
                    <thead>
                        <tr>
                            <th>Service Type</th>
                            <th>Estimated Price Range</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>
                                <div class="td-content">
                                    <?php echo file_exists(get_template_directory() . '/assets/icons/price-tag.svg') ? file_get_contents(get_template_directory() . '/assets/icons/price-tag.svg') : ''; ?>
                                    Emergency Hazard Limb Removal
                                </div>
                            </td>
                            <td class="price-value">$300 &ndash; $800+</td>
                        </tr>
                        <tr>
                            <td>
                                <div class="td-content">
                                    <?php echo file_exists(get_template_directory() . '/assets/icons/price-tag.svg') ? file_get_contents(get_template_directory() . '/assets/icons/price-tag.svg') : ''; ?>
                                    Tree Fell on House &mdash; Structural Removal
                                </div>
                            </td>
                            <td class="price-value">$1,000 &ndash; $4,000+</td>
                        </tr>
                        <tr>
                            <td>
                                <div class="td-content">
                                    <?php echo file_exists(get_template_directory() . '/assets/icons/price-tag.svg') ? file_get_contents(get_template_directory() . '/assets/icons/price-tag.svg') : ''; ?>
                                    After-Hours Emergency Response Fee
                                </div>
                            </td>
                            <td class="price-value">$150 &ndash; $300</td>
                        </tr>
                        <tr>
                            <td>
                                <div class="td-content">
                                    <?php echo file_exists(get_template_directory() . '/assets/icons/price-tag.svg') ? file_get_contents(get_template_directory() . '/assets/icons/price-tag.svg') : ''; ?>
                                    Storm Debris Cleanup (per property)
                                </div>
                            </td>
                            <td class="price-value">$300 &ndash; $800</td>
                        </tr>
                        <tr>
                            <td>
                                <div class="td-content">
                                    <?php echo file_exists(get_template_directory() . '/assets/icons/price-tag.svg') ? file_get_contents(get_template_directory() . '/assets/icons/price-tag.svg') : ''; ?>
                                    Emergency Stump Securing
                                </div>
                            </td>
                            <td class="price-value">$200 &ndash; $500</td>
                        </tr>
                        <tr>
                            <td>
                                <div class="td-content">
                                    <?php echo file_exists(get_template_directory() . '/assets/icons/price-tag.svg') ? file_get_contents(get_template_directory() . '/assets/icons/price-tag.svg') : ''; ?>
                                    Temporary Tarping (structure protection)
                                </div>
                            </td>
                            <td class="price-value">$200 &ndash; $600</td>
                        </tr>
                        <tr>
                            <td>
                                <div class="td-content">
                                    <?php echo file_exists(get_template_directory() . '/assets/icons/price-tag.svg') ? file_get_contents(get_template_directory() . '/assets/icons/price-tag.svg') : ''; ?>
                                    Commercial Emergency Response
                                </div>
                            </td>
                            <td class="price-value">Custom Quote</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>

<section class="communities-served-section">
    <div class="communities-container">
        <div class="section-header">
            <span class="global-subtitle">Service Area</span>
            <h2>Communities We Serve - Buffalo & Beyond</h2>
            <p class="header-desc">
                Maple Majesty provides emergency tree services near me throughout Buffalo, Western New York, and surrounding communities with fast local response.
            </p>
            <p class="service-area-intro">Our emergency tree service area includes:</p>
        </div>
        
        <div class="communities-list-grid">
            <?php 
            $communities = [
                'Elma', 'Buffalo', 'Kenmore', 'Amherst', 'Clarence', 'Hamburg', 
                'Lockport', 'Lewiston', 'Tonawanda', 'West Seneca', 'Cheektowaga',
                'Williamsville', 'Orchard Park', 'East Aurora', 'Niagara Falls',
                'North Tonawanda'
            ];
            usort($communities, fn($a, $b) => strlen($a) - strlen($b));
            
            foreach ($communities as $community) {
                echo '<div class="community-item">';
                echo '<div class="community-icon">';
                echo file_exists(get_template_directory() . '/assets/icons/map-point.svg') ? file_get_contents(get_template_directory() . '/assets/icons/map-point.svg') : '';
                echo '</div>';
                echo '<span>' . esc_html($community) . '</span>';
                echo '</div>';
            }
            ?>
        </div>
    </div>
</section>

