<?php
/**
 * Template Part: Tree Pruning Sub-Service Page Content (Buffalo, NY)
 * Contains 100% verbatim content for all sections requested by user.
 */

// Helper to safely render inline SVGs
if (!function_exists('tp_render_svg')) {
    function tp_render_svg($filename, $fallback = '') {
        $path = get_template_directory() . '/assets/icons/' . $filename;
        if (file_exists($path)) {
            return file_get_contents($path);
        }
        return $fallback;
    }
}
?>


<!-- =========================================================================
     SECTION 1: UNDERSTANDING PROFESSIONAL TREE PRUNING
     ========================================================================= -->
<section class="tp-section">
    <div class="tp-container">
        <span class="global-subtitle">
            TREE PRUNING OVERVIEW
        </span>
        <h2 class="global-section-title">Understanding Professional Tree Pruning</h2>
        <div class="section-divider"></div>

        <!-- Key Takeaway Box -->
        <div style="background-color: var(--color-soft-lilac); border-left: 4px solid var(--color-warm-gold); border-radius: 8px; padding: 1.75rem 2rem; margin: 2rem 0; display: flex; gap: 1.25rem; align-items: flex-start;">
            <div style="flex-shrink: 0; width: 28px; height: 28px; color: var(--color-brand-purple);">
                <?php echo tp_render_svg('info-circle.svg', 'ℹ️'); ?>
            </div>
            <p style="font-size: 1.05rem; line-height: 1.6; font-weight: 700; color: var(--color-brand-purple); margin: 0;">
               Professional tree pruning selectively removes dead, weak, diseased, or poorly positioned branches to improve tree health, structure, safety, and long-term growth.
            </p>
        </div>

        <h3 style="font-size: 1.5rem; color: var(--color-brand-purple); margin-top: 2rem; margin-bottom: 1rem;">What Is Tree Pruning?</h3>
        <p style="font-size: 1.1rem; line-height: 1.8; color: var(--color-text-gray);">
            Tree Pruning is defined as the selective removal of plant materials to improve the health, function, form, and structure of the trees. It is essential that pruning is done by trained professionals who know about tree biology, branch union and proper techniques for cutting branches. In Maple Majesty Tree care, our professionals perform a detailed assessment of tree species, age, condition, canopy and surrounding structures before pruning a tree. Again, there are many pruning services offered by various tree care companies, such as dead wood removal, correction of structure, branch clean-up, and removal of branches affected by disease.
        </p>
    </div>
</section>

<!-- =========================================================================
     SECTION 2: WHY YOUR TREES NEED REGULAR PRUNING
     ========================================================================= -->
<section class="tp-section-alt">
    <div class="tp-container">
        <div class="text-center tp-maintenance-header">
            <span class="global-subtitle">
                ESSENTIAL MAINTENANCE
            </span>
            <h2 class="global-section-title">Why Your Trees Need Regular Pruning</h2>
            <div class="section-divider" style="margin: 1rem auto 1.5rem auto;"></div>

            <!-- Key Takeaway Box -->
            <div class="tp-maintenance-takeaway" style="background-color: var(--color-white); border-left: 4px solid var(--color-warm-gold); border-radius: 8px; padding: var(--global-padding-x, 20px); margin: 1.5rem 0 2rem 0; text-align: left; box-shadow: 0 4px 15px rgba(0,0,0,0.03);">
                <p style="font-size: 1.05rem; line-height: 1.6; font-weight: 700; color: var(--color-brand-purple); margin: 0;">
                 Regular pruning helps reduce hazardous branches, improve structural strength, maintain clearance, and support healthier growth before small problems become larger risks.
                </p>
            </div>

            <h3 style="font-size: 1.35rem; color: var(--color-brand-purple); margin-bottom: 1rem;">Why Pruning Matters</h3>
            <p style="font-size: 1.1rem; color: var(--color-text-gray); line-height: 1.7;">
                Tree pruning promotes good health, structure, and safety before minor issues turn into costly and dangerous situations. Well-maintained trees are also beautiful and easier to maintain.
            </p>
        </div>

        <div class="tp-benefits-grid">
            <!-- 1 -->
            <div class="tp-benefit-card">
                <div class="tp-card-icon"><?php echo tp_render_svg('pruning-health.svg', '🌱'); ?></div>
                <h3>Improves Tree Health</h3>
                <p>Pruning dead, diseased or damaged branches helps the tree focus its energy on healthy branches. Pruning also provides the arborist with a chance to check for disease, pest infestation, decay and structural issues.</p>
            </div>

            <!-- 2 -->
            <div class="tp-benefit-card">
                <div class="tp-card-icon"><?php echo tp_render_svg('pruning-structure.svg', '🌳'); ?></div>
                <h3>Encourages Stronger Structure</h3>
                <p>As a tree ages, it may develop structural issues from crossing or rubbing branches or from poorly attached branches. Selective pruning will help to develop a better framework and enhance the branch spacing.</p>
            </div>

            <!-- 3 -->
            <div class="tp-benefit-card">
                <div class="tp-card-icon"><?php echo tp_render_svg('storm-damage.svg', '⚠️'); ?></div>
                <h3>Reduces Hazardous Branches</h3>
                <p>Branches that are weak or not well-supported can be hazardous during Buffalo's snowy, icy conditions and windy weather. Identified hazards can be removed before the onset of severe weather, helping to minimize the risk of falling limbs.</p>
            </div>

            <!-- 4 -->
            <div class="tp-benefit-card">
                <div class="tp-card-icon"><?php echo tp_render_svg('pruning-airflow.svg', '☀️'); ?></div>
                <h3>Improves Airflow and Light</h3>
                <p>Too dense canopies may limit sunlight and air circulation. Selective pruning is used to clear out the appropriate areas of the canopy, while maintaining adequate foliage for good growth.</p>
            </div>

            <!-- 5 -->
            <div class="tp-benefit-card">
                <div class="tp-card-icon"><?php echo tp_render_svg('pruning-property.svg', '🏡'); ?></div>
                <h3>Protects Property</h3>
                <p>Branches that are directed toward roofs, windows, driveways, sidewalks, fences or other structures are likely to become a problem in the future. Appropriate separation is maintained by clearing and pruning.</p>
            </div>

            <!-- 6 -->
            <div class="tp-benefit-card">
                <div class="tp-card-icon"><?php echo tp_render_svg('pruning-appearance.svg', '✨'); ?></div>
                <h3>Maintains Natural Appearance</h3>
                <p>Symmetry and shape can be enhanced by professional pruning, but it will not cause an unnatural appearance. The goal is to keep the tree as it grows naturally, but to correct any growth issues that arise.</p>
            </div>

            <!-- 7 -->
            <div class="tp-benefit-card">
                <div class="tp-card-icon"><?php echo tp_render_svg('pruning-maintenance.svg', '⏳'); ?></div>
                <h3>Provides long-term tree maintenance</h3>
                <p>Planning a pruning schedule helps homeowners to work on structural issues over a period of time instead of focusing on emergencies. This can be especially beneficial for older trees that are pruned for significant landscape value.</p>
            </div>
        </div>
    </div>
</section>

<!-- =========================================================================
     SECTION 3: OUR TREE PRUNING PROCESS
     ========================================================================= -->
<section class="tp-section">
    <div class="tp-container">
        <div class="text-center" style="max-width: 850px; margin: 0 auto 3.5rem auto;">
            <span class="global-subtitle">
                SYSTEMATIC APPROACH
            </span>
            <h2 class="global-section-title">Our Tree Pruning Process</h2>
            <div class="section-divider" style="margin: 1rem auto 1.5rem auto;"></div>
            <p style="font-size: 1.15rem; color: var(--color-text-gray); line-height: 1.7;">
                Our tree pruning service starts with an assessment, followed by planning, accurate pruning, cleanup, and inspection. All steps are custom-made for each tree and property.
            </p>
        </div>

        <div class="tp-process-grid">
            <!-- Step 1 -->
            <div class="tp-process-card">
                <h3 style="font-size: 1.3rem; color: var(--color-brand-purple); margin-bottom: 0.75rem;">Step 1: Tree Assessment</h3>
                <p style="font-size: 1rem; color: var(--color-text-gray); line-height: 1.65; margin: 0;">
                    Our ISA-Certified Arborists examine the species, health, canopy, branch structure and surrounding environment of the tree. Dead wood, weak wood attachments, crossing limbs, disease issues and hazards are identified.
                </p>
            </div>

            <!-- Step 2 -->
            <div class="tp-process-card">
                <h3 style="font-size: 1.3rem; color: var(--color-brand-purple); margin-bottom: 0.75rem;">Step 2: Pruning Plan</h3>
                <p style="font-size: 1rem; color: var(--color-text-gray); line-height: 1.65; margin: 0;">
                    Identifies branches to be removed and chooses the appropriate pruning method. The plan takes into account the season, seasonal conditions, tree age, growth pattern, property requirements, and long-term goals.
                </p>
            </div>

            <!-- Step 3 -->
            <div class="tp-process-card">
                <h3 style="font-size: 1.3rem; color: var(--color-brand-purple); margin-bottom: 0.75rem;">Step 3: Work Area Preparation</h3>
                <p style="font-size: 1rem; color: var(--color-text-gray); line-height: 1.65; margin: 0;">
                    Before pruning activity, we set up a safe work area, determine hazards, secure adjacent landscaping, and assemble equipment.
                </p>
            </div>

            <!-- Step 4 -->
            <div class="tp-process-card">
                <h3 style="font-size: 1.3rem; color: var(--color-brand-purple); margin-bottom: 0.75rem;">Step 4: Professional Pruning</h3>
                <p style="font-size: 1rem; color: var(--color-text-gray); line-height: 1.65; margin: 0;">
                    Using the right pruning tools and equipment, our arborists will make accurate cuts. Hand pruners, pruning saws, pole saws, chainsaws, climbing systems, bucket trucks, and rigging equipment are among the equipment that may be used, depending on the tree.
                </p>
            </div>

            <!-- Step 5 -->
            <div class="tp-process-card">
                <h3 style="font-size: 1.3rem; color: var(--color-brand-purple); margin-bottom: 0.75rem;">Step 5: Cleanup</h3>
                <p style="font-size: 1rem; color: var(--color-text-gray); line-height: 1.65; margin: 0;">
                    Once pruned, branches and debris are taken from the work area. Driveways, lawns, walkways and other places people can access are kept clean.
                </p>
            </div>

            <!-- Step 6 -->
            <div class="tp-process-card">
                <h3 style="font-size: 1.3rem; color: var(--color-brand-purple); margin-bottom: 0.75rem;">Step 6: Final Inspection</h3>
                <p style="font-size: 1rem; color: var(--color-text-gray); line-height: 1.65; margin: 0;">
                    When it is finished, we check the finished tree to ensure it meets our pruning goals and has a natural, balanced look.
                </p>
            </div>
        </div>
    </div>
</section>

<!-- =========================================================================
     SECTION 4: TYPES OF TREE PRUNING WE OFFER
     ========================================================================= -->
<section class="tp-section-alt">
    <div class="tp-container">
        <div class="text-center" style="max-width: 850px; margin: 0 auto 3rem auto;">
            <span class="global-subtitle">
                PRUNING METHODS
            </span>
            <h2 class="global-section-title">Types of Tree Pruning We Offer</h2>
            <div class="section-divider" style="margin: 1rem auto 1.5rem auto;"></div>

            <!-- Key Takeaway Box -->
            <div style="background-color: var(--color-white); border-left: 4px solid var(--color-warm-gold); border-radius: 8px; padding: 1.5rem 2rem; margin: 1.5rem 0 2rem 0; text-align: left; box-shadow: 0 4px 15px rgba(0,0,0,0.03);">
                <p style="font-size: 1.05rem; line-height: 1.6; font-weight: 700; color: var(--color-brand-purple); margin: 0;">
                 The right pruning method depends on the tree’s age, species, condition, structure, and the goal of the work, such as deadwood removal, clearance, thinning, or structural correction.
                </p>
            </div>

            <p style="font-size: 1.1rem; color: var(--color-text-gray); line-height: 1.7;">
                The type of pruning varies between trees. Depending on the arborist's training, the method used is determined by the reason for the pruning, tree species, age, tree health, and tree structure.
            </p>
        </div>

        <div class="tp-types-grid">
            <!-- 1 -->
            <div class="tp-type-card">
                <div class="tp-card-icon"><?php echo tp_render_svg('type-structural.svg', '📐'); ?></div>
                <h3 style="font-size: 1.25rem; color: var(--color-brand-purple); margin-bottom: 0.85rem;">Structural Pruning</h3>
                <p style="font-size: 1rem; color: var(--color-text-gray); line-height: 1.65; margin: 0;">
                    Structural pruning enhances the architecture of a tree by removing poorly placed, crossing, and poorly attached branches. With young trees, this is particularly helpful since early pruning of limbs to fix issues can help the tree grow into a better shape as it gets older.
                </p>
            </div>

            <!-- 2 -->
            <div class="tp-type-card">
                <div class="tp-card-icon"><?php echo tp_render_svg('type-deadwood.svg', '🍂'); ?></div>
                <h3 style="font-size: 1.25rem; color: var(--color-brand-purple); margin-bottom: 0.85rem;">Deadwood Removal</h3>
                <p style="font-size: 1rem; color: var(--color-text-gray); line-height: 1.65; margin: 0;">
                    Deadwood removal aims to eliminate dead, broken, dying or non-functional branches. Falling branches are especially hazardous during the winter months in Buffalo when snow, ice, and wind can occur.
                </p>
            </div>

            <!-- 3 -->
            <div class="tp-type-card">
                <div class="tp-card-icon"><?php echo tp_render_svg('type-disease.svg', '🐛'); ?></div>
                <h3 style="font-size: 1.25rem; color: var(--color-brand-purple); margin-bottom: 0.85rem;">Disease and Pest-Related Pruning</h3>
                <p style="font-size: 1rem; color: var(--color-text-gray); line-height: 1.65; margin: 0;">
                    Some diseases and pest issues might necessitate the removal of infected branches. Our arborists survey the affected areas and decide if pruning is part of the recommended treatment. Depending on the condition, removal of affected material may prevent the spread of a problem throughout portions of the tree.
                </p>
            </div>

            <!-- 4 -->
            <div class="tp-type-card">
                <div class="tp-card-icon"><?php echo tp_render_svg('reduction.svg', '⬇️'); ?></div>
                <h3 style="font-size: 1.25rem; color: var(--color-brand-purple); margin-bottom: 0.85rem;">Crown Reduction</h3>
                <p style="font-size: 1rem; color: var(--color-text-gray); line-height: 1.65; margin: 0;">
                    Crown reduction selectively reduces the overall size of a canopy when appropriate. May be used when the tree has outgrown its space or when specific limbs are a problem around buildings. Professional crown reduction does not indiscriminately cut back the canopy of the tree.
                </p>
            </div>

            <!-- 5 -->
            <div class="tp-type-card">
                <div class="tp-card-icon"><?php echo tp_render_svg('type-clearance.svg', '⚡'); ?></div>
                <h3 style="font-size: 1.25rem; color: var(--color-brand-purple); margin-bottom: 0.85rem;">Clearance Pruning</h3>
                <p style="font-size: 1rem; color: var(--color-text-gray); line-height: 1.65; margin-bottom: 0.75rem;">
                    The proper spacing between limbs and proximity to other structures is established with clearance pruning.
                </p>
                <p style="font-size: 0.95rem; color: var(--color-brand-purple); font-weight: bold; margin-bottom: 0.5rem;">Common areas include:</p>
                <ul style="list-style: none; padding: 0; margin: 0; display: grid; grid-template-columns: 1fr 1fr; gap: 0.4rem; font-size: 0.95rem; color: var(--color-text-gray);">
                    <li>• Roofs</li>
                    <li>• Buildings</li>
                    <li>• Driveways</li>
                    <li>• Sidewalks</li>
                    <li>• Roads</li>
                    <li>• Fences</li>
                    <li>• Utility areas</li>
                </ul>
            </div>

            <!-- 6 -->
            <div class="tp-type-card">
                <div class="tp-card-icon"><?php echo tp_render_svg('type-thinning.svg', '🌿'); ?></div>
                <h3 style="font-size: 1.25rem; color: var(--color-brand-purple); margin-bottom: 0.85rem;">Crown Thinning</h3>
                <p style="font-size: 1rem; color: var(--color-text-gray); line-height: 1.65; margin: 0;">
                    Crown thinning selectively removes some branches in the canopy, allowing light and air to penetrate the tree, while retaining an adequate amount of foliage.
                </p>
            </div>

            <!-- 7 -->
            <div class="tp-type-card">
                <div class="tp-card-icon"><?php echo tp_render_svg('type-young.svg', '🌱'); ?></div>
                <h3 style="font-size: 1.25rem; color: var(--color-brand-purple); margin-bottom: 0.85rem;">Young Tree Pruning</h3>
                <p style="font-size: 1rem; color: var(--color-text-gray); line-height: 1.65; margin: 0;">
                    Young trees can be given structural support early in growth. Corrective pruning can be used to set up a desirable branch structure and to minimize potential structural issues as the tree develops.
                </p>
            </div>
        </div>
    </div>
</section>

<!-- =========================================================================
     SECTION 5: BEST TIME FOR TREE PRUNING IN WESTERN NEW YORK
     ========================================================================= -->
<section class="tp-section">
    <div class="tp-container">
        <div class="text-center" style="max-width: 850px; margin: 0 auto 3rem auto;">
            <span class="global-subtitle">
                OPTIMAL TIMING
            </span>
            <h2 class="global-section-title">Best Time for Tree Pruning in Western New York</h2>
            <div class="section-divider" style="margin: 1rem auto 1.5rem auto;"></div>
            
            <h3 style="font-size: 1.35rem; color: var(--color-brand-purple); margin-bottom: 1rem;">When Is the Best Time to Prune Trees in Buffalo?</h3>
            <p style="font-size: 1.05rem; color: var(--color-text-gray); line-height: 1.7; margin-bottom: 1rem;">
                Pruning's ideal time is influenced by tree species, tree health, pruning goals and weather. Many routine pruning projects may be scheduled during dormancy; branches that pose a hazard should be pruned whenever needed.
            </p>
            <p style="font-size: 1.05rem; color: var(--color-text-gray); line-height: 1.7;">
                The weather in Buffalo is unpredictable and changes seasonally, so it is crucial to respond at the right time. Weak branches may be revealed during the winter season from snow or ice and active growth starts in the spring and summer months.
            </p>
        </div>

        <div class="tp-seasons-grid">
            <!-- Winter -->
            <div class="tp-season-card">
                <div class="tp-card-icon"><?php echo tp_render_svg('winter.svg', '❄️'); ?></div>
                <h3 style="font-size: 1.25rem; color: var(--color-brand-purple); margin-bottom: 0.75rem;">Winter Pruning</h3>
                <p style="font-size: 1rem; color: var(--color-text-gray); line-height: 1.65; margin-bottom: 0.75rem;">
                    Many of the common pruning tasks can be done during the winter months when trees are dormant and their branches are easier to see.
                </p>
                <p style="font-size: 0.95rem; color: var(--color-brand-purple); font-weight: bold; margin-bottom: 0.4rem;">Advantages may include:</p>
                <ul style="list-style: none; padding: 0; margin: 0; font-size: 0.95rem; color: var(--color-text-gray); line-height: 1.5;">
                    <li>• Easier canopy inspection</li>
                    <li>• Reduced active growth</li>
                    <li>• Clearer views of the branches.</li>
                    <li>• Cover cropping for the spring crop.</li>
                </ul>
            </div>

            <!-- Spring -->
            <div class="tp-season-card">
                <div class="tp-card-icon"><?php echo tp_render_svg('spring.svg', '🌸'); ?></div>
                <h3 style="font-size: 1.25rem; color: var(--color-brand-purple); margin-bottom: 0.75rem;">Spring Pruning</h3>
                <p style="font-size: 1rem; color: var(--color-text-gray); line-height: 1.65; margin: 0;">
                    Winter damage and some structural issues can be dealt with during the spring pruning season. The timing is dependent upon tree species and condition, however. Heavy pruning should not be done on trees that have been damaged by winter storms without first assessing the situation.
                </p>
            </div>

            <!-- Summer -->
            <div class="tp-season-card">
                <div class="tp-card-icon"><?php echo tp_render_svg('summer.svg', '☀️'); ?></div>
                <h3 style="font-size: 1.25rem; color: var(--color-brand-purple); margin-bottom: 0.75rem;">Summer Pruning</h3>
                <p style="font-size: 1rem; color: var(--color-text-gray); line-height: 1.65; margin: 0;">
                    For some corrective, clearance, and/or safety reasons, summer pruning may be suitable. During the growing season, branches may need to be pruned or removed due to their rapid growth or the effects of storms.
                </p>
            </div>

            <!-- Fall -->
            <div class="tp-season-card">
                <div class="tp-card-icon"><?php echo tp_render_svg('fall.svg', '🍁'); ?></div>
                <h3 style="font-size: 1.25rem; color: var(--color-brand-purple); margin-bottom: 0.75rem;">Fall Pruning</h3>
                <p style="font-size: 1rem; color: var(--color-text-gray); line-height: 1.65; margin: 0;">
                    Fall gives a chance to check out trees before winter in Buffalo. Pruning known problem branches may minimize the potential of winter issues.
                </p>
            </div>

            <!-- Emergency -->
            <div class="tp-season-card" style="border-top-color: var(--color-warm-gold);">
                <div class="tp-card-icon"><?php echo tp_render_svg('alert.svg', '🚨'); ?></div>
                <h3 style="font-size: 1.25rem; color: var(--color-brand-purple); margin-bottom: 0.75rem;">Emergency Pruning</h3>
                <p style="font-size: 1rem; color: var(--color-text-gray); line-height: 1.65; margin-bottom: 0.75rem;">
                    It is not only not the ideal pruning time, but also a hazardous branch should not be left.
                </p>
                <p style="font-size: 0.95rem; color: var(--color-brand-purple); font-weight: bold; margin-bottom: 0.4rem;">Immediate professional attention may be necessary when:</p>
                <ul style="list-style: none; padding: 0; margin: 0; font-size: 0.95rem; color: var(--color-text-gray); line-height: 1.5;">
                    <li>• A branch has broken</li>
                    <li>• A limb is hanging over a structure</li>
                    <li>• Storm damage has occurred</li>
                    <li>• Branches block roads and/or walkways</li>
                    <li>• A tree presents an immediate safety concern</li>
                </ul>
            </div>
        </div>
    </div>
</section>

<!-- =========================================================================
     SECTION 6: TREE PRUNING SERVICES IN YOUR BUFFALO NEIGHBORHOOD
     ========================================================================= -->
<section class="tp-section-alt">
    <div class="tp-container">
        <div class="text-center" style="max-width: 850px; margin: 0 auto 3rem auto;">
            <span class="global-subtitle">
                COMMUNITY CARE
            </span>
            <h2 class="global-section-title">Tree Pruning Services in Your Buffalo Neighborhood</h2>
            <div class="section-divider" style="margin: 1rem auto 1.5rem auto;"></div>

            <!-- Key Takeaway Box -->
            <div style="background-color: var(--color-white); border-left: 4px solid var(--color-warm-gold); border-radius: 8px; padding: 1.5rem 2rem; margin: 1.5rem 0 2rem 0; text-align: left; box-shadow: 0 4px 15px rgba(0,0,0,0.03);">
                <p style="font-size: 1.05rem; line-height: 1.6; font-weight: 700; color: var(--color-brand-purple); margin: 0;">
                    <strong>Key Takeaway:</strong> Local pruning experience matters because Buffalo trees face different exposure, property layouts, snow loads, wind conditions, and clearance challenges from one neighborhood to another.
                </p>
            </div>

            <h3 style="font-size: 1.35rem; color: var(--color-brand-purple); margin-bottom: 1rem;">Local Tree Pruning for Buffalo Properties</h3>
            <p style="font-size: 1.05rem; color: var(--color-text-gray); line-height: 1.7; margin-bottom: 1rem;">
                Property owners should look for tree pruning near me professionals who are well-versed in the local trees and Buffalo weather.
            </p>
            <p style="font-size: 1.05rem; color: var(--color-text-gray); line-height: 1.7;">
                Choosing the right company for tree pruning is important because improper cuts can damage trees and create long-term structural problems. Maple Majesty Tree Care combines arborist knowledge, professional equipment, safety practices, and local experience.
            </p>
        </div>

        <div style="background: var(--color-white); border-radius: 16px; padding: 2.5rem; box-shadow: 0 6px 20px rgba(0,0,0,0.04); margin-bottom: 3rem; border-left: 5px solid var(--color-brand-purple);">
            <h3 style="font-size: 1.3rem; color: var(--color-brand-purple); margin-bottom: 1rem;">We offer pruning services to:</h3>
            <ul style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 0.75rem; list-style: none; padding: 0; margin: 0;">
                <li style="display: flex; align-items: center; gap: 0.5rem; color: var(--color-text-gray); font-weight: 500;"><span style="color: var(--color-warm-gold);"><?php echo tp_render_svg('check-circle.svg', '✓'); ?></span> Residential properties</li>
                <li style="display: flex; align-items: center; gap: 0.5rem; color: var(--color-text-gray); font-weight: 500;"><span style="color: var(--color-warm-gold);"><?php echo tp_render_svg('check-circle.svg', '✓'); ?></span> Commercial buildings</li>
                <li style="display: flex; align-items: center; gap: 0.5rem; color: var(--color-text-gray); font-weight: 500;"><span style="color: var(--color-warm-gold);"><?php echo tp_render_svg('check-circle.svg', '✓'); ?></span> Rental properties</li>
                <li style="display: flex; align-items: center; gap: 0.5rem; color: var(--color-text-gray); font-weight: 500;"><span style="color: var(--color-warm-gold);"><?php echo tp_render_svg('check-circle.svg', '✓'); ?></span> Apartment communities</li>
                <li style="display: flex; align-items: center; gap: 0.5rem; color: var(--color-text-gray); font-weight: 500;"><span style="color: var(--color-warm-gold);"><?php echo tp_render_svg('check-circle.svg', '✓'); ?></span> HOAs</li>
                <li style="display: flex; align-items: center; gap: 0.5rem; color: var(--color-text-gray); font-weight: 500;"><span style="color: var(--color-warm-gold);"><?php echo tp_render_svg('check-circle.svg', '✓'); ?></span> Schools</li>
                <li style="display: flex; align-items: center; gap: 0.5rem; color: var(--color-text-gray); font-weight: 500;"><span style="color: var(--color-warm-gold);"><?php echo tp_render_svg('check-circle.svg', '✓'); ?></span> Churches</li>
                <li style="display: flex; align-items: center; gap: 0.5rem; color: var(--color-text-gray); font-weight: 500;"><span style="color: var(--color-warm-gold);"><?php echo tp_render_svg('check-circle.svg', '✓'); ?></span> Larger landscapes</li>
            </ul>
        </div>

        <h3 style="font-size: 1.4rem; color: var(--color-brand-purple); text-align: center; margin-bottom: 2rem;">Buffalo Neighborhoods We Serve</h3>
        <p style="text-align: center; color: var(--color-text-gray); margin-bottom: 2rem;">We serve communities and neighborhoods in and around the local area, including:</p>

        <div class="tp-communities-grid">
            <div class="tp-community-card">
                <div class="tp-card-icon" style="margin: 0 auto 1.25rem auto;"><?php echo tp_render_svg('map-point.svg', '📍'); ?></div>
                <h3 style="font-size: 1.2rem; color: var(--color-brand-purple); margin-bottom: 0.75rem;">Downtown Buffalo</h3>
            </div>
            <div class="tp-community-card">
                <div class="tp-card-icon" style="margin: 0 auto 1.25rem auto;"><?php echo tp_render_svg('map-point.svg', '📍'); ?></div>
                <h3 style="font-size: 1.2rem; color: var(--color-brand-purple); margin-bottom: 0.75rem;">Elmwood Village</h3>
            </div>
            <div class="tp-community-card">
                <div class="tp-card-icon" style="margin: 0 auto 1.25rem auto;"><?php echo tp_render_svg('map-point.svg', '📍'); ?></div>
                <h3 style="font-size: 1.2rem; color: var(--color-brand-purple); margin-bottom: 0.75rem;">North Buffalo</h3>
            </div>
            <div class="tp-community-card">
                <div class="tp-card-icon" style="margin: 0 auto 1.25rem auto;"><?php echo tp_render_svg('map-point.svg', '📍'); ?></div>
                <h3 style="font-size: 1.2rem; color: var(--color-brand-purple); margin-bottom: 0.75rem;">South Buffalo</h3>
            </div>
            <div class="tp-community-card">
                <div class="tp-card-icon" style="margin: 0 auto 1.25rem auto;"><?php echo tp_render_svg('map-point.svg', '📍'); ?></div>
                <h3 style="font-size: 1.2rem; color: var(--color-brand-purple); margin-bottom: 0.75rem;">Allentown</h3>
            </div>
            <div class="tp-community-card">
                <div class="tp-card-icon" style="margin: 0 auto 1.25rem auto;"><?php echo tp_render_svg('map-point.svg', '📍'); ?></div>
                <h3 style="font-size: 1.2rem; color: var(--color-brand-purple); margin-bottom: 0.75rem;">Black Rock</h3>
            </div>
            <div class="tp-community-card">
                <div class="tp-card-icon" style="margin: 0 auto 1.25rem auto;"><?php echo tp_render_svg('map-point.svg', '📍'); ?></div>
                <h3 style="font-size: 1.2rem; color: var(--color-brand-purple); margin-bottom: 0.75rem;">Riverside</h3>
            </div>
            <div class="tp-community-card">
                <div class="tp-card-icon" style="margin: 0 auto 1.25rem auto;"><?php echo tp_render_svg('map-point.svg', '📍'); ?></div>
                <h3 style="font-size: 1.2rem; color: var(--color-brand-purple); margin-bottom: 0.75rem;">University Heights</h3>
            </div>
            <div class="tp-community-card">
                <div class="tp-card-icon" style="margin: 0 auto 1.25rem auto;"><?php echo tp_render_svg('map-point.svg', '📍'); ?></div>
                <h3 style="font-size: 1.2rem; color: var(--color-brand-purple); margin-bottom: 0.75rem;">West Side Buffalo</h3>
            </div>
        </div>

        <p style="text-align: center; color: var(--color-text-gray); margin-top: 2rem; font-size: 1.05rem;">
            Others also who live in the surrounding areas of Western New York and enjoy our services.
        </p>
        <p style="text-align: center; color: var(--color-text-gray); font-size: 1.05rem;">
            Local knowledge is important as tree conditions will differ from lot to lot due to the size, exposure, adjacent structures, and landscape design.
        </p>
    </div>
</section>

<!-- =========================================================================
     SECTION 7: BUFFALO'S TOP CHOICE FOR PROFESSIONAL TREE PRUNING
     ========================================================================= -->
<section class="tp-section">
    <div class="tp-container">
        <div class="text-center" style="max-width: 850px; margin: 0 auto 3rem auto;">
            <span class="global-subtitle">
                TOP RATED CARE
            </span>
            <h2 class="global-section-title">Buffalo's Top Choice for Professional Tree Pruning</h2>
            <div class="section-divider" style="margin: 1rem auto 1.5rem auto;"></div>

            <!-- Key Takeaway Box -->
            <div style="background-color: var(--color-soft-lilac); border-left: 4px solid var(--color-warm-gold); border-radius: 8px; padding: 1.5rem 2rem; margin: 1.5rem 0 2rem 0; text-align: left;">
                <p style="font-size: 1.05rem; line-height: 1.6; font-weight: 700; color: var(--color-brand-purple); margin: 0;">
                Quality tree pruning combines arborist knowledge, proper equipment, safe work practices, and species-specific recommendations to protect both the tree and surrounding property.
                </p>
            </div>

            <h3 style="font-size: 1.35rem; color: var(--color-brand-purple); margin-bottom: 1rem;">Why Choose Maple Majesty Tree Care?</h3>
            <p style="font-size: 1.05rem; color: var(--color-text-gray); line-height: 1.7;">
                Tree pruning service is a necessary service, but it is important to select the right company as there are certain risks involved with choosing the wrong one, such as cutting into the structure of the tree. The combination of an arborist's expertise, professional tools, safety protocols and local experience is what makes Maple Majesty Tree Care a great choice.
            </p>
        </div>

        <div class="tp-trust-grid">
            <!-- 1 -->
            <div class="tp-trust-card">
                <div class="tp-card-icon" style="margin: 0 auto 1.5rem auto;"><?php echo tp_render_svg('trust-arborist.svg', '🎓'); ?></div>
                <h3 style="font-size: 1.25rem; color: var(--color-brand-purple); margin-bottom: 0.85rem;">ISA-Certified Arborist Expertise</h3>
                <p style="font-size: 1rem; color: var(--color-text-gray); line-height: 1.65; margin: 0;">
                    Our Tree Specialists, who are ISA Certified Arborists, are familiar with tree biology, structural growth, disease issues and correct tree care techniques. This information is useful in deciding what branches to prune and what to retain to provide the structure we need.
                </p>
            </div>

            <!-- 2 -->
            <div class="tp-trust-card">
                <div class="tp-card-icon" style="margin: 0 auto 1.5rem auto;"><?php echo tp_render_svg('trust-safety.svg', '🛡️'); ?></div>
                <h3 style="font-size: 1.25rem; color: var(--color-brand-purple); margin-bottom: 0.85rem;">Safety-Focused Service</h3>
                <p style="font-size: 1rem; color: var(--color-text-gray); line-height: 1.65; margin: 0;">
                    Pruning can require the use of elevated platforms, heavy limbs, specific tools, and structures. The work area is evaluated before beginning and proper safety precautions and equipment is used.
                </p>
            </div>

            <!-- 3 -->
            <div class="tp-trust-card">
                <div class="tp-card-icon" style="margin: 0 auto 1.5rem auto;"><?php echo tp_render_svg('trust-equipment.svg', '⚙️'); ?></div>
                <h3 style="font-size: 1.25rem; color: var(--color-brand-purple); margin-bottom: 0.85rem;">Professional Equipment</h3>
                <p style="font-size: 1rem; color: var(--color-text-gray); line-height: 1.65; margin-bottom: 0.5rem;">
                    These items depend on the project and could include:
                </p>
                <ul style="list-style: none; padding: 0; margin: 0; font-size: 0.95rem; color: var(--color-text-gray); line-height: 1.5;">
                    <li>• Hand pruners</li>
                    <li>• Pruning saws</li>
                    <li>• Pole saws</li>
                    <li>• Chainsaws</li>
                    <li>• Climbing equipment</li>
                    <li>• Bucket trucks</li>
                    <li>• Rigging systems</li>
                </ul>
            </div>

            <!-- 4 -->
            <div class="tp-trust-card">
                <div class="tp-card-icon" style="margin: 0 auto 1.5rem auto;"><?php echo tp_render_svg('customized.svg', '📋'); ?></div>
                <h3 style="font-size: 1.25rem; color: var(--color-brand-purple); margin-bottom: 0.85rem;">Customized Recommendations</h3>
                <p style="font-size: 1rem; color: var(--color-text-gray); line-height: 1.65; margin: 0;">
                    No two trees are ever the same. Pruning recommendations are based on species, age, condition, location, canopy density, and structural issues.
                </p>
            </div>

            <!-- 5 -->
            <div class="tp-trust-card">
                <div class="tp-card-icon" style="margin: 0 auto 1.5rem auto;"><?php echo tp_render_svg('trust-local.svg', '🦬'); ?></div>
                <h3 style="font-size: 1.25rem; color: var(--color-brand-purple); margin-bottom: 0.85rem;">Local Buffalo Experience</h3>
                <p style="font-size: 1rem; color: var(--color-text-gray); line-height: 1.65; margin: 0;">
                    Strong winds, ice and snow can pose special tree care problems in Buffalo. As we have local experience, we can recognise any potential weak points and can suggest suitable maintenance.
                </p>
            </div>

            <!-- 6 -->
            <div class="tp-trust-card">
                <div class="tp-card-icon" style="margin: 0 auto 1.5rem auto;"><?php echo tp_render_svg('honest.svg', '💬'); ?></div>
                <h3 style="font-size: 1.25rem; color: var(--color-brand-purple); margin-bottom: 0.85rem;">Honest Tree Care</h3>
                <p style="font-size: 1rem; color: var(--color-text-gray); line-height: 1.65; margin: 0;">
                    We are not looking to remove as many branches as we can. We only provide the services your tree needs and make it easy to understand.
                </p>
            </div>

            <!-- 7 -->
            <div class="tp-trust-card">
                <div class="tp-card-icon" style="margin: 0 auto 1.5rem auto;"><?php echo tp_render_svg('trust-solutions.svg', '🌿'); ?></div>
                <h3 style="font-size: 1.25rem; color: var(--color-brand-purple); margin-bottom: 0.85rem;">Complete Tree Services</h3>
                <p style="font-size: 1rem; color: var(--color-text-gray); line-height: 1.65; margin: 0;">
                    If pruning is not the right option, we are able to assist in determining other tree care requirements such as tree removal, emergency tree services, stump removal, land clearing or storm cleanup.
                </p>
            </div>
        </div>
    </div>
</section>

<!-- =========================================================================
     SECTION 8: TREE PRUNING NEAR ME — BUFFALO & WESTERN NEW YORK
     ========================================================================= -->
<section class="tp-section-alt">
    <div class="tp-container">
        <div>
            <span class="global-subtitle">
                SERVICE AREA
            </span>
            <h2 class="global-section-title">Tree Pruning Near Me — Buffalo & Western New York</h2>
            <div class="section-divider"></div>

            <!-- Key Takeaway Box -->
            <div style="background-color: var(--color-white); border-left: 4px solid var(--color-warm-gold); border-radius: 8px; padding: 1.5rem 2rem; margin: 1.5rem 0 2rem 0; box-shadow: 0 4px 15px rgba(0,0,0,0.03);">
                <p style="font-size: 1.05rem; line-height: 1.6; font-weight: 700; color: var(--color-brand-purple); margin: 0;">
                 Maple Majesty Tree Care provides professional pruning throughout Buffalo and nearby Western New York communities for residential, commercial, rental, and managed properties.
                </p>
            </div>

            <p style="font-size: 1.1rem; color: var(--color-text-gray); line-height: 1.7; margin-bottom: 1.5rem;">
                Tree pruning near me is provided by Maple Majesty Tree Care of Buffalo and the nearby Western New York areas.
            </p>
        </div>

        <div style="background: var(--color-white); border-radius: 16px; padding: 2.5rem; box-shadow: 0 6px 20px rgba(0,0,0,0.04); margin-bottom: 2rem; border-left: 5px solid var(--color-forest-green);">
            <h3 style="font-size: 1.35rem; color: var(--color-brand-purple); margin-bottom: 1.5rem;">Primary Service Area</h3>
            <ul style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 0.75rem; list-style: none; padding: 0; margin: 0 0 1.5rem 0;">
                <li style="display: flex; align-items: center; gap: 0.5rem; color: var(--color-text-gray); font-weight: 500;"><span style="color: var(--color-warm-gold);"><?php echo tp_render_svg('map-pin.svg', '📍'); ?></span> Buffalo</li>
                <li style="display: flex; align-items: center; gap: 0.5rem; color: var(--color-text-gray); font-weight: 500;"><span style="color: var(--color-warm-gold);"><?php echo tp_render_svg('map-pin.svg', '📍'); ?></span> Amherst</li>
                <li style="display: flex; align-items: center; gap: 0.5rem; color: var(--color-text-gray); font-weight: 500;"><span style="color: var(--color-warm-gold);"><?php echo tp_render_svg('map-pin.svg', '📍'); ?></span> Williamsville</li>
                <li style="display: flex; align-items: center; gap: 0.5rem; color: var(--color-text-gray); font-weight: 500;"><span style="color: var(--color-warm-gold);"><?php echo tp_render_svg('map-pin.svg', '📍'); ?></span> Cheektowaga</li>
                <li style="display: flex; align-items: center; gap: 0.5rem; color: var(--color-text-gray); font-weight: 500;"><span style="color: var(--color-warm-gold);"><?php echo tp_render_svg('map-pin.svg', '📍'); ?></span> Tonawanda</li>
                <li style="display: flex; align-items: center; gap: 0.5rem; color: var(--color-text-gray); font-weight: 500;"><span style="color: var(--color-warm-gold);"><?php echo tp_render_svg('map-pin.svg', '📍'); ?></span> Kenmore</li>
                <li style="display: flex; align-items: center; gap: 0.5rem; color: var(--color-text-gray); font-weight: 500;"><span style="color: var(--color-warm-gold);"><?php echo tp_render_svg('map-pin.svg', '📍'); ?></span> West Seneca</li>
                <li style="display: flex; align-items: center; gap: 0.5rem; color: var(--color-text-gray); font-weight: 500;"><span style="color: var(--color-warm-gold);"><?php echo tp_render_svg('map-pin.svg', '📍'); ?></span> Hamburg</li>
                <li style="display: flex; align-items: center; gap: 0.5rem; color: var(--color-text-gray); font-weight: 500;"><span style="color: var(--color-warm-gold);"><?php echo tp_render_svg('map-pin.svg', '📍'); ?></span> Orchard Park</li>
                <li style="display: flex; align-items: center; gap: 0.5rem; color: var(--color-text-gray); font-weight: 500;"><span style="color: var(--color-warm-gold);"><?php echo tp_render_svg('map-pin.svg', '📍'); ?></span> Clarence</li>
                <li style="display: flex; align-items: center; gap: 0.5rem; color: var(--color-text-gray); font-weight: 500;"><span style="color: var(--color-warm-gold);"><?php echo tp_render_svg('map-pin.svg', '📍'); ?></span> Lancaster</li>
                <li style="display: flex; align-items: center; gap: 0.5rem; color: var(--color-text-gray); font-weight: 500;"><span style="color: var(--color-warm-gold);"><?php echo tp_render_svg('map-pin.svg', '📍'); ?></span> Depew</li>
                <li style="display: flex; align-items: center; gap: 0.5rem; color: var(--color-text-gray); font-weight: 500;"><span style="color: var(--color-warm-gold);"><?php echo tp_render_svg('map-pin.svg', '📍'); ?></span> Lackawanna</li>
            </ul>
            <p style="color: var(--color-text-gray); margin: 0; font-size: 1.05rem;">We service homes and businesses throughout the region.</p>
        </div>

        <p style="font-size: 1.1rem; color: var(--color-text-gray); line-height: 1.7; text-align: center; max-width: 900px; margin: 0 auto;">
            We can assess the tree and determine the next step, whether it requires routine pruning for a mature backyard tree, structural pruning for a young tree, or if it has been damaged by a storm. We will assess the tree and then recommend the next step.
        </p>
    </div>
</section>


