<?php
/**
 * FAQ Section Template Part
 * 
 * Expects: $args['faqs'] to be an array of ['question' => '...', 'answer' => '...']
 */
$faqs = isset($args['faqs']) ? $args['faqs'] : [];

if (empty($faqs)) {
    return; // Don't output anything if no FAQs are provided
}
?>

<section class="faq-section">
    <div class="container faq-container">
        <div class="text-center" style="margin-bottom: 3rem;">
            <span class="global-subtitle">HAVE QUESTIONS?</span>
            <h2 class="global-section-title">Frequently Asked Questions</h2>
            <div class="section-divider" style="margin: 1rem auto;"></div>
        </div>

        <div class="faq-accordion">
            <?php foreach ($faqs as $index => $faq) : ?>
                <details class="faq-item" <?php echo $index === 0 ? 'open' : ''; ?>>
                    <summary class="faq-question">
                        <span class="faq-question-text"><?php echo esc_html($faq['question']); ?></span>
                        <span class="faq-toggle-icon">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <polyline points="6 9 12 15 18 9"></polyline>
                            </svg>
                        </span>
                    </summary>
                    <div class="faq-answer">
                        <p><?php echo wp_kses_post($faq['answer']); ?></p>
                    </div>
                </details>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Dynamic FAQ Schema Markup (JSON-LD) -->
<?php
$faq_schema = [
    '@context' => 'https://schema.org',
    '@type' => 'FAQPage',
    'mainEntity' => []
];

foreach ($faqs as $faq) {
    if (!empty($faq['question']) && !empty($faq['answer'])) {
        $faq_schema['mainEntity'][] = [
            '@type' => 'Question',
            'name' => wp_strip_all_tags($faq['question']),
            'acceptedAnswer' => [
                '@type' => 'Answer',
                'text' => wp_strip_all_tags($faq['answer'])
            ]
        ];
    }
}

if (!empty($faq_schema['mainEntity'])):
?>
<script type="application/ld+json">
<?php echo json_encode($faq_schema, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?>
</script>
<?php endif; ?>

