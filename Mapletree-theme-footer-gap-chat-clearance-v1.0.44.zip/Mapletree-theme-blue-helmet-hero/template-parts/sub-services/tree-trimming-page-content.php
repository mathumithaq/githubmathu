<?php
/**
 * Template Part: Tree Trimming Sub-Service Page Content (Buffalo, NY)
 * Contains 100% verbatim content for all sections requested by user.
 */

// Helper to safely render inline SVGs
if (!function_exists('tt_render_svg')) {
    function tt_render_svg($filename, $fallback = '') {
        $path = get_template_directory() . '/assets/icons/' . $filename;
        if (file_exists($path)) {
            return file_get_contents($path);
        }
        return $fallback;
    }
}
?>


<!-- =========================================================================
     SECTION 1: WHAT IS TREE TRIMMING?
     ========================================================================= -->
<section class="tt-section">
    <div class="tt-container">
        <span class="global-subtitle">
            TREE TRIMMING OVERVIEW
        </span>
        <h2 class="global-section-title">What Is Tree Trimming?</h2>
        <div class="section-divider"></div>
        
        <p style="font-size: 1.1rem; line-height: 1.8; color: var(--color-text-gray); margin-top: 1.5rem;">
            Tree Trimming is the art of removing certain branches to enhance the health, safety, appearance, and structure of trees. It is not just a cutting operation, but entails an understanding of tree biology and correct cutting practices. Weak, overgrown or damaged limbs can stifle air circulation, block sunshine and pose a danger during Buffalo's stormy, snowy and icy weather. Our ISA-certified arborists at Maple Majesty Tree Care evaluate the tree species, condition and environment of each tree to determine an appropriate trimming solution. Services offered include dead wood removal, canopy improvement, clearance pruning and shaping to ensure healthier trees and safer properties throughout Buffalo.
        </p>
    </div>
</section>

<!-- =========================================================================
     SECTION 2: TOP BENEFITS OF REGULAR TREE TRIMMING
     ========================================================================= -->
<section class="tt-section-alt">
    <div class="tt-container">
        <div class="text-center" style="max-width: 850px; margin: 0 auto 3rem auto;">
            <span class="global-subtitle">
                HEALTH & SAFETY BENEFITS
            </span>
            <h2 class="global-section-title">Top Benefits of Regular Tree Trimming</h2>
            <div class="section-divider" style="margin: 1rem auto 1.5rem auto;"></div>
            
            <h3 style="font-size: 1.35rem; color: var(--color-brand-purple); margin-bottom: 1rem;">Why Is Regular Tree Trimming Important?</h3>
            <p style="font-size: 1.1rem; color: var(--color-text-gray); line-height: 1.7;">
                Regular tree trimming can do more than just enhance the look of your landscape. Regular maintenance is a good way to keep trees healthy, safe and to prevent damage to your property.
            </p>
        </div>

        <div class="tt-benefits-grid">
            <!-- 1 -->
            <div class="tt-benefit-card">
                <div class="tt-card-icon"><?php echo tt_render_svg('pruning-health.svg', '🌱'); ?></div>
                <h3>1. Improves Tree Health</h3>
                <p>Pruning dead, diseased, or damaged branches enables trees to allocate their energy to healthy growth. Frequent pruning enhances structure, facilitates recovery and enables arborists to identify problems at an early stage.</p>
            </div>

            <!-- 2 -->
            <div class="tt-benefit-card">
                <div class="tt-card-icon"><?php echo tt_render_svg('pruning-structure.svg', '🌳'); ?></div>
                <h3>2. Strengthens Tree Structure</h3>
                <p>Various professional pruning techniques enhance branch spacing and minimize stress on weaker or overcrowded branches. Young trees will particularly benefit from structural pruning, which helps promote stronger and more balanced growth.</p>
            </div>

            <!-- 3 -->
            <div class="tt-benefit-card">
                <div class="tt-card-icon"><?php echo tt_render_svg('pruning-airflow.svg', '☀️'); ?></div>
                <h3>3. Enhances Tree Canopy</h3>
                <p>Selective pruning and crown thinning enhance ventilation and light reaching the tree canopy. Improved circulation will minimize moisture accumulation and promote good tree growth.</p>
            </div>

            <!-- 4 -->
            <div class="tt-benefit-card">
                <div class="tt-card-icon"><?php echo tt_render_svg('storm-damage.svg', '❄️'); ?></div>
                <h3>4. Reduces Storm Damage Risks</h3>
                <p>Trees can be stressed by heavy snow, ice storm and strong wind conditions in Buffalo. Trimming regularly gets rid of weak limbs before they become a liability due to severe weather or cause property damage.</p>
            </div>

            <!-- 5 -->
            <div class="tt-benefit-card">
                <div class="tt-card-icon"><?php echo tt_render_svg('pruning-property.svg', '🏡'); ?></div>
                <h3>5. Protects Your Property</h3>
                <p>Branches growing too near roofs, windows, driveways, fences and utilities may form hazards. Safe clearance and protection of the home and property is provided with professional trimming.</p>
            </div>

            <!-- 6 -->
            <div class="tt-benefit-card">
                <div class="tt-card-icon"><?php echo tt_render_svg('pruning-appearance.svg', '✨'); ?></div>
                <h3>6. Improves Landscape Appearance</h3>
                <p>Cleanup tidies up trees, making them more attractive and clean. Good shaping can increase curb appeal and maintain the tree's natural shape and growth habits.</p>
            </div>

            <!-- 7 -->
            <div class="tt-benefit-card">
                <div class="tt-card-icon"><?php echo tt_render_svg('pruning-maintenance.svg', '⏳'); ?></div>
                <h3>7. Supports Long-Term Tree Maintenance</h3>
                <p>Regular cutting is important for homeowners to avoid future issues and deal with the problem early on. Establishing a regular maintenance program can extend the life of the tree and ensure the longevity of valuable landscape trees for many years.</p>
            </div>
        </div>
    </div>
</section>

<!-- =========================================================================
     SECTION 3: HOW TREE TRIMMING SERVICE WORKS
     ========================================================================= -->
<section class="tt-section">
    <div class="tt-container">
        <div class="text-center" style="max-width: 850px; margin: 0 auto 3rem auto;">
            <span class="global-subtitle">
                STEP-BY-STEP PROCESS
            </span>
            <h2 class="global-section-title">How Tree Trimming Service Works</h2>
            <div class="section-divider" style="margin: 1rem auto 1.5rem auto;"></div>
            <p style="font-size: 1.1rem; color: var(--color-text-gray); line-height: 1.7; margin-bottom: 1.5rem;">
                About professional tree trimming services in Buffalo, NY by certified arborists, safe and environmentally friendly techniques and equipment to ensure tree health and property security.
            </p>
        </div>

        <div style="background: var(--color-soft-lilac); border-radius: 12px; padding: 2rem; margin-bottom: 3rem; border-left: 4px solid var(--color-brand-purple);">
            <h3 style="font-size: 1.35rem; color: var(--color-brand-purple); margin-bottom: 1rem;">How Does Professional Tree Trimming Service Work?</h3>
            <p style="font-size: 1.05rem; color: var(--color-text-gray); line-height: 1.7; margin-bottom: 1rem;">
                A professional tree trimming service goes through a series of steps to enhance tree health and safety, lower potential dangers, and preserve the organic beauty of your landscaping. Every time you bring in Maple Majesty Tree Care for a trim, it starts with an assessment by trained arborists with a deep understanding of tree biology, growth habits, and seasonal issues faced in Buffalo.
            </p>
            <p style="font-size: 1.05rem; color: var(--color-text-gray); line-height: 1.7; margin: 0;">
                Tree pruning is more than just branches. Improper pruning of branches can result in structural weaknesses in the tree that lead to new issues. Using correct arboricultural practice, we can identify the branches to be removed without compromising the tree's future health.
            </p>
        </div>

        <div class="tt-process-grid">
            <!-- Step 1 -->
            <div class="tt-process-card">
                <div class="tt-card-icon"><?php echo tt_render_svg('step-assessment.svg', '1'); ?></div>
                <h3 style="font-size: 1.3rem; color: var(--color-brand-purple); margin-bottom: 0.75rem;">Step 1: Tree Health Assessment</h3>
                <p style="font-size: 1rem; color: var(--color-text-gray); line-height: 1.65; margin: 0;">
                    Our Arborists, who are ISA Certified, examine your tree's health, structure, and environment to look for any potential hazards, assess branch conditions, and determine the safest way to trim your tree.
                </p>
            </div>

            <!-- Step 2 -->
            <div class="tt-process-card">
                <div class="tt-card-icon"><?php echo tt_render_svg('step-plan.svg', '2'); ?></div>
                <h3 style="font-size: 1.3rem; color: var(--color-brand-purple); margin-bottom: 0.75rem;">Step 2: Creating a Customized Trimming Plan</h3>
                <p style="font-size: 1rem; color: var(--color-text-gray); line-height: 1.65; margin: 0;">
                    Each tree should have a different solution. An individual trimming program, which is unique to each species, age, growth rate, and property requirements and safety considerations, is developed.
                </p>
            </div>

            <!-- Step 3 -->
            <div class="tt-process-card">
                <div class="tt-card-icon"><?php echo tt_render_svg('step-safety.svg', '3'); ?></div>
                <h3 style="font-size: 1.3rem; color: var(--color-brand-purple); margin-bottom: 0.75rem;">Step 3: Preparing the Work Area</h3>
                <p style="font-size: 1rem; color: var(--color-text-gray); line-height: 1.65; margin: 0;">
                    Before the start of trimming, our team creates safety zones, safeguards your landscape, evaluates conditions, and arranges for the necessary professional equipment.
                </p>
            </div>

            <!-- Step 4 -->
            <div class="tt-process-card">
                <div class="tt-card-icon"><?php echo tt_render_svg('tools.svg', '4'); ?></div>
                <h3 style="font-size: 1.3rem; color: var(--color-brand-purple); margin-bottom: 0.75rem;">Step 4: Performing Professional Tree Trimming</h3>
                <p style="font-size: 1rem; color: var(--color-text-gray); line-height: 1.65; margin: 0;">
                    Our arborists carefully use specific tools and techniques to remove selected branches with precise cuts that help to lower stress on the tree and to improve overall tree health.
                </p>
            </div>

            <!-- Step 5 -->
            <div class="tt-process-card">
                <div class="tt-card-icon"><?php echo tt_render_svg('step-cleanup.svg', '5'); ?></div>
                <h3 style="font-size: 1.3rem; color: var(--color-brand-purple); margin-bottom: 0.75rem;">Step 5: Cleanup and Final Inspection</h3>
                <p style="font-size: 1rem; color: var(--color-text-gray); line-height: 1.65; margin: 0;">
                    Once trimming has been completed, we remove debris, check the tree's balance, ensure safety improvements were made, and leave your property clean and prepared.
                </p>
            </div>
        </div>
    </div>
</section>

<!-- =========================================================================
     SECTION 4: TYPES OF TREE TRIMMING SERVICES WE OFFER
     ========================================================================= -->
<section class="tt-section-alt">
    <div class="tt-container">
        <div class="text-center" style="max-width: 850px; margin: 0 auto 3rem auto;">
            <span class="global-subtitle">
                SPECIALIZED TECHNIQUES
            </span>
            <h2 class="global-section-title">Types of Tree Trimming Services We Offer</h2>
            <div class="section-divider" style="margin: 1rem auto 1.5rem auto;"></div>
            <p style="font-size: 1.1rem; color: var(--color-text-gray); line-height: 1.7; margin-bottom: 1.5rem;">
                The tree trimming services we provide for Buffalo properties are done professionally and include such services as crown thinning, deadwooding, clearance pruning, shaping, and structural pruning.
            </p>
            <h3 style="font-size: 1.35rem; color: var(--color-brand-purple); margin-bottom: 1rem;">What Types of Tree Trimming Services Are Available?</h3>
            <p style="font-size: 1.05rem; color: var(--color-text-gray); line-height: 1.7;">
                The variety of species, age, site and condition of the trees will necessitate various trimming techniques. Maple Majesty Tree Care offers customized tree trimming services aimed at enhancing the safety, aesthetic value, and overall health of trees.
            </p>
        </div>

        <div class="tt-types-grid">
            <!-- 1 -->
            <div class="tt-type-card">
                <div class="tt-card-icon"><?php echo tt_render_svg('type-thinning.svg', '🌿'); ?></div>
                <h3 style="font-size: 1.25rem; color: var(--color-brand-purple); margin-bottom: 0.85rem;">Crown Thinning</h3>
                <p style="font-size: 1rem; color: var(--color-text-gray); line-height: 1.65; margin: 0;">
                    Crown thinning selectively removes branches across the tree canopy to enhance air movement, penetration of the canopy by sunlight and tree form. It may decrease branch weight, increase circulation and reduce wind resistance in older, mature Buffalo shade trees.
                </p>
            </div>

            <!-- 2 -->
            <div class="tt-type-card">
                <div class="tt-card-icon"><?php echo tt_render_svg('type-deadwood.svg', '🍂'); ?></div>
                <h3 style="font-size: 1.25rem; color: var(--color-brand-purple); margin-bottom: 0.85rem;">Deadwooding</h3>
                <p style="font-size: 1rem; color: var(--color-text-gray); line-height: 1.65; margin: 0;">
                    Deadwooding involves the removal of dead, dying or broken limbs which could pose a safety risk. This service will decrease the risk of falling limbs during Buffalo's winter storms, heavy snow, ice buildup, and high winds, and will aid in the health of the trees.
                </p>
            </div>

            <!-- 3 -->
            <div class="tt-type-card">
                <div class="tt-card-icon"><?php echo tt_render_svg('type-clearance.svg', '⚡'); ?></div>
                <h3 style="font-size: 1.25rem; color: var(--color-brand-purple); margin-bottom: 0.85rem;">Clearance Pruning</h3>
                <p style="font-size: 1rem; color: var(--color-text-gray); line-height: 1.65; margin: 0;">
                    Clearance pruning provides safe clearance between power lines, water mains, garages, sidewalks, driveways and trees and other structures. Prevents property damage, makes it easier to get around and keeps outdoor areas safer.
                </p>
            </div>

            <!-- 4 -->
            <div class="tt-type-card">
                <div class="tt-card-icon"><?php echo tt_render_svg('shaping.svg', '✂️'); ?></div>
                <h3 style="font-size: 1.25rem; color: var(--color-brand-purple); margin-bottom: 0.85rem;">Tree Shaping</h3>
                <p style="font-size: 1rem; color: var(--color-text-gray); line-height: 1.65; margin: 0;">
                    Tree shaping enhances the tree's form and appearance without compromising its growth. Our arborists take out unwanted branches from ornamental trees, landscape trees and young trees in a selective manner using non-harmful cutting techniques.
                </p>
            </div>

            <!-- 5 -->
            <div class="tt-type-card">
                <div class="tt-card-icon"><?php echo tt_render_svg('type-structural.svg', '📐'); ?></div>
                <h3 style="font-size: 1.25rem; color: var(--color-brand-purple); margin-bottom: 0.85rem;">Structural Pruning</h3>
                <p style="font-size: 1rem; color: var(--color-text-gray); line-height: 1.65; margin: 0;">
                    Structural pruning is performed to enhance tree strength and to improve the branch structure and spacing. It will help minimise weak connections, stimulate even growth and avoid potential future problems, particularly with young, developing trees.
                </p>
            </div>

            <!-- 6 -->
            <div class="tt-type-card">
                <div class="tt-card-icon"><?php echo tt_render_svg('raising.svg', '⬆️'); ?></div>
                <h3 style="font-size: 1.25rem; color: var(--color-brand-purple); margin-bottom: 0.85rem;">Crown Raising</h3>
                <p style="font-size: 1rem; color: var(--color-text-gray); line-height: 1.65; margin: 0;">
                    Crown raising involves taking off the lower limbs to provide more space under trees. It enhances visibility and accessibility around driveways, walkways, parking areas and commercial properties, but preserves the tree's natural health and appearance.
                </p>
            </div>

            <!-- 7 -->
            <div class="tt-type-card">
                <div class="tt-card-icon"><?php echo tt_render_svg('reduction.svg', '⬇️'); ?></div>
                <h3 style="font-size: 1.25rem; color: var(--color-brand-purple); margin-bottom: 0.85rem;">Crown Reduction</h3>
                <p style="font-size: 1rem; color: var(--color-text-gray); line-height: 1.65; margin: 0;">
                    Where trees have grown beyond their site or have architectural issues, crown reduction is carefully employed to reduce canopy size. Professional reduction preserves the natural shape of the tree without endangering it as may harmful topping practices.
                </p>
            </div>
        </div>
    </div>
</section>

<!-- =========================================================================
     SECTION 5: BEST TIME FOR TREE TRIMMING IN WESTERN NEW YORK
     ========================================================================= -->
<section class="tt-section">
    <div class="tt-container">
        <div class="text-center" style="max-width: 850px; margin: 0 auto 3rem auto;">
            <span class="global-subtitle">
                SEASONAL TIMING
            </span>
            <h2 class="global-section-title">Best Time for Tree Trimming in Western New York</h2>
            <div class="section-divider" style="margin: 1rem auto 1.5rem auto;"></div>
            <p style="font-size: 1.1rem; color: var(--color-text-gray); line-height: 1.7; margin-bottom: 1.5rem;">
                Understand the optimal time of the year to trim trees in Western New York according to tree species, weather and Buffalo's seasonal climate.
            </p>
            <h3 style="font-size: 1.35rem; color: var(--color-brand-purple); margin-bottom: 1rem;">When Is the Best Time to Trim Trees in Buffalo?</h3>
            <p style="font-size: 1.05rem; color: var(--color-text-gray); line-height: 1.7; margin-bottom: 1rem;">
                The timing of tree trimming varies depending on species, condition and purpose of the trimming. The best time for tree care in Western New York depends on the weather.
            </p>
            <p style="font-size: 1.05rem; color: var(--color-text-gray); line-height: 1.7;">
                Many trees can be pruned during the late winter or early spring. For this time of year, arborists are able to assess the branch structure more readily prior to the emergence of new growth.
            </p>
        </div>

        <div class="tt-seasons-grid">
            <!-- Winter -->
            <div class="tt-season-card">
                <h3 style="font-size: 1.25rem; color: var(--color-brand-purple); margin-bottom: 0.75rem;">Winter Tree Trimming</h3>
                <p style="font-size: 1rem; color: var(--color-text-gray); line-height: 1.65; margin: 0;">
                    For some tree species, winter can be a great time to work as there are fewer insects, the trees are not in leaf, and branches can be examined prior to the onset of spring growth.
                </p>
            </div>

            <!-- Spring -->
            <div class="tt-season-card">
                <h3 style="font-size: 1.25rem; color: var(--color-brand-purple); margin-bottom: 0.75rem;">Spring Tree Trimming</h3>
                <p style="font-size: 1rem; color: var(--color-text-gray); line-height: 1.65; margin: 0;">
                    Spring trimming is intended to correct winter damage, structural problems, and to promote a young tree. But too much pruning at growth time is not advisable.
                </p>
            </div>

            <!-- Summer -->
            <div class="tt-season-card">
                <h3 style="font-size: 1.25rem; color: var(--color-brand-purple); margin-bottom: 0.75rem;">Summer Tree Trimming</h3>
                <p style="font-size: 1rem; color: var(--color-text-gray); line-height: 1.65; margin: 0;">
                    Summer pruning is helpful for storm-damaged trees, safety, clearance and quick-growing trees. During warmer months, evaluation by professionals will determine the best approach.
                </p>
            </div>

            <!-- Fall -->
            <div class="tt-season-card">
                <h3 style="font-size: 1.25rem; color: var(--color-brand-purple); margin-bottom: 0.75rem;">Fall Tree Trimming</h3>
                <p style="font-size: 1rem; color: var(--color-text-gray); line-height: 1.65; margin: 0;">
                    A good time to trim trees of weak limbs and branches before the winter weather hits Buffalo is in the fall. Prevention of snow and ice damage risks are possible through preventive trimming.
                </p>
            </div>

            <!-- Emergency -->
            <div class="tt-season-card" style="border-top-color: var(--color-warm-gold);">
                <h3 style="font-size: 1.25rem; color: var(--color-brand-purple); margin-bottom: 0.75rem;">Emergency Tree Trimming</h3>
                <p style="font-size: 1rem; color: var(--color-text-gray); line-height: 1.65; margin: 0;">
                    Damage or instability of limbs that pose a risk to property, persons or utilities indicates the need for emergency trimming. A fast response by a professional prevents further damage and safety issues.
                </p>
            </div>
        </div>
    </div>
</section>

<!-- =========================================================================
     SECTION 6: LOCAL TREE TRIMMING — SERVING BUFFALO COMMUNITIES
     ========================================================================= -->
<section class="tt-section-alt">
    <div class="tt-container">
        <div class="text-center" style="max-width: 850px; margin: 0 auto 3rem auto;">
            <span class="global-subtitle">
                COMMUNITY TREE CARE
            </span>
            <h2 class="global-section-title">Local Tree Trimming — Serving Buffalo Communities</h2>
            <div class="section-divider" style="margin: 1rem auto 1.5rem auto;"></div>
            
            <p style="font-size: 1.15rem; color: var(--color-brand-purple); font-weight: bold; margin-bottom: 1.5rem;">
                Looking for tree trimming near me? Maple Majesty Tree Care provides professional tree trimming service near me for Buffalo homes and businesses.
            </p>
            
            <h3 style="font-size: 1.4rem; color: var(--color-brand-purple); margin-bottom: 1rem;">Professional Tree Trimming Services for Buffalo Communities</h3>
            <p style="font-size: 1.05rem; color: var(--color-text-gray); line-height: 1.7; margin-bottom: 1rem;">
                Property owners calling for tree trimming near me require professionals who are acquainted with the trees, climate, and particular property difficulties. Maple Majesty Tree Care offers hassle-free trimming services in Buffalo and Western New York with safe and effective techniques.
            </p>
            <p style="font-size: 1.05rem; color: var(--color-text-gray); line-height: 1.7;">
                Heavy snow, ice and strong winds can cause tree damage and endanger the safety of people and property; our ISA Certified Arborists can improve and help keep trees healthy while preventing these issues. We are reputable tree trimmers in this area and we care for homes, landscapes and outdoor areas by providing professional tree trimming services.
            </p>
        </div>

        <h3 style="font-size: 1.4rem; color: var(--color-brand-purple); text-align: center; margin-bottom: 2rem;">Buffalo Neighborhoods We Serve</h3>
        <p style="text-align: center; color: var(--color-text-gray); margin-bottom: 2rem;">Maple Majesty Tree Care proudly offers tree trimming services to Buffalo neighborhoods such as:</p>

        <div class="tt-communities-grid">
            <div class="tt-community-card">
                <div class="tt-card-icon" style="margin: 0 auto 1.25rem auto;"><?php echo tt_render_svg('map-point.svg', '📍'); ?></div>
                <h3 style="font-size: 1.2rem; color: var(--color-brand-purple); margin-bottom: 0.75rem;">Elmwood Village</h3>
                <p style="font-size: 0.95rem; color: var(--color-text-gray); line-height: 1.6; margin: 0;">Proper care of historic properties and old trees is necessary to preserve old buildings, sidewalks and landscaped areas. We arborists employ careful and accurate techniques for urban environments.</p>
            </div>
            <div class="tt-community-card">
                <div class="tt-card-icon" style="margin: 0 auto 1.25rem auto;"><?php echo tt_render_svg('map-point.svg', '📍'); ?></div>
                <h3 style="font-size: 1.2rem; color: var(--color-brand-purple); margin-bottom: 0.75rem;">North Buffalo</h3>
                <p style="font-size: 0.95rem; color: var(--color-text-gray); line-height: 1.6; margin: 0;">North Buffalo homes are frequently found with older shade trees that are in need of ongoing upkeep to control growth and mitigate storm damage.</p>
            </div>
            <div class="tt-community-card">
                <div class="tt-card-icon" style="margin: 0 auto 1.25rem auto;"><?php echo tt_render_svg('map-point.svg', '📍'); ?></div>
                <h3 style="font-size: 1.2rem; color: var(--color-brand-purple); margin-bottom: 0.75rem;">South Buffalo</h3>
                <p style="font-size: 0.95rem; color: var(--color-text-gray); line-height: 1.6; margin: 0;">We assist homeowners in caring for trees when seasonal weather threatens them, such as heavy snow and wind exposure.</p>
            </div>
            <div class="tt-community-card">
                <div class="tt-card-icon" style="margin: 0 auto 1.25rem auto;"><?php echo tt_render_svg('map-point.svg', '📍'); ?></div>
                <h3 style="font-size: 1.2rem; color: var(--color-brand-purple); margin-bottom: 0.75rem;">Allentown</h3>
                <p style="font-size: 0.95rem; color: var(--color-text-gray); line-height: 1.6; margin: 0;">When dealing with urban landscapes that are limited in space, the care and consideration involved in trimming approaches can prevent damage to surrounding buildings and property features.</p>
            </div>
            <div class="tt-community-card">
                <div class="tt-card-icon" style="margin: 0 auto 1.25rem auto;"><?php echo tt_render_svg('map-point.svg', '📍'); ?></div>
                <h3 style="font-size: 1.2rem; color: var(--color-brand-purple); margin-bottom: 0.75rem;">Downtown Buffalo</h3>
                <p style="font-size: 0.95rem; color: var(--color-text-gray); line-height: 1.6; margin: 0;">Professional tree care enhances safety around commercial and residential buildings, sidewalks and public places.</p>
            </div>
            <div class="tt-community-card">
                <div class="tt-card-icon" style="margin: 0 auto 1.25rem auto;"><?php echo tt_render_svg('map-point.svg', '📍'); ?></div>
                <h3 style="font-size: 1.2rem; color: var(--color-brand-purple); margin-bottom: 0.75rem;">West Side Buffalo</h3>
                <p style="font-size: 0.95rem; color: var(--color-text-gray); line-height: 1.6; margin: 0;">We offer tree trimming services for property owners seeking to make their trees healthier, more attractive and safer.</p>
            </div>
            <div class="tt-community-card">
                <div class="tt-card-icon" style="margin: 0 auto 1.25rem auto;"><?php echo tt_render_svg('map-point.svg', '📍'); ?></div>
                <h3 style="font-size: 1.2rem; color: var(--color-brand-purple); margin-bottom: 0.75rem;">Riverside</h3>
                <p style="font-size: 0.95rem; color: var(--color-text-gray); line-height: 1.6; margin: 0;">Trees on properties in this area may be under constant stress from the weather, and should be regularly inspected and maintained.</p>
            </div>
            <div class="tt-community-card">
                <div class="tt-card-icon" style="margin: 0 auto 1.25rem auto;"><?php echo tt_render_svg('map-point.svg', '📍'); ?></div>
                <h3 style="font-size: 1.2rem; color: var(--color-brand-purple); margin-bottom: 0.75rem;">University Heights</h3>
                <p style="font-size: 0.95rem; color: var(--color-text-gray); line-height: 1.6; margin: 0;">We provide professional trimming services for homeowners and property managers for residential and rental properties.</p>
            </div>
        </div>

        <div style="background: var(--color-white); border-radius: 16px; padding: 3rem; box-shadow: 0 8px 25px rgba(0,0,0,0.04); margin-top: 3rem; border-left: 5px solid var(--color-forest-green);">
            <h3 style="font-size: 1.4rem; color: var(--color-brand-purple); margin-bottom: 1rem;">Surrounding Western New York Areas We Serve</h3>
            <p style="color: var(--color-text-gray); margin-bottom: 1.5rem;">Tree trimming is not just for Buffalo, we also do tree trimming in surrounding areas such as:</p>
            <ul style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 0.75rem; list-style: none; padding: 0; margin: 0;">
                <li style="display: flex; align-items: center; gap: 0.5rem; color: var(--color-text-gray); font-weight: 500;"><span style="color: var(--color-warm-gold);"><?php echo tt_render_svg('map-pin.svg', '📍'); ?></span> Amherst</li>
                <li style="display: flex; align-items: center; gap: 0.5rem; color: var(--color-text-gray); font-weight: 500;"><span style="color: var(--color-warm-gold);"><?php echo tt_render_svg('map-pin.svg', '📍'); ?></span> Williamsville</li>
                <li style="display: flex; align-items: center; gap: 0.5rem; color: var(--color-text-gray); font-weight: 500;"><span style="color: var(--color-warm-gold);"><?php echo tt_render_svg('map-pin.svg', '📍'); ?></span> Cheektowaga</li>
                <li style="display: flex; align-items: center; gap: 0.5rem; color: var(--color-text-gray); font-weight: 500;"><span style="color: var(--color-warm-gold);"><?php echo tt_render_svg('map-pin.svg', '📍'); ?></span> Tonawanda</li>
                <li style="display: flex; align-items: center; gap: 0.5rem; color: var(--color-text-gray); font-weight: 500;"><span style="color: var(--color-warm-gold);"><?php echo tt_render_svg('map-pin.svg', '📍'); ?></span> Kenmore</li>
                <li style="display: flex; align-items: center; gap: 0.5rem; color: var(--color-text-gray); font-weight: 500;"><span style="color: var(--color-warm-gold);"><?php echo tt_render_svg('map-pin.svg', '📍'); ?></span> West Seneca</li>
                <li style="display: flex; align-items: center; gap: 0.5rem; color: var(--color-text-gray); font-weight: 500;"><span style="color: var(--color-warm-gold);"><?php echo tt_render_svg('map-pin.svg', '📍'); ?></span> Hamburg</li>
                <li style="display: flex; align-items: center; gap: 0.5rem; color: var(--color-text-gray); font-weight: 500;"><span style="color: var(--color-warm-gold);"><?php echo tt_render_svg('map-pin.svg', '📍'); ?></span> Orchard Park</li>
                <li style="display: flex; align-items: center; gap: 0.5rem; color: var(--color-text-gray); font-weight: 500;"><span style="color: var(--color-warm-gold);"><?php echo tt_render_svg('map-pin.svg', '📍'); ?></span> Clarence</li>
                <li style="display: flex; align-items: center; gap: 0.5rem; color: var(--color-text-gray); font-weight: 500;"><span style="color: var(--color-warm-gold);"><?php echo tt_render_svg('map-pin.svg', '📍'); ?></span> Lancaster</li>
                <li style="display: flex; align-items: center; gap: 0.5rem; color: var(--color-text-gray); font-weight: 500;"><span style="color: var(--color-warm-gold);"><?php echo tt_render_svg('map-pin.svg', '📍'); ?></span> Depew</li>
                <li style="display: flex; align-items: center; gap: 0.5rem; color: var(--color-text-gray); font-weight: 500;"><span style="color: var(--color-warm-gold);"><?php echo tt_render_svg('map-pin.svg', '📍'); ?></span> Lackawanna</li>
            </ul>
        </div>
    </div>
</section>

<!-- =========================================================================
     SECTION 7: WHY TRUST US WITH YOUR TREE TRIMMING NEEDS?
     ========================================================================= -->
<section class="tt-section">
    <div class="tt-container">
        <div class="text-center" style="max-width: 850px; margin: 0 auto 3rem auto;">
            <span class="global-subtitle">
                TRUSTED ARBORISTS
            </span>
            <h2 class="global-section-title">Why Trust Us With Your Tree Trimming Needs?</h2>
            <div class="section-divider" style="margin: 1rem auto 1.5rem auto;"></div>
            <p style="font-size: 1.1rem; color: var(--color-text-gray); line-height: 1.7; margin-bottom: 1.5rem;">
                Maple Majesty Tree Care provides professional tree trimming services in Buffalo by certified arborists, safe methods and local knowledge.
            </p>
            <h3 style="font-size: 1.35rem; color: var(--color-brand-purple); margin-bottom: 1rem;">Why Choose Maple Majesty Tree Care?</h3>
            <p style="font-size: 1.05rem; color: var(--color-text-gray); line-height: 1.7; margin-bottom: 1rem;">
                Tree cutting skills, experience, and equipment are required. Tree pruning can cause damage, poor growth, and future safety hazards if done incorrectly.Our tree care services at Maple Majesty Tree Care are all about best practices for trees and tree care that are going to maximize tree health and minimize the risk to your property.From local experience to technical expertise and safety protocols, our team provides reliable and trusted solutions to your tree care needs.
            </p>
        </div>

        <div class="tt-trust-grid">
            <!-- 1 -->
            <div class="tt-trust-card">
                <div class="tt-card-icon" style="margin: 0 auto 1.5rem auto;"><?php echo tt_render_svg('trust-arborist.svg', '🎓'); ?></div>
                <h3 style="font-size: 1.25rem; color: var(--color-brand-purple); margin-bottom: 0.85rem;">ISA-Certified Arborist Knowledge</h3>
                <p style="font-size: 1rem; color: var(--color-text-gray); line-height: 1.65; margin: 0;">
                    Our ISA Certified Arborists are familiar with tree biology, growth, disease, structure and correct pruning practices. This knowledge enables us to decide on the most secure and effective way to trim each tree.
                </p>
            </div>

            <!-- 2 -->
            <div class="tt-trust-card">
                <div class="tt-card-icon" style="margin: 0 auto 1.5rem auto;"><?php echo tt_render_svg('trust-safety.svg', '🛡️'); ?></div>
                <h3 style="font-size: 1.25rem; color: var(--color-brand-purple); margin-bottom: 0.85rem;">Safety-Focused Work Practices</h3>
                <p style="font-size: 1rem; color: var(--color-text-gray); line-height: 1.65; margin: 0;">
                    Proper tree pruning should be done by a well-trained and equipped professional with appropriate safety measures. Tree conditions and weather, branch weight, accessibility and surrounding structures are assessed to ensure property protection and safety of all parties.
                </p>
            </div>

            <!-- 3 -->
            <div class="tt-trust-card">
                <div class="tt-card-icon" style="margin: 0 auto 1.5rem auto;"><?php echo tt_render_svg('trust-equipment.svg', '⚙️'); ?></div>
                <h3 style="font-size: 1.25rem; color: var(--color-brand-purple); margin-bottom: 0.85rem;">Professional Equipment and Techniques</h3>
                <p style="font-size: 1rem; color: var(--color-text-gray); line-height: 1.65; margin: 0;">
                    Professional equipment such as pruning saws, pole saws, chainsaws, climbing and bucket trucks and rigging systems is used. Our team can safely and efficiently accomplish our trimming projects using proper tools.
                </p>
            </div>

            <!-- 4 -->
            <div class="tt-trust-card">
                <div class="tt-card-icon" style="margin: 0 auto 1.5rem auto;"><?php echo tt_render_svg('honest.svg', '💬'); ?></div>
                <h3 style="font-size: 1.25rem; color: var(--color-brand-purple); margin-bottom: 0.85rem;">Honest Tree Care Recommendations</h3>
                <p style="font-size: 1rem; color: var(--color-text-gray); line-height: 1.65; margin: 0;">
                    We give you honest advice according to the health, safety and property requirements, and long-term maintenance objectives of trees. We care for what is needed, not what is not needed.
                </p>
            </div>

            <!-- 5 -->
            <div class="tt-trust-card">
                <div class="tt-card-icon" style="margin: 0 auto 1.5rem auto;"><?php echo tt_render_svg('trust-local.svg', '🦬'); ?></div>
                <h3 style="font-size: 1.25rem; color: var(--color-brand-purple); margin-bottom: 0.85rem;">Experience With Buffalo Tree Conditions</h3>
                <p style="font-size: 1rem; color: var(--color-text-gray); line-height: 1.65; margin: 0;">
                    Ice damage, weight of snow, strong wind, deteriorating buildings and storm stress are issues for buffalo trees. Local experience helps to recognize risks as potential hazards.
                </p>
            </div>

            <!-- 6 -->
            <div class="tt-trust-card">
                <div class="tt-card-icon" style="margin: 0 auto 1.5rem auto;"><?php echo tt_render_svg('trust-solutions.svg', '🌿'); ?></div>
                <h3 style="font-size: 1.25rem; color: var(--color-brand-purple); margin-bottom: 0.85rem;">Complete Tree Care Solutions</h3>
                <p style="font-size: 1rem; color: var(--color-text-gray); line-height: 1.65; margin: 0;">
                    Maple Majesty Tree Care provides full tree care services such as tree removal, storm cleanup, tree stump removal, land clearing, tree health assessments and emergency services all year long for the safety of property.
                </p>
            </div>
        </div>
    </div>
</section>

<!-- =========================================================================
     SECTION 8: TREE TRIMMING COST IN BUFFALO, NY
     ========================================================================= -->
<section class="tt-section-alt">
    <div class="tt-container">
        <div>
            <span class="global-subtitle">
                PRICING GUIDE
            </span>
            <h2 class="global-section-title">Tree Trimming Cost in Buffalo, NY</h2>
            <div class="section-divider"></div>
            
            <p style="font-size: 1.1rem; color: var(--color-text-gray); line-height: 1.7; margin-top: 1.5rem; margin-bottom: 1.5rem;">
                Understand the factors that impact the price of tree trimming in Buffalo, NY, such as tree size, accessibility, equipment necessary, branch density and cleanup requirements.
            </p>

            <h3 style="font-size: 1.35rem; color: var(--color-brand-purple); margin-bottom: 1rem;">How Much Does Tree Trimming Cost in Buffalo?</h3>
            <p style="font-size: 1.05rem; color: var(--color-text-gray); line-height: 1.7; margin-bottom: 1rem;">
                Tree trimming cost will be different from tree to tree, depending on the condition of the tree, the work needed to be done, and how complicated it is. Each property will be unique and only a professional can best advise you on correct pricing.
            </p>
            <p style="font-size: 1.05rem; color: var(--color-text-gray); line-height: 1.7; margin-bottom: 2rem;">
                The final cost is determined by the height of the tree, its location, access and equipment needs
            </p>
        </div>

        <div style="max-width: 900px; margin: 0 auto;">
            <table class="styled-table" style="background: var(--color-white); border-radius: 12px; overflow: hidden; box-shadow: 0 6px 20px rgba(0,0,0,0.04);">
                <thead>
                    <tr style="background-color: var(--color-brand-purple); color: var(--color-white);">
                        <th style="padding: 1.25rem 2rem;">Cost Factor</th>
                        <th style="padding: 1.25rem 2rem;">Description</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Small Tree Trimming (under 25 ft)</td>
                        <td>$75 – $400</td>
                    </tr>
                    <tr>
                        <td>Medium Tree Trimming (25–50 ft)</td>
                        <td>$300 – $600</td>
                    </tr>
                    <tr>
                        <td>Large Tree Trimming (50+ ft)</td>
                        <td>$600 – $1,200+</td>
                    </tr>
                    <tr>
                        <td>Deadwood Removal</td>
                        <td>$200 – $500</td>
                    </tr>
                    <tr>
                        <td>Crown Raising</td>
                        <td>$250 – $550</td>
                    </tr>
                    <tr>
                        <td>Tree Health Assessment</td>
                        <td>$75 – $600</td>
                    </tr>
                    <tr>
                        <td>Fruit Tree Pruning</td>
                        <td>$150 – $350</td>
                    </tr>
                    <tr>
                        <td>Emergency Hazard Limb Removal</td>
                        <td>$300 – $800+</td>
                    </tr>
                    <tr>
                        <td>Seasonal Maintenance Trimming</td>
                        <td>$200 – $600</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</section>

<!-- =========================================================================
     SECTION 9: TREE TRIMMING NEAR ME — BUFFALO & WESTERN NEW YORK
     ========================================================================= -->
<section class="tt-section">
    <div class="tt-container">
        <div>
            <span class="global-subtitle">
                REGIONAL SERVICE
            </span>
            <h2 class="global-section-title">Tree Trimming Near Me — Buffalo & Western New York</h2>
            <div class="section-divider"></div>
            
            <p style="font-size: 1.1rem; color: var(--color-text-gray); line-height: 1.7; margin-top: 1.5rem; margin-bottom: 2rem;">
                Find reliable tree trimming near me services in Buffalo, NY. Maple Majesty Tree Care provides professional trimming solutions throughout Western New York.
            </p>
        </div>

        <div class="tt-regional-grid">
            <div class="tt-regional-info">
                <h3 style="font-size: 1.35rem; color: var(--color-brand-purple); margin-bottom: 1rem;">Professional Tree Trimming Throughout Western New York</h3>
                <p style="font-size: 1.05rem; color: var(--color-text-gray); line-height: 1.75;">
                    When hiring a tree care company to provide tree trimming Buffalo NY services, look for one that is familiar with local tree care requirements, weather conditions, and the types of trees found in your area. Maple Majesty Tree Care provides professional tree trimming services for the Buffalo and Western New York area, enhancing tree health, minimizing hazards, and preparing landscapes for the season's weather conditions.
                </p>
            </div>

            <div class="tt-regional-card" style="background: var(--color-soft-lilac); border-radius: 16px; padding: 2.5rem; border-left: 5px solid var(--color-forest-green);">
                <h3 style="font-size: 1.3rem; color: var(--color-brand-purple); margin-bottom: 1.5rem;">Tree Trimming Service Areas</h3>
                <p style="color: var(--color-text-gray); margin-bottom: 1rem;">Maple Majesty Tree Care serves:</p>
                <ul style="list-style: none; padding: 0; margin: 0; display: flex; flex-direction: column; gap: 0.75rem;">
                    <li style="display: flex; align-items: center; gap: 0.5rem; color: var(--color-text-gray); font-weight: 500;"><span style="color: var(--color-warm-gold);"><?php echo tt_render_svg('check-circle.svg', '✓'); ?></span> Buffalo, NY</li>
                    <li style="display: flex; align-items: center; gap: 0.5rem; color: var(--color-text-gray); font-weight: 500;"><span style="color: var(--color-warm-gold);"><?php echo tt_render_svg('check-circle.svg', '✓'); ?></span> Amherst</li>
                    <li style="display: flex; align-items: center; gap: 0.5rem; color: var(--color-text-gray); font-weight: 500;"><span style="color: var(--color-warm-gold);"><?php echo tt_render_svg('check-circle.svg', '✓'); ?></span> Cheektowaga</li>
                    <li style="display: flex; align-items: center; gap: 0.5rem; color: var(--color-text-gray); font-weight: 500;"><span style="color: var(--color-warm-gold);"><?php echo tt_render_svg('check-circle.svg', '✓'); ?></span> Tonawanda</li>
                    <li style="display: flex; align-items: center; gap: 0.5rem; color: var(--color-text-gray); font-weight: 500;"><span style="color: var(--color-warm-gold);"><?php echo tt_render_svg('check-circle.svg', '✓'); ?></span> West Seneca</li>
                    <li style="display: flex; align-items: center; gap: 0.5rem; color: var(--color-text-gray); font-weight: 500;"><span style="color: var(--color-warm-gold);"><?php echo tt_render_svg('check-circle.svg', '✓'); ?></span> Hamburg</li>
                    <li style="display: flex; align-items: center; gap: 0.5rem; color: var(--color-text-gray); font-weight: 500;"><span style="color: var(--color-warm-gold);"><?php echo tt_render_svg('check-circle.svg', '✓'); ?></span> Williamsville</li>
                    <li style="display: flex; align-items: center; gap: 0.5rem; color: var(--color-text-gray); font-weight: 500;"><span style="color: var(--color-warm-gold);"><?php echo tt_render_svg('check-circle.svg', '✓'); ?></span> Kenmore</li>
                    <li style="display: flex; align-items: center; gap: 0.5rem; color: var(--color-text-gray); font-weight: 500;"><span style="color: var(--color-warm-gold);"><?php echo tt_render_svg('check-circle.svg', '✓'); ?></span> Orchard Park</li>
                </ul>
            </div>
        </div>
    </div>
</section>


