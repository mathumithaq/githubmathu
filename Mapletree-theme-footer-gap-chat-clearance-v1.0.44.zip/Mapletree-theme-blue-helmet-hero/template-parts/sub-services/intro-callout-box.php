<?php
/**
 * Template Part: Intro Callout Box
 * 
 * Dynamic intro section for sub-service pages.
 * Reads from a single WordPress custom field: intro_callout_data (JSON)
 * 
 * JSON Structure:
 * {
 *   "description": "Your intro paragraph text here.",
 *   "trust_signals": ["Signal 1", "Signal 2", "Signal 3"],
 *   "phone": "+17164000763"
 * }
 */

$page_id = get_the_ID();

// --- Read single JSON field ---
$raw = '';
if (function_exists('get_field') && get_field('intro_callout_data')) {
    $raw = get_field('intro_callout_data');
} else {
    $raw = get_post_meta($page_id, 'intro_callout_data', true);
}

// Parse JSON
$data = [];
if (!empty($raw)) {
    $decoded = json_decode($raw, true);
    if (is_array($decoded)) {
        $data = $decoded;
    }
}

// --- Extract values with defaults ---
$description = !empty($data['description']) ? $data['description'] : '';
$phone = !empty($data['phone']) ? $data['phone'] : '+17164000763';
$trust_signals = !empty($data['trust_signals']) && is_array($data['trust_signals'])
    ? $data['trust_signals']
    : ['500+ Five-Star Reviews', 'Licensed & Insured', 'Free On-Site Estimates', 'ISA-Certified Arborists'];

// Fallback descriptions by page slug if custom field is not populated
if (empty($description)) {
    global $post;
    $slug = !empty($post->post_name) ? $post->post_name : '';
    $fallback_descriptions = [
        'tree-crown-reduction' => 'Tree Crown Reduction reduces the height and spread of a tree canopy while preserving its natural shape, health, and structural integrity. Our ISA-Certified Arborists in Buffalo, NY provide expert crown management to protect your property and ensure safe, balanced tree growth.',
        'crown-reduction'      => 'Tree Crown Reduction reduces the height and spread of a tree canopy while preserving its natural shape, health, and structural integrity. Our ISA-Certified Arborists in Buffalo, NY provide expert crown management to protect your property and ensure safe, balanced tree growth.',
        'tree-removal'         => 'Looking for professional tree removal in Buffalo, NY? Maple Majesty Tree Care provides safe, expert tree removal with specialized equipment and certified arborists.',
        'tree-trimming'        => 'Professional tree trimming services in Buffalo, NY. Our certified arborists enhance tree health, shape, and structure while protecting your home and landscape.',
        'tree-pruning'         => 'Expert tree pruning services in Buffalo, NY. We utilize industry-standard pruning techniques to improve airflow, eliminate hazards, and promote healthy growth.',
        'stump-removal'        => 'Complete stump removal services throughout Buffalo, NY. We extract the stump and substantial root material safely, leaving your property clean and ready for landscaping.',
        'stump-grinding'       => 'Fast, reliable stump grinding in Buffalo, NY. We grind unwanted tree stumps below grade to restore your lawn and eliminate safety hazards.',
        'emergency-tree'       => '24/7 Emergency tree services in Buffalo, NY. Rapid storm response and hazardous limb removal to safeguard your property.',
        'emergency-service'    => '24/7 Emergency tree services in Buffalo, NY. Rapid storm response and hazardous limb removal to safeguard your property.',
        'land-brush-clearing'  => 'Professional land and brush clearing services in Buffalo, NY. Thorough site preparation and vegetation management for properties of any size.',
        'land-clearing'        => 'Professional land and brush clearing services in Buffalo, NY. Thorough site preparation and vegetation management for properties of any size.',
        'arborist-service'     => 'Certified Arborist services in Buffalo, NY. Professional tree health evaluations, risk assessments, and specialized tree care consultations.'
    ];
    if (isset($fallback_descriptions[$slug])) {
        $description = $fallback_descriptions[$slug];
    }
}

// If no data at all, skip rendering
if (empty($description) && empty($raw)) {
    return;
}

$check_icon = file_exists(get_template_directory() . '/assets/icons/check-circle.svg')
    ? file_get_contents(get_template_directory() . '/assets/icons/check-circle.svg')
    : '✓';
?>

<section class="intro-callout-section">
    <div class="intro-callout-container">
        <div class="intro-callout-box">

            <?php if (!empty($description)): ?>
                <div class="description"><?php echo wp_kses_post(wpautop($description)); ?></div>
            <?php endif; ?>

            <div class="hero-buttons">
                <a href="tel:<?php echo esc_attr($phone); ?>" class="btn-primary">
                    Call Now
                </a>
                <a href="<?php echo esc_url(site_url('/contact/')); ?>" class="btn-secondary">
                    Request a Quote
                </a>
            </div>

            <?php if (!empty($trust_signals)): ?>
                <ul class="sub-service-trust-signals"
                    style="margin-top: 2.5rem; border-top: 1px solid rgba(0,0,0,0.1); padding-top: 2rem; justify-content: flex-start; gap: 2rem;">
                    <?php foreach ($trust_signals as $signal): ?>
                        <li>
                            <span class="check-icon"><?php echo $check_icon; ?></span>
                            <?php echo esc_html($signal); ?>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>

        </div>
    </div>
</section>