<?php
/**
 * About Us Page Content Sections
 */
$icon_path = get_template_directory() . '/assets/icons/';
?>

<!-- 1. History Section -->
<section class="about-history-section">
    <div class="about-container">
        <div class="about-grid">
            <div class="about-content-left">
                <div style="margin-bottom: 2rem;">
                    <span class="global-subtitle">Our Story</span>
                    <h2 class="global-section-title">How Maple Majesty Tree Care Began</h2>
                </div>
                <p>Find out what makes Maple Majesty Tree Care so special, and why we can offer reliable and
                    professional tree care services to Buffalo homeowners. Maple Majesty Tree Care was founded with a
                    passion for preserving the natural beauty of trees while helping property owners maintain safe
                    outdoor spaces.</p>
                <p>After all these years, we learned that homeowners required more than just tree-cutting services. They
                    required knowledgeable professionals who can understand tree health, identify potential hazards and
                    offer solutions that are protective of the tree and property. Our philosophy is based on responsible
                    tree care. We do not remove trees unless it is necessary; we make a recommendation based on the
                    needs of each tree for safety, health, and long-term growth.</p>
                <p>We are committed to our dedication to providing uncompromising service, attention to detail, and
                    satisfaction for our customers, serving the Buffalo community and surrounding Western New York.</p>
            </div>
        </div>
    </div>
</section>

<!-- 2. Mission & Core Values -->
<section class="about-mission-section">
    <div class="about-container text-center">
        <span class="global-subtitle">Mission & Values</span>
        <h2 class="global-section-title">Our Mission & Core Values</h2>
        <p class="section-intro">Our goal is to deliver safe tree care services professionally and in an environmentally
            responsible manner while at the same time establishing a long-term relationship with the Buffalo property
            owner. Maple Majesty Tree Care's goal is to make trees healthier and safer and offer outstanding customer
            service. We feel that a great tree care company should have more than just technical skills. It takes
            honesty, responsibility and respect for all of our properties.</p>

        <h3 class="values-heading">Our Core Values Include:</h3>
        <div class="values-grid">
            <div class="value-card">
                <?php echo file_get_contents($icon_path . 'value-safety.svg'); ?>
                <h3>Safety First</h3>
                <p>Safety is always our top concern! To safeguard our personnel, customers, properties, and surrounding
                    landscapes, we adhere to professional practices.</p>
            </div>
            <div class="value-card">
                <?php echo file_get_contents($icon_path . 'value-quality.svg'); ?>
                <h3>Quality Workmanship</h3>
                <p>Careful planning is given to every project and attention is paid to details. We are proud to provide
                    results that meet the professional standard.</p>
            </div>
            <div class="value-card">
                <?php echo file_get_contents($icon_path . 'value-honesty.svg'); ?>
                <h3>Honest Recommendations</h3>
                <p>We offer unequivocal instructions according to the needs of your trees. We want to suggest the right
                    solution – not extra services.</p>
            </div>
            <div class="value-card">
                <?php echo file_get_contents($icon_path . 'value-nature.svg'); ?>
                <h3>Respect for Nature</h3>
                <p>Trees that are in good health offer benefits to the environment, aesthetics, and value. We practice
                    responsible management for long-term tree health.</p>
            </div>
            <div class="value-card">
                <?php echo file_get_contents($icon_path . 'value-satisfaction.svg'); ?>
                <h3>Customer Satisfaction</h3>
                <p>We appreciate all of our clients and work to give a seamless and professional experience from start
                    to finish.</p>
            </div>
        </div>
    </div>
</section>

<!-- 3. Certified Team -->
<section class="about-team-section">
    <div class="about-container">
        <div style="margin-bottom: 3rem;">
            <span class="global-subtitle">Our Experts</span>
            <h2 class="global-section-title">Our Certified Team - Buffalo's Arborist Experts</h2>
        </div>
        <div class="about-grid two-col reverse-mobile">
            <div class="team-list-box">
                <h3>Our arborists are well-trained to evaluate:</h3>
                <ul class="custom-check-list">
                    <li><?php echo file_get_contents($icon_path . 'check-circle.svg'); ?> Tree health and structure</li>
                    <li><?php echo file_get_contents($icon_path . 'check-circle.svg'); ?> Potential safety risks</li>
                    <li><?php echo file_get_contents($icon_path . 'check-circle.svg'); ?> Disease and pest concerns</li>
                    <li><?php echo file_get_contents($icon_path . 'check-circle.svg'); ?> Proper pruning techniques</li>
                    <li><?php echo file_get_contents($icon_path . 'check-circle.svg'); ?> Storm damage impacts</li>
                    <li><?php echo file_get_contents($icon_path . 'check-circle.svg'); ?> Long-term maintenance needs
                    </li>
                </ul>
            </div>
            <div class="about-content-right">
                <p>As a certified Arborist Buffalo NY team, connect with our skilled arborists who are dedicated to
                    delivering professional solutions and dependable advice.</p>
                <p>Knowledge, experience and understanding of tree biology are necessary to proper tree care. With
                    professional expertise, our team can provide homeowners with the information they need to make
                    informed decisions about their landscapes.</p>
                <p>A certified arborist Buffalo NY is trained and qualified to evaluate trees and provide them with the
                    necessary care, all while adhering to industry standards.</p>
                <p>Our team handles each situation with care and precision, whether your tree requires routine care,
                    crown reduction, emergency services, or removal. We know that trees in Buffalo are subjected to a
                    variety of challenges, including heavy snowfalls, ice storms, strong winds, and seasonal weather
                    changes. Our area experience enables us to deliver solutions that are tailored to the conditions in
                    the western part of the state.</p>
            </div>
        </div>
    </div>
</section>

<!-- 4. What Makes Us Different -->
<section class="about-difference-section">
    <div class="about-container text-center">
        <span class="global-subtitle">Why Choose Us</span>
        <h2 class="global-section-title">What Makes Us Different From Other Tree Services</h2>
        <p class="section-intro">Discover why Maple Majesty Tree Care stands apart as the best local tree service choice
            for reliable, professional, and customer-focused tree solutions. It is an important decision to choose a
            tree care provider. Trees are investments, and incorrect work will lead to long-term issues.</p>
        <p class="section-intro">At Maple Majesty Tree Care, we aim to provide the service homeowners would expect the
            top tree care professionals in the area would provide.</p>

        <div class="difference-grid">
            <div class="diff-card">
                <h3>Local Knowledge</h3>
                <p>We know the trees, weather, and property issues unique to Buffalo and Western New York. Our advice
                    and recommendations are based on local experience and professional knowledge.</p>
            </div>
            <div class="diff-card">
                <h3>Personalized Tree Care Plans</h3>
                <p>Each property comes with its own set of characteristics. Each scenario is unique, and solutions are
                    developed to address the tree condition, location, and objectives.</p>
            </div>
            <div class="diff-card">
                <h3>Safety-Focused Approach</h3>
                <p>Tree operations are potentially hazardous. Our team works safely with the correct equipment and
                    procedures to complete projects.</p>
            </div>
            <div class="diff-card">
                <h3>Clear Communication</h3>
                <p>We feel that our customers deserve the truth and a clear recommendation as well. We will discuss the
                    work that is required and what options are available.</p>
            </div>
        </div>

        <div class="complete-services-box">
            <h3>Complete Tree Care Services</h3>
            <p>We offer a complete range of solutions from preventative maintenance to emergencies, such as:</p>
            <ul class="inline-services-list">
                <li>Tree trimming</li>
                <li>Tree pruning</li>
                <li>Tree removal</li>
                <li>Emergency tree services</li>
                <li>Storm damage cleanup</li>
                <li>Stump removal</li>
                <li>Tree health assessments</li>
            </ul>
        </div>
    </div>
</section>

<!-- 5. Certifications -->
<section class="about-certifications-section">
    <div class="about-container">
        <div class="about-grid two-col">
            <div class="about-content-left">
                <span class="global-subtitle">Professional Standards</span>
                <h2 class="global-section-title">Our Professional Affiliations & Certifications</h2>
                <p>Discover the professional standards, training and certifications that enable our commitment to safe
                    and reliable tree care. To provide professional tree care services, continued education and
                    commitment to industry standards are necessary.</p>
                <p>Our commitment to Maple Majesty Tree Care is to provide our customers with top-quality service
                    through ongoing training, safe work practices, and professional development.</p>
                <p>A deep understanding of professional knowledge is key to safeguarding trees and delivering reliable
                    services.</p>
            </div>
            <div class="cert-list-box">
                <h3>Our commitment includes:</h3>
                <ul class="custom-check-list">
                    <li><?php echo file_get_contents($icon_path . 'cert-badge.svg'); ?> Following industry-approved
                        pruning practices</li>
                    <li><?php echo file_get_contents($icon_path . 'cert-badge.svg'); ?> Using professional safety
                        procedures</li>
                    <li><?php echo file_get_contents($icon_path . 'cert-badge.svg'); ?> Staying updated on modern tree
                        care techniques</li>
                    <li><?php echo file_get_contents($icon_path . 'cert-badge.svg'); ?> Applying responsible tree
                        management methods</li>
                    <li><?php echo file_get_contents($icon_path . 'cert-badge.svg'); ?> Maintaining high standards of
                        workmanship</li>
                </ul>
            </div>
        </div>
    </div>
</section>

<!-- 6. Commitment to WNY -->
<section class="about-commitment-section">
    <div class="about-container text-center">
        <span class="global-subtitle">Community Focus</span>
        <h2 class="global-section-title">Our Commitment to Western New York</h2>
        <p class="section-intro">We take pride in serving the Buffalo area and its surrounding communities with reliable
            tree services, contributing to the beauty of the local landscapes. Trees are an important part of Western
            New York communities. They offer shade, enhance neighborhoods, and add to the natural character of the
            region.</p>
        <p class="section-intro">At Maple Majesty Tree Care, we are committed to helping homeowners protect and maintain
            their trees through responsible care.</p>

        <p class="section-intro" style="font-weight: 600; margin-bottom: 2rem;">We proudly serve local neighborhoods by
            providing:</p>

        <div class="commitment-grid">
            <div class="commit-card">
                <h3>Safe tree maintenance</h3>
            </div>
            <div class="commit-card">
                <h3>Storm response services</h3>
            </div>
            <div class="commit-card">
                <h3>Property protection solutions</h3>
            </div>
            <div class="commit-card">
                <h3>Professional tree assessments</h3>
            </div>
        </div>
        <p class="commitment-footer">Our team understands the importance of maintaining healthy trees throughout
            Buffalo’s changing seasons.</p>
    </div>
</section>

<!-- 7. Tree Care Across WNY (Service Areas) -->
<section class="about-areas-section">
    <div class="about-container">
        <div class="areas-header text-center">
            <span class="global-subtitle">Where We Work</span>
            <h2 class="global-section-title">Tree Care Across Western New York</h2>
            <p>Maple Majesty Tree Care provides professional tree services throughout Buffalo and surrounding Western
                New York communities with reliable local expertise. We proudly provide professional tree service Buffalo
                NY homeowners can depend on.</p>
            <h3>Our service areas include:</h3>
        </div>
        <div class="areas-grid">
            <div class="area-item"><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?> Buffalo, NY</div>
            <div class="area-item"><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?> Amherst, NY</div>
            <div class="area-item"><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?> Williamsville, NY</div>
            <div class="area-item"><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?> East Amherst, NY</div>
            <div class="area-item"><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?> Clarence, NY</div>
            <div class="area-item"><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?> Cheektowaga, NY</div>
            <div class="area-item"><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?> Tonawanda, NY</div>
            <div class="area-item"><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?> Kenmore, NY</div>
            <div class="area-item"><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?> West Seneca, NY</div>
            <div class="area-item"><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?> North Tonawanda, NY
            </div>
            <div class="area-item"><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?> Orchard Park, NY</div>
            <div class="area-item"><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?> Hamburg, NY</div>
            <div class="area-item"><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?> East Aurora, NY</div>
            <div class="area-item"><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?> Lockport, NY</div>
            <div class="area-item"><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?> Niagara Falls, NY</div>
        </div>
    </div>
</section>

<!-- 8. CTA -->
<section class="about-cta-section">
    <div class="about-container text-center">
        <h2 class="global-section-title">Let's Get Started — Request Your Free Quote</h2>
        <p>Need professional tree care? Contact Maple Majesty Tree Care today for reliable service, expert
            recommendations, and your free estimate.</p>
        <p>If you are searching for reliable tree service near me, Maple Majesty Tree Care is ready to provide
            professional solutions for your property. Our team will evaluate your trees, explain your options, and
            recommend the best approach tailored to your specific needs.</p>
        <p>Whether you need trimming, pruning, storm cleanup, or complete tree removal, we are here to help.</p>
        <h3 class="cta-subtitle">Contact Maple Majesty Tree Care today to schedule your free consultation.</h3>
        <p style="font-weight: 600; margin-bottom: 20px; color: var(--color-brand-green);">Trusted tree care for Buffalo and Western New York homeowners.</p>

        <div class="cta-buttons">
            <a href="tel:+17164000763" class="btn-primary cta-btn cta-btn-svg">
                <?php echo file_get_contents(get_template_directory() . '/assets/icons/phone-call.svg'); ?>
                <span>Call Now</span>
            </a>
            <a href="<?php echo esc_url(site_url('/contact/')); ?>" class="btn-secondary cta-btn cta-btn-svg">
                <?php echo file_get_contents(get_template_directory() . '/assets/icons/step-quote.svg'); ?>
                <span>Free Quote</span>
            </a>
        </div>
    </div>
</section>