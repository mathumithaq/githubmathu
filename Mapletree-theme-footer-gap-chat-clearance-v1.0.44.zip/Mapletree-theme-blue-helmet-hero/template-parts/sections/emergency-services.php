<section class="emergency-section">
    <div class="emergency-header">
        <span class="global-subtitle">Emergency Services</span>
        <h2 class="global-section-title">24HR EMERGENCY TREE SERVICES</h2>
    </div>
    <div class="section-divider" style="margin-bottom: 3rem; max-width: 800px;"></div>
    
    <div class="emergency-content-grid">
        <!-- Left Column: Key Takeaway -->
        <div class="emergency-takeaway">
            <div class="takeaway-item">
                <div class="takeaway-icon">
                    <?php echo file_get_contents(get_template_directory() . '/assets/icons/broken-tree.svg'); ?>
                </div>
                <div class="takeaway-text">
                    Fallen trees, hanging limbs, split trunks, and storm damage can create immediate safety risks.
                </div>
            </div>
            
            <div class="takeaway-item">
                <div class="takeaway-icon">
                    <?php echo file_get_contents(get_template_directory() . '/assets/icons/barricade.svg'); ?>
                </div>
                <div class="takeaway-text">
                    Professional emergency tree service helps secure the area and address hazardous tree conditions quickly.
                </div>
            </div>
        </div>
        
        <!-- Right Column: Context & CTA -->
        <div class="emergency-cta-area">
            <p class="emergency-context">
                A tree down on your property? Don't wait. Our emergency tree service crews respond 24/7 across Buffalo and Western New York when storm damage threatens your home.
            </p>
            
            <div class="emergency-action">
                <a href="tel:+17164000763" class="btn-primary">
                    Call Now
                </a>
            </div>
        </div>
    </div>
</section>
