<section class="faqs-section" id="faqs">
    <div class="faqs-container">
        
        <div class="faqs-header">
            <span class="global-subtitle">FAQS</span>
            <h2 class="faqs-title">Frequently Asked Questions</h2>
        </div>

        <div class="faqs-grid">
            <?php 
            $faqs = [
                [
                    'q' => 'How much does tree removal cost in Buffalo, NY?',
                    'a' => 'Cost depends on tree size, accessibility, and job complexity. Most companies, including Maple Majesty, offer a free on-site estimate so you get an accurate number rather than a generic average.'
                ],
                [
                    'q' => 'Do I need a permit to remove a tree in Buffalo?',
                    'a' => 'Some municipalities require permits for large or protected trees. Requirements vary by property and species, so it\'s best to confirm with your local building department or ask your tree service to help verify.'
                ],
                [
                    'q' => 'How do I know if my tree needs to be removed or can be saved?',
                    'a' => 'Extensive dead branches, fungal growth at the base, root damage, or a sudden lean often indicate removal is necessary. A certified arborist can assess the tree\'s structure and recommend the safest option.'
                ],
                [
                    'q' => 'What\'s the best time of year for tree trimming?',
                    'a' => 'Late winter to early spring, while trees are dormant, is generally ideal for most trimming and pruning. Hazardous limbs, however, should be addressed immediately regardless of the season.'
                ],
                [
                    'q' => 'Is stump grinding better than stump removal?',
                    'a' => 'Stump grinding is faster and grinds the stump below grade so you can landscape over it. Full stump removal extracts the entire root system, which is better if you\'re planning new construction in that spot.'
                ],
                [
                    'q' => 'Do you offer emergency tree removal services?',
                    'a' => 'Yes. Maple Majesty provides 24/7 emergency response for storm damage, fallen trees, and hazardous limbs threatening a property in Buffalo and Western New York.'
                ],
                [
                    'q' => 'Are your arborists certified?',
                    'a' => 'Yes. Our crews are led by ISA-Certified Arborists with formal training in tree biology, risk assessment, and proper care techniques, backed by 5+ years of local field experience.'
                ],
                [
                    'q' => 'Will my homeowner\'s insurance cover tree removal?',
                    'a' => 'Coverage varies by policy and circumstances, especially for storm-related damage. Check with your insurance provider directly. We\'re happy to provide documentation to support a claim.'
                ],
                [
                    'q' => 'How often should trees be trimmed or pruned?',
                    'a' => 'Most trees benefit from trimming every 1 to 3 years, though this varies by species, age, and health. A dead or hazardous limb should be handled right away, not on a schedule.'
                ],
                [
                    'q' => 'Do you clean up debris after the job is done?',
                    'a' => 'Yes. Every job includes full debris removal and site cleanup. Branches, sawdust, and brush don\'t get left behind for you to handle.'
                ]
            ];
            
            foreach($faqs as $index => $faq) {
                $openAttr = ($index === 0) ? ' open' : '';
                echo '<details class="faq-item"' . $openAttr . '>';
                echo '  <summary class="faq-summary">';
                echo '      <span class="faq-question">' . esc_html($faq['q']) . '</span>';
                echo '      <span class="faq-icon-wrapper">';
                echo '          <img src="' . get_template_directory_uri() . '/assets/icons/plus.svg" class="faq-icon-plus" alt="Expand" width="16" height="16">';
                echo '          <img src="' . get_template_directory_uri() . '/assets/icons/minus.svg" class="faq-icon-minus" alt="Collapse" width="16" height="16">';
                echo '      </span>';
                echo '  </summary>';
                echo '  <div class="faq-answer-wrapper">';
                echo '      <div class="faq-answer">' . esc_html($faq['a']) . '</div>';
                echo '  </div>';
                echo '</details>';
            }
            ?>
        </div>

    </div>
</section>