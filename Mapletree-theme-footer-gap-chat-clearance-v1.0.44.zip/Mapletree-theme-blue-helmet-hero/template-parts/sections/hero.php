<section class="hero-section">
    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/hero-arborist-orange-v2.webp" srcset="<?php echo get_template_directory_uri(); ?>/assets/images/hero-arborist-orange-mobile.webp 480w, <?php echo get_template_directory_uri(); ?>/assets/images/hero-arborist-orange-v2.webp 920w" sizes="100vw" alt="" class="hero-bg-img" fetchpriority="high" loading="eager" decoding="async" width="920" height="518">
    <div class="hero-bg-overlay"></div>
    <div class="hero-container">
        <div class="hero-content">
            <h1 class="hero-heading">Expert Tree Service in Buffalo, NY</h1>
            <p class="hero-subtext">When searching for a tree company near me, choose our trusted tree service company for professional tree care throughout Buffalo and Western New York.</p>
            
            <div class="trust-signals">
                <div class="trust-item"><span>Five-Star Reviews</span></div>
                <div class="trust-item"><span>ISA-Certified Arborists</span></div>
                <div class="trust-item"><span>24/7 Emergency Response</span></div>
                <div class="trust-item"><span>Fully Licensed & Insured</span></div>
                <div class="trust-item"><span>100% Satisfaction Guaranteed</span></div>
            </div>

            <div class="hero-actions">
                <a href="tel:+17164000763" class="btn-primary">
                    <?php echo file_get_contents(get_template_directory() . '/assets/icons/phone-call.svg'); ?>
                    Call Now
                </a>
                <a href="<?php echo esc_url(site_url('/contact/')); ?>" class="btn-secondary">
                    <?php echo file_get_contents(get_template_directory() . '/assets/icons/message.svg'); ?>
                    Get Free Quote
                </a>
            </div>
        </div>
        <div class="hero-image-wrapper">
            <img src="<?php echo get_template_directory_uri(); ?>/assets/images/hero-arborist-orange-v2.webp" srcset="<?php echo get_template_directory_uri(); ?>/assets/images/hero-arborist-orange-mobile.webp 480w, <?php echo get_template_directory_uri(); ?>/assets/images/hero-arborist-orange-v2.webp 920w" alt="Professional arborist in orange safety equipment climbing a mature tree" class="hero-image" loading="eager" fetchpriority="high" decoding="async" width="920" height="518" sizes="(max-width: 768px) 100vw, 50vw">
        </div>
    </div>
</section>
