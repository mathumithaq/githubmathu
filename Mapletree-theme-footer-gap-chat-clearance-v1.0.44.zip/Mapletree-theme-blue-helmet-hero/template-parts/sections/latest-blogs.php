<section class="latest-blogs-section" id="latest-blogs">
    <div class="latest-blogs-container">
        <div class="blogs-header">
            <span class="global-subtitle">Latest Blogs</span>
            <h2 class="blogs-title">Latest Blogs</h2>
            <p class="blogs-description">Keen to discover more tree maintenance ideas? Our site features information on when and how to prune your trees, weather-proofing them and caring for specific varieties, as well as responses to frequently asked questions regarding trees in Buffalo. If you are facing particular issues or seeking tips on how to care for your trees and plants in each season of the year, you will find plenty of useful tree service advice in our timely and expert articles.</p>
        </div>

        <div class="blogs-grid">
            <?php
            $recent_posts = new WP_Query([
                'posts_per_page' => 3,
                'post_status'    => 'publish'
            ]);

            if ($recent_posts->have_posts()) :
                while ($recent_posts->have_posts()) : $recent_posts->the_post();
                    $categories = get_the_category();
                    $cat_name = !empty($categories) ? esc_html($categories[0]->name) : 'Blog';
                    $thumb_url = has_post_thumbnail() ? get_the_post_thumbnail_url(get_the_ID(), 'medium_large') : get_template_directory_uri() . '/assets/images/placeholder.webp';
                    ?>
                    <article class="blog-card">
                        <div class="blog-card-image" style="background-image: url('<?php echo esc_url($thumb_url); ?>');">
                        </div>
                        <div class="blog-card-content">
                            <div class="blog-meta">
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/calendar.svg" alt="Calendar" class="blog-meta-icon">
                                <span><?php echo get_the_date('F j, Y'); ?></span>
                            </div>
                            <h3 class="blog-card-title"><?php the_title(); ?></h3>
                            <p class="blog-card-excerpt"><?php echo wp_trim_words(get_the_excerpt(), 15, '...'); ?></p>
                            <a href="<?php the_permalink(); ?>" class="btn-primary" style="align-self: flex-start; margin-top: auto; display: inline-flex; align-items: center; gap: 0.5rem; text-decoration: none;">
                                Read Article 
                            </a>
                        </div>
                    </article>
                <?php
                endwhile;
                wp_reset_postdata();
            else :
                echo '<p>No recent posts found.</p>';
            endif;
            ?>
        </div>
    </div>
</section>
