
<?php
/**
 * Contact Page Content Sections
 */
$icon_path = get_template_directory() . '/assets/icons/';
?>

<!-- 1. Contact Info & Form -->
<section class="contact-page-intro">
    <div class="about-container">
        <div class="contact-page-grid">
            <!-- Left: Contact Info -->
            <div class="contact-info-col">
                <span class="global-subtitle">How to Reach Us</span>
                <h2 class="global-section-title">Have questions or need to schedule a service?</h2>
                <p>Our friendly team is ready to assist you.</p>

                <div class="contact-info-list">
                    <div class="contact-info-item">
                        <div class="contact-icon-wrapper">
                            <?php echo file_get_contents($icon_path . 'phone-call.svg'); ?>
                        </div>
                        <div class="contact-info-text">
                            <h3>Phone</h3>
                            <a href="tel:+17164000763">(716) 400-0763</a>
                        </div>
                    </div>

                    <div class="contact-info-item">
                        <div class="contact-icon-wrapper">
                            <?php echo file_get_contents($icon_path . 'clock.svg'); ?>
                        </div>
                        <div class="contact-info-text">
                            <h3>Business Hours</h3>
                            <p>Monday – Friday: 8:00 AM – 6:00 PM</p>
                            <p>Saturday: 8:00 AM – 3:00 PM</p>
                             <p>Sunday: Emergency Services Available</p>
                            <p class="contact-emergency-response">24/7 Emergency Tree Response</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Right: GHL Form -->
            <div class="contact-form-box">
                <h3 style="color: var(--color-brand-purple); margin-bottom: 1rem;">Request Your Free Estimate</h3>
                <p style="color: var(--color-text-gray); margin-bottom: 2rem;">Request your free tree service estimate Buffalo NY today. Tell us about your tree care needs, and our team will contact you promptly.</p>
                <p style="color: var(--color-text-gray); margin-bottom: 2rem;">Complete our contact form to request a no-obligation estimate. Whether you need tree removal, trimming, pruning, stump grinding, or emergency tree services, our arborists will evaluate your property and recommend the best solution.</p>

                <?php get_template_part('partials/forms/form'); ?>
            </div>
        </div>
    </div>
</section>

<!-- 2. Trust Strip -->
<div class="trust-strip">
    <div class="trust-strip-container">
        <div class="trust-item">
            <?php echo file_get_contents($icon_path . 'estimation.svg'); ?>
            Free Estimates
        </div>
        <div class="trust-item">
            <?php echo file_get_contents($icon_path . 'shield.svg'); ?>
            Licensed & Insured
        </div>
        <div class="trust-item">
            <?php echo file_get_contents($icon_path . 'badge.svg'); ?>
            ISA-Certified Arborists
        </div>
        <div class="trust-item">
            <?php echo file_get_contents($icon_path . 'star.svg'); ?>
            5-Star Customer Reviews
        </div>
        <div class="trust-item">
            <?php echo file_get_contents($icon_path . 'clock.svg'); ?>
            24/7 Emergency Response
        </div>
        <div class="trust-item">
            <?php echo file_get_contents($icon_path . 'trust-local.svg'); ?>
            Locally Owned & Operated
        </div>
    </div>
</div>

<!-- 3. Where We Work -->
<section class="contact-areas-section">
    <div class="about-container">
        <div class="text-center">
            <span class="global-subtitle">Where We Work</span>
            <h2 class="global-section-title">Buffalo & Surrounding Communities</h2>
            <p class="section-intro">We proudly provide professional tree service Buffalo NY and throughout Western New York with reliable, local tree care solutions.</p>
            <p class="section-intro">Maple Majesty Tree Care proudly serves residential and commercial customers throughout</p>

        </div>

        <div class="contact-areas-grid">
            <div class="contact-area-column">
                <h3>Buffalo & Neighborhoods</h3>
                <ul class="contact-area-list">
                    <li><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?> Buffalo</li>
                    <li><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?> North Buffalo</li>
                    <li><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?> South Buffalo</li>
                    <li><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?> Allentown</li>
                    <li><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?> Elmwood Village</li>
                    <li><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?> Delaware Park / Midtown</li>
                </ul>
            </div>
            <div class="contact-area-column">
                <h3>Erie County North</h3>
                <ul class="contact-area-list">
                    <li><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?> Amherst</li>
                    <li><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?> East Amherst</li>
                    <li><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?> Williamsville</li>
                    <li><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?> Getzville</li>
                    <li><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?> Kenmore</li>
                    <li><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?> Tonawanda</li>
                    <li><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?> Clarence</li>
                    <li><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?> Clarence Center</li>
                    <li><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?> Newstead</li>
                    <li><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?>Akron</li>
                    <li><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?>West Amherst</li>
                </ul>
            </div>
            <div class="contact-area-column">
                <h3>Erie County South</h3>
                <ul class="contact-area-list">
                    <li><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?> Cheektowaga</li>
                    <li><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?> Depew</li>
                    <li><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?> West Seneca</li>
                    <li><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?> Alden</li>
                    <li><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?> Lackawanna</li>
                    <li><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?> Blasdell</li>
                    <li><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?> Hamburg</li>
                    <li><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?> Orchard Park</li>
                    <li><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?> East Aurora</li>
                    <li><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?> Elma</li>
                </ul>
            </div>
            <div class="contact-area-column">
                <h3>Niagara County</h3>
                <ul class="contact-area-list">
                    <li><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?> North Tonawanda</li>
                    <li><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?> Niagara Falls</li>
                    <li><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?> Lockport</li>
                    <li><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?> Lewiston</li>
                    <li><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?> Pendleton</li>
                    <li><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?> Ransomville</li>
                    <li><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?> Sanborn</li>
                    <li><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?> Wheatfield</li>
                    <li><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?> Youngstown</li>
                    <li><?php echo file_get_contents($icon_path . 'map-pin.svg'); ?> Wilson</li>
                </ul>
            </div>
        </div>
    </div>
</section>

<!-- 4. Next Steps -->
<section class="contact-steps-section">
    <div class="about-container">
        <div class="text-center">
            <span class="global-subtitle">Next Steps</span>
            <h2 class="global-section-title">From Your Call to Cleanup</h2>
            <p class="section-intro">From your first call to final cleanup, our simple process ensures professional service, clear communication, and quality tree care every step of the way.</p>
            <p class="section-intro">Getting started with Maple Majesty Tree Care is easy.</p>
        </div>

        <div class="contact-steps-grid">
            <div class="contact-step-card">
                <div class="step-number">1</div>
                <div class="step-icon"><?php echo file_get_contents($icon_path . 'phone-call.svg'); ?></div>
                <h3>Contact Us</h3>
                <p>Call, email, or submit your online estimate request.</p>
            </div>
            <div class="contact-step-card">
                <div class="step-number">2</div>
                <div class="step-icon"><?php echo file_get_contents($icon_path . 'search.svg'); ?></div>
                <h3>Schedule an Inspection</h3>
                <p>We'll arrange a convenient time to inspect your trees and discuss your needs.</p>
            </div>
            <div class="contact-step-card">
                <div class="step-number">3</div>
                <div class="step-icon"><?php echo file_get_contents($icon_path . 'file-text.svg'); ?></div>
                <h3>Receive Your Free Estimate</h3>
                <p>Our team will provide honest recommendations and transparent pricing before any work begins.</p>
            </div>
            <div class="contact-step-card">
                <div class="step-number">4</div>
                <div class="step-icon"><?php echo file_get_contents($icon_path . 'shield.svg'); ?></div>
                <h3>Professional Tree Service</h3>
                <p>Our experienced crew completes the work safely using professional equipment and industry-approved techniques.</p>
            </div>
            <div class="contact-step-card">
                <div class="step-number">5</div>
                <div class="step-icon"><?php echo file_get_contents($icon_path . 'check-circle.svg'); ?></div>
                <h3>Complete Cleanup</h3>
                <p>We remove all debris and leave your property clean, safe, and ready to enjoy.</p>
            </div>
        </div>
    </div>
</section>

<!-- 5. Emergency CTA -->
<section class="contact-emergency-section">
    <div class="about-container text-center">
        <span class="global-subtitle">24/7 Emergency Tree Response</span>
        <h2 class="global-section-title" style="color: var(--color-warm-gold) !important;">Urgent Tree Issue? Contact Our Emergency Team</h2>
        <p>Need emergency tree service after a storm or fallen tree? Contact Maple Majesty Tree Care for fast, reliable emergency response in Buffalo.</p>
        <p>Storm damage can happen at any time. If a fallen tree or broken branch is threatening your home, driveway, or power lines, don't wait.</p>
        <p>Our emergency tree service team responds quickly to help remove hazards, protect your property, and restore safety as soon as possible.</p>

        <a href="tel:+17164000763" class="btn-primary cta-btn">
            Call Now
        </a>
    </div>
</section>

<!-- 6. FAQs -->
<section class="faqs-section" id="faqs">
    <div class="about-container">
        <div class="text-center">
            <span class="global-subtitle">FAQs</span>
            <h2 class="global-section-title">Frequently Asked Questions</h2>
            <p class="section-intro">Find answers to common questions about scheduling, estimates, emergency response, and contacting Maple Majesty Tree Care.</p>
        </div>

        <div class="faqs-grid">
            <?php 
            $contact_faqs = [
                [
                    'q' => 'How quickly do you respond to inquiries?',
                    'a' => 'We respond to most calls and online requests within one business day, with emergency requests prioritized for faster service.'
                ],
                [
                    'q' => 'Do I need to be home for the estimate?',
                    'a' => 'Not always. If we have access to the tree, we can often perform an inspection and provide an estimate without you being present.'
                ],
                [
                    'q' => 'Is the estimate really free?',
                    'a' => 'Yes. We provide free, no-obligation estimates for all residential and commercial tree care services.'
                ],
                [
                    'q' => 'What areas do you serve?',
                    'a' => 'We proudly serve Buffalo and surrounding Western New York communities, including Amherst, Cheektowaga, Tonawanda, Hamburg, Clarence, and nearby areas.'
                ],
                [
                    'q' => 'Do you offer emergency tree services?',
                    'a' => 'Yes. Our team provides 24/7 emergency tree services for storm damage, fallen trees, and hazardous branches.'
                ],
                [
                    'q' => 'How can I schedule an appointment?',
                    'a' => 'Call us, email us, or complete our online contact form. We\'ll arrange a convenient time to inspect your property and provide a free estimate.'
                ]
            ];
            
            foreach($contact_faqs as $index => $faq) {
                $openAttr = ($index === 0) ? ' open' : '';
                echo '<details class="faq-item"' . $openAttr . '>';
                echo '  <summary class="faq-summary">';
                echo '      <span class="faq-question">' . esc_html($faq['q']) . '</span>';
                echo '      <span class="faq-icon-wrapper">';
                echo '          <img src="' . get_template_directory_uri() . '/assets/icons/plus.svg" class="faq-icon-plus" alt="Expand" width="16" height="16">';
                echo '          <img src="' . get_template_directory_uri() . '/assets/icons/minus.svg" class="faq-icon-minus" alt="Collapse" width="16" height="16">';
                echo '      </span>';
                echo '  </summary>';
                echo '  <div class="faq-answer-wrapper">';
                echo '      <div class="faq-answer">' . esc_html($faq['a']) . '</div>';
                echo '  </div>';
                echo '</details>';
            }
            ?>
        </div>
    </div>
</section>

