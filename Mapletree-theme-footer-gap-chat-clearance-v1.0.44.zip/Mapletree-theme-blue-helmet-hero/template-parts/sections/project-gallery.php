<section class="gallery-section">
    <div class="gallery-container">
        <div class="gallery-header">
            <span class="global-subtitle">Project Gallery</span>
            <div class="gallery-title-wrapper">
                <h2 class="gallery-title">Before & After</h2>
            </div>
        </div>

        <div class="gallery-projects-tabs">
            <button class="project-tab active" data-project="1" data-before="project1-before.webp" data-after="project1-after.webp">
                Emergency Storm Cleanup
            </button>
            <button class="project-tab" data-project="2" data-before="project2-before.webp" data-after="project2-after.webp">
                Full Crown Reduction
            </button>
            <button class="project-tab" data-project="3" data-before="project3-before.webp" data-after="project3-after.webp">
                Stump Grinding Project
            </button>
            <button class="project-tab" data-project="4" data-before="project4-before.webp" data-after="project4-after.webp">
                Land Clearing
            </button>
            <button class="project-tab" data-project="5" data-before="project5-before.webp" data-after="project5-after.webp">
                Hazard Tree Removal
            </button>
        </div>
        
        <div class="gallery-project-description" id="project-desc">
            Emergency storm cleanup - fallen silver maple removed from a residential driveway in Amherst, NY
        </div>

        <div class="before-after-container">
            <div class="img-background" id="ba-img-after" style="background-image: url('<?php echo get_template_directory_uri(); ?>/assets/images/projects/project1-after.webp');">
                <span class="ba-label ba-label-after">After</span>
            </div>
            <div class="img-foreground" id="ba-img-before" style="background-image: url('<?php echo get_template_directory_uri(); ?>/assets/images/projects/project1-before.webp');">
                <span class="ba-label ba-label-before">Before</span>
            </div>
            <input type="range" min="1" max="100" value="50" class="slider" name="slider" id="ba-slider" aria-label="Image comparison slider">
            <div class="slider-button">
                <?php echo file_get_contents(get_template_directory() . '/assets/icons/leaf.svg'); ?>
            </div>
        </div>
    </div>
</section>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const slider = document.getElementById('ba-slider');
    const foreground = document.querySelector('.img-foreground');
    const sliderBtn = document.querySelector('.slider-button');
    
    // Project data mapping
    const projectDescriptions = {
        '1': 'Emergency storm cleanup - fallen silver maple removed from a residential driveway in Amherst, NY',
        '2': 'Full crown reduction on a mature oak - improved canopy shape and reduced storm risk',
        '3': 'Stump grinding project - backyard restored and ready for landscaping in West Seneca',
        '4': 'Land clearing before new construction - overgrown lot cleared and graded in Orchard Park',
        '5': 'Hazard tree removal near power lines - completed safely with zero property damage'
    };

    if(slider && foreground && sliderBtn) {
        slider.addEventListener('input', (e) => {
            const sliderPos = e.target.value;
            foreground.style.width = `${sliderPos}%`;
            sliderBtn.style.left = `calc(${sliderPos}% - 18px)`;
        });
    }

    // Tab switching logic
    const tabs = document.querySelectorAll('.project-tab');
    const descEl = document.getElementById('project-desc');
    const bgAfter = document.getElementById('ba-img-after');
    const bgBefore = document.getElementById('ba-img-before');
    const themeUri = '<?php echo get_template_directory_uri(); ?>';

    tabs.forEach(tab => {
        tab.addEventListener('click', function() {
            // Remove active from all
            tabs.forEach(t => t.classList.remove('active'));
            // Add active to clicked
            this.classList.add('active');

            // Get data
            const pid = this.getAttribute('data-project');
            const beforeImg = this.getAttribute('data-before');
            const afterImg = this.getAttribute('data-after');

            // Update DOM
            descEl.textContent = projectDescriptions[pid];
            bgBefore.style.backgroundImage = `url('${themeUri}/assets/images/projects/${beforeImg}')`;
            bgAfter.style.backgroundImage = `url('${themeUri}/assets/images/projects/${afterImg}')`;
            
            // Reset slider to middle
            if(slider && foreground && sliderBtn) {
                slider.value = 50;
                foreground.style.width = '50%';
                sliderBtn.style.left = 'calc(50% - 18px)';
            }
        });
    });
});
</script>
