<section class="mm-about-section" id="about-us">
    <div class="mm-about-container">
        
        <!-- Section Header -->
        <div class="mm-about-header">
            <span class="global-subtitle">ABOUT US</span>
            <h2>About Maple Majesty Tree Care - Tree Services in Buffalo NY</h2>
        </div>

        <!-- Key Takeaway -->
        <div class="mm-about-takeaway">
            <p>Local tree care requires an understanding of Buffalo's weather, tree species, soil conditions, and seasonal risks. Professional arborist guidance helps property owners choose the safest and most appropriate care.</p>
        </div>

        <!-- Description Content -->
        <div class="mm-about-content">
            <p>Local trees face local problems, such as lake-effect snow loads, ice-storm limb failure, and clay-heavy soil that weakens root systems. A local tree service that works in these exact conditions year-round, like Maple Majesty Tree Care, can diagnose and respond faster and more accurately than a national franchise unfamiliar with Buffalo's climate.</p>
            
            <p>Maple Majesty Tree Care started small, with a crew working odd jobs around South Buffalo, and has grown, over more than 5+ years, into one of the region's trusted names in local tree service. What hasn't changed is the mindset: we still show up like it's a favor for a neighbor, because most of the time, it is.</p>
            
            <p>If you searched "tree service Buffalo NY" and landed here, here's what you should know. We're a full-service tree service company built around one idea: your trees deserve care from people who understand tree biology, not just people who own a chainsaw. Every crew works under the guidance of ISA-Certified Arborists, so pruning cuts, removals, and health assessments are based on horticultural science, not guesswork.</p>
            
            <p>Our understanding of Buffalo's environmental conditions. We spent more than 5+ years dealing with ice storm-damaged silver maples, emerald ash borer-afflicted ash trees, and thriving old-growth oaks. We know where the challenging overhead wires are located and where the debris disposal laws apply. Being a genuine tree service in Buffalo, NY means our trucks can reach Elmwood Village, Kenmore, or Orchard Park quickly — because our service radius was built around actually being local.</p>
        </div>

        <!-- Process Section -->
        <div class="mm-about-process-section">
            <h3>We work in the following way:</h3>
            <div class="mm-process-grid">
                <div class="mm-process-item">
                    <div class="mm-process-icon">
                        <?php echo file_get_contents(get_template_directory() . '/assets/icons/estimation.svg'); ?>
                    </div>
                    <h4>Estimation</h4>
                    <p>Inspect the condition of the tree while assessing the situation regarding its roots and possible influences from outside (nearby buildings and electric power lines).</p>
                </div>

                <div class="mm-process-item">
                    <div class="mm-process-icon">
                        <?php echo file_get_contents(get_template_directory() . '/assets/icons/clarification.svg'); ?>
                    </div>
                    <h4>Clarification</h4>
                    <p>Let the client know what the problem is, why it is essential, and what actions should be taken, namely removal, trimming, cable installation, or monitoring.</p>
                </div>

                <div class="mm-process-item">
                    <div class="mm-process-icon">
                        <?php echo file_get_contents(get_template_directory() . '/assets/icons/action.svg'); ?>
                    </div>
                    <h4>Action</h4>
                    <p>Get to work in accordance with the standards set forth by ISA and using the appropriate rigging system.</p>
                </div>

                <div class="mm-process-item">
                    <div class="mm-process-icon">
                        <?php echo file_get_contents(get_template_directory() . '/assets/icons/cleaning.svg'); ?>
                    </div>
                    <h4>Cleaning</h4>
                    <p>The place is cleaned fully; the stump should be ground properly, the branches removed.</p>
                </div>
            </div>
        </div>

        <!-- Principles Section -->
        <div class="mm-about-principles-section">
            <h3>Every job is driven by three main principles:</h3>
            <div class="mm-principles-grid">
                <div class="mm-principle-item">
                    <div class="mm-principle-icon">
                        <?php echo file_get_contents(get_template_directory() . '/assets/icons/safety.svg'); ?>
                    </div>
                    <h4>Safety is a priority</h4>
                    <p>Tree service is among the riskiest professions. By following certain rules, our specialists have complete training in rigging, fall protection, and felling techniques from our expert partners. Additionally, we possess full licenses and insurance, so you won't have to worry for a second.</p>
                </div>

                <div class="mm-principle-item">
                    <div class="mm-principle-icon">
                        <?php echo file_get_contents(get_template_directory() . '/assets/icons/communication.svg'); ?>
                    </div>
                    <h4>Honest, upfront communication</h4>
                    <p>If your tree needs just some light trimming rather than cutting it down, we'll let you know about it because we want to help you as a client, regardless of what our income might be.</p>
                </div>

                <div class="mm-principle-item">
                    <div class="mm-principle-icon">
                        <?php echo file_get_contents(get_template_directory() . '/assets/icons/property.svg'); ?>
                    </div>
                    <h4>Respect for your property</h4>
                    <p>Lawns, gardens, and driveways are protected during our work.</p>
                </div>
            </div>
        </div>

        <!-- Closing Content -->
        <div class="mm-about-closing">
            <p>Over 5+ years, we have grown from ordinary removal to complete assistance, which includes emergency storm response services, clearing of land and brush, stump grinding, crown reduction services, and consistent consultation services in arboriculture for homeowners, willing to keep their landscape healthy constantly, rather than dealing with problems when they happen. We are collaborating with homeowners, preserving century-old trees, developers, cleaning the land for future constructions, and property managers, looking for trustworthy crews during storm seasons.</p>
            
            <p>When you call Maple Majesty Tree Care, you speak with the people who know the value of mature oak canopies for certain blocks and care about doing a good, clean and safe job.</p>
        </div>

    </div>
</section>
