<section class="contact-section" id="contact">
    <div class="contact-container">
        <!-- Left Column: Contact Info & Details -->
        <div class="contact-content-side">
            <div class="contact-header">
                <span class="global-subtitle">Contact Us</span>
                <h2 class="contact-title">Get a Free Tree Service Quote in Buffalo, NY</h2>
            </div>
            <?php if (is_front_page()) : ?>
                <img class="contact-hero-thumbnail"
                    src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/hero-arborist-orange-v2.webp'); ?>"
                    alt="Arborist working on a tree"
                    width="920" height="518" loading="lazy" decoding="async">
            <?php endif; ?>
            <div class="contact-content">
                <p class="contact-description">Ready to get started? Request a free, no-obligation estimate on your tree service in Buffalo, NY project we respond quickly and schedule your on-site visit.</p>
                
                <div class="contact-info-blocks">
                    <div class="contact-info-block">
                        <div class="contact-info-icon">
                            <?php echo file_get_contents(get_template_directory() . '/assets/icons/phone-call.svg'); ?>
                        </div>
                        <div>
                            <h3>Call Us Directly</h3>
                            <a href="tel:+17164000763">(716) 400-0763</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Right Column: GHL Form -->
        <div class="contact-form-side">
            <div class="contact-form-wrapper">
                <?php get_template_part('partials/forms/form'); ?>
            </div>
        </div>
    </div>
</section>
