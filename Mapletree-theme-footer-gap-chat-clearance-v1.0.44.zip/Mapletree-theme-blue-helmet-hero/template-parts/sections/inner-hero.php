<?php
/**
 * Inner Hero Section Template Part
 * Used on inner pages like Contact, About Us, etc.
 */

// Dynamic Content
$title = get_the_title();
$custom_title = get_post_meta(get_the_ID(), 'inner_hero_title', true);
if ( function_exists('get_field') && get_field('inner_hero_title') ) {
    $custom_title = get_field('inner_hero_title');
}
if ( !empty($custom_title) ) {
    $title = $custom_title;
}

$custom_description = get_post_meta(get_the_ID(), 'inner_hero_description', true);
if ( function_exists('get_field') && get_field('inner_hero_description') ) {
    $custom_description = get_field('inner_hero_description');
}

if ( !empty($custom_description) ) {
    $description = $custom_description;
} elseif ( has_excerpt() ) {
    $description = get_the_excerpt();
} else {
    $description = '';
}

// Custom subtitle (No default)
$subtitle = get_post_meta(get_the_ID(), 'inner_hero_subtitle', true);

// Hero Image logic
$hero_image_url = get_the_post_thumbnail_url(get_the_ID(), 'full');
if (empty($hero_image_url)) {
    $hero_image_url = get_template_directory_uri() . '/assets/images/hero-arborists.webp';
}

$icon_path = get_template_directory() . '/assets/icons/';
?>

<section class="inner-hero-section">
    <div class="inner-hero-container">
        <!-- Centered Content -->
        <div class="inner-hero-content-col centered-hero" style="text-align: center; display: flex; flex-direction: column; align-items: center; margin: 0 auto;">
            <?php if (!empty($subtitle)) : ?>
            <div class="inner-hero-subtitle-wrapper">
                <?php if(file_exists($icon_path . 'hero-accent.svg')) { echo file_get_contents($icon_path . 'hero-accent.svg'); } ?>
                <span class="global-subtitle inner-subtitle"><?php echo esc_html($subtitle); ?></span>
            </div>
            <?php endif; ?>
            <h1 class="inner-hero-title"><?php echo esc_html($title); ?></h1>
            <?php if (!empty($description) && !is_page('contact') && !is_page('blog') && !is_page_template('page-contact.php') && !is_page_template('page-blog.php')) : ?>
                <p class="inner-hero-description"><?php echo esc_html($description); ?></p>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Bottom SVG Wave Divider -->
    <div class="inner-hero-wave">
        <svg viewBox="0 0 1440 120" preserveAspectRatio="none">
            <path fill="var(--color-soft-lilac)" d="M0,60 C320,120 420,0 720,60 C1020,120 1120,0 1440,60 L1440,120 L0,120 Z"></path>
        </svg>
    </div>
</section>
