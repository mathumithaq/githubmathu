<?php
/**
 * Template part for displaying the Tree Removal Warning Signs section
 */
?>

<section class="warning-signs-section">
    <div class="warning-signs-container">
        <!-- Global Subtitle & Title -->
        <div class="text-center">
            <span class="global-subtitle">Tree Assessment</span>
            <h2 class="global-section-title">Warning Signs &mdash; When to Remove a Tree</h2>
            <div class="section-divider"></div>
        </div>

        <div class="warning-signs-intro text-center">
            <p>It may appear to be a healthy tree from afar, but it may have internal structural issues that cause it to be more prone to failure. The early detection of signs of warning can avert damage to property, injury to persons, and expensive emergencies.</p>
            <p class="intro-highlight">Tree removal may be recommended when a tree can no longer be safely maintained through other techniques such as tree trimming or pruning.</p>
        </div>

        <div class="warning-signs-grid">
            
            <!-- Item 1 -->
            <div class="warning-card">
                <div class="warning-icon-wrapper">
                    <?php echo file_get_contents( get_template_directory() . '/assets/icons/tree-leaning.svg' ); ?>
                </div>
                <div class="warning-content">
                    <h3>1. Severe Leaning or Structural Instability</h3>
                    <p>Trees that suddenly start leaning may have issues with their roots, soil, or internal tree structure. Trees growing in proximity to homes, driveways or walkways must be evaluated by a licensed arborist right away, as they could fall unexpectedly.</p>
                </div>
            </div>

            <!-- Item 2 -->
            <div class="warning-card">
                <div class="warning-icon-wrapper">
                    <?php echo file_get_contents( get_template_directory() . '/assets/icons/dead-branches.svg' ); ?>
                </div>
                <div class="warning-content">
                    <h3>2. Large Dead or Broken Branches</h3>
                    <p>During Buffalo's rough winds, winter storms, and heavy snow, the limbs of trees can fall. As large branches hang above roofs, vehicles, or outdoor spaces, there are significant safety concerns.</p>
                </div>
            </div>

            <!-- Item 3 -->
            <div class="warning-card">
                <div class="warning-icon-wrapper">
                    <?php echo file_get_contents( get_template_directory() . '/assets/icons/disease-decay.svg' ); ?>
                </div>
                <div class="warning-content">
                    <h3>3. Extensive Disease or Decay</h3>
                    <p>Trees with advanced disease, fungus, and woody rot can become structurally unsound. If the trunk or main branches are involved, it may be safer to remove the tree than to try to treat it.</p>
                </div>
            </div>

            <!-- Item 4 -->
            <div class="warning-card">
                <div class="warning-icon-wrapper">
                    <?php echo file_get_contents( get_template_directory() . '/assets/icons/root-problems.svg' ); ?>
                </div>
                <div class="warning-content">
                    <h3>4. Root System Problems</h3>
                    <p>A damaged root system can cause the entire tree to be weakened. Symptoms are soil heaving around the trunk, exposed roots, molds around the base, or wobbling or unsteadiness.</p>
                </div>
            </div>

            <!-- Item 5 -->
            <div class="warning-card">
                <div class="warning-icon-wrapper">
                    <?php echo file_get_contents( get_template_directory() . '/assets/icons/storm-damage.svg' ); ?>
                </div>
                <div class="warning-content">
                    <h3>5. Storm Damage</h3>
                    <p>Buffalo is affected by seasonal weather that can cause tree damage, such as ice buildup, heavy snow or strong winds. Trees that have split trunks, broken leaders or are severely damaged by a storm might need to be removed.</p>
                </div>
            </div>

            <!-- Item 6 -->
            <div class="warning-card">
                <div class="warning-icon-wrapper">
                    <?php echo file_get_contents( get_template_directory() . '/assets/icons/property-damage.svg' ); ?>
                </div>
                <div class="warning-content">
                    <h3>6. Tree Damage to Property</h3>
                    <p>Trees too near buildings, foundations, fences or utility areas can pose long-term problems. Roots and branches may start to cause damage to structures, requiring removal.</p>
                </div>
            </div>

            <!-- Item 7 -->
            <div class="warning-card">
                <div class="warning-icon-wrapper">
                    <?php echo file_get_contents( get_template_directory() . '/assets/icons/poor-location.svg' ); ?>
                </div>
                <div class="warning-content">
                    <h3>7. Poor Tree Location</h3>
                    <p>Occasionally, a tree is in the wrong place, even though it is healthy. If trees are planted too close to each other, interfering with construction plans, or interfering with property improvement, they may require professional removal services.</p>
                </div>
            </div>

            <!-- Item 8 -->
            <div class="warning-card">
                <div class="warning-icon-wrapper">
                    <?php echo file_get_contents( get_template_directory() . '/assets/icons/failed-repairs.svg' ); ?>
                </div>
                <div class="warning-content">
                    <h3>8. Multiple Failed Repairs</h3>
                    <p>If the tree continues to have recurring issues after pruning and treatment, removing the tree may be the most cost-effective and safest choice.</p>
                </div>
            </div>

        </div>

        <div class="warning-signs-image-cta">
            <div class="hero-buttons">
                <a href="<?php echo esc_url(site_url('/contact/')); ?>" class="btn-primary">Request an Evaluation</a>
                <a href="tel:+17164000763" class="btn-secondary">Call Us Now</a>
            </div>
        </div>
    </div>
</section>
