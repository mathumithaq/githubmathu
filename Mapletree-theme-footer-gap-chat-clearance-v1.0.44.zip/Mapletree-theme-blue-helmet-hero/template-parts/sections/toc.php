<?php
$toc_data = get_post_meta(get_queried_object_id(), 'table_of_contents', true);

if (!empty($toc_data)) {
    $toc_lines = explode("\n", $toc_data);
    $counter = 0;
    ?>
    <section class="simple-toc-section">
        <div class="toc-container">
            <div class="toc-header">
                <h2 class="toc-title">Quick View</h2>
            </div>
            
            <ul class="simple-toc-list">
                <?php
                foreach ($toc_lines as $index => $line) {
                    $line = trim($line);
                    if (empty($line)) continue;
                    
                    $counter++;
                    $parts = explode('|', $line);
                    $title = trim($parts[0]);
                    $anchor = isset($parts[1]) ? trim($parts[1]) : '';
                    
                    echo '<li class="toc-item">';
                    echo '  <span class="toc-bullet">' . $counter . '</span>';
                    if (!empty($anchor)) {
                        echo '  <a href="#' . esc_attr($anchor) . '">' . esc_html($title) . '</a>';
                    } else {
                        echo '  ' . esc_html($title);
                    }
                    echo '</li>';
                }
                ?>
            </ul>
        </div>
    </section>
    <?php
}
?>
