﻿<section class="why-choose-us-section">
    <div class="why-choose-us-container">
        <div class="why-choose-us-header">
            <span class="global-subtitle">Why Choose Us</span>
            <h2 class="why-choose-us-title">Buffalo's Trusted Tree Care Experts</h2>
            <p class="why-choose-us-key-takeaway">
                A dependable tree service combines trained arborists, proper equipment, safe work practices, insurance coverage, and local experience to protect both trees and surrounding property.
            </p>
            <p class="why-choose-us-intro">
                Homeowners choose Maple Majesty because our crews are ISA-certified, fully licensed and insured, and have spent 5+ years working specifically in Buffalo's climate and soil conditions, not a generic national playbook.
            </p>
        </div>

        <div class="why-choose-us-grid">
            <!-- Item 1 -->
            <div class="why-choose-us-item">
                <div class="why-choose-us-icon">
                    <?php echo file_get_contents(get_template_directory() . '/assets/icons/badge.svg'); ?>
                </div>
                <div class="why-choose-us-content">
                    <h3>ISA-Certified Expertise You Can Rely On</h3>
                    <p>While anyone can purchase a chainsaw and describe themselves as a tree service, few understand the biology of a tree, its root structure, or how a single bad cut can render a tree unstable for years. All our crews are led by ISA-Certified Arborists who have been trained for every job, from simple trimming to complex removals near power lines. This certificate is not a marketing certificate; it is based on real arboricultural science, not guesswork. That knowledge not only helps keep your trees alive and well, but it also keeps your property safe when it comes to diagnosis, storm damage recovery or determining if and how much canopy should be removed.</p>
                </div>
            </div>

            <!-- Item 2 -->
            <div class="why-choose-us-item">
                <div class="why-choose-us-icon">
                    <?php echo file_get_contents(get_template_directory() . '/assets/icons/map.svg'); ?>
                </div>
                <div class="why-choose-us-content">
                    <h3>Deep Local Knowledge of Buffalo's Trees and Climate</h3>
                    <p>A real tree service in Buffalo NY needs to know more than how to properly cut the tree; they need to know this area's climate. Local trees grow and fail in a variety of ways, due to lake-effect snow loads, sudden ice storms, and clay-heavy soil. For 5+ years, we have collaborated with the trees, learning exactly how they behave under local conditions, as they have been snapped or weakened by winter storms or the emerald ash borer. We also know which streets have tight overhead utility lines, and which neighborhoods have strict rules about disposing of brush. That local knowledge means quicker and more accurate evaluations than a national franchise can ever provide.</p>
                </div>
            </div>

            <!-- Item 3 -->
            <div class="why-choose-us-item">
                <div class="why-choose-us-icon">
                    <?php echo file_get_contents(get_template_directory() . '/assets/icons/shield.svg'); ?>
                </div>
                <div class="why-choose-us-content">
                    <h3>Safety, Licensing, and Insurance You Can Verify</h3>
                    <p>Tree removal and extensive pruning are among the more dangerous trades jobs carried out, and we take this seriously on every job site. All technicians adhere to rigorous safety procedures, including correct rigging practices, fall arrest, and tree felling around structures and power lines. On all projects, we are fully licensed and insured, so you never have to worry about liability in the event of an unforeseen occurrence during the work. This protection isn't just paper; it's also a sense of security for you and responsibility for us. Every safety precaution is taken before any crew's entry onto your property.</p>
                </div>
            </div>

            <!-- Item 4 -->
            <div class="why-choose-us-item">
                <div class="why-choose-us-icon">
                    <?php echo file_get_contents(get_template_directory() . '/assets/icons/estimation.svg'); ?>
                </div>
                <div class="why-choose-us-content">
                    <h3>Transparent Pricing With No Surprises</h3>
                    <p>Nobody likes hidden fees, so we don't have any. We will visit the premises with you before any work is undertaken to discuss what work is required, why it is required and present you with a clear written estimate. If a job ends up being more complex than anticipated, for instance, we find out that there is internal rot and we change the direction of the removal and immediately let them know that we are doing a different approach as opposed to padding up the final bill. We want to have a customer who will come back every day rather than stopping at one payday and it is through honesty in pricing that trust is gained. What you're quoted upfront is what you should expect to pay once the job is complete.</p>
                </div>
            </div>

            <!-- Item 5 -->
            <div class="why-choose-us-item">
                <div class="why-choose-us-icon">
                    <?php echo file_get_contents(get_template_directory() . '/assets/icons/star.svg'); ?>
                </div>
                <div class="why-choose-us-content">
                    <h3>A Reputation Built on Results, Not Advertising</h3>
                    <p>We are the best local tree service in Buffalo because we have a proven history of service. We are a five-star rated company for a reason, and we have been given this honor one project at a time from homeowners throughout Buffalo, Amherst, Cheektowaga and beyond. With the chainsaw in their hands and swinging sixty feet above your roofline, reputation is more important than a slickly produced advertisement. We've worked for more than 5 years to establish that trust, not by marketing pledges. In the end, it's about trust and that's what we expect every tree service to have, and we have it on our team.</p>
                </div>
            </div>
        </div>
    </div>
</section>
