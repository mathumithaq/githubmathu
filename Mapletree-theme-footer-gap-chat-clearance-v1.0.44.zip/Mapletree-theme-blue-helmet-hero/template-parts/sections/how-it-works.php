<section class="how-it-works-section">
    <div class="how-it-works-container container">
        
        <div class="hiw-header">
            <span class="global-subtitle">HOW IT WORKS</span>
            <h2 class="hiw-title">Our Tree Service Process</h2>
            
            <div class="hiw-takeaway">
                Professional tree service starts with an assessment and clear recommendation, followed by safe work, controlled debris removal, complete cleanup, and a final property review.
            </div>

            <p class="hiw-description">
                From the first time we receive your call to the time we complete the cleanup, this is what will happen when you hire Maple Majesty tree services.
            </p>
        </div>

        <div class="hiw-steps-grid">
            
            <!-- Step 1 -->
            <div class="hiw-step-card" data-step="01">
                <h3 class="hiw-step-title">Call or Request Online</h3>
                <p class="hiw-step-desc">
                    Tell us about your tree concern, property location, and the service you may need. Requesting an estimate takes only a few minutes.
                </p>
            </div>

            <!-- Step 2 -->
            <div class="hiw-step-card" data-step="02">
                <h3 class="hiw-step-title">Free On-Site Assessment</h3>
                <p class="hiw-step-desc">
                    An ISA-Certified Arborist assesses tree health, structural condition, root stability, access, nearby structures, and potential property risks before recommending the appropriate service.
                </p>
            </div>

            <!-- Step 3 -->
            <div class="hiw-step-card" data-step="03">
                <h3 class="hiw-step-title">Receive Your Written Quote</h3>
                <p class="hiw-step-desc">
                    Receive a detailed estimate outlining the recommended work, expected scope, pricing, and project details so you know what to expect before approving the job.
                </p>
            </div>

            <!-- Step 4 -->
            <div class="hiw-step-card" data-step="04">
                <h3 class="hiw-step-title">Safe Professional Tree Work</h3>
                <p class="hiw-step-desc">
                    Our crew completes the approved work using professional climbing, rigging, controlled sectional dismantling, and specialized equipment when appropriate for the tree and site conditions.
                </p>
            </div>

            <!-- Step 5 -->
            <div class="hiw-step-card" data-step="05">
                <h3 class="hiw-step-title">Complete Cleanup & Final Review</h3>
                <p class="hiw-step-desc">
                    Branches, wood, sawdust, and other job-related debris are cleared as agreed, followed by a final review to make sure the work area is left clean and safe.
                </p>
            </div>

        </div>
    </div>
</section>
