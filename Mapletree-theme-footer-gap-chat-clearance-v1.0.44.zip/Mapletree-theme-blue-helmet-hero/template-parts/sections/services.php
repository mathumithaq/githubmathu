<?php
/**
 * Template part for displaying the Services section
 * Grid: repeat(4, 1fr)
 * Active pages: emergency-tree, land-brush-clearing
 * Inactive (no page yet): all others — shown as Coming Soon
 */
?>
<section class="services-section" id="services">
    <div class="services-wrapper">

        <!-- Header -->
        <div class="services-header">
            <span class="global-subtitle">Our services</span>
        </div>

        <!-- Cards Grid: repeat(4, 1fr) -->
        <div class="services-grid">

            <!-- ACTIVE: Emergency Tree Service -->
            <a href="<?php echo esc_url(site_url('/emergency-tree/')); ?>" class="service-card">
                <h3 class="service-card-title">24/7 Emergency Tree Service</h3>
                <p class="service-card-desc">Disasters do not consider working hours and neither do we. No matter if a tree has fallen or is threatening your house, our emergency team works 24/7 to protect your building.</p>
                <span class="btn-primary" style="margin-top: 1rem;">VIEW</span>
            </a>

            <!-- ACTIVE: Land & Brush Clearing -->
            <a href="<?php echo esc_url(site_url('/land-brush-clearing/')); ?>" class="service-card">
                <h3 class="service-card-title">Land &amp; Brush Clearing</h3>
                <p class="service-card-desc">If you need to clear my property for construction, gardening, or maintaining anything, we can clear the area of overgrown plants, small trees, and garbage.</p>
                <span class="btn-primary" style="margin-top: 1rem;">VIEW</span>
            </a>

            <!-- ACTIVE: Tree Removal -->
            <a href="<?php echo esc_url(site_url('/tree-removal/')); ?>" class="service-card">
                <h3 class="service-card-title">Tree Removal</h3>
                <p class="service-card-desc">If the tree is dead, sick, structurally weak, or simply placed where it should not be, our specialists will remove it without causing damage to your property.</p>
                <span class="btn-primary" style="margin-top: 1rem;">VIEW</span>
            </a>

            <!-- ACTIVE: Tree Trimming -->
            <a href="<?php echo esc_url(site_url('/tree-trimming/')); ?>" class="service-card">
                <h3 class="service-card-title">Tree Trimming</h3>
                <p class="service-card-desc">Regular trimming is a must to keep trees healthy and beautiful. Trimmed trees do not interfere with buildings, power lines, or pedestrian walkways.</p>
                <span class="btn-primary" style="margin-top: 1rem;">VIEW</span>
            </a>

            <!-- ACTIVE: Tree Pruning -->
            <a href="<?php echo esc_url(site_url('/tree-pruning/')); ?>" class="service-card">
                <h3 class="service-card-title">Tree Pruning</h3>
                <p class="service-card-desc">Correct pruning leads to stronger trees that produce more flowers or fruit, and drop fewer leaves around.</p>
                <span class="btn-primary" style="margin-top: 1rem;">VIEW</span>
            </a>

            <!-- ACTIVE: Stump Grinding -->
            <a href="<?php echo esc_url(site_url('/stump-grinding/')); ?>" class="service-card">
                <h3 class="service-card-title">Stump Grinding</h3>
                <p class="service-card-desc">We can grind the tree stump under the soil surface and you will use this space for planting grass or any other purposes in the yard.</p>
                <span class="btn-primary" style="margin-top: 1rem;">VIEW</span>
            </a>

            <!-- ACTIVE: Stump Removal -->
            <a href="<?php echo esc_url(site_url('/stump-removal/')); ?>" class="service-card">
                <h3 class="service-card-title">Stump Removal</h3>
                <p class="service-card-desc">For those projects that require the complete removal of all roots, not simply stump grinding, the complete stump removal service is important to prepare the site for new development or planting.</p>
                <span class="btn-primary" style="margin-top: 1rem;">VIEW</span>
            </a>

            <!-- ACTIVE: Tree Crown Reduction -->
            <a href="<?php echo esc_url(site_url('/tree-crown-reduction/')); ?>" class="service-card">
                <h3 class="service-card-title">Tree Crown Reduction</h3>
                <p class="service-card-desc">Tree crown reduction is the process of reducing the height and spread of the tree canopy. This can prove useful in relieving stress on weak tree branches and root systems, especially in older trees and trees that have been damaged by storms.</p>
                <span class="btn-primary" style="margin-top: 1rem;">VIEW</span>
            </a>

            <!-- ACTIVE: Arborist Service -->
            <a href="<?php echo esc_url(site_url('/arborist-service/')); ?>" class="service-card">
                <h3 class="service-card-title">Arborist Service</h3>
                <p class="service-card-desc">Our ISA-Certified arborists provide tree health assessments, disease identification, and recommend long-term programs for your trees.</p>
                <span class="btn-primary" style="margin-top: 1rem;">VIEW</span>
            </a>

        </div>
    </div>
</section>
