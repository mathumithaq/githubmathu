<section class="service-areas-section" id="service-areas">
    <div class="sa-container">
        <div class="sa-header">
            <span class="global-subtitle">SERVICE AREAS</span>
            <h2 class="sa-title">Tree Services Near Me - Buffalo &amp; Western New York</h2>
        </div>

        <div class="sa-content-split">
            <!-- Left Side: Content & Locations -->
            <div class="sa-info">
                
                <p class="sa-description">
                    Local service means working with crews familiar with Buffalo and Western New York’s seasonal weather, common tree problems, and property conditions.
                </p>

                <div class="sa-takeaway-box">
                    <div class="sa-takeaway-icon">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/info-circle.svg" alt="Info Icon" width="24" height="24">
                    </div>
                    <div class="sa-takeaway-text">
                        Searching for tree service near me? Maple Majesty proudly serves Buffalo and surrounding communities with fast local response and dependable, certified tree care.
                    </div>
                </div>

                <div class="sa-locations-grid">
                    <?php 
                    $locations = [
                        'Buffalo', 'Amherst', 'Williamsville', 'Cheektowaga', 
                        'Tonawanda', 'North Tonawanda', 'West Seneca', 'Orchard Park', 
                        'Hamburg', 'Niagara Falls', 'Lockport', 'Lewiston', 
                        'Kenmore', 'East Amherst', 'Clarence', 'Depew', 
                        'East Aurora', 'Elma'
                    ];
                    
                    foreach($locations as $location) {
                        echo '<div class="sa-pill">';
                        $svg_path = get_template_directory() . '/assets/icons/map-pin.svg';
                        if (file_exists($svg_path)) {
                            echo '<span class="sa-icon">' . file_get_contents($svg_path) . '</span>';
                        }
                        echo '<span>' . esc_html($location) . '</span>';
                        echo '</div>';
                    }
                    ?>
                </div>
            </div>

            <!-- Right Side: Abstract Map Graphic -->
            <div class="sa-map-graphic">
                <div class="sa-map-wrapper">
                    <iframe title="Google Maps Service Area" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2227.4656024274473!2d-78.8484952!3d42.867302599999995!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89d313b51997ac31%3A0x4b51265ea9899a04!2sMaple%20Majesty%20Tree%20Care!5e1!3m2!1sen!2slk!4v1787172984571!5m2!1sen!2slk" class="sa-abstract-map" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="strict-origin-when-cross-origin"></iframe>
                </div>
            </div>
        </div>

    </div>
</section>
