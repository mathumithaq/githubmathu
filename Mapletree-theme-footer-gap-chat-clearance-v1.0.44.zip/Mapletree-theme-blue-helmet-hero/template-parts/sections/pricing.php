<section class="pricing-section">
    <div class="pricing-container">
        
        <div class="pricing-header-center">
            <span class="global-subtitle">PRICING PLANS</span>
            <h2 class="pricing-title">Tree Service Cost in Buffalo, NY</h2>
            <p class="pricing-description">
                Tree service costs vary based on tree size, condition, accessibility, nearby structures, equipment needs, cleanup requirements, and urgency. An on-site assessment provides the most accurate estimate.
        </div>

        <div class="pricing-takeaway">
           In Buffalo, tree removal services typically start at around $800 for smaller trees, $1,500 for intermediate-sized trees, or $2,500 for larger trees, excluding the stump grinding fee. The total price of this service varies based on several factors, including size, accessibility, and the complexity of the process. You can get the precise amount by getting an expert to assess your property.
        </div>

        <div class="pricing-cards-grid">
            
            <!-- Card 1 -->
            <div class="pricing-card">
                <h3 class="pc-title">Tree Trimming & Pruning</h3>
                <div class="pc-price">$150<span>–$1,200</span></div>
                <p class="pc-description">Professional care for residential trees of all sizes</p>
                
                <a href="<?php echo esc_url(site_url('/contact/')); ?>" class="btn-primary pc-button">Choose Plan</a>
            </div>

            <!-- Card 2 -->
            <div class="pricing-card">
                <h3 class="pc-title">Small Tree Removal</h3>
                <div class="pc-price">$200<span>–$500</span></div>
                <p class="pc-description">Trees and large shrubs under 25 feet</p>
                
                <a href="<?php echo esc_url(site_url('/contact/')); ?>" class="btn-primary pc-button">Choose Plan</a>
            </div>

            <!-- Card 3 -->
            <div class="pricing-card pricing-card-featured">
                <div class="pc-badge">Most Common</div>
                <h3 class="pc-title">Medium Tree Removal</h3>
                <div class="pc-price">$500<span>–$1,500</span></div>
                <p class="pc-description">Residential trees measuring 25–60 feet</p>
                
                <a href="<?php echo esc_url(site_url('/contact/')); ?>" class="btn-primary pc-button">Choose Plan</a>
            </div>

            <!-- Card 4 -->
            <div class="pricing-card">
                <h3 class="pc-title">Large Tree Removal</h3>
                <div class="pc-price">$1,500<span>–$3,000</span></div>
                <p class="pc-description">Mature trees measuring 60–100 feet</p>
                
                <a href="<?php echo esc_url(site_url('/contact/')); ?>" class="btn-primary pc-button">Choose Plan</a>
            </div>
            
            <!-- Card 5 -->
            <div class="pricing-card">
                <h3 class="pc-title">Complex Tree Removal</h3>
                <div class="pc-price">$3,000<span>–$5,000+</span></div>
                <p class="pc-description">Trees over 100 feet, near structures, or requiring crane assistance</p>
                
                <a href="<?php echo esc_url(site_url('/contact/')); ?>" class="btn-primary pc-button">Choose Plan</a>
            </div>

            <!-- Card 6 -->
            <div class="pricing-card">
                <h3 class="pc-title">Stump Grinding</h3>
                <div class="pc-price">$100<span>–$400</span></div>
                <p class="pc-description">Priced per stump, with discounts for bundled services</p>
                
                <a href="<?php echo esc_url(site_url('/contact/')); ?>" class="btn-primary pc-button">Choose Plan</a>
            </div>

            <!-- Card 7 -->
            <div class="pricing-card">
                <h3 class="pc-title">Emergency & Storm Tree Removal</h3>
                <div class="pc-price">An additional +20<span>-40% surcharge</span></div>
                <p class="pc-description">Same-day, after-hours, and urgent hazard response</p>
                
                <a href="<?php echo esc_url(site_url('/contact/')); ?>" class="btn-primary pc-button">Choose Plan</a>
            </div>

        </div>

    </div>
</section>
