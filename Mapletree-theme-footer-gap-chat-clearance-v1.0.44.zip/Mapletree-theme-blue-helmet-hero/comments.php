<?php
/**
 * The template for displaying comments
 */

if (post_password_required()) {
    return;
}

$commenter = wp_get_current_commenter();
$user = wp_get_current_user();
$current_user_avatar = get_avatar_url(get_current_user_id() ? get_current_user_id() : 0, ['size' => 64]);
?>

<section class="sp-comments-section" id="comments">
    <div class="container">
        <div class="sp-comments-wrap">
            <h2 class="sp-comments-title">
                <?php
                $comment_count = get_comments_number();
                if ($comment_count == 0) {
                    echo 'Discussion';
                } elseif ($comment_count == 1) {
                    echo 'Discussion (1)';
                } else {
                    echo 'Discussion (' . esc_html($comment_count) . ')';
                }
                ?>
            </h2>

            <?php if (comments_open()) : ?>
                <!-- Comment Form Box -->
                <div class="sp-comment-form-box">
                    <img src="<?php echo esc_url($current_user_avatar); ?>" alt="User" class="sp-comment-user-avatar">
                    <form action="<?php echo esc_url(site_url('/wp-comments-post.php')); ?>" method="post" id="commentform" class="sp-comment-form">
                        
                        <textarea name="comment" id="comment" placeholder="Add to the discussion..." rows="3" required></textarea>
                        
                        <?php if (!is_user_logged_in()) : ?>
                            <div class="sp-comment-guest-fields">
                                <input type="text" name="author" id="author" placeholder="Your Name *" value="<?php echo esc_attr($commenter['comment_author']); ?>" required>
                                <input type="email" name="email" id="email" placeholder="Your Email *" value="<?php echo esc_attr($commenter['comment_author_email']); ?>" required>
                            </div>
                        <?php else : ?>
                            <p class="sp-logged-in-as">Logged in as <strong><?php echo esc_html($user->display_name); ?></strong>. <a href="<?php echo esc_url(wp_logout_url(get_permalink())); ?>">Log out?</a></p>
                        <?php endif; ?>

                        <div class="sp-comment-actions">
                            <button type="submit" name="submit" id="submit" class="sp-btn-primary">Post Comment</button>
                        </div>
                        
                        <?php comment_id_fields(); ?>
                        <?php do_action('comment_form', get_the_ID()); ?>
                    </form>
                </div>
            <?php else : ?>
                <p class="sp-comments-closed">Comments are closed for this article.</p>
            <?php endif; ?>

            <!-- Comment List Thread -->
            <?php if (have_comments()) : ?>
                <div class="sp-comment-thread">
                    <?php
                    $comments = get_comments([
                        'post_id' => get_the_ID(),
                        'status'  => 'approve',
                        'order'   => 'ASC'
                    ]);

                    foreach ($comments as $comm) :
                        $comm_id = $comm->comment_ID;
                        $comm_avatar = get_avatar_url($comm, ['size' => 48]);
                        $comm_author = get_comment_author($comm_id);
                        $comm_time = human_time_diff(get_comment_time('U', true, $comm), current_time('timestamp')) . ' ago';
                    ?>
                        <div class="sp-comment-item" id="comment-<?php echo esc_attr($comm_id); ?>">
                            <img src="<?php echo esc_url($comm_avatar); ?>" alt="<?php echo esc_attr($comm_author); ?>" class="sp-comment-avatar">
                            <div class="sp-comment-content">
                                <div class="sp-comment-header">
                                    <span class="sp-comment-author"><?php echo esc_html($comm_author); ?></span>
                                    <span class="sp-comment-date"><?php echo esc_html($comm_time); ?></span>
                                </div>
                                <div class="sp-comment-text">
                                    <?php echo wpautop(esc_html($comm->comment_content)); ?>
                                </div>
                                <div class="sp-comment-footer">
                                    <button type="button" class="sp-reply-btn" onclick="document.getElementById('comment_parent').value='<?php echo esc_js($comm_id); ?>'; document.getElementById('comment').focus(); document.getElementById('comment').placeholder='Reply to <?php echo esc_js($comm_author); ?>...';">Reply</button>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

        </div>
    </div>
</section>
