<?php
/**
 * Template Name: Terms & Conditions
 * Description: Terms and Conditions page for Maple Majesty Tree Care / Redefine Landscaping Buffalo
 */

get_header(); 
$icon_path = get_template_directory() . '/assets/icons/';
?>

<main id="primary" class="site-main">

    <!-- Inner Hero Section -->
    <?php get_template_part('template-parts/sections/inner-hero'); ?>

    <!-- Terms & Conditions Section -->
    <section class="sub-service-section legal-page-section">
        <div class="container">

            <div class="legal-header">
                <span class="global-subtitle">
                    TERMS OF SERVICE
                </span>
                <h1 class="global-section-title">Terms &amp; Conditions</h1>
                <div class="section-divider"></div>
                <p class="legal-meta-date">Last Updated: <?php echo date('F d, Y'); ?></p>
            </div>

            <div class="legal-intro-card">
                <div class="legal-intro-icon">
                    <?php echo file_exists($icon_path . 'info-circle.svg') ? file_get_contents($icon_path . 'info-circle.svg') : ''; ?>
                </div>
                <div class="legal-intro-text">
                    <p>Welcome to Redefine Landscaping Buffalo / Maple Majesty Tree Care. By accessing our website, requesting estimates, or engaging our services, you agree to comply with and be bound by the following Terms and Conditions. Please review them carefully before using our website or contracting services.</p>
                </div>
            </div>

            <!-- 1. Services and Estimates -->
            <div class="legal-block">
                <h2 class="legal-block-title">
                    <span class="legal-title-icon">
                        <?php echo file_exists($icon_path . 'document.svg') ? file_get_contents($icon_path . 'document.svg') : ''; ?>
                    </span>
                    1. Services and Estimates
                </h2>
                <p>All estimates and proposals provided by Redefine Landscaping Buffalo / Maple Majesty Tree Care are subject to on-site evaluation, property access, and written agreement. Estimates remain valid for 30 days from date of issue unless specified otherwise.</p>
            </div>

            <!-- 2. SMS MESSAGING TERMS OF SERVICE (USER MANDATE) -->
            <div class="legal-block legal-sms-box">
                <div class="legal-badge-pill">
                    <span class="badge-icon">
                        <?php echo file_exists($icon_path . 'message.svg') ? file_get_contents($icon_path . 'message.svg') : ''; ?>
                    </span>
                    SMS Terms of Service
                </div>
                
                <h2 class="legal-block-title legal-sms-title">SMS Messaging Terms of Service</h2>

                <div class="legal-sub-box">
                    <h3 class="legal-sub-title">
                        <span class="sub-title-icon">
                            <?php echo file_exists($icon_path . 'info-circle.svg') ? file_get_contents($icon_path . 'info-circle.svg') : ''; ?>
                        </span>
                        Program Description
                    </h3>
                    <p class="legal-sub-desc">By providing your phone number, you agree to receive recurring messages from Redefine Landscaping Buffalo regarding service updates, project status, and promotional offers.</p>
                </div>

                <div class="legal-sub-box">
                    <h3 class="legal-sub-title">
                        <span class="sub-title-icon">
                            <?php echo file_exists($icon_path . 'clear.svg') ? file_get_contents($icon_path . 'clear.svg') : ''; ?>
                        </span>
                        Opt-Out
                    </h3>
                    <p class="legal-sub-desc">You can cancel the SMS service at any time. You can opt-out of receiving SMS messages by replying "STOP" to any message we send. After you send the SMS message "STOP" to us, we will send you an SMS message to confirm that you have been unsubscribed. After this, you will no longer receive SMS messages from us.</p>
                </div>

                <div class="legal-sub-box">
                    <h3 class="legal-sub-title">
                        <span class="sub-title-icon">
                            <?php echo file_exists($icon_path . 'phone-call.svg') ? file_get_contents($icon_path . 'phone-call.svg') : ''; ?>
                        </span>
                        Support
                    </h3>
                    <p class="legal-sub-desc">If you are experiencing issues with the messaging program you can reply with the keyword HELP for more assistance, or contact us directly at <a href="tel:+17164000763" class="legal-link">(716) 400-0763</a> or visit our contact page.</p>
                </div>

                <div class="legal-sub-box">
                    <h3 class="legal-sub-title">
                        <span class="sub-title-icon">
                            <?php echo file_exists($icon_path . 'dollar-circle.svg') ? file_get_contents($icon_path . 'dollar-circle.svg') : ''; ?>
                        </span>
                        Message &amp; Data Rates
                    </h3>
                    <p class="legal-sub-desc">As always, message and data rates may apply for any messages sent to you from us and to us from you. Message frequency varies based on your service requests and project status.</p>
                </div>

                <div class="legal-sub-box">
                    <h3 class="legal-sub-title">
                        <span class="sub-title-icon">
                            <?php echo file_exists($icon_path . 'shield.svg') ? file_get_contents($icon_path . 'shield.svg') : ''; ?>
                        </span>
                        Carrier Liability
                    </h3>
                    <p class="legal-sub-desc">Carriers are not liable for delayed or undelivered messages. Redefine Landscaping Buffalo is not liable for delayed or undelivered messages. Delivery of information and content through SMS is subject to your mobile carrier’s capability and is not guaranteed.</p>
                </div>

                <div class="legal-sub-box">
                    <h3 class="legal-sub-title">
                        <span class="sub-title-icon">
                            <?php echo file_exists($icon_path . 'cert-badge.svg') ? file_get_contents($icon_path . 'cert-badge.svg') : ''; ?>
                        </span>
                        Age Restriction
                    </h3>
                    <p class="legal-sub-desc">You must be 18 years of age or older to participate in our SMS program.</p>
                </div>
            </div>

            <!-- 3. Property Access and Responsibilities -->
            <div class="legal-block">
                <h2 class="legal-block-title">
                    <span class="legal-title-icon">
                        <?php echo file_exists($icon_path . 'property.svg') ? file_get_contents($icon_path . 'property.svg') : ''; ?>
                    </span>
                    3. Property Access and Responsibilities
                </h2>
                <p>Property owners agree to provide adequate site access for service vehicles and crew. Property owners are responsible for identifying non-public underground utilities, irrigation systems, or invisible fences before work begins.</p>
            </div>

            <!-- 4. Payment Terms -->
            <div class="legal-block">
                <h2 class="legal-block-title">
                    <span class="legal-title-icon">
                        <?php echo file_exists($icon_path . 'dollar-circle.svg') ? file_get_contents($icon_path . 'dollar-circle.svg') : ''; ?>
                    </span>
                    4. Payment Terms
                </h2>
                <p>Invoices are due upon completion of services unless prior credit arrangements have been agreed upon in writing. Late payments beyond 30 days are subject to standard late interest charges.</p>
            </div>

            <!-- 5. Contact Us Card -->
            <div class="legal-block legal-contact-card">
                <h2 class="legal-contact-title">
                    <span class="legal-title-icon white-icon">
                        <?php echo file_exists($icon_path . 'phone-call.svg') ? file_get_contents($icon_path . 'phone-call.svg') : ''; ?>
                    </span>
                    5. Contact Us
                </h2>
                <p class="legal-contact-text">If you have questions regarding these Terms &amp; Conditions or our SMS program, please contact us:</p>
                
                <div class="legal-contact-inner">
                    <p class="contact-brand-title"><strong>Redefine Landscaping Buffalo / Maple Majesty Tree Care</strong></p>
                    <p class="contact-detail-line">
                        <span class="contact-icon">
                            <?php echo file_exists($icon_path . 'map-pin.svg') ? file_get_contents($icon_path . 'map-pin.svg') : ''; ?>
                        </span>
                        <a href="https://www.google.com/maps/place/Maple+Majesty+Tree+Care/@42.8673026,-78.8484952,17z/data=!3m1!4b1!4m6!3m5!1s0x89d313b51997ac31:0x4b51265ea9899a04!8m2!3d42.8673026!4d-78.8484952!16s%2Fg%2F11wsp0b0_f" target="_blank" rel="noopener noreferrer">19 Euclid Pl, Buffalo, NY 14210, United States</a>
                    </p>
                    <p class="contact-detail-line">
                        <span class="contact-icon">
                            <?php echo file_exists($icon_path . 'phone-call.svg') ? file_get_contents($icon_path . 'phone-call.svg') : ''; ?>
                        </span>
                        <a href="tel:+17164000763">(716) 400-0763</a>
                    </p>
                </div>
            </div>

        </div>
    </section>

</main>

<?php get_footer(); ?>
