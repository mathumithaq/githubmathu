<?php
/**
 * Template Name: About Us
 * Description: The template for displaying the About Us page.
 */

get_header(); ?>

<main id="primary" class="site-main">
    
    <!-- Dynamic Inner Hero Section -->
    <?php get_template_part('template-parts/sections/inner-hero'); ?>

    <!-- Main Page Content (From WordPress Editor) -->
    <div class="container" style="padding-top: 2rem; padding-bottom: 2rem;">
        <?php
        while ( have_posts() ) :
            the_post(); ?>
            <?php the_content(); ?>
        <?php endwhile; ?>
    </div>

    <!-- About Us Page Sections -->
    <?php get_template_part('template-parts/sections/about-content'); ?>

</main>

<?php get_footer(); ?>
