<?php
/**
 * Template Name: Blog Page
 * 
 * Custom template for the Blog listing page (page-blog.php).
 *
 * @package Mapletree-theme
 */

get_header();

$icon_path = get_template_directory() . '/assets/icons/';
?>

<main id="primary" class="site-main blog-page-main">

    <!-- 1. Inner Hero Section -->
    <?php get_template_part('template-parts/sections/inner-hero'); ?>

    <!-- 2. What's New / Articles Grid (3 Cards Per Row: repeat(3, 1fr)) -->
    <section class="blog-featured-section" style="margin-top: 0; padding: 0 0 40px;">
        <div class="blog-container">
            <span class="global-subtitle">What's New on the Blog</span>
            <h2 class="global-section-title">Latest Articles & Guides</h2>
            <div class="section-divider" style="margin: 1rem 0 2rem 0; max-width: 80px;"></div>

            <!-- Categories / Topic Filter -->
            <div class="categories-grid" style="margin-bottom: 35px; justify-content: flex-start;">
                <?php
                $categories = get_categories(array(
                    'orderby' => 'name',
                    'order'   => 'ASC',
                    'hide_empty' => true,
                ));
                
                if (!empty($categories)) {
                    foreach ($categories as $category) {
                        printf('<a href="%s" class="category-pill">%s</a>',
                            esc_url(get_category_link($category->term_id)),
                            esc_html($category->name)
                        );
                    }
                }
                ?>
            </div>

            <!-- 3 Cards Per Row Grid -->
            <div class="blog-cards-grid">
                <?php
                $paged = (get_query_var('paged')) ? get_query_var('paged') : ((get_query_var('page')) ? get_query_var('page') : 1);
                $posts_per_page = 9; // 3 rows of 3 cards = 9

                $blog_args = array(
                    'post_type' => 'post',
                    'post_status' => 'publish',
                    'posts_per_page' => $posts_per_page,
                    'paged' => $paged,
                );

                $blog_query = new WP_Query($blog_args);

                if ($blog_query->have_posts()):
                    while ($blog_query->have_posts()): $blog_query->the_post();
                        $categories = get_the_category();
                        $cat_name = !empty($categories) ? esc_html($categories[0]->name) : 'Updates';
                        ?>
                        <article id="post-<?php the_ID(); ?>" <?php post_class('modern-blog-card'); ?>>
                            <div class="modern-card-image-wrap">
                                <?php if (has_post_thumbnail()): ?>
                                    <a href="<?php the_permalink(); ?>" aria-label="Read <?php echo esc_attr(get_the_title()); ?>">
                                        <?php the_post_thumbnail('medium_large'); ?>
                                        <span class="screen-reader-text">Read <?php the_title(); ?></span>
                                    </a>
                                <?php else: ?>
                                    <a href="<?php the_permalink(); ?>" class="modern-fallback-img" aria-label="Read <?php echo esc_attr(get_the_title()); ?>">
                                        <?php echo file_exists($icon_path . 'leaf.svg') ? file_get_contents($icon_path . 'leaf.svg') : '🍃'; ?>
                                        <span class="screen-reader-text">Read <?php the_title(); ?></span>
                                    </a>
                                <?php endif; ?>
                            </div>
                            <div class="modern-card-content">
                                <div class="modern-post-meta">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="calendar-icon"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
                                    <span class="meta-date"><?php echo get_the_date('F j, Y'); ?></span>
                                </div>

                                <h3 class="modern-post-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>

                                <div class="modern-post-excerpt">
                                    <?php
                                    $excerpt = wp_trim_words(get_the_excerpt(), 18, '...');
                                    echo '<p>' . $excerpt . '</p>';
                                    ?>
                                </div>

                                <a href="<?php the_permalink(); ?>" class="btn-read-article">READ ARTICLE</a>
                            </div>
                        </article>
                        <?php
                    endwhile;
                    
                    echo '<div class="modern-pagination" style="grid-column: 1 / -1;">';
                    if ($blog_query->max_num_pages > 1) {
                        echo paginate_links(array(
                            'base' => get_pagenum_link(1) . '%_%',
                            'format' => 'page/%#%/',
                            'current' => $paged,
                            'total' => $blog_query->max_num_pages,
                            'prev_text' => '&larr; Prev',
                            'next_text' => 'Next &rarr;',
                        ));
                    } else {
                        echo '<span class="current">1</span>';
                    }
                    echo '</div>';

                    wp_reset_postdata();
                else:
                    echo '<p class="glass-no-posts" style="grid-column: 1 / -1; text-align: center; color: var(--color-text-gray);">No posts found.</p>';
                endif;
                ?>
            </div>
        </div>
    </section>

    <!-- 3. CTA Section -->
    <section class="about-cta-section">
        <div class="about-container text-center">
            <h2 class="global-section-title">Have Questions? Contact Our Tree Care Team</h2>
            <p>Looking for reliable tree service near me? Contact Maple Majesty Tree Care today for expert advice, professional tree care, and a free estimate.</p>
            <p>If you're searching for dependable tree service near me, Maple Majesty Tree Care is here to help. Whether you need tree trimming, removal, emergency storm cleanup, or expert arborist advice, our experienced team is ready to provide safe and professional solutions.</p>
            <p>Contact us today to schedule your free consultation and keep your trees healthy, safe, and beautiful.</p>

            <div class="cta-buttons">
                <a href="tel:+17164000763" class="btn-primary cta-btn cta-btn-svg">
                    <?php if (file_exists(get_template_directory() . '/assets/icons/phone-call.svg')) echo file_get_contents(get_template_directory() . '/assets/icons/phone-call.svg'); ?>
                    <span>Call Now</span>
                </a>
                <a href="<?php echo esc_url(site_url('/contact/')); ?>" class="btn-secondary cta-btn cta-btn-svg">
                    <?php if (file_exists(get_template_directory() . '/assets/icons/step-quote.svg')) echo file_get_contents(get_template_directory() . '/assets/icons/step-quote.svg'); ?>
                    <span>Free Quote</span>
                </a>
            </div>
        </div>
    </section>

</main>

<?php
get_footer();
