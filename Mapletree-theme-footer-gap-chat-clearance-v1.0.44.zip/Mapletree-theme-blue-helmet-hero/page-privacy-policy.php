<?php
/**
 * Template Name: Privacy Policy
 * Description: Privacy Policy page for Maple Majesty Tree Care / Redefine Landscaping Buffalo
 */

get_header(); 
$icon_path = get_template_directory() . '/assets/icons/';
?>

<main id="primary" class="site-main">

    <!-- Inner Hero Section -->
    <?php get_template_part('template-parts/sections/inner-hero'); ?>

    <!-- Privacy Policy Section -->
    <section class="sub-service-section legal-page-section">
        <div class="container">

            <div class="legal-header">
                <span class="global-subtitle">
                    LEGAL &amp; PRIVACY
                </span>
                <h1 class="global-section-title">Privacy Policy</h1>
                <div class="section-divider"></div>
                <p class="legal-meta-date">Last Updated: <?php echo date('F d, Y'); ?></p>
            </div>

            <div class="legal-intro-card">
                <div class="legal-intro-icon">
                    <?php echo file_exists($icon_path . 'info-circle.svg') ? file_get_contents($icon_path . 'info-circle.svg') : ''; ?>
                </div>
                <div class="legal-intro-text">
                    <p>Maple Majesty Tree Care / Redefine Landscaping Buffalo ("we," "our," or "us") respects your privacy and is committed to protecting your personal information. This Privacy Policy explains how we collect, use, disclose, and safeguard your data when you visit our website or interact with our services.</p>
                </div>
            </div>

            <!-- 1. General Information Collection -->
            <div class="legal-block">
                <h2 class="legal-block-title">
                    <span class="legal-title-icon">
                        <?php echo file_exists($icon_path . 'document.svg') ? file_get_contents($icon_path . 'document.svg') : ''; ?>
                    </span>
                    1. Information We Collect
                </h2>
                <p>We collect personal information that you voluntarily provide to us when expressing an interest in obtaining information about us or our products and services, when participating in activities on the site, or otherwise contacting us.</p>
                <ul class="legal-bullet-list">
                    <li><strong>Contact Data:</strong> Name, physical address, and phone number provided through online request forms or phone calls.</li>
                    <li><strong>Service Data:</strong> Details regarding property location, tree service requests, land clearing, and project specifications.</li>
                    <li><strong>Technical Data:</strong> IP address, browser type, operating system, and website usage statistics collected automatically.</li>
                </ul>
            </div>

            <!-- 2. SMS PRIVACY NOTICE (USER MANDATE) -->
            <div class="legal-block legal-sms-box">
                <div class="legal-badge-pill">
                    <span class="badge-icon">
                        <?php echo file_exists($icon_path . 'message.svg') ? file_get_contents($icon_path . 'message.svg') : ''; ?>
                    </span>
                    SMS Privacy Notice
                </div>
                
                <h2 class="legal-block-title legal-sms-title">SMS Privacy Notice</h2>

                <div class="legal-sub-box">
                    <h3 class="legal-sub-title">
                        <span class="sub-title-icon">
                            <?php echo file_exists($icon_path . 'phone-call.svg') ? file_get_contents($icon_path . 'phone-call.svg') : ''; ?>
                        </span>
                        Collection of Information
                    </h3>
                    <p class="legal-sub-desc">We collect your mobile phone number when you opt-in to receive SMS communications from us.</p>
                </div>

                <div class="legal-sub-box">
                    <h3 class="legal-sub-title">
                        <span class="sub-title-icon">
                            <?php echo file_exists($icon_path . 'services.svg') ? file_get_contents($icon_path . 'services.svg') : ''; ?>
                        </span>
                        Use of Information
                    </h3>
                    <p class="legal-sub-desc">We use your phone number to send you service updates, appointment reminders, and marketing offers related to our landscaping services.</p>
                </div>

                <div class="legal-sub-box">
                    <h3 class="legal-sub-title">
                        <span class="sub-title-icon">
                            <?php echo file_exists($icon_path . 'shield.svg') ? file_get_contents($icon_path . 'shield.svg') : ''; ?>
                        </span>
                        Data Sharing
                    </h3>
                    <p class="legal-sub-desc"><strong>No mobile information will be shared with third parties or affiliates for marketing or promotional purposes. All the above categories exclude text messaging originator opt-in data and consent; this information will not be shared with any third parties under any circumstances.</strong> We do not share, sell, or rent your mobile phone information or SMS consent data with any third parties or affiliates for their own marketing purposes.</p>
                </div>

                <div class="legal-sub-box">
                    <h3 class="legal-sub-title">
                        <span class="sub-title-icon">
                            <?php echo file_exists($icon_path . 'check-circle.svg') ? file_get_contents($icon_path . 'check-circle.svg') : ''; ?>
                        </span>
                        Your Rights
                    </h3>
                    <p class="legal-sub-desc">You have the right to request access to or deletion of your personal data. To exercise these rights, please contact us by phone at <a href="tel:+17164000763" class="legal-link">(716) 400-0763</a> or visit our <a href="<?php echo esc_url(site_url('/contact/')); ?>" class="legal-link">Contact Us</a> page.</p>
                </div>
            </div>

            <!-- 3. How We Use Your Information -->
            <div class="legal-block">
                <h2 class="legal-block-title">
                    <span class="legal-title-icon">
                        <?php echo file_exists($icon_path . 'check-circle.svg') ? file_get_contents($icon_path . 'check-circle.svg') : ''; ?>
                    </span>
                    3. How We Use Your Information
                </h2>
                <p>We use personal information collected via our website for a variety of business purposes, including to provide services, deliver customer support, send administrative notifications, respond to inquiries, and comply with legal obligations.</p>
            </div>

            <!-- 4. Data Security -->
            <div class="legal-block">
                <h2 class="legal-block-title">
                    <span class="legal-title-icon">
                        <?php echo file_exists($icon_path . 'safety-shield.svg') ? file_get_contents($icon_path . 'safety-shield.svg') : ''; ?>
                    </span>
                    4. Security of Your Information
                </h2>
                <p>We use administrative, technical, and physical security measures to help protect your personal information. While we have taken reasonable steps to secure the personal information you provide to us, please be aware that no security measures are perfect or impenetrable.</p>
            </div>

            <!-- 5. Contact Us Card -->
            <div class="legal-block legal-contact-card">
                <h2 class="legal-contact-title">
                    <span class="legal-title-icon white-icon">
                        <?php echo file_exists($icon_path . 'phone-call.svg') ? file_get_contents($icon_path . 'phone-call.svg') : ''; ?>
                    </span>
                    5. Contact Us
                </h2>
                <p class="legal-contact-text">If you have questions or comments about this Privacy Policy or wish to request data access or deletion, please contact us:</p>
                
                <div class="legal-contact-inner">
                    <p class="contact-brand-title"><strong>Maple Majesty Tree Care / Redefine Landscaping Buffalo</strong></p>
                    <p class="contact-detail-line">
                        <span class="contact-icon">
                            <?php echo file_exists($icon_path . 'map-pin.svg') ? file_get_contents($icon_path . 'map-pin.svg') : ''; ?>
                        </span>
                        <a href="https://www.google.com/maps/place/Maple+Majesty+Tree+Care/@42.8673026,-78.8484952,17z/data=!3m1!4b1!4m6!3m5!1s0x89d313b51997ac31:0x4b51265ea9899a04!8m2!3d42.8673026!4d-78.8484952!16s%2Fg%2F11wsp0b0_f" target="_blank" rel="noopener noreferrer">19 Euclid Pl, Buffalo, NY 14210, United States</a>
                    </p>
                    <p class="contact-detail-line">
                        <span class="contact-icon">
                            <?php echo file_exists($icon_path . 'phone-call.svg') ? file_get_contents($icon_path . 'phone-call.svg') : ''; ?>
                        </span>
                        <a href="tel:+17164000763">(716) 400-0763</a>
                    </p>
                </div>
            </div>

        </div>
    </section>

</main>

<?php get_footer(); ?>
