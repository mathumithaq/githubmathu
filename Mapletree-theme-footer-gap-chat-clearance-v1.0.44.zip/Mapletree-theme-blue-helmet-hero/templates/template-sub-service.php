<?php
/**
 * Template Name: Sub Service Page
 * 
 * Template for displaying individual sub-service pages.
 */

get_header();

// Include the sub-service hero section
get_template_part('template-parts/sub-services/sub-service-hero');
?>

<main id="main" class="site-main sub-service-main">

    <?php get_template_part('template-parts/sub-services/intro-callout-box'); ?>

    <div class="container sub-service-content">
        <?php
        while (have_posts()) :
            the_post();
            the_content();
        endwhile;
        ?>
    </div>

    <?php 
    global $post;
    
    // Automatically load the custom templates for sub-services based on the page slug
    $slug = $post->post_name;
    $known_slugs = [
        'emergency-tree' => 'emergency',
        'emergency-service' => 'emergency',
        'land-brush-clearing' => 'land-clearing',
        'land-clearing' => 'land-clearing',
        'tree-removal' => 'tree-removal',
        'tree-trimming' => 'tree-trimming',
        'stump-grinding' => 'stump-grinding',
        'stump-removal' => 'stump-removal',
        'tree-pruning' => 'tree-pruning',
        'tree-crown-reduction' => 'tree-crown-reduction',
        'arborist-service' => 'arborist-service'
    ];

    if (isset($known_slugs[$slug])) {
        get_template_part('template-parts/sub-services/' . $known_slugs[$slug] . '-page-content');
    } else {
        echo '<!-- DEBUG: No matching sub-service template found for slug: ' . esc_html($slug) . ' -->';
    }
    ?>
    
    <!-- DYNAMIC FAQ SECTION -->
    <hr style="border: 0; height: 1px; background: #e0e0e0; margin: 0;">
    <?php
    $faqs_json = get_post_meta(get_the_ID(), 'faqs_json', true);
    
    // Clean up potential markdown formatting if the user accidentally pasted it
    $faqs_json = preg_replace('/^```json\s*/i', '', $faqs_json);
    $faqs_json = preg_replace('/\s*```$/', '', $faqs_json);
    $faqs_json = trim($faqs_json);
    
    $faqs = $faqs_json ? json_decode($faqs_json, true) : [];
    
    if (json_last_error() !== JSON_ERROR_NONE) {
        $faqs = json_decode(stripslashes($faqs_json), true);
    }
    
    if (!empty($faqs)) {
        get_template_part('template-parts/sub-services/faq', null, ['faqs' => $faqs]);
    } else {
        if ($faqs_json) {
            echo '<!-- FAQ JSON Parse Error: ' . json_last_error_msg() . ' -->';
        }
    }
    ?>
    <!-- END DYNAMIC FAQ SECTION -->

    <!-- FINAL CTA SECTION -->
    <?php
    $cta_json_raw = get_post_meta(get_the_ID(), 'cta_json', true);
    if (!empty($cta_json_raw)) {
        $cta_json_raw = preg_replace('/^```json\s*/i', '', $cta_json_raw);
        $cta_json_raw = preg_replace('/\s*```$/', '', $cta_json_raw);
        $cta_json_raw = trim($cta_json_raw);
        
        $cta_data = json_decode($cta_json_raw, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            $cta_data = json_decode(stripslashes($cta_json_raw), true);
        }
        
        if (is_array($cta_data) && !empty($cta_data['title'])) {
            $cta_title = $cta_data['title'];
            $cta_desc = $cta_data['description'] ?? '';
            $cta_bottom_text = $cta_data['bottom_text'] ?? '';
            
            $cta_btn1_text = $cta_data['buttons'][0]['text'] ?? '';
            $cta_btn1_url = $cta_data['buttons'][0]['url'] ?? '';
            $cta_btn2_text = $cta_data['buttons'][1]['text'] ?? '';
            $cta_btn2_url = $cta_data['buttons'][1]['url'] ?? '';
            ?>
            <section class="final-cta-section" style="background-color: var(--color-forest-green); padding: 5rem 0; text-align: center; color: white;">
                <div class="container">
                    <h2 style="color: white; font-size: 2.5rem; margin-bottom: 1.5rem; font-family: var(--font-heading); text-align: center; margin-left: auto; margin-right: auto;"><?php echo esc_html($cta_title); ?></h2>
                    <?php if (!empty($cta_desc)): ?>
                    <div style="font-size: 1.15rem; line-height: 1.6; margin-bottom: 3rem; text-align: center; margin-left: auto; margin-right: auto;">
                        <?php echo wp_kses_post($cta_desc); ?>
                    </div>
                    <?php endif; ?>
                    <div class="final-cta-buttons" style="display: flex; gap: 2rem; justify-content: center; flex-wrap: wrap;">
                        <?php if (!empty($cta_btn1_text)): ?>
                        <a href="<?php echo esc_url($cta_btn1_url); ?>" class="btn-yellow"><?php echo esc_html($cta_btn1_text); ?></a>
                        <?php endif; ?>
                        <?php if (!empty($cta_btn2_text)): ?>
                        <a href="<?php echo esc_url($cta_btn2_url); ?>" class="btn-yellow"><?php echo esc_html($cta_btn2_text); ?></a>
                        <?php endif; ?>
                    </div>
                    <?php if (!empty($cta_bottom_text)): ?>
                    <p style="margin-top: 3rem; font-size: 1.25rem; font-weight: bold; color: var(--color-warm-gold);">
                        <?php echo esc_html($cta_bottom_text); ?>
                    </p>
                    <?php endif; ?>
                </div>
            </section>
            <?php
        }
    }
    ?>
    
    <!-- END FINAL CTA SECTION -->

</main>

<?php
get_footer();
