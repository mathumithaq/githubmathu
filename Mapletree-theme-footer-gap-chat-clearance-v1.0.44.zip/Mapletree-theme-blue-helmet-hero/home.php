<?php
/**
 * The home template file (Blog listing page fallback)
 *
 * @package Mapletree-theme
 */

require_once get_template_directory() . '/page-blog.php';
