<?php
/**
 * Mapletree-theme functions and definitions
 */

function mapletree_theme_scripts()
{
    $theme_dir = get_template_directory();
    $theme_uri = get_template_directory_uri();

    $global_file  = file_exists($theme_dir . '/assets/css/global.min.css') ? '/assets/css/global.min.css' : '/assets/css/global.css';
    $section_file = file_exists($theme_dir . '/assets/css/section.min.css') ? '/assets/css/section.min.css' : '/assets/css/section.css';

    $global_ver  = file_exists($theme_dir . $global_file) ? filemtime($theme_dir . $global_file) : '1.0.0';
    $section_ver = file_exists($theme_dir . $section_file) ? filemtime($theme_dir . $section_file) : '1.0.0';
    $header_ver  = file_exists($theme_dir . '/assets/js/header.js') ? filemtime($theme_dir . '/assets/js/header.js') : '1.0.0';
    $toc_ver     = file_exists($theme_dir . '/assets/js/toc.js') ? filemtime($theme_dir . '/assets/js/toc.js') : '1.0.0';

    // Enqueue Global CSS (Critical base tokens & layout)
    wp_enqueue_style('mapletree-global-style', $theme_uri . $global_file, array(), $global_ver);
    wp_enqueue_style('mapletree-section-style', $theme_uri . $section_file, array('mapletree-global-style'), $section_ver);

    // Enqueue Header JS
    wp_enqueue_script('mapletree-header-js', $theme_uri . '/assets/js/header.js', array(), $header_ver, true);

    // Enqueue Table of Contents JS
    wp_enqueue_script('mapletree-toc-js', $theme_uri . '/assets/js/toc.js', array(), $toc_ver, true);
}
add_action('wp_enqueue_scripts', 'mapletree_theme_scripts');

// Show only the requested domain in the browser tab on every theme page.
function mapletree_browser_title($title) {
    return 'maplemajestytreecare.com';
}
add_filter('pre_get_document_title', 'mapletree_browser_title', 999);

function mapletree_async_section_styles($tag, $handle, $href, $media) {
    // The section stylesheet defines above-the-fold dimensions. Applying it
    // after the first paint shifts the hero and adjacent content on desktop.
    return $tag;
}
add_filter('style_loader_tag', 'mapletree_async_section_styles', 10, 4);

// Remove unused block subscription styles to eliminate 1,280ms duration
function mapletree_remove_unused_subscription_css($tag, $handle, $src) {
    if (is_admin()) {
        return $tag;
    }
    if (strpos($src, 'subscription') !== false || strpos($handle, 'subscription') !== false) {
        if (!is_page('subscription') && !is_page('subscribe')) {
            return '';
        }
    }
    return $tag;
}
add_filter('style_loader_tag', 'mapletree_remove_unused_subscription_css', 10, 3);

// Add defer attribute to theme scripts to eliminate render-blocking JS
function mapletree_defer_scripts($tag, $handle, $src) {
    if (is_admin()) {
        return $tag;
    }
    if (in_array($handle, ['mapletree-header-js', 'mapletree-toc-js'])) {
        return '<script src="' . esc_url($src) . '" id="' . esc_attr($handle) . '-js" defer></script>' . "\n";
    }
    return $tag;
}
add_filter('script_loader_tag', 'mapletree_defer_scripts', 10, 3);

// Enforce font-display: swap on all external/Bunny/Google fonts to eliminate 370ms font delay
function mapletree_optimize_font_loading($tag, $handle, $href) {
    if (is_admin()) {
        return $tag;
    }
    if (strpos($href, 'fonts.bunny.net') !== false || strpos($href, 'fonts.googleapis.com') !== false) {
        if (strpos($href, 'display=swap') === false) {
            $new_href = add_query_arg('display', 'swap', $href);
            return str_replace($href, esc_url($new_href), $tag);
        }
    }
    return $tag;
}
add_filter('style_loader_tag', 'mapletree_optimize_font_loading', 10, 3);

// Dequeue unused WordPress block library CSS & subscriptions on front page
function mapletree_dequeue_unused_block_css() {
    wp_dequeue_style('wp-block-jetpack-subscriptions');
    wp_dequeue_style('jetpack-subscriptions');
    wp_dequeue_style('wp-block-subscriptions');
    wp_dequeue_style('newsletter-subscription');

    if (is_front_page()) {
        wp_dequeue_style('wp-block-library');
        wp_dequeue_style('wp-block-library-theme');
        wp_dequeue_style('wc-blocks-style');
    }
}
add_action('wp_enqueue_scripts', 'mapletree_dequeue_unused_block_css', 100);

// Add theme support for basic features
function mapletree_theme_setup()
{
    add_theme_support('title-tag');
}
add_action('after_setup_theme', 'mapletree_theme_setup');


function mm_add_meta_description() {
    $description = '';

    if (is_front_page() || is_home()) {
        $front_page_id = get_option('page_on_front');
        if ($front_page_id) {
            $description = get_post_meta($front_page_id, '_meta_description', true);
            if (empty($description)) {
                $description = get_post_meta($front_page_id, 'meta_description', true);
            }
        }
        if (empty($description)) {
            $site_desc = get_bloginfo('description');
            $description = !empty($site_desc) && $site_desc !== 'Just another WordPress site'
                ? $site_desc
                : 'Maple Majesty Tree Care provides top-rated tree removal, trimming, pruning, stump grinding, and 24/7 emergency tree services in Buffalo & Western New York.';
        }
    } elseif (is_singular()) {
        $post_id = get_the_ID();
        $description = get_post_meta($post_id, '_meta_description', true);
        if (empty($description)) {
            $description = get_post_meta($post_id, 'meta_description', true);
        }
        if (empty($description) && has_excerpt($post_id)) {
            $description = get_the_excerpt($post_id);
        }
        if (empty($description)) {
            $post = get_post($post_id);
            if (!empty($post->post_content)) {
                $clean_content = wp_strip_all_tags(strip_shortcodes($post->post_content));
                $clean_content = preg_replace('/\s+/', ' ', $clean_content);
                $description = wp_trim_words($clean_content, 25, '...');
            }
        }
        if (empty($description)) {
            $description = get_the_title() . ' - Professional, safe, and reliable tree care services in Buffalo, NY by Maple Majesty Tree Care.';
        }
    } elseif (is_category() || is_tag() || is_tax()) {
        $term_desc = term_description();
        $description = !empty($term_desc)
            ? wp_strip_all_tags($term_desc)
            : 'Explore expert tree service articles and guides on ' . single_term_title('', false) . ' from Maple Majesty Tree Care.';
    } elseif (is_archive()) {
        $description = 'Browse tree care news, tips, and service updates from the certified arborists at Maple Majesty Tree Care in Buffalo, NY.';
    } else {
        // Catch-all: always output a description so PageSpeed never flags missing meta
        $description = 'Maple Majesty Tree Care provides top-rated tree removal, trimming, pruning, stump grinding, and 24/7 emergency tree services in Buffalo & Western New York.';
    }

    if (!empty($description)) {
        $description = wp_strip_all_tags($description);
        $description = trim(preg_replace('/\s+/', ' ', $description));
        if (mb_strlen($description) > 160) {
            $description = mb_substr($description, 0, 157) . '...';
        }

        // Feed the active SEO plugin when available so it owns the final tag.
        if (defined('WPSEO_VERSION')) {
            add_filter('wpseo_metadesc', static function () use ($description) {
                return $description;
            });
        } elseif (class_exists('RankMath')) {
            add_filter('rank_math/frontend/description', static function () use ($description) {
                return $description;
            });
        } elseif (defined('AIOSEO_VERSION')) {
            add_filter('aioseo_meta_description', static function () use ($description) {
                return $description;
            });
        } else {
            echo '<meta name="description" content="' . esc_attr($description) . '">' . "\n";
        }
    }
}
add_action('wp_head', 'mm_add_meta_description', 1);

// Add Favicon
function mapletree_favicon() {
    echo '<link rel="icon" type="image/webp" href="' . get_template_directory_uri() . '/assets/images/fav.webp">' . "\n";
    echo '<link rel="shortcut icon" type="image/webp" href="' . get_template_directory_uri() . '/assets/images/fav.webp">' . "\n";
    echo '<link rel="apple-touch-icon" href="' . get_template_directory_uri() . '/assets/images/fav.webp">' . "\n";
}
add_action('wp_head', 'mapletree_favicon', 1);

// Keep the legal pages published and connected to their dedicated templates.
function mapletree_create_legal_pages() {
    $pages = [
        'privacy-policy' => [
            'title' => 'Privacy Policy',
            'template' => 'page-privacy-policy.php',
        ],
        'terms-and-conditions' => [
            'title' => 'Terms & Conditions',
            'template' => 'page-terms-and-conditions.php',
        ],
    ];

    foreach ($pages as $slug => $page_data) {
        $page = get_page_by_path($slug, OBJECT, 'page');
        if ($page && $page->post_status !== 'publish') {
            wp_update_post([
                'ID' => $page->ID,
                'post_status' => 'publish',
            ]);
        } elseif (!$page) {
            $page_id = wp_insert_post([
                'post_title'     => $page_data['title'],
                'post_name'      => $slug,
                'post_status'    => 'publish',
                'post_type'      => 'page',
                'post_content'   => '',
                'comment_status' => 'closed',
            ]);
            $page = $page_id ? get_post($page_id) : null;
        }

        if ($page instanceof WP_Post) {
            update_post_meta($page->ID, '_wp_page_template', $page_data['template']);
        }
    }
}
add_action('init', 'mapletree_create_legal_pages');

function mapletree_flush_legal_page_rules() {
    if (get_option('mapletree_legal_rules_version') !== '1') {
        flush_rewrite_rules(false);
        update_option('mapletree_legal_rules_version', '1', false);
    }
}
add_action('init', 'mapletree_flush_legal_page_rules', 20);

function mapletree_register_menus() {
    register_nav_menus(array(
        'footer-main-areas' => __('Footer Main Areas', 'mapletree'),
    ));
}
add_action('init', 'mapletree_register_menus');
