<?php
/**
 * The template for displaying all single posts
 */

get_header();

// Function to generate TOC and inject IDs into headings
function mapletree_generate_toc($content) {
    preg_match_all('/<h([2-3])([^>]*)>(.*?)<\/h\1>/s', $content, $matches);
    
    if (empty($matches[0])) {
        return ['content' => $content, 'toc' => ''];
    }
    
    $toc = '<ul class="sp-toc-list">';
    $current_level = 2;
    $counter = 1;
    
    foreach ($matches[0] as $i => $full_match) {
        $level = intval($matches[1][$i]);
        $title = strip_tags($matches[3][$i]);
        $slug = sanitize_title($title) . '-' . $counter;
        
        $new_heading = '<h' . $level . $matches[2][$i] . ' id="' . $slug . '">' . $matches[3][$i] . '</h' . $level . '>';
        $content = str_replace($full_match, $new_heading, $content);
        
        $class = ($level === 3) ? 'sp-toc-h3' : 'sp-toc-h2';
        $toc .= '<li class="' . $class . '"><a href="#' . $slug . '">' . $title . '</a></li>';
        
        $counter++;
    }
    
    $toc .= '</ul>';
    
    return ['content' => $content, 'toc' => $toc];
}

while ( have_posts() ) :
    the_post();
    
    // Process content for TOC
    $raw_content = apply_filters('the_content', get_the_content());
    $processed = mapletree_generate_toc($raw_content);
    $post_content = $processed['content'];
    $toc_html = $processed['toc'];

    // Post Meta Data
    $categories = get_the_category();
    $cat_name = !empty($categories) ? esc_html($categories[0]->name) : 'Blog';
    $read_time = max(1, round(str_word_count(strip_tags($post_content)) / 200)); // Approx 200 words/min
    $updated_date = get_the_modified_date('M Y');
    $author_id = get_the_author_meta('ID');
    $author_name = get_the_author_meta('display_name');
    $author_avatar = get_avatar_url($author_id, ['size' => 64]);
    $author_bio = get_the_author_meta('description');
    if(empty($author_bio)) $author_bio = 'Tree care expert and contributor at Maple Majesty Tree Care.';
?>

<main id="primary" class="site-main sp-main">
    
    <!-- HEADER -->
    <header class="sp-header">
        <div class="container sp-header-container">
            <div class="sp-meta-top">
                <span class="sp-cat-badge"><?php echo $cat_name; ?></span>
                <span class="sp-meta-dot">&bull;</span>
                <span class="sp-read-time"><?php echo $read_time; ?> min read</span>
                <span class="sp-meta-dot">&bull;</span>
                <span class="sp-updated-date">Updated: <?php echo $updated_date; ?></span>
            </div>
            
            <h1 class="sp-title"><?php the_title(); ?></h1>
            
            <?php if (has_excerpt()) : ?>
                <p class="sp-excerpt"><?php echo get_the_excerpt(); ?></p>
            <?php endif; ?>
            
            <div class="sp-author-bar">
                <div class="sp-author-info">
                    <img src="<?php echo esc_url($author_avatar); ?>" alt="<?php echo esc_attr($author_name); ?>" class="sp-author-avatar">
                    <span class="sp-author-name">By <?php echo $author_name; ?></span>
                </div>
            </div>
        </div>
    </header>

    <!-- HERO IMAGE -->
    <?php if (has_post_thumbnail()) : ?>
    <div class="container">
        <div class="sp-hero-image">
            <?php the_post_thumbnail('full', ['class' => 'sp-feat-img']); ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- TWO COLUMN LAYOUT -->
    <div class="container sp-layout-grid">
        
        <!-- MAIN CONTENT AREA -->
        <article class="sp-article-content">
            
            <!-- Mobile TOC -->
            <?php if (!empty($toc_html)) : ?>
            <div class="sp-mobile-toc">
                <details>
                    <summary>Quick View</summary>
                    <div class="sp-mobile-toc-content">
                        <?php echo $toc_html; ?>
                    </div>
                </details>
            </div>
            <?php endif; ?>

            <div class="sp-rich-text">
                <?php echo $post_content; ?>
            </div>

            <!-- ARTICLE FOOTER -->
            <footer class="sp-article-footer">
                <div class="sp-tags">
                    <?php
                    $tags = get_the_tags();
                    if ($tags) {
                        foreach ($tags as $tag) {
                            echo '<a href="'.esc_url(get_tag_link($tag->term_id)).'" class="sp-tag-pill">#'.esc_html($tag->name).'</a>';
                        }
                    }
                    ?>
                </div>
                
                <div class="sp-feedback-bar">
                    <div class="sp-feedback-prompt">
                        <span>Was this article helpful?</span>
                        <button type="button" class="sp-feedback-btn" data-feedback="helpful">👍 Helpful</button>
                        <button type="button" class="sp-feedback-btn" data-feedback="not-helpful">👎 Not</button>
                    </div>
                    <div class="sp-share-bottom">
                        <button type="button" class="sp-share-btn" data-share-title="<?php echo esc_attr(get_the_title()); ?>">Share Article</button>
                    </div>
                </div>
            </footer>
            
        </article>

        <!-- SIDEBAR -->
        <aside class="sp-sidebar">
            <div class="sp-sticky-sidebar">
                
                <!-- Author Bio Card -->
                <div class="sp-widget sp-author-card">
                    <img src="<?php echo esc_url($author_avatar); ?>" alt="<?php echo esc_attr($author_name); ?>" class="sp-card-avatar">
                    <p class="sp-card-name"><?php echo esc_html($author_name); ?></p>
                    <p class="sp-card-bio"><?php echo esc_html($author_bio); ?></p>
                </div>

                <!-- Quick View (Desktop) -->
                <?php if (!empty($toc_html)) : ?>
                <div class="sp-widget sp-toc-widget">
                    <p class="sp-widget-title" role="heading" aria-level="2">Quick View</p>
                    <?php echo $toc_html; ?>
                </div>
                <?php endif; ?>

                <!-- Newsletter Signup -->
                <div class="sp-widget sp-newsletter-widget">
                    <p class="sp-widget-title" role="heading" aria-level="2">Get Tree Care Tips</p>
                    <p class="sp-widget-desc">Subscribe to our newsletter for seasonal tree care advice.</p>
                    <form class="sp-newsletter-form" novalidate>
                        <input type="email" placeholder="Your email address" required>
                        <button type="submit">Subscribe</button>
                        <p class="sp-newsletter-status" aria-live="polite"></p>
                    </form>
                </div>

                <!-- Trending Posts -->
                <div class="sp-widget sp-trending-widget">
                    <p class="sp-widget-title" role="heading" aria-level="2">Trending Posts</p>
                    <div class="sp-trending-list">
                        <?php
                        $trending = new WP_Query([
                            'posts_per_page' => 3,
                            'post__not_in' => [get_the_ID()],
                            'orderby' => 'comment_count'
                        ]);
                        if ($trending->have_posts()) :
                            while ($trending->have_posts()) : $trending->the_post(); ?>
                                <a href="<?php the_permalink(); ?>" class="sp-trending-item">
                                    <div class="sp-trending-img">
                                        <?php if(has_post_thumbnail()) { the_post_thumbnail('thumbnail'); } else { echo '<div class="sp-placeholder-img"></div>'; } ?>
                                    </div>
                                    <div class="sp-trending-info">
                                        <h4 class="sp-trending-title"><?php echo wp_trim_words(get_the_title(), 6, '...'); ?></h4>
                                        <span class="sp-trending-date"><?php echo get_the_date('M j, Y'); ?></span>
                                    </div>
                                </a>
                            <?php endwhile;
                            wp_reset_postdata();
                        endif;
                        ?>
                    </div>
                </div>

            </div>
        </aside>

    </div>

    <!-- RELATED ARTICLES GRID -->
    <section class="sp-related-section">
        <div class="container">
            <h2 class="sp-related-heading">Related Articles</h2>
            <div class="sp-related-grid">
                <?php
                $cat_ids = [];
                if (!empty($categories)) {
                    foreach($categories as $c) { $cat_ids[] = $c->term_id; }
                }
                $related = new WP_Query([
                    'category__in' => $cat_ids,
                    'post__not_in' => [get_the_ID()],
                    'posts_per_page' => 3
                ]);
                
                // Fallback to latest posts if not enough category posts exist
                if (!$related->have_posts()) {
                    $related = new WP_Query([
                        'post__not_in' => [get_the_ID()],
                        'posts_per_page' => 3
                    ]);
                }
                
                if ($related->have_posts()) :
                    while ($related->have_posts()) : $related->the_post(); ?>
                        <div class="sp-related-card">
                            <a href="<?php the_permalink(); ?>" class="sp-rc-img-link">
                                <?php if(has_post_thumbnail()) { the_post_thumbnail('medium', ['class' => 'sp-rc-img']); } else { echo '<div class="sp-rc-img sp-placeholder-img"></div>'; } ?>
                            </a>
                            <div class="sp-rc-body">
                                <span class="sp-rc-cat"><?php $cats = get_the_category(); echo !empty($cats) ? $cats[0]->name : 'Blog'; ?></span>
                                <h3 class="sp-rc-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                                <div class="sp-rc-meta">
                                    <span><?php echo get_the_date('M j, Y'); ?></span>
                                    <span>&bull;</span>
                                    <span><?php echo max(1, round(str_word_count(strip_tags(get_the_content())) / 200)); ?> min read</span>
                                </div>
                            </div>
                        </div>
                    <?php endwhile;
                    wp_reset_postdata();
                endif;
                ?>
            </div>
        </div>
    </section>

    <!-- COMMENTS SECTION -->
    <?php comments_template(); ?>

</main>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Feedback buttons
    const feedbackBtns = document.querySelectorAll('.sp-feedback-btn');
    const feedbackPrompt = document.querySelector('.sp-feedback-prompt');
    
    if (feedbackBtns && feedbackPrompt) {
        feedbackBtns.forEach(btn => {
            btn.addEventListener('click', function() {
                feedbackPrompt.innerHTML = '<span>Thank you for your feedback!</span>';
            });
        });
    }

    // Share button
    const shareBtn = document.querySelector('.sp-share-btn');
    if (shareBtn) {
        shareBtn.addEventListener('click', function() {
            if (navigator.share) {
                navigator.share({
                    title: document.title,
                    url: window.location.href
                }).catch(console.error);
            } else {
                navigator.clipboard.writeText(window.location.href).then(() => {
                    const originalText = shareBtn.innerText;
                    shareBtn.innerText = 'Link Copied!';
                    setTimeout(() => { shareBtn.innerText = originalText; }, 2000);
                });
            }
        });
    }
});
</script>

<?php
endwhile;

get_footer();
?>
