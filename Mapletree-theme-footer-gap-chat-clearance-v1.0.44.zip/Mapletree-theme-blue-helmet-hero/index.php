<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 *
 * @package Mapletree-theme
 */

get_header();
?>

<main id="primary" class="site-main">
    <?php
    if ( have_posts() ) :
        while ( have_posts() ) :
            the_post();
            // Include a generic content part if needed, or just the title/content
            echo '<h2>' . get_the_title() . '</h2>';
            if (is_singular()) {
                get_template_part('template-parts/sections/toc');
            }
            the_content();
        endwhile;
    else :
        echo '<p>No content found</p>';
    endif;
    ?>
</main>

<?php
get_footer();
