document.addEventListener('DOMContentLoaded', () => {
    // Mobile Sidebar Drawer & Backdrop Logic
    const toggle = document.querySelector('.menu-toggle');
    const nav = document.querySelector('#primary-menu');
    const backdrop = document.querySelector('.mobile-menu-backdrop');
    const mobileCloseBtn = document.querySelector('.mobile-close-btn');

    // Show the first page hero image through the header until it scrolls away.
    const pageHero = document.querySelector('main > .hero-section:first-child, main > .inner-hero-section:first-child, body > .inner-hero-section.sub-service-hero-section');
    const siteHeader = document.querySelector('.site-header');
    if (pageHero && siteHeader) {
        const updatePageHeader = () => {
            const heroBottom = pageHero.getBoundingClientRect().bottom;
            const pastHero = heroBottom <= siteHeader.offsetHeight;
            siteHeader.classList.toggle('past-page-hero', pastHero);
        };
        updatePageHeader();
        window.addEventListener('scroll', updatePageHeader, { passive: true });
        window.addEventListener('resize', updatePageHeader, { passive: true });
    }

    // Keep the drawer outside the sticky header, which otherwise clips and
    // overlays its scrollable items on narrow mobile screens.
    const originalHeader = nav && nav.parentNode;
    function placeMobileDrawer() {
        if (!nav || !originalHeader) return;
        if (window.innerWidth <= 768) {
            if (backdrop && backdrop.parentNode !== document.body) document.body.appendChild(backdrop);
            if (nav.parentNode !== document.body) document.body.appendChild(nav);
        } else if (nav.parentNode !== originalHeader) {
            closeMobileMenu();
            if (backdrop) originalHeader.appendChild(backdrop);
            originalHeader.appendChild(nav);
        }
    }
    placeMobileDrawer();
    window.addEventListener('resize', placeMobileDrawer, { passive: true });

    function openMobileMenu() {
        if (!nav) return;
        nav.classList.add('is-open');
        if (backdrop) backdrop.classList.add('is-open');
        document.body.classList.add('mobile-menu-open');
        if (toggle) {
            toggle.setAttribute('aria-expanded', 'true');
            const iconMenu = toggle.querySelector('.icon-menu');
            const iconClose = toggle.querySelector('.icon-close');
            if (iconMenu && iconClose) {
                iconMenu.style.display = 'none';
                iconClose.style.display = 'flex';
            }
        }
    }

    function closeMobileMenu() {
        if (!nav) return;
        nav.classList.remove('is-open');
        if (backdrop) backdrop.classList.remove('is-open');
        document.body.classList.remove('mobile-menu-open');
        if (toggle) {
            toggle.setAttribute('aria-expanded', 'false');
            const iconMenu = toggle.querySelector('.icon-menu');
            const iconClose = toggle.querySelector('.icon-close');
            if (iconMenu && iconClose) {
                iconMenu.style.display = 'flex';
                iconClose.style.display = 'none';
            }
        }
    }

    if (toggle && nav) {
        toggle.addEventListener('click', (e) => {
            e.stopPropagation();
            if (nav.classList.contains('is-open')) {
                closeMobileMenu();
            } else {
                openMobileMenu();
            }
        });
    }

    if (mobileCloseBtn) {
        mobileCloseBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            closeMobileMenu();
        });
    }

    if (backdrop) {
        backdrop.addEventListener('click', () => {
            closeMobileMenu();
        });
    }

    // Close mobile menu on ESC
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && nav && nav.classList.contains('is-open')) {
            closeMobileMenu();
        }
    });

    // Close mobile sidebar when clicking links
    if (nav) {
        const directLinks = nav.querySelectorAll('a');
        directLinks.forEach(link => {
            link.addEventListener('click', () => {
                if (window.innerWidth <= 768) {
                    closeMobileMenu();
                }
            });
        });
    }

    // Mobile Dropdown Accordion Toggle Logic (Services Sub-menu)
    // Pointer navigation away from Services should close its desktop focus state.
    const servicesDropdown = document.querySelector('.has-dropdown');
    if (servicesDropdown) {
        const servicesButton = servicesDropdown.querySelector('.dropdown-toggle-btn');
        document.querySelectorAll('.site-logo, .icon-nav > li:not(.has-dropdown)').forEach(target => {
            target.addEventListener('pointerenter', () => {
                if (window.innerWidth > 768 && servicesButton && document.activeElement === servicesButton) {
                    servicesButton.blur();
                }
            });
        });
    }
    const dropdownBtns = document.querySelectorAll('.has-dropdown > button.nav-item, .dropdown-toggle-btn');
    dropdownBtns.forEach(btn => {
        btn.addEventListener('click', (e) => {
            if (window.innerWidth <= 768) {
                e.preventDefault();
                e.stopPropagation();
                const parentLi = btn.closest('li.has-dropdown');
                if (parentLi) {
                    const isOpen = parentLi.classList.contains('is-expanded');
                    if (isOpen) {
                        parentLi.classList.remove('is-expanded');
                        btn.setAttribute('aria-expanded', 'false');
                    } else {
                        parentLi.classList.add('is-expanded');
                        btn.setAttribute('aria-expanded', 'true');
                    }
                }
            }
        });
    });

    // Active Page Indicator Logic
    const currentUrl = (window.location.href || '').split(/[?#]/)[0].replace(/\/$/, ''); // Normalize current URL
    const navItems = document.querySelectorAll('.nav-item');
    
    // Determine home URL assuming the first anchor nav item is Home
    let homeUrl = '';
    const firstLinkItem = document.querySelector('a.nav-item');
    if (firstLinkItem && firstLinkItem.href) {
        homeUrl = firstLinkItem.href.split(/[?#]/)[0].replace(/\/$/, '');
    }

    navItems.forEach(item => {
        let isActive = false;
        
        if (item.href) {
            const linkHref = item.href.split(/[?#]/)[0].replace(/\/$/, '');
            
            // Exact match
            if (currentUrl === linkHref) {
                isActive = true;
            } 
            // Match sub-pages (e.g., /blog/post-1 matches /blog), but exclude the home page from prefix matching
            else if (linkHref && linkHref !== homeUrl && currentUrl.startsWith(linkHref + '/')) {
                isActive = true;
            }
        }
        
        // Check if this nav-item has a mega-menu dropdown with a matching link
        const parentLi = item.closest('li.has-dropdown');
        if (parentLi) {
            const subLinks = parentLi.querySelectorAll('.mega-menu-list a');
            subLinks.forEach(subLink => {
                if (subLink.href) {
                    const subLinkHref = subLink.href.split(/[?#]/)[0].replace(/\/$/, '');
                    if (currentUrl === subLinkHref || (subLinkHref && subLinkHref !== homeUrl && currentUrl.startsWith(subLinkHref + '/'))) {
                        isActive = true;
                        subLink.classList.add('active-sub-link');
                    }
                }
            });
        }
        
        if (isActive) {
            const iconBtn = item.querySelector('.nav-icon-btn');
            if (iconBtn) {
                iconBtn.classList.add('active');
            }
        }
    });

    // Floating Chat Box Logic
    const chatWidget = document.getElementById('maple-chat-widget');
    const chatTriggerBtn = document.getElementById('chat-trigger-btn');
    const chatBoxWindow = document.getElementById('chat-box-window');
    const chatCloseBtn = document.getElementById('chat-close-btn');

    if (chatTriggerBtn && chatBoxWindow) {
        const iconOpen = chatTriggerBtn.querySelector('.chat-icon-open');
        const iconClose = chatTriggerBtn.querySelector('.chat-icon-close');

        function toggleChat(open) {
            const isOpen = typeof open === 'boolean' ? open : !chatBoxWindow.classList.contains('is-open');
            if (isOpen) {
                chatBoxWindow.classList.add('is-open');
                chatBoxWindow.setAttribute('aria-hidden', 'false');
                chatTriggerBtn.setAttribute('aria-expanded', 'true');
                if (iconOpen) iconOpen.style.display = 'none';
                if (iconClose) iconClose.style.display = 'flex';
            } else {
                chatBoxWindow.classList.remove('is-open');
                chatBoxWindow.setAttribute('aria-hidden', 'true');
                chatTriggerBtn.setAttribute('aria-expanded', 'false');
                if (iconOpen) iconOpen.style.display = 'flex';
                if (iconClose) iconClose.style.display = 'none';
            }
        }

        chatTriggerBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            toggleChat();
        });

        if (chatCloseBtn) {
            chatCloseBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                toggleChat(false);
            });
        }

        // Close when clicking outside
        document.addEventListener('click', (e) => {
            if (chatBoxWindow.classList.contains('is-open') && !chatWidget.contains(e.target)) {
                toggleChat(false);
            }
        });

        // Close on ESC key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && chatBoxWindow.classList.contains('is-open')) {
                toggleChat(false);
            }
        });
    }

    // Back to Top Button Logic
    const backToTopBtn = document.getElementById('back-to-top');
    if (backToTopBtn) {
        const checkScroll = () => {
            const scrollPos = window.pageYOffset || document.documentElement.scrollTop || window.scrollY || 0;
            if (scrollPos > 200) {
                backToTopBtn.classList.add('show');
            } else {
                backToTopBtn.classList.remove('show');
            }
        };

        window.addEventListener('scroll', checkScroll, { passive: true });
        window.addEventListener('DOMContentLoaded', checkScroll);
        
        backToTopBtn.addEventListener('click', (e) => {
            e.preventDefault();
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }

    // Article actions provide immediate feedback without requiring a backend.
    const feedbackButtons = document.querySelectorAll('.sp-feedback-btn');
    feedbackButtons.forEach(button => {
        button.addEventListener('click', () => {
            feedbackButtons.forEach(item => item.classList.remove('is-selected'));
            button.classList.add('is-selected');
            button.setAttribute('aria-pressed', 'true');
        });
    });

    const shareButton = document.querySelector('.sp-share-btn');
    if (shareButton) {
        shareButton.addEventListener('click', async () => {
            const shareData = {
                title: shareButton.dataset.shareTitle || document.title,
                url: window.location.href
            };

            if (navigator.share) {
                await navigator.share(shareData).catch(() => {});
                return;
            }

            try {
                await navigator.clipboard.writeText(shareData.url);
                shareButton.textContent = 'Link Copied';
                window.setTimeout(() => { shareButton.textContent = 'Share Article'; }, 2000);
            } catch (error) {
                window.prompt('Copy this article link:', shareData.url);
            }
        });
    }

    const newsletterForm = document.querySelector('.sp-newsletter-form');
    if (newsletterForm) {
        newsletterForm.addEventListener('submit', event => {
            event.preventDefault();
            const emailInput = newsletterForm.querySelector('input[type="email"]');
            const status = newsletterForm.querySelector('.sp-newsletter-status');
            if (!emailInput || !status) return;

            status.textContent = emailInput.checkValidity()
                ? 'Thanks. We will be in touch soon.'
                : 'Enter a valid email address.';
            if (emailInput.checkValidity()) newsletterForm.reset();
        });
    }
});

// Position delayed chat launchers above the mobile action bar, including shadow DOM.
(function () {
    function init() {
        var bar = document.querySelector('.mobile-sticky-bar');
        if (!bar) return;
        var queued = false;
        var roots = new WeakSet();
        var adjusted = new Map();
        function schedule() {
            if (!queued) { queued = true; requestAnimationFrame(update); }
        }
        function observe(root) {
            if (roots.has(root)) return;
            roots.add(root);
            new MutationObserver(schedule).observe(root, {childList: true, subtree: true, attributes: true, attributeFilter: ['style', 'class']});
        }
        function place(element, barHeight) {
            var box = element.getBoundingClientRect();
            var style = getComputedStyle(element);
            if (style.position !== 'fixed' || box.width <= 0 || box.height <= 0) return;
            // Only reposition small launchers or bottom-anchored chat frames.
            if (box.top < window.innerHeight / 2 || box.width > 440) return;
            var bottom = 'calc(' + (barHeight + 12) + 'px + env(safe-area-inset-bottom, 0px))';
            if (!adjusted.has(element)) adjusted.set(element, {bottom: element.style.getPropertyValue('bottom'), priority: element.style.getPropertyPriority('bottom')});
            if (element.style.getPropertyValue('bottom') !== bottom || element.style.getPropertyPriority('bottom') !== 'important') {
                element.style.setProperty('bottom', bottom, 'important');
            }
        }
        function update() {
            queued = false;
            var mobile = window.innerWidth <= 991;
            var height = mobile ? Math.ceil(bar.getBoundingClientRect().height) : 0;
            var value = height + 'px';
            if (document.body.style.getPropertyValue('--maple-mobile-bar-height') !== value) document.body.style.setProperty('--maple-mobile-bar-height', value);
            if (!mobile) {
                adjusted.forEach(function (old, element) {
                    if (old.bottom) element.style.setProperty('bottom', old.bottom, old.priority);
                    else element.style.removeProperty('bottom');
                });
                adjusted.clear();
            }
            function visit(root, insideChat) {
                observe(root);
                root.querySelectorAll('*').forEach(function (element) {
                    var identity = (element.id + ' ' + element.className + ' ' + element.localName).toLowerCase();
                    var frameSource = element.tagName === 'IFRAME' ? (element.getAttribute('src') || '') : '';
                    var chat = insideChat || /chat-widget|lc_text-widget|leadconnector-chat|chat-bubble|chat-launcher/.test(identity) || /leadconnectorhq.*chat|chat-widget/.test(frameSource);
                    if (mobile && chat) place(element, height);
                    if (element.shadowRoot) visit(element.shadowRoot, chat);
                });
            }
            visit(document, false);
        }
        if ('ResizeObserver' in window) new ResizeObserver(schedule).observe(bar);
        window.addEventListener('resize', schedule, {passive: true});
        update();
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
    else init();
})();
