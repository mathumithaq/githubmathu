document.addEventListener('DOMContentLoaded', function() {
    var schemaData = {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "Is emergency tree removal covered by insurance?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "It varies according to your homeowner's policy and the cause of damage. There can be coverage for storm-related tree damage. We can provide the required documentation for the claim."
          }
        },
        {
          "@type": "Question",
          "name": "How fast can you respond to emergency tree situations?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "We respond as quickly as possible to emergency tree situations in Buffalo, NY. Response times depend on your location, weather conditions, and the severity of the emergency."
          }
        },
        {
          "@type": "Question",
          "name": "What should I do after a tree falls on my property?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "You must keep away from the fallen tree, avoid touching nearby branches and wires, and call for an expert emergency tree service to evaluate the damage."
          }
        },
        {
          "@type": "Question",
          "name": "Can you remove a tree from my roof or driveway?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes. Our emergency tree service safely removes fallen trees from roofs, driveways, vehicles, fences, and other structures while minimizing further property damage."
          }
        },
        {
          "@type": "Question",
          "name": "Do you provide emergency tree services during storms?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes. We provide 24/7 emergency tree services during storms across Buffalo and Western New York, responding quickly to hazardous trees and storm-related property damage."
          }
        },
        {
          "@type": "Question",
          "name": "Should I remove a leaning tree immediately?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "When disturbing storms occur, a leaning tree presents a danger. It requires the skills and knowledge of an expert arborist to determine whether the tree should be cut down."
          }
        },
        {
          "@type": "Question",
          "name": "Do you clean up after emergency tree removal?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes. After emergency tree removal, we thoroughly clean the area by removing branches, logs, wood debris, and other tree waste, leaving your property safe."
          }
        }
      ]
    };
    
    var script = document.createElement('script');
    script.type = 'application/ld+json';
    script.text = JSON.stringify(schemaData);
    document.head.appendChild(script);
});
