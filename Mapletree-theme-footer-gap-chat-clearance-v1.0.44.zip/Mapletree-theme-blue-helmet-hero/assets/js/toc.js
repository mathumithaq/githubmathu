// Anchor navigation is handled by CSS so clicks do not force a layout read.
