<?php
/* Template Name: Arborist Consultation */

get_header();
?>

<section class="service-hero" 
data-bg="https://images.unsplash.com/photo-1425913397330-cf8af2ff40a1?w=1400">

    <div class="container">

        <div class="service-content">

            <span class="service-tag">Certified Tree Experts</span>

            <h1>Arborist Consultation</h1>

            <p>
                Ut enim ad minim veniam quis nostrud exercitation ullamco laboris
                nisi ut aliquip ex ea commodo consequat.
            </p>

            <a href="/contact" class="service-btn">
                Talk To Expert
            </a>

        </div>

    </div>

</section>

<?php get_footer(); ?>