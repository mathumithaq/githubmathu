<?php
/* Template Name: Stump Grinding */

get_header();
?>

<section class="service-hero" 
data-bg="https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=1400">


    <div class="container">

        <div class="service-content">

            <span class="service-tag">Complete Yard Cleanup</span>

            <h1>Stump Grinding Service</h1>

            <p>
                Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod
                tempor incididunt ut labore et dolore magna aliqua.
            </p>

            <a href="/contact" class="service-btn">
                Book Service
            </a>

        </div>

    </div>

</section>

<?php get_footer(); ?>