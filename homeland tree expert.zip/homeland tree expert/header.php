<?php
// Hide header buttons on mobile responsive
echo '<style>
    @media (max-width: 768px) {
        .main-header .trust-buttons,
        .main-header .btn-estimate,
        .main-header .btn-call {
            display: none !important;
            visibility: hidden !important;
        }
    }
</style>';
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
    <title>home land tree care</title>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">

    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

<header class="main-header">
    <div class="container">

       <!-- LOGO -->
        <div class="logo">
            <a href="<?php echo home_url(); ?>">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/images/homeland tree.png" alt="Logo">
            </a>
        </div>

        <!-- HAMBURGER -->
        <div class="hamburger" id="hamburger">
            <span></span>
            <span></span>
            <span></span>
        </div>

        <!-- NAVIGATION -->
        <nav class="navbar" id="navbar">
            <ul class="nav-menu">
                <li><a href="#hero-section">Home</a></li>
                <li>
                    <a href="#services-section">Tree Services</a>
                    
                </li>
                <li><a href="#about-section">About</a></li>
                <li><a href="#servicearea-section">Service Areas</a></li>
                <li><a href="#gallery-section">Gallery</a></li>
                <li><a href="#contact-section">Contact</a></li>
            </ul>
            
            <!-- CALL BUTTON INSIDE MOBILE MENU -->
             
            <a href="tel:+17164543636" class="header-call-btn">
                <span>Call (716) 454-3636</span>
            </a>
        </nav>

        <!-- CALL BUTTON (Desktop) -->
        <a href="tel:+17164543636" class="btn-call">
            <span>Call (716) 454-3636</span>
        </a>
    </div>
</header>

<!-- Mobile Menu Overlay -->
<div class="menu-overlay" id="menuOverlay"></div>

