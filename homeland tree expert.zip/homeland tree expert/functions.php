<?php
/**
 * functions.php
 * @package HomelandTreeService
 */

/* ══════════════════════════════════════════════
   1. ENQUEUE ALL CSS & JS FILES
══════════════════════════════════════════════ */

function mytheme_assets() {

    $theme_uri = get_template_directory_uri();
    $theme_dir = get_template_directory();
/* GLOBAL CSS */
wp_enqueue_style(
    'theme-global-style',
    $theme_uri . '/assets/css/global.css',
    array(),
    filemtime( $theme_dir . '/assets/css/global.css' ),
    'all'
);
    /* HEADER CSS */
    wp_enqueue_style(
        'theme-header-style',
        $theme_uri . '/assets/css/header.css',
        array(),
        filemtime( $theme_dir . '/assets/css/header.css' ),
        'all'
    );

    /* FOOTER CSS */
    wp_enqueue_style(
        'theme-footer-style',
        $theme_uri . '/assets/css/footer.css',
        array(),
        filemtime( $theme_dir . '/assets/css/footer.css' ),
        'all'
    );

    /* HERO CSS */
    wp_enqueue_style(
        'theme-hero-style',
        $theme_uri . '/assets/css/hero.css',
        array(),
        filemtime( $theme_dir . '/assets/css/hero.css' ),
        'all'
    );

wp_enqueue_style(
    'theme-local-trust-style',
    $theme_uri . '/assets/css/local-trust.css',
    array(),
    filemtime( $theme_dir . '/assets/css/local-trust.css' ),
    'all'
);
    /* QUICK SERVICES CSS */
    wp_enqueue_style(
        'theme-quick-services',
        $theme_uri . '/assets/css/quick-services.css',
        array(),
        filemtime( $theme_dir . '/assets/css/quick-services.css' ),
        'all'
    );
/*  WHY CHOOSE US CSS */
    wp_enqueue_style(
        'theme-why-choose-us',
        $theme_uri . '/assets/css/why-choose-us.css',
        array(),
        filemtime( $theme_dir . '/assets/css/why-choose-us.css' ),
        'all'
    );
/* TREE REMOVAL */
wp_enqueue_style(
    'theme-tree-removal',
    $theme_uri . '/assets/css/tree-removal.css',
    array(),
    filemtime( $theme_dir . '/assets/css/tree-removal.css' ),
    'all'
);
/* TREE TRIMMING */
wp_enqueue_style(
    'theme-tree-trimming',
    $theme_uri . '/assets/css/tree-trimming.css',
    array(),
    filemtime( $theme_dir . '/assets/css/tree-trimming.css' ),
    'all'
);

/* STUMP GRINDING */
wp_enqueue_style(
    'theme-stump-grinding',
    $theme_uri . '/assets/css/stump-grinding.css',
    array(),
    filemtime( $theme_dir . '/assets/css/stump-grinding.css' ),
    'all'
);

/* EMERGENCY TREE SERVICE */
wp_enqueue_style(
    'theme-emergency-tree-service',
    $theme_uri . '/assets/css/emergency-tree-service.css',
    array(),
    filemtime( $theme_dir . '/assets/css/emergency-tree-service.css' ),
    'all'
);

/* STORM DAMAGE CLEANUP */
wp_enqueue_style(
    'theme-storm-damage-cleanup',
    $theme_uri . '/assets/css/storm-damage-cleanup.css',
    array(),
    filemtime( $theme_dir . '/assets/css/storm-damage-cleanup.css' ),
    'all'
);

/* SAFE TREE REMOVAL */
wp_enqueue_style(
    'theme-safe-tree-removal',
    $theme_uri . '/assets/css/safe-tree-removal.css',
    array(),
    filemtime( $theme_dir . '/assets/css/safe-tree-removal.css' ),
    'all'
);

/* PROPERTY PROTECTION */
wp_enqueue_style(
    'theme-property-protection',
    $theme_uri . '/assets/css/property-protection.css',
    array(),
    filemtime( $theme_dir . '/assets/css/property-protection.css' ),
    'all'
);

/* EQUIPMENT & TOOLS */
wp_enqueue_style(
    'theme-equipment-tools',
    $theme_uri . '/assets/css/equipment-tools.css',
    array(),
    filemtime( $theme_dir . '/assets/css/equipment-tools.css' ),
    'all'
);

/* TREE HEALTH RISK */
wp_enqueue_style(
    'theme-tree-health-risk',
    $theme_uri . '/assets/css/tree-health-risk.css',
    array(),
    filemtime( $theme_dir . '/assets/css/tree-health-risk.css' ),
    'all'
);

/* BEFORE & AFTER */
wp_enqueue_style(
    'theme-before-after',
    $theme_uri . '/assets/css/before-after.css',
    array(),
    filemtime( $theme_dir . '/assets/css/before-after.css' ),
    'all'
);

/* REVIEWS */
wp_enqueue_style(
    'theme-reviews',
    $theme_uri . '/assets/css/reviews.css',
    array(),
    filemtime( $theme_dir . '/assets/css/reviews.css' ),
    'all'
);

/* LOCAL EXPERIENCE */
wp_enqueue_style(
    'theme-local-experience',
    $theme_uri . '/assets/css/local-experience.css',
    array(),
    filemtime( $theme_dir . '/assets/css/local-experience.css' ),
    'all'
);
wp_enqueue_style(
    'theme-contact-cta',
    $theme_uri . '/assets/css/contact-cta.css',
    array(),
    filemtime( $theme_dir . '/assets/css/contact-cta.css' ),
    'all'
);

/* CONTACT NAP */
wp_enqueue_style(
    'theme-contact-nap',
    $theme_uri . '/assets/css/contact-nap.css',
    array(),
    filemtime( $theme_dir . '/assets/css/contact-nap.css' ),
    'all'
);

/* LICENSED & INSURED */
wp_enqueue_style(
    'theme-licensed-insured',
    $theme_uri . '/assets/css/licensed-insured.css',
    array(),
    filemtime( $theme_dir . '/assets/css/licensed-insured.css' ),
    'all'
);

/* SEASONAL TREE CARE */
wp_enqueue_style(
    'theme-seasonal-tree-care',
    $theme_uri . '/assets/css/seasonal-tree-care.css',
    array(),
    filemtime( $theme_dir . '/assets/css/seasonal-tree-care.css' ),
    'all'
);

/* FINAL TRUST CLOSER */
wp_enqueue_style(
    'theme-final-trust-closer',
    $theme_uri . '/assets/css/final-trust-closer.css',
    array(),
    filemtime( $theme_dir . '/assets/css/final-trust-closer.css' ),
    'all'
);

/* SERVICE AREA */
wp_enqueue_style(
    'theme-service-area',
    $theme_uri . '/assets/css/service-area.css',
    array(),
    filemtime( $theme_dir . '/assets/css/service-area.css' ),
    'all'
);

/*INTERACTIVE MAP */
wp_enqueue_style(
    'theme-interactive-map',
    $theme_uri . '/assets/css/interactive-map.css',
    array(),
    filemtime( $theme_dir . '/assets/css/interactive-map.css' ),
    'all'
);

/* FAQ */
wp_enqueue_style(
    'theme-faq',
    $theme_uri . '/assets/css/faq.css',
    array(),
    filemtime( $theme_dir . '/assets/css/faq.css' ),
    'all'
);
    /* MAIN JS */
    wp_enqueue_script(
        'theme-main-js',
        $theme_uri . '/assets/js/main.min.js',
        array(),
        filemtime( $theme_dir . '/assets/js/main.min.js' ),
        true
    );

}
add_action( 'wp_enqueue_scripts', 'mytheme_assets' );


/* ══════════════════════════════════════════════
   2. REMOVE DEFAULT WORDPRESS FOOTER WIDGETS
══════════════════════════════════════════════ */

function mytheme_remove_widget_footer() {

    unregister_sidebar( 'footer-1' );
    unregister_sidebar( 'footer-2' );
    unregister_sidebar( 'footer-3' );
    unregister_sidebar( 'footer-4' );

}
add_action( 'widgets_init', 'mytheme_remove_widget_footer', 20 );


/* ══════════════════════════════════════════════
   3. THEME SUPPORTS
══════════════════════════════════════════════ */

function homeland_theme_setup() {

    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'custom-logo' );

    add_theme_support(
        'html5',
        array(
            'search-form',
            'comment-form',
            'comment-list',
            'gallery',
            'caption',
        )
    );

}
add_action( 'after_setup_theme', 'homeland_theme_setup' );


/* ══════════════════════════════════════════════
   4. MENUS
══════════════════════════════════════════════ */

function homeland_register_menus() {

    register_nav_menus(
        array(
            'primary-menu' => __( 'Primary Menu', 'homelandtreeservice' ),
        )
    );

}
add_action( 'after_setup_theme', 'homeland_register_menus' );


/* ══════════════════════════════════════════════
   5. SOCIAL ICONS
══════════════════════════════════════════════ */

function get_footer_social_icon( $network ) {

    $icons = array(
        'instagram' => '<svg viewBox="0 0 24 24"><path d="..."/></svg>',
        'facebook'  => '<svg viewBox="0 0 24 24"><path d="..."/></svg>',
        'twitter'   => '<svg viewBox="0 0 24 24"><path d="..."/></svg>',
        'linkedin'  => '<svg viewBox="0 0 24 24"><path d="..."/></svg>',
    );

    return $icons[$network] ?? '';
}


/* ══════════════════════════════════════════════
   6. CUSTOMIZER SOCIAL LINKS
══════════════════════════════════════════════ */

function theme_footer_customizer( $wp_customize ) {

    $wp_customize->add_section( 'footer_social_links', array(
        'title'    => __( 'Footer Social Links', 'homelandtreeservice' ),
        'priority' => 160,
    ) );

    $social_networks = array(
        'social_instagram' => 'Instagram URL',
        'social_facebook'  => 'Facebook URL',
        'social_twitter'   => 'Twitter URL',
        'social_linkedin'  => 'LinkedIn URL',
    );

    foreach ( $social_networks as $id => $label ) {

        $wp_customize->add_setting( $id, array(
            'default'           => '',
            'sanitize_callback' => 'esc_url_raw',
        ) );

        $wp_customize->add_control( $id, array(
            'label'   => __( $label, 'homelandtreeservice' ),
            'section' => 'footer_social_links',
            'type'    => 'url',
        ) );

    }

}
add_action( 'customize_register', 'theme_footer_customizer' );
function theme_enqueue_scripts() {

    wp_enqueue_style(
        'theme-style',
        get_stylesheet_uri()
    );

    wp_enqueue_script(
        'hero-slider',
        get_template_directory_uri() . '/assets/js/hero-slider.js',
        array(),
        filemtime( get_template_directory() . '/assets/js/hero-slider.js' ),
        true
    );

}
add_action('wp_enqueue_scripts', 'theme_enqueue_scripts');
// Change browser tab title
add_filter( 'pre_get_document_title', 'custom_document_title' );
function custom_document_title( $title ) {
    return 'green-okapi-830500.hostingersite.com';
}
add_action('wp_enqueue_scripts', 'enqueue_custom_scroll_script');
function enqueue_custom_scroll_script() {
    wp_enqueue_script(
        'custom-scroll',
        get_template_directory_uri() . '/assets/js/custom-scroll.js',
        array('jquery'),
        '1.0.0',
        true
    );
}
