<?php
/**
 * The template for displaying the footer
 *
 * @package HomelandTreeService
 */
?>

<footer id="site-footer" class="site-footer">

    <div class="footer-main">
        <!-- LOGO -->
        <div class="logo">
            <a href="<?php echo home_url(); ?>">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/images/homeland tree.png" alt="Logo">
            </a>
        </div>
        <div class="footer-container">

            <!-- Column 1 : Company -->
            <div class="footer-col">

                <h4 class="footer-heading">
                    Homeland Tree Service
                </h4>

                <p class="footer-text">
                    Professional Tree Removal, Tree Trimming,
                    Emergency Tree Services & Property Protection
                    with safe and reliable solutions.
                </p>

            </div>

            <!-- Column 2 : Services -->
            <div class="footer-col">

                <h4 class="footer-heading">
                    Services
                </h4>

                <ul class="footer-links">

                    <li>
                        <a href="#treeremoval-section">
                            Tree Removal
                        </a>
                    </li>

                    <li>
                        <a href="#tree-trimming">
                            Tree Trimming
                        </a>
                    </li>

                    <li>
                        <a href="#stump-grinding">
                            Stump Grinding
                        </a>
                    </li>

                    <li>
                        <a href="#emergency-tree">
                            Emergency Service
                        </a>
                    </li>

                    <li>
                        <a href="#storm-damage">
                            Storm Cleanup
                        </a>
                    </li>

                </ul>

            </div>

            <!-- Column 3 : Quick Links -->
            <div class="footer-col">

                <h4 class="footer-heading">
                    Quick Links
                </h4>

                <ul class="footer-links">

                    <li>
                        <a href="#hero-section">
                            Home
                        </a>
                    </li>

                    <li>
                        <a href="#reviews-section">Reviews</a>
                    </li>

                    <li>
                        <a href="#faq-section">Faq</a>
                    </li>
                </ul>

            </div>

            <!-- Column 4 : Contact -->
            <div class="footer-col">

                <h4 class="footer-heading">
                    Contact Info
                </h4>

                <ul class="footer-links">

                    <li>
                        <a href="tel:+17164543636">
                            (716) 454-3636
                        </a>
                    </li>

                    <li>
                        <a href="mailto:info@homelandtree.com">
                            info@homelandtree.com
                        </a>
                    </li>

                    <li>
                        <a href="https://maps.app.goo.gl/oAUNRNdMjddtNTWV7" target="_blank" rel="noopener noreferrer">
                            316 Newfield St, Buffalo, NY 14207, United States
                        </a>
                    </li>

                </ul>

            </div>
        </div>

    </div>

    <!-- Column 5 : Google Map -->
    <div class="footer-col footer-col-map">

        <div class="footer-map-wrapper">
            <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2224.0108926146077!2d-78.9027394!3d42.962954599999996!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89d36dccc00c78dd%3A0xeae47361a15a276b!2sHomeland%20Tree%20Care!5e1!3m2!1sen!2slk!4v1779307732165!5m2!1sen!2slk">
            </iframe>
        </div>
    </div>

    <!-- Footer Bottom -->

    <div class="footer-bottom">

        <div class="footer-container footer-bottom-inner">

            <p class="footer-copy">

                © <?php echo esc_html(date('Y')); ?>
                <a href="<?php echo esc_url(home_url('/')); ?>" class="footer-brand-link">
                    Homeland Tree Service.
                    All Rights Reserved.

            </p>

            <div class="footer-bottom-links">

                <a href="#privacy-policy">
                    Privacy Policy
                </a>

                <a href="#terms-conditions">
                    Terms & Conditions
                </a>

            </div>

        </div>

    </div>

</footer>

<?php wp_footer(); ?>
<button id="backToTop" aria-label="Back To Top">

    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor"
        stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">

        <path d="M12 19V5"></path>
        <path d="M5 12L12 5L19 12"></path>

    </svg>

</button>
</body>

</html>