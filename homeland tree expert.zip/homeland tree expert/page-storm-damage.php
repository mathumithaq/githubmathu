<?php
/* Template Name: Storm Damage Cleanup */

get_header();
?>

<section class="service-hero" 
data-bg="https://images.unsplash.com/photo-1527482797697-8795b05a13fe?w=1400">

    <div class="container">

        <div class="service-content">

            <span class="service-tag">Fast Cleanup Solutions</span>

            <h1>Storm Damage Cleanup</h1>

            <p>
                Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod
                tempor incididunt ut labore magna aliqua.
            </p>

            <a href="/contact" class="service-btn">
                Request Cleanup
            </a>

        </div>

    </div>

</section>

<?php get_footer(); ?>