<?php
/* Template Name: Tree Removal */
get_header();
?>

<!-- HERO SECTION -->
<section class="service-hero"
data-bg="https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=1400">

    <div class="container">

        <div class="service-content">

            <span class="service-tag">Professional Tree Care</span>

            <h1>Tree Removal Service</h1>

            <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. In eleifend elit non pulvinar congue. Nunc vitae iaculis turpis. Pellentesque risus lacus, eleifend ut commodo id, tristique in nisl.</p>
            </p>

            <a href="/contact" class="service-btn">Get Free Estimate</a>

        </div>

    </div>

</section>

<!-- INFO SECTION -->
<section class="service-info">

    <div class="container service-grid">

        <div class="service-image">
            <img src="<?php echo get_template_directory_uri(); ?>/assets/images/tree-removal.jpg" alt="">
        </div>

        <div class="service-text">

            <h2>Safe & Professional Tree Removal</h2>

            <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. In eleifend elit non pulvinar congue. Nunc vitae iaculis turpis. Pellentesque risus lacus, eleifend ut commodo id, tristique in nisl.</p>
            </p>

            <ul>
                <li>Emergency Tree Removal</li>
                <li>Hazardous Tree Removal</li>
                <li>Large Tree Cutting</li>
                <li>Residential & Commercial</li>
            </ul>

        </div>

    </div>

</section>

<!-- PROCESS SECTION -->
<section class="service-process">

    <div class="container">

        <h2>How We Work</h2>

        <div class="grid">

            <div>
                <h3>1. Inspection</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. </p>
            </div>

            <div>
                <h3>2. Planning</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. </p>
            </div>

            <div>
                <h3>3. Removal</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. </p>
            </div>

            <div>
                <h3>4. Cleanup</h3>
                <p>We clean all debris and leave your property neat.</p>
            </div>

        </div>

    </div>

</section>

<!-- WHY CHOOSE US -->
<section class="why-choose">

    <div class="container">

        <h2>Why Choose Us</h2>

        <div class="grid">

            <div>Certified Arborists</div>
            <div>24/7 Emergency Service</div>
            <div>Safe & Insured Work</div>
            <div>Affordable Pricing</div>
            <div>Fast Response</div>
            <div>Modern Equipment</div>

        </div>

    </div>

</section>

<!-- CTA SECTION -->
<section class="service-cta">

    <div class="container">

        <h2>Need Tree Removal Service?</h2>

        <p>Contact us today for a free inspection and quote.</p>

        <a href="/contact" class="service-btn">Get Free Quote</a>

    </div>

</section>

<?php get_footer(); ?>