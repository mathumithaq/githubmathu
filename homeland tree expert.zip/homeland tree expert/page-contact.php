<?php
/* Template Name: Contact Page */
get_header();
?>

<!-- ================= HERO ================= -->
<section class="contact-hero">

    <div class="container hero-grid">

        <!-- TEXT -->
        <div class="hero-text">
            <h1>Contact Us</h1>
            <p>
                We’re here to help you with professional tree care services.
                Get in touch with our expert team today.
            </p>
        </div>

        <!-- IMAGE -->
        <div class="hero-image">
            <div class="image-overlay"></div>

            <img src="https://www.lolclife.com/images/site-specific/contact/contact-S360-mobile.webp"
                 alt="Contact Tree Service">
        </div>

    </div>

</section>


<!-- ================= CONTACT SECTION ================= -->
<section class="contact-section">

    <div class="container contact-grid">

        <!-- LEFT INFO -->
        <div class="contact-info">

            <h2>Get in Touch</h2>

            <div class="info-box">
                <div class="info-icon">
                    <svg class="icon">
        <use href="<?php echo get_template_directory_uri(); ?>/assets/icons/icons.svg#icon-location"></use>
    </svg>
                </div>
                <div>
                    <h3>Location</h3>
                    <p>316 Newfield St, Buffalo, NY 14207, United States</p>
                </div>
            </div>

            <div class="info-box">
                <div class="info-icon">
                    <svg class="icon">
        <use href="<?php echo get_template_directory_uri(); ?>/assets/icons/icons.svg#icon-phone"></use>
    </svg>
                </div>
                <div>
                    <h3>Phone</h3>
                    <p>(716)4543636</p>
                </div>
            </div>

            <div class="info-box">
                <div class="info-icon">
                     <svg class="icon">
        <use href="<?php echo get_template_directory_uri(); ?>/assets/icons/icons.svg#icon-email"></use>
    </svg>
                </div>
                <div>
                    <h3>Email</h3>
                    <p>info@homelandtree.com</p>
                </div>
            </div>

            <div class="info-box">
                <div class="info-icon">
                   <svg class="icon">
        <use href="<?php echo get_template_directory_uri(); ?>/assets/icons/icons.svg#icon-clock"></use>
    </svg>
                </div>
                <div>
                    <h3>Working Hours</h3>
                    <p>Mon - Sat: 8:00 AM - 6:00 PM</p>
                </div>
            </div>

        </div>

        <!-- FORM -->
        <div class="contact-form">

            <h2>Send a Message</h2>

            <form>
                <input type="text" placeholder="Your Name" required>
                <input type="email" placeholder="Email Address" required>
                <input type="text" placeholder="Subject">
                <textarea rows="6" placeholder="Your Message"></textarea>
                <button type="submit">Send Message</button>
            </form>

        </div>

    </div>

</section>

<?php get_footer(); ?>