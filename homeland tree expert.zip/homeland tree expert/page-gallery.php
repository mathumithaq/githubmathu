<?php
/* Template Name: Gallery Page */
get_header();
?>

<!-- =========================
        HERO SECTION
========================= -->
<section class="gallery-hero">

    <div class="hero-overlay"></div>

    <div class="container hero-content">

        <h1>Our Projects</h1>

        <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean libero lacus, tristique ut faucibus vel, pellentesque et lorem. Pellentesque non sapien enim. Cras non orci luctus, posuere risus nec, scelerisque orci. Etiam pulvinar velit quis malesuada tincidunt. Nulla feugiat,
        </p>

    </div>

</section>


<!-- =========================
        GALLERY SECTION
========================= -->
<section class="gallery-section">

        <div class="section-header">

            <h2>Recent Tree Service Projects</h2>

            <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
            </p>

        </div>
    <div class="container">
        <div class="gallery-grid">

            <!-- PROJECT 1 -->
            <div class="project-card">

                <img src="https://images.unsplash.com/photo-1506744038136-46273834b3fb?q=80&w=1200&auto=format&fit=crop"
                     alt="Tree Removal Project">

                <div class="project-overlay">

                    <span class="project-badge">
                        Tree Removal
                    </span>

                    <h3>Large Hazardous Tree Removal</h3>

                    <p>Buffalo, NY</p>

                </div>

            </div>


            <!-- PROJECT 2 -->
            <div class="project-card">

                <img src="https://images.unsplash.com/photo-1441974231531-c6227db76b6e?q=80&w=1200&auto=format&fit=crop"
                     alt="Storm Cleanup">

                <div class="project-overlay">

                    <span class="project-badge">
                        Storm Cleanup
                    </span>

                    <h3>Emergency Storm Damage Cleanup</h3>

                    <p>Erie County, NY</p>

                </div>

            </div>


            <!-- PROJECT 3 -->
            <div class="project-card">

                <img src="https://images.unsplash.com/photo-1473773508845-188df298d2d1?q=80&w=1200&auto=format&fit=crop"
                     alt="Tree Trimming">

                <div class="project-overlay">

                    <span class="project-badge">
                        Tree Trimming
                    </span>

                    <h3>Residential Tree Pruning</h3>

                    <p>Amherst, NY</p>

                </div>

            </div>


            <!-- PROJECT 4 -->
            <div class="project-card">

                <img src="https://images.unsplash.com/photo-1465146344425-f00d5f5c8f07?q=80&w=1200&auto=format&fit=crop"
                     alt="Stump Grinding">

                <div class="project-overlay">

                    <span class="project-badge">
                        Stump Grinding
                    </span>

                    <h3>Complete Stump Removal</h3>

                    <p>Cheektowaga, NY</p>

                </div>

            </div>


            <!-- PROJECT 5 -->
            <div class="project-card">

                <img src="https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?q=80&w=1200&auto=format&fit=crop"
                     alt="Emergency Tree Service">

                <div class="project-overlay">

                    <span class="project-badge">
                        Emergency Service
                    </span>

                    <h3>Fallen Tree Emergency Response</h3>

                    <p>Tonawanda, NY</p>

                </div>

            </div>


            <!-- PROJECT 6 -->
            <div class="project-card">

                <img src="https://images.unsplash.com/photo-1511497584788-876760111969?q=80&w=1200&auto=format&fit=crop"
                     alt="Lot Clearing">

                <div class="project-overlay">

                    <span class="project-badge">
                        Lot Clearing
                    </span>

                    <h3>Commercial Lot Clearing Project</h3>

                    <p>Hamburg, NY</p>

                </div>

            </div>

        </div>

    </div>

</section>


<!-- =========================
        CTA SECTION
========================= -->
<section class="gallery-cta">

    <div class="container">

        <h2>Need Professional Tree Service in Buffalo?</h2>

        <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean libero lacus, tristique ut faucibus vel, pellentesque et lorem. Pellentesque
        </p>

        <div class="cta-buttons">

            <a href="tel:+17164543636" class="btn-primary">
                Call Now
            </a>

            <a href="/contact" class="btn-secondary">
                Free Estimate
            </a>

        </div>

    </div>

</section>

<?php get_footer(); ?>