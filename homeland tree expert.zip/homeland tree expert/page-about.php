<?php
/* Template Name: About Page */
get_header();
?>

<!-- ========================================
   ABOUT HERO
======================================== -->
<section class="about-hero">
<span class="about-tag">Who We Are</span>
    <div class="container">
        <h1>
            Protecting Trees.
            <span>Serving Communities.</span>
        </h1>

        <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
            eiusmod tempor incididunt ut labore et dolore magna aliqua.
            Ut enim ad minim veniam quis nostrud exercitation ullamco laboris.
        </p>

    </div>

</section>

<!-- ========================================
   INTRO + MISSION
======================================== -->
<section class="about-intro">

    <div class="container">

        <div class="about-intro-grid">

            <div class="about-intro-image">
                <img src="https://images.unsplash.com/photo-1441974231531-c6227db76b6e?q=80&w=1400&auto=format&fit=crop" alt="">
            </div>

            <div class="about-intro-content">

                <span class="section-mini">Our Mission</span>

                <h2>
                    Dedicated To Safe &
                    Reliable Tree Care
                </h2>

                <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                    sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                    Ut enim ad minim veniam quis nostrud exercitation ullamco laboris.
                </p>

                <p>
                    Duis aute irure dolor in reprehenderit in voluptate velit
                    esse cillum dolore eu fugiat nulla pariatur excepteur sint occaecat.
                </p>

                <div class="mission-points">

                    <div class="mission-box">
                        Certified Arborists
                    </div>

                    <div class="mission-box">
                        Fully Licensed
                    </div>

                    <div class="mission-box">
                        Emergency Support
                    </div>

                    <div class="mission-box">
                        Modern Equipment
                    </div>

                </div>

            </div>

        </div>

    </div>

</section>

<!-- ========================================
   JOURNEY
======================================== -->
<section class="about-journey">
 <div class="section-heading">

            <span class="section-mini">Our Journey</span>

            <h2>How Homeland Tree Service Started</h2>
    <div class="container">

       

            <p>
                Lorem ipsum dolor sit amet consectetur adipiscing elit sed do
                eiusmod tempor incididunt ut labore et dolore magna aliqua.
            </p>

        </div>

        <div class="journey-grid">

            <div class="journey-card">
                <span class="journey-year">2014</span>
                <h3>The Beginning</h3>
                <p>
                    Lorem ipsum dolor sit amet consectetur adipiscing elit
                    sed do eiusmod tempor incididunt ut labore.
                </p>
            </div>

            <div class="journey-card">
                <span class="journey-year">2018</span>
                <h3>Community Growth</h3>
                <p>
                    Ut enim ad minim veniam quis nostrud exercitation ullamco
                    laboris nisi ut aliquip ex ea commodo consequat.
                </p>
            </div>

            <div class="journey-card">
                <span class="journey-year">2022</span>
                <h3>Expanded Services</h3>
                <p>
                    Duis aute irure dolor in reprehenderit in voluptate velit
                    esse cillum dolore eu fugiat nulla pariatur.
                </p>
            </div>

        </div>

    </div>

</section>

<!-- ========================================
   CORE VALUES
======================================== -->
<section class="about-values">

        <div class="section-heading">

            <span class="section-mini">Core Values</span>

            <h2>What We Stand For</h2>

        </div>
    <div class="container">
        <div class="values-grid">

            <div class="value-card">
                <h3>Safety First</h3>
                <p>
                    Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod.
                </p>
            </div>

            <div class="value-card">
                <h3>Environmental Care</h3>
                <p>
                    Ut enim ad minim veniam quis nostrud exercitation ullamco laboris.
                </p>
            </div>

            <div class="value-card">
                <h3>Professional Quality</h3>
                <p>
                    Duis aute irure dolor in reprehenderit in voluptate velit esse.
                </p>
            </div>

            <div class="value-card">
                <h3>Community Trust</h3>
                <p>
                    Excepteur sint occaecat cupidatat non proident sunt in culpa.
                </p>
            </div>

        </div>

    </div>

</section>

<!-- ========================================
   TEAM
======================================== -->
<section class="about-team">
<div class="section-heading">

            <span class="section-mini">Meet The Team</span>

            <h2>Certified Tree Experts</h2>

        </div>
    <div class="container">
        <div class="team-grid">

            <div class="team-card">

                <img src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=1200&auto=format&fit=crop" alt="">

                <div class="team-content">

                    <h3>James Walker</h3>

                    <span>Lead Arborist</span>

                    <p>
                        Lorem ipsum dolor sit amet consectetur adipiscing elit sed do.
                    </p>

                </div>

            </div>

            <div class="team-card">

                <img src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=1200&auto=format&fit=crop" alt="">

                <div class="team-content">

                    <h3>Sarah Mitchell</h3>

                    <span>Tree Safety Specialist</span>

                    <p>
                        Ut enim ad minim veniam quis nostrud exercitation ullamco.
                    </p>

                </div>

            </div>

            <div class="team-card">

                <img src="https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?q=80&w=1200&auto=format&fit=crop" alt="">

                <div class="team-content">

                    <h3>David Carter</h3>

                    <span>Operations Manager</span>

                    <p>
                        Duis aute irure dolor in reprehenderit in voluptate velit.
                    </p>

                </div>

            </div>

        </div>

    </div>

</section>

<!-- ========================================
   SOCIAL PROOF
======================================== -->
<section class="about-proof">

    <div class="container">

        <div class="proof-grid">

            <div class="proof-card">
                <h2>500+</h2>
                <p>Projects Completed</p>
            </div>

            <div class="proof-card">
                <h2>12+</h2>
                <p>Years Experience</p>
            </div>

            <div class="proof-card">
                <h2>98%</h2>
                <p>Customer Satisfaction</p>
            </div>

            <div class="proof-card">
                <h2>24/7</h2>
                <p>Emergency Service</p>
            </div>

        </div>

    </div>

</section>

<!-- ========================================
   CTA
======================================== -->
<section class="about-cta">

    <div class="container">

        <div class="about-cta-box">

            <div class="about-cta-text">

                <h2>Need Professional Tree Service?</h2>

                <p>
                    Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor.
                </p>

            </div>

            <a href="#" class="about-btn">
                Get Free Estimate
            </a>

        </div>

    </div>

</section>

<?php get_footer(); ?>