<?php get_header(); ?>

<!-- HERO SECTION -->
<?php get_template_part('template-parts/sections/hero'); ?>

<!-- LOCAL TRUST INTRO SECTION -->
<?php get_template_part('template-parts/sections/local-trust'); ?>

<!-- QUICK SERVICES OVERVIEW GRID -->
<?php get_template_part('template-parts/sections/quick-services'); ?>

<!-- WHY HOMEOWNERS CHOOSE HOMELAND TREE CARE -->
<?php get_template_part('template-parts/sections/why-choose-us'); ?>

<!-- TREE REMOVAL SERVICE SECTION -->
<?php get_template_part('template-parts/sections/tree-removal'); ?>

<!-- TREE TRIMMING & PRUNING SECTION -->
<?php get_template_part('template-parts/sections/tree-trimming'); ?>

<!-- STUMP GRINDING SECTION -->
<?php get_template_part('template-parts/sections/stump-grinding'); ?>

<!-- EMERGENCY TREE SERVICE SECTION -->
<?php get_template_part('template-parts/sections/emergency-tree-service'); ?>

<!-- STORM DAMAGE CLEANUP SECTION -->
<?php get_template_part('template-parts/sections/storm-damage-cleanup'); ?>

<!-- SAFE TREE REMOVAL PROCESS -->
<?php get_template_part('template-parts/sections/safe-tree-removal'); ?>

<!-- PROPERTY PROTECTION SECTION -->
<?php get_template_part('template-parts/sections/property-protection'); ?>

<!-- EQUIPMENT & PROFESSIONAL TOOLS SECTION -->
<?php get_template_part('template-parts/sections/equipment-tools'); ?>

<!-- TREE HEALTH & RISK ASSESSMENT SECTION -->
<?php get_template_part('template-parts/sections/tree-health-risk'); ?>

<!-- SERVICE AREA SECTION -->
<?php get_template_part('template-parts/sections/service-area'); ?>

<!-- BEFORE & AFTER RESULTS SECTION -->
<?php get_template_part('template-parts/sections/before-after'); ?>

<!-- CUSTOMER REVIEWS / TESTIMONIALS -->
<?php get_template_part('template-parts/sections/reviews'); ?>

<!-- FAQ SECTION -->
<?php get_template_part('template-parts/sections/faq'); ?>

<!-- LOCAL EXPERIENCE SECTION -->
<?php get_template_part('template-parts/sections/local-experience'); ?>

<!-- CALL-TO-ACTION SECTION -->
<?php get_template_part('template-parts/sections/contact-cta'); ?>

<!-- CONTACT / NAP SECTION -->
<?php get_template_part('template-parts/sections/contact-nap'); ?>

<!-- GOOGLE MAP EMBED SECTION -->
<?php get_template_part('template-parts/sections/interactive-map'); ?>

<!-- LICENSED & INSURED SECTION -->
<?php get_template_part('template-parts/sections/licensed-insured'); ?>

<!-- SEASONAL TREE CARE CONTENT BLOCK -->
<?php get_template_part('template-parts/sections/seasonal-tree-care'); ?>

<!-- FINAL TRUST CLOSER -->
<?php get_template_part('template-parts/sections/final-trust-closer'); ?>

<!-- PRIVACY & TERMS SECTION -->
<?php get_template_part('template-parts/sections/privacy-terms'); ?>

<?php get_footer(); ?>