<?php
/* Template Name: Tree Trimming */

get_header();
?>

<section class="service-hero" 
data-bg="https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=1400">

    <div class="container">

        <div class="service-content">

            <span class="service-tag">Expert Tree Maintenance</span>

            <h1>Tree Trimming Service</h1>

            <p>
                Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod
                tempor incididunt ut labore magna aliqua.
            </p>

            <a href="/contact" class="service-btn">
                Schedule Service
            </a>

        </div>

    </div>

</section>

<section class="service-info">

    <div class="container service-grid">

        <div class="service-image">
            <img src="<?php echo get_template_directory_uri(); ?>/assets/images/tree-trimming.jpg" alt="">
        </div>

        <div class="service-text">

            <h2>Improve Tree Health & Appearance</h2>

            <p>
                Ut enim ad minim veniam quis nostrud exercitation ullamco laboris nisi
                ut aliquip ex ea commodo consequat.
            </p>

            <ul>
                <li>Crown Reduction</li>
                <li>Branch Pruning</li>
                <li>Seasonal Maintenance</li>
                <li>Tree Shaping</li>
            </ul>

        </div>

    </div>

</section>

<?php get_footer(); ?>