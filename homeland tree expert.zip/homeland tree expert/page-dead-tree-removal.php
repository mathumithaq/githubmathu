<?php
/* Template Name: Dead Tree Removal */

get_header();
?>

<section class="service-hero" 
data-bg="https://images.unsplash.com/photo-1425913397330-cf8af2ff40a1?w=1400">

    <div class="container">

        <div class="service-content">

            <span class="service-tag">Protect Your Property</span>

            <h1>Dead Tree Removal</h1>

            <p>
                Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod
                tempor incididunt ut labore et dolore magna aliqua.
            </p>

            <a href="/contact" class="service-btn">
                Schedule Inspection
            </a>

        </div>

    </div>

</section>

<?php get_footer(); ?>