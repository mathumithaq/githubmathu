const slides = document.querySelectorAll('.hero-slide');
const dots = document.querySelectorAll('.dot');
const prevBtn = document.querySelector('.slider-btn.prev');
const nextBtn = document.querySelector('.slider-btn.next');

let currentIndex = 0;

function showSlide(index) {
    slides.forEach((slide, i) => {
        slide.classList.toggle('active', i === index);
        if (dots[i]) dots[i].classList.toggle('active', i === index);
    });
}

function nextSlide() {
    currentIndex = (currentIndex + 1) % slides.length;
    showSlide(currentIndex);
}

function prevSlide() {
    currentIndex = (currentIndex - 1 + slides.length) % slides.length;
    showSlide(currentIndex);
}

nextBtn?.addEventListener('click', nextSlide);
prevBtn?.addEventListener('click', prevSlide);

dots.forEach((dot, i) => {
    dot.addEventListener('click', () => {
        currentIndex = i;
        showSlide(currentIndex);
    });
});

// AUTO SLIDE
setInterval(nextSlide, 6000);

const readBtn = document.querySelector(".read-more-btn");
const moreText = document.querySelector(".more-text");

if (readBtn && moreText) {
    moreText.style.display = "none";

    readBtn.addEventListener("click", function () {
        const isHidden = moreText.style.display === "none";

        moreText.style.display = isHidden ? "inline" : "none";
        this.innerText = isHidden ? "Read Less" : "Read More";
    });
}
document.querySelectorAll(".read-more-btn").forEach(btn => {
    btn.addEventListener("click", function () {

        const parent = this.closest(".hero-content");
        const moreText = parent.querySelector(".more-text");

        moreText.classList.toggle("show");

        this.innerText = moreText.classList.contains("show")
            ? "Read Less"
            : "Read More";
    });
});

// Dynamically adjust hero slide padding-bottom to perfectly fit the absolute card
function adjustHeroPadding() {
    const card = document.querySelector('.hero-card-wrapper');
    const slides = document.querySelectorAll('.hero-slide');
    if (card && slides.length > 0) {
        if (window.innerWidth <= 1024) {
            const cardHeight = card.offsetHeight;
            slides.forEach(slide => {
                // Set padding-bottom to card height + 5px gap
                slide.style.setProperty('padding-bottom', `${cardHeight + 5}px`, 'important');
            });
            card.style.setProperty('bottom', '0px', 'important');
        } else {
            // Reset on desktop
            slides.forEach(slide => {
                slide.style.removeProperty('padding-bottom');
            });
            card.style.removeProperty('bottom');
        }
    }
}

window.addEventListener('load', adjustHeroPadding);
window.addEventListener('resize', adjustHeroPadding);
// Also run immediately
adjustHeroPadding();

// Add a ResizeObserver to catch height changes due to webfonts loading late
const cardElement = document.querySelector('.hero-card-wrapper');
if (cardElement) {
    const observer = new ResizeObserver(() => {
        adjustHeroPadding();
    });
    observer.observe(cardElement);
}
