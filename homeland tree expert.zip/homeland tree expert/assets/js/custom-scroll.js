/**
 * custom-scroll.js
 * High performance IntersectionObserver for scroll entrance animations.
 */
document.addEventListener("DOMContentLoaded", function () {
    const fadeElements = document.querySelectorAll(".animate-on-scroll");

    if (!fadeElements.length) return;

    // Check if IntersectionObserver is supported
    if ("IntersectionObserver" in window) {
        const observerOptions = {
            root: null, // viewport
            rootMargin: "0px 0px -80px 0px", // Trigger slightly before element enters fully
            threshold: 0.1 // 10% of the element is visible
        };

        const observer = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add("animated");
                    observer.unobserve(entry.target); // Trigger only once
                }
            });
        }, observerOptions);

        fadeElements.forEach(el => {
            observer.observe(el);
        });
    } else {
        // Fallback for older browsers
        fadeElements.forEach(el => {
            el.classList.add("animated");
        });
    }
});
