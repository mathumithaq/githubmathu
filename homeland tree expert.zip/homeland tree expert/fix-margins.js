const fs = require('fs');
const path = require('path');

const sectionsDir = path.join(__dirname, 'template-parts', 'sections');

if (fs.existsSync(sectionsDir)) {
    const files = fs.readdirSync(sectionsDir);
    files.forEach(file => {
        if (file.endsWith('.php')) {
            const filePath = path.join(sectionsDir, file);
            let content = fs.readFileSync(filePath, 'utf8');
            // Fix unclosed span in section-tag
            const newContent = content.replace(/<div class="section-tag"><span>(.*?)<span><\/div>/g, '<div class="section-tag"><span>$1</span></div>');
            if (content !== newContent) {
                fs.writeFileSync(filePath, newContent, 'utf8');
                console.log(`Fixed span in ${file}`);
            }
        }
    });
}

const globalCssPath = path.join(__dirname, 'assets', 'css', 'global.css');
if (fs.existsSync(globalCssPath)) {
    let css = fs.readFileSync(globalCssPath, 'utf8');
    
    // We want to replace the .container definition that has flex
    // Let's find it.
    const containerRegex = /\.container\s*\{\s*width:\s*100%\s*!important;\s*max-width:\s*1200px\s*!important;\s*margin-left:\s*auto\s*!important;\s*margin-right:\s*auto\s*!important;\s*padding-left:\s*40px\s*!important;\s*padding-right:\s*40px\s*!important;\s*display:\s*flex;\s*justify-content:\s*space-between;\s*align-items:\s*center;\s*\}/;
    
    const newContainerDef = `.container {
    width: 100% !important;
    max-width: 1200px !important;
    margin-left: auto !important;
    margin-right: auto !important;
    padding-left: 40px !important;
    padding-right: 40px !important;
}`;

    const newCss = css.replace(containerRegex, newContainerDef);
    if (css !== newCss) {
        fs.writeFileSync(globalCssPath, newCss, 'utf8');
        console.log('Fixed .container in global.css');
    } else {
        console.log('Could not find exact .container definition to replace.');
    }
}
