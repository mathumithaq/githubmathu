<?php
/* Template Name: Emergency Tree Service */

get_header();
?>

<section class="service-hero" 
data-bg="https://images.unsplash.com/photo-1504701954957-2010ec3bcec1?w=1400">


    <div class="container">

        <div class="service-content">

            <span class="service-tag">24/7 Emergency Support</span>

            <h1>Emergency Tree Service</h1>

            <p>
                Excepteur sint occaecat cupidatat non proident sunt in culpa
                qui officia deserunt mollit anim id est laborum.
            </p>

            <a href="/contact" class="service-btn">
                Call Now
            </a>

        </div>

    </div>

</section>

<?php get_footer(); ?>