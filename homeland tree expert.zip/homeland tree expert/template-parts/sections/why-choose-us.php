<section id="about-section" class="why-choose-us">
 <div class="section-tag"><span>ABOUT US</span></div>
    <!-- Header -->
    <div class="section-title">
        <h2 id="dynamic-heading">Reliable Service with Attention to Detail</h2>
        <p>
Many property owners search for a tree company that not only removes trees safely, but also respects their home and outdoor space during the process. Homeland Tree Care approaches every project with careful planning, organized job site management, and professional attention to detail from start to finish.
Our crew arrives prepared with the equipment, safety gear, rigging systems, and removal strategy needed for each unique project. Before work begins, we inspect surrounding structures, landscaping, fences, utility lines, driveways, and property access points to help reduce unnecessary disruption during the job.
We also understand that communication is an important part of professional service. Customers want realistic timelines, honest recommendations, and responsive scheduling. That is why we focus on keeping property owners informed throughout every stage of the project.

        </p>
         <!-- CTA BUTTONS -->
      <div class="trust-buttons">

        <a href="#contact-section" class="btn-estimate">
          Request Free Estimate
        </a>

        <a href="tel:+17164543636" class="btn-call">
          Call (716) 454-3636
        </a>

      </div>

        <h3>What Sets Homeland Tree Care Apart</h3>
    </div>

    <div class="container">

        <!-- Features Grid -->
        <div class="features">

            <div class="feature-box">
                <h3>Licensed & Insured Professionals</h3>
                <p>Property owners should feel confident knowing the company working on their home follows professional standards and safety practices. Homeland Tree Care operates with a strong focus on responsible work procedures and customer protection.
</p>
            </div>

            <div class="feature-box">
                <h3>Experienced Local Tree Crews</h3>
                <p>Our team understands Buffalo’s mature tree species, seasonal weather conditions, and neighborhood property layouts. Local experience allows us to work more efficiently in difficult residential environments.
</p>
            </div>

            <div class="feature-box">
                <h3>Detailed Cleanup After Every Job</h3>
                <p>A tree service project should not leave your property covered in debris. We remove branches, logs, wood chips, and leftover materials while keeping work areas organized throughout the project.
</p>
            </div>

            <div class="feature-box">
                <h3>Fast Scheduling & Responsive Communication</h3>
                <p>We understand that hazardous tree situations often require quick attention. Our team works hard to provide responsive scheduling and dependable communication for every customer.
</p>
            </div>

            <div class="feature-box">
                <h3>Property Protection Systems</h3>
                <p>Tree removals often take place near homes, fences, patios, and landscaping. We use controlled rigging systems, precision lowering techniques, and careful planning to help protect surrounding property.</p>
            </div>

            <div class="feature-box">
                <h3>Professional-Grade Equipment</h3>
                <p>Using the right equipment improves both safety and efficiency. Homeland Tree Care invests in professional tools, climbing gear, stump grinders, rigging systems, and specialized removal equipment.</p>
            </div>

            
            <div class="feature-box full-width">
                  <p>Our goal is to help homeowners feel confident throughout the process while delivering professional tree care solutions designed for long-term property safety and curb appeal improvement.
</p>
<p>We believe honest communication and reliable service are essential parts of every successful tree care project. That is why we provide clear recommendations, transparent estimates, and straightforward solutions based on your property’s specific needs.
</p>
                <h3>Additional Reasons Customers Choose Homeland Tree Care</h3>
                <ul class="feature-list">
        <li class="feature-item">
            <span class="tick-icon">
                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M20 6L9 17L4 12" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </span>
            <span>Careful project planning before work begins</span>
        </li>
        <li class="feature-item">
            <span class="tick-icon">
                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M20 6L9 17L4 12" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </span>
            <span>Organized and professional job sites</span>
        </li>
        <li class="feature-item">
            <span class="tick-icon">
                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M20 6L9 17L4 12" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </span>
            <span>Respectful local crews</span>
        </li>
        <li class="feature-item">
            <span class="tick-icon">
                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M20 6L9 17L4 12" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </span>
            <span>Efficient debris and branch cleanup</span>
        </li>
        <li class="feature-item">
            <span class="tick-icon">
                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M20 6L9 17L4 12" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </span>
            <span>Safe climbing and rigging procedures</span>
        </li>
        <li class="feature-item">
            <span class="tick-icon">
                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M20 6L9 17L4 12" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </span>
            <span>Detailed tree condition assessments</span>
        </li>
        <li class="feature-item">
            <span class="tick-icon">
                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M20 6L9 17L4 12" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </span>
            <span>Modern equipment and removal tools</span>
        </li>
        <li class="feature-item">
            <span class="tick-icon">
                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M20 6L9 17L4 12" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </span>
            <span>Emergency response availability</span>
        </li>
        <li class="feature-item">
            <span class="tick-icon">
                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M20 6L9 17L4 12" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </span>
            <span>Residential and commercial experience</span>
        </li>
        <li class="feature-item">
            <span class="tick-icon">
                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M20 6L9 17L4 12" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </span>
            <span>Property-focused safety practices</span>
        </li>
    </ul>

                
            </div>
           
        </div>

    </div>
  
</section>