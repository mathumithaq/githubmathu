<section class="licensed-section">
    <div class="section-tag"><span>LICENSED & INSURED</span></div>

     <div class="section-title">
          
            <h2 id="dynamic-heading">
               Licensed & Insured Tree Professionals

            </h2>

            <p>
                Hiring a licensed and insured tree company helps protect homeowners, properties, and workers during tree service projects.
Homeland Tree Care follows professional safety standards and uses proper equipment designed for safe tree removal, trimming, and storm cleanup operations.
Our crew focuses on safe procedures, controlled removals, and responsible job site management throughout every project.
            </p>

<!-- CTA BUTTONS -->
      <div class="trust-buttons">

        <a href="#contact-section" class="btn-estimate">
          Request Free Estimate
        </a>

        <a href="tel:+17164543636" class="btn-call">
          Call (716) 454-3636
        </a>

      </div>
</div>
    <div class="container">

      <!-- LEFT IMAGE -->
        <div class="licensed-image">
            <img src="https://www.vintagetreecare.com/wp-content/uploads/2019/08/treecareprofessional.jpg" alt="licensed insured">
        </div>
        <!-- RIGHT FEATURES -->
        
        <div class="licensed-features">
 <h3>Why Insurance Matters</h3>
            <div class="license-item">
                <div class="license-number">01</div>

                <div class="license-text">
                    
                    <p>
                        Helps protect against accidental property damage

                    </p>
                </div>
            </div>

            <div class="license-item">
                <div class="license-number">02</div>

                <div class="license-text">
                  
                    <p>
                        Supports worker safety during elevated tree work

                    </p>
                </div>
            </div>

            <div class="license-item">
                <div class="license-number">03</div>

                <div class="license-text">
                    
                    <p>
                        Provides added peace of mind for homeowners

                    </p>
                </div>
            </div>

            <div class="license-item">
                <div class="license-number">04</div>

                <div class="license-text">
                   
                    <p>
                        Demonstrates professional operational standards

                    </p>
                </div>
            </div>

        </div>
</p>

    </div>

</section>