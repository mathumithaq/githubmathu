<section class="cta-section-split">
  <div class="cta-left">
    <div class="cta-left-inner">
      <div class="section-tag"><span>GET IN TOUCH</span></div>
      
      <h2 class="section-title">Need Safe Reliable Tree Service in Buffalo?</h2>
      
      <p>
        Whether you need emergency tree removal, seasonal trimming, stump grinding, or storm cleanup,
        Homeland Tree Care is ready to help. Contact our local team today to schedule professional
        tree services in Buffalo and surrounding Erie County communities.
      </p>
      
      <h3 >We provide</h3>
      
      <div class="cta-features-grid">
        <div class="cta-list-item">
          <div class="cta-list-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg></div>
          <span>Free Estimates</span>
        </div>
        <div class="cta-list-item">
          <div class="cta-list-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg></div>
          <span>Responsive Scheduling</span>
        </div>
        <div class="cta-list-item">
           <div class="cta-list-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg></div>
          <span>Emergency Service Availability</span>
        </div>
        <div class="cta-list-item">
           <div class="cta-list-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg></div>
          <span>Residential &amp; Commercial Tree Care</span>
        </div>
        <div class="cta-list-item">
           <div class="cta-list-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg></div>
          <span>Safe Removal Methods</span>
        </div>
        <div class="cta-list-item">
           <div class="cta-list-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg></div>
          <span>Property-First Approach</span>
        </div>
      </div>
       <!-- CTA BUTTONS -->
      <div class="trust-buttons">

        <a href="#contact-section" class="btn-estimate">
          Request Free Estimate
        </a>

        <a href="tel:+17164543636" class="btn-call">
          Call (716) 454-3636
        </a>

      </div>

    </div>
  </div>
  
  <div class="cta-right">
      <div class="cta-right-overlay"></div>
  </div>
</section>