<section class="tree-health-section">
  <div class="section-tag"><span>HEALTH & RISK ASSESSMENT</span></div>
    <div class="section-title">
      
      <h2 id="dynamic-heading">Professional tree health & risk assessment</h2>
      <p>
        Identifying tree problems early can help prevent costly property damage and dangerous failures. Homeland Tree Care provides tree health evaluations and risk assessments for homeowners throughout Buffalo and nearby communities.

      </p>
    </div>
  <div class="container">
    <div class="tree-grid">

      <div class="tree-card">
        <h3>Dead Tree Warning Signs</h3>
        <p>Trees with dead limbs, peeling bark, hollow sections, or excessive branch drop may be declining structurally.</p>
      </div>

      <div class="tree-card">
        <h3>Fungus Growth
</h3>
        <p>Fungal growth near the base of a tree can indicate internal decay and root deterioration that weakens stability.
</p>
      </div>

      <div class="tree-card">
        <h3>Leaning Trees</h3>
        <p>Sudden leaning or shifting root plates may suggest root failure or compromised structural support.</p>
      </div>

      <div class="tree-card">
        <h3>Root Instability</h3>
        <p>Construction damage, soil erosion, and saturated ground conditions can weaken root systems over time.</p>
      </div>

      <div class="tree-card">
        <h3>Pest & Insect Damage</h3>
        <p>Certain insects and wood-boring pests can damage internal tree structures and accelerate decline.
</p>
      </div>
 <div class="tree-card">
        <h3>Storm Risk Evaluations</h3>
        <p>We assess vulnerable limbs, overloaded canopies, and structurally weak trees before severe weather seasons arrive.
</p>
      </div>
    </div>

</div>

  </div>
  <div class="tree-risk-content">

<div class="risk-content-box">

    <span class="risk-tag">Tree Safety Inspection</span>

    <h3>Signs a Tree May Need Professional Attention</h3>

    <p class="risk-intro">
        Trees affected by disease, storm damage, or internal decay may still appear healthy from a distance. Professional inspections help identify hidden structural concerns before they become serious property hazards.
    </p>

    <div class="risk-grid">

        <div class="risk-item">
            
            <p>Large dead branches</p>
        </div>

        <div class="risk-item">
            
            <p>Bark peeling or falling away</p>
        </div>

        <div class="risk-item">
            
            <p>Hollow trunk sections</p>
        </div>

        <div class="risk-item">
            
            <p>Mushrooms near the base</p>
        </div>

        <div class="risk-item">
            
            <p>Cracks in major limbs</p>
        </div>

        <div class="risk-item">
            
            <p>Sudden leaning</p>
        </div>

        <div class="risk-item">
           
            <p>Sparse leaf growth</p>
        </div>

        <div class="risk-item">
           
            <p>Exposed or damaged roots</p>
        </div>

    </div>

    <p class="risk-bottom-text">
      Trees affected by disease or internal decay may still appear healthy from a distance. Professional inspections help identify hidden structural concerns that may not be visible to homeowners.

Professional inspections help property owners make informed decisions about trimming, maintenance, or removal needs before hazards become emergencies.

    </p>
<!-- CTA BUTTONS -->
      <div class="trust-buttons">

        <a href="#contact-section" class="btn-estimate">
          Request Free Estimate
        </a>

        <a href="tel:+17164543636" class="btn-call">
          Call (716) 454-3636
        </a>

      </div>

</div>


</section>