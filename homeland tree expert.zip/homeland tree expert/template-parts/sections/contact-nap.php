<section id="contact-section" class="contact-nap">
  <div class="section-tag"><span>CONTACT US</span></div>
  
  <!-- Heading Content Over Background -->
  <div class="section-title">
    <h2>Contact Homeland Tree Care</h2>
    <p>
      Professional tree care services throughout Buffalo, NY and Erie County.
      Contact us today for a free estimate.
    </p>
  </div>

  <div class="overlay"></div>

  <div class="container">
    <div class="contact-content">

      <!-- NAP CARDS WITH SVG ICONS -->
      <div class="nap-grid animate-on-scroll fade-in-left">

        <!-- Business Name Card -->
        <div class="nap-card">
          <i class="svg-icon">
            <svg width="26" height="26" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M3 9L12 3L21 9L12 15L3 9Z" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
              <path d="M5 10.5V16.5L12 21L19 16.5V10.5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
              <path d="M12 15V21" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
              <path d="M8 12L12 14.5L16 12" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </i>
          <div>
            <h4>Business Name</h4>
            <p>Homeland Tree Care</p>
          </div>
        </div>

        <!-- Phone Number Card -->
        <div class="nap-card">
          <i class="svg-icon">
            <svg width="26" height="26" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M22 16.92V19.92C22.0011 20.1985 21.9441 20.4742 21.8325 20.7294C21.7209 20.9845 21.5573 21.2136 21.352 21.4019C21.1467 21.5901 20.9043 21.7335 20.6405 21.8227C20.3767 21.9119 20.0973 21.945 19.82 21.92C16.7428 21.5856 13.787 20.5341 11.19 18.85C8.77382 17.3147 6.72533 15.2662 5.19 12.85C3.49995 10.2415 2.4483 7.27279 2.12 4.18C2.09497 3.90347 2.12799 3.6241 2.21708 3.36032C2.30617 3.09654 2.44944 2.85411 2.63759 2.64872C2.82575 2.44333 3.05478 2.27962 3.30991 2.16796C3.56505 2.05629 3.84074 1.99926 4.12 2H7.12C7.60496 1.99577 8.07464 2.16385 8.44607 2.47258C8.8175 2.78132 9.06394 3.20841 9.14 3.68C9.26187 4.51449 9.48114 5.33111 9.79 6.11C9.92813 6.46654 9.95407 6.85671 9.86464 7.22873C9.7752 7.60075 9.57496 7.93564 9.29 8.19L7.73 9.72C9.06696 12.2034 11.0166 14.3976 13.41 15.98L14.96 14.66C15.2342 14.342 15.6149 14.1355 16.0301 14.0809C16.4453 14.0263 16.8647 14.1272 17.21 14.36C17.9827 14.7966 18.7992 15.1494 19.65 15.41C20.0964 15.54 20.4954 15.7938 20.7956 16.1397C21.0958 16.4857 21.2832 16.9076 21.33 17.36C21.3618 17.6544 21.3452 17.9525 21.2813 18.2408C21.2175 18.5291 21.1076 18.8027 20.957 19.05C20.8064 19.2973 20.6181 19.5157 20.3999 19.695C20.1817 19.8743 19.9374 20.0114 19.68 20.1" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </i>
          <div>
            <h4>Phone Number</h4>
            <p>(716) 454-3636</p>
          </div>
        </div>

        <!-- Service Area Card -->
        <div class="nap-card">
          <i class="svg-icon">
            <svg width="26" height="26" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M21 10C21 17 12 23 12 23C12 23 3 17 3 10C3 7.61305 3.94821 5.32387 5.63604 3.63604C7.32387 1.94821 9.61305 1 12 1C14.3869 1 16.6761 1.94821 18.364 3.63604C20.0518 5.32387 21 7.61305 21 10Z" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
              <circle cx="12" cy="10" r="3" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </i>
          <div>
            <h4>Service Area</h4>
            <p>Buffalo, NY & Erie County</p>
          </div>
        </div>

      </div>

      <!-- CTA BOX -->
      <div class="cta-box animate-on-scroll fade-in-right">
        <h3>Need Tree Service?</h3>
        <p>
          Request your free estimate today and speak directly with our experienced tree care team.
        </p>
        <div class="trust-buttons">
          <a href="#contact-form" class="btn-estimate">
            Request Free Estimate
          </a>
          <a href="tel:+17164543636" class="btn-call">
            Call (716) 454-3636
          </a>
        </div>
      </div>

    </div>
  </div>
</section>