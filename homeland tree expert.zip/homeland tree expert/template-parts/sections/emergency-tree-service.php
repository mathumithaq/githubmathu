<!-- =========================================
EMERGENCY TREE SERVICE SECTION
FILE: emergency-tree-service.php
========================================= -->

<section id="emergency-tree" class="emergency-tree-service">
    <div class="section-tag"><span>EMERGENCY SERVICE</span></div>
    <div class="section-title">
        <h2 id="dynamic-heading">
            24/7 Emergency Tree Service in Buffalo
        </h2>
        <p>
            Storm-damaged trees can create dangerous situations with very little warning. Homeland Tree Care provides emergency tree services throughout Buffalo and surrounding Erie County communities when fast response and professional handling matter most.
        </p>
        <p>
            Heavy winds, snowstorms, ice accumulation, saturated soil, and falling limbs can block driveways, damage roofs, threaten nearby structures, and create immediate safety hazards for homeowners and businesses. In many situations, damaged trees remain unstable even after the storm has passed.
            Our emergency response team works quickly to assess hazardous conditions, stabilize dangerous areas, and remove fallen or damaged trees safely.
        </p>
    </div>

    <div class="container">
        <!-- WRAPPER: LEFT CONTENT (CTA + SERVICES) | RIGHT IMAGE -->
        <div class="emergency-wrapper">
            
            <!-- LEFT COLUMN: CTA BOX + SERVICES GRID -->
            <div class="emergency-content">
                
                <!-- CTA BOX -->
                <div class="emergency-cta-box">
                    <div class="cta-text">
                        <p>
                            If a tree has fallen or you notice unstable limbs after severe weather, Homeland Tree Care is ready to respond with safety-focused emergency solutions.
                        </p>
                    </div>
                    <div class="trust-buttons">
                        <a href="#contact-section" class="btn-estimate">
                            Request Free Estimate
                        </a>
                        <a href="tel:+17164543636" class="btn-call">
                            Call (716) 454-3636
                        </a>
                    </div>
                </div>

                <!-- SERVICE LIST - 2 COLUMN GRID (INSIDE LEFT COLUMN) -->
                <div class="emergency-services">
                    <!-- ITEM 1 -->
                    <div class="emergency-item">
                        <h3>Fallen Tree Removal</h3>
                        <p>
                            We safely remove fallen trees from homes, garages, sheds, fences, vehicles, driveways, and yards using controlled methods designed to reduce additional property damage.
                        </p>
                        <p>
                            Every emergency removal is approached carefully based on tree position, structural pressure, access limitations, and surrounding hazards.
                        </p>
                    </div>

                    <!-- ITEM 2 -->
                    <div class="emergency-item">
                        <h3>Emergency Branch Removal</h3>
                        <p>
                            Broken or hanging branches often become highly unstable after storms. These branches may remain suspended overhead for hours or even days before suddenly falling.
                        </p>
                        <p>
                            Our crew responds quickly to remove dangerous branches safely while helping reduce risks to people, vehicles, and surrounding structures.
                        </p>
                    </div>

                    <!-- ITEM 3 -->
                    <div class="emergency-item">
                        <h3>Wind Damage Cleanup</h3>
                        <p>
                            Buffalo weather frequently produces strong wind events capable of damaging mature trees and overloaded branches.
                        </p>
                        <p>
                            We provide debris removal, hazardous limb cleanup, emergency stabilization, and storm-related tree assessments following severe weather conditions.
                        </p>
                    </div>

                    <!-- ITEM 4 -->
                    <div class="emergency-item">
                        <h3>Insurance Assistance</h3>
                        <p>
                            Storm-related property damage can feel overwhelming for homeowners.
                        </p>
                        <p>
                            Homeland Tree Care helps document visible tree damage and provides information that may assist during insurance claim discussions whenever needed.
                        </p>
                    </div>
                </div>

            </div>

            <!-- RIGHT COLUMN: ONLY IMAGE -->
            <div class="emergency-image">
                <img src="https://akatreeservice.com/wp-content/uploads/2023/12/AKA-Emergency-Service.webp" alt="Emergency Tree Service">
                <div class="emergency-floating-card">
                    <h4>Buffalo Storm Safety Alert</h4>
                    <p>
                        Never stand beneath hanging branches or partially split trees after heavy snow or windstorms. Limbs under tension can fail unexpectedly without visible warning signs.

                    </p>
                    
                </div>
                 <!-- HIGHLIGHT ITEM 5 (FULL WIDTH) -->
                    <div class="emergency-item emergency-highlight">
                        <h3>Fast Emergency Response</h3>
                        <p>
                            Emergency situations often require immediate action. Our crew prioritizes calls involving:
                        </p>
                        <ul class="emergency-list">
                            <li>Trees fallen onto homes or garages</li>
                            <li>Blocked driveways or access areas</li>
                            <li>Dangerous hanging branches</li>
                            <li>Split or cracked trunks</li>
                            <li>Storm-damaged trees near structures</li>
                            <li>Uprooted trees after high winds</li>
                            <li>Hazardous debris cleanup</li>
                            <li>Trees affecting walkways or vehicles</li>
                        </ul>
                    </div>
            </div>

        </div>
    </div>
</section>