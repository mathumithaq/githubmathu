<!-- QUICK SERVICES SECTION -->
<section id="services-section" class="quick-services">
  <div class="section-tag"><span>SERVICES</span></div>
  <div class="section-title">
    <h2 id="dynamic-heading">Complete Tree Services for Buffalo Properties</h2>
    <p>Homeland Tree Care provides comprehensive tree care services for residential and commercial properties throughout Buffalo and surrounding Erie County communities. 
      Our services are designed to improve property safety, maintain tree health, and help homeowners manage storm-related risks throughout the year.</p>
  <!-- CTA BUTTONS -->
      <div class="trust-buttons">

        <a href="#contact-section" class="btn-estimate">
          Request Free Estimate
        </a>

        <a href="tel:+17164543636" class="btn-call">
          Call (716) 454-3636
        </a>

      </div>

    </div>
  <div class="container">
    <div class="service-grid">
      <?php
      $services = [
        [
          "title" => "Arborist Consultation",
          "desc"  => "Our arborist consultation services help property owners better understand tree health, structural concerns, storm risks, and long-term maintenance needs. We inspect trees for visible decay, fungus growth, weak branch attachments, root instability, pest activity, and structural defects while recommending practical solutions that support both safety and landscape appearance.
Property owners often contact us when they notice leaning trunks, thinning canopies, cracked limbs, hollow sections, or unusual growth patterns. Early inspections can help identify risks before major tree failures occur.
",
          "image" =>"https://sperrytreecare.com/wp-content/uploads/2022/09/Alby_Consultation-scaled.jpg"
        ],
        [
          "title" => "Tree Removal",
          "desc"  => "We safely remove hazardous, dead, damaged, leaning, or unwanted trees using controlled dismantling methods and professional equipment. Our crew handles everything from backyard tree removals to large tree dismantling projects near homes, garages, fences, and utility lines.
Each removal project is carefully planned to improve safety and reduce unnecessary disruption to the surrounding property.
",
          "image" =>  "https://i.pinimg.com/280x280_RS/dc/b3/e8/dcb3e854be942085927936fd88aeee7a.jpg"
        ],
        [
          "title" => "Tree Trimming & Pruning",
          "desc"  => "Professional tree trimming helps improve tree health, structural balance, airflow, and overall appearance. We remove overgrown limbs, reduce branch weight, improve roof clearance, and shape trees for stronger long-term growth patterns while helping reduce storm damage risks.
Routine pruning also helps minimize debris buildup on roofs, gutters, driveways, and walkways.
",
          "image" => "https://treenewal.com/wp-content/uploads/2022/08/tree_trimming_and_tree_pruning.jpg"
        ],
        [
          "title" => "Crane-Assisted Tree Removal",
          "desc"  => "Some trees require specialized crane-assisted removal methods due to extreme size, difficult access conditions, or structural instability. Crane support allows large tree sections to be lifted safely and efficiently while minimizing impact on nearby landscaping and structures.
These services are especially helpful in tight residential neighborhoods throughout Buffalo, where space is limited.
",
          "image" => "https://limbwalkersnc.com/wp-content/uploads/crane-assisted-tree-removal%E2%80%8B.jpg"
        ],
        [
          "title" => "Tree Stump Grinding & Removal",
          "desc"  => "After a tree is removed, leftover stumps can become trip hazards, attract insects, interfere with mowing, and reduce usable yard space. We provide stump grinding and stump removal services to help clear your property and prepare the area for landscaping, lawn restoration, or future planting projects.",
          "image" => "https://stumpbusters.co.nz/wp-content/uploads/2018/02/tree-stump-removal-stumpgrinder.jpg"
        ],
        [
          "title" => "Emergency Tree Services",
          "desc"  => "Storm-damaged trees and fallen limbs can create immediate hazards for homes, vehicles, sidewalks, and driveways. Homeland Tree Care provides emergency tree services for dangerous situations involving wind damage, split trunks, hanging branches, blocked access areas, and emergency removals.
Our team responds quickly to help restore safety after severe weather.
 Emergency Tree Safety Tip: Never attempt to cut hanging limbs or damaged trees after a storm. Trees under tension can shift suddenly and create serious injury risks without warning.",
          "image" =>"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTsC62bRRxdR9SQ3rJrpj7nXzkjZpTfJ2lB5g&s"
        ],
        [
          "title" => "Commercial Tree Services",
          "desc"  => "We work with businesses, apartment complexes, property managers, retail facilities, and commercial properties throughout Buffalo and Erie County. Commercial tree services include maintenance trimming, hazard assessments, storm cleanup, seasonal pruning, and long-term property maintenance planning.

Para - Our goal is to help commercial properties maintain safe and professional-looking outdoor spaces year-round.
",
          "image" =>"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSi0-FEiLnNzaOCudQosvcYEcQZbms9oro9dw&s"
        ]
      ];
      $delay_classes = ['delay-100', 'delay-200', 'delay-300', 'delay-400'];
      $counter = 0;
      foreach($services as $service) :
          $delay_class = $delay_classes[$counter % 4];
          $counter++;
      ?>
      <div class="service-card animate-on-scroll fade-in-up <?php echo $delay_class; ?>">
        <div class="service-card-image">
          <img src="<?php echo esc_url($service['image']); ?>" 
               alt="<?php echo esc_attr($service['title']); ?>">
        </div>
        <div class="service-card-body">
          <h3><?php echo esc_html($service['title']); ?></h3>
          <?php $desc = wp_strip_all_tags($service['desc']); ?>
          <p class="service-desc">
            <?php echo esc_html($desc); ?>
          </p>
        </div>
      </div>
      <?php endforeach; ?>
      </div>
    </div>
  </div>
  
</section>