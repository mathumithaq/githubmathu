<?php
/**
 * Hero Section - Homeland Tree Care
 * File: template-parts/hero-section.php
 */
?>

<section id="hero-section" class="hero-section">

    <div class="hero-slider">

        <!-- SLIDE 01 -->
        <div class="hero-slide active"
            style="background-image:url('https://static.vecteezy.com/system/resources/thumbnails/071/885/519/small/two-arborists-cutting-down-a-large-tree-photo.jpg');">
            <div class="hero-overlay"></div>
            <div class="container">
                <div class="hero-content">
                    <h1 class="hero-title">Tree Service in Buffalo, NY - Get a free quote</h1>
                    <p>Professional Tree Removal, Tree Trimming & Emergency Tree Services Across Buffalo and Nearby Areas</p>
                    <p>When trees become damaged, overgrown, unstable, or unsafe, property owners need a local tree company that responds quickly and works carefully.
                    </p>
                    <div class="trust-buttons">
                        <a href="#contact-section" class="btn-estimate">Request Free Estimate</a>
                        <a href="tel:+17164543636" class="btn-call">Call (716) 454-3636</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- SLIDE 02 -->
        <div class="hero-slide"
            style="background-image:url('https://www.walnuttreeservice.com/wp-content/uploads/elementor/thumbs/IMG_1446-1-qwwpugivtygp2aq3lm9ca9psedpocowu5y55wv2bog.webp');">
            <div class="hero-overlay"></div>
            <div class="container">
                <div class="hero-content">
                    <h1 class="hero-title">Tree Service in Buffalo, NY - Get a free quote</h1>
                    <p> Homeland Tree Care provides professional tree services throughout Buffalo, NY with a strong focus on safety, communication, and long-term property protection.
                        Our team understands that two properties are not the same. Some homes in Buffalo have mature maples growing close to roofs and power lines, 
                        while others deal with leaning trunks, overcrowded canopies, dead limbs, or storm-damaged trees after heavy winds and winter weather. 
                        Every project starts with a careful inspection so we can recommend the safest and most practical solution for your property.</p>
                    <div class="trust-buttons">
                        <a href="#contact-section" class="btn-estimate">Request Free Estimate</a>
                        <a href="tel:+17164543636" class="btn-call">Call (716) 454-3636</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- SLIDE 03 -->
        <div class="hero-slide"
            style="background-image:url('https://static.vecteezy.com/system/resources/thumbnails/071/885/579/small/arborist-cutting-a-large-tree-branch-photo.jpg');">
            <div class="hero-overlay"></div>
            <div class="container">
                <div class="hero-content">
                    <h1 class="hero-title">Tree Service in Buffalo, NY - Get a free quote</h1>
                    <p>Whether you need emergency tree removal after a storm, seasonal tree trimming to improve tree health, or stump grinding to restore your yard, Homeland Tree Care delivers dependable service backed by local experience and professional equipment.</p>
                    <p>We proudly help homeowners and commercial property owners maintain safer, cleaner, and more attractive outdoor spaces throughout every season in Western New York.</p>
                    <div class="trust-buttons">
                        <a href="#contact-section" class="btn-estimate">Request Free Estimate</a>
                        <a href="tel:+17164543636" class="btn-call">Call (716) 454-3636</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- SLIDE 04 -->
        <div class="hero-slide"
            style="background-image:url('https://media.istockphoto.com/id/186690958/photo/tree-stump-grinding.jpg?s=612x612&w=0&k=20&c=X67KIKnarKFWI2MPRj4NVCDBVZdkJeUp-xJEaU9HWG8=');">
            <div class="hero-overlay"></div>
            <div class="container">
                <div class="hero-content">
                    <h1 class="hero-title">Tree Service in Buffalo, NY - Get a free quote</h1>
                    <h3>Buffalo Weather Warning</h3>
                    <p>Heavy snow loads, freezing rain, and high winds can weaken tree limbs long before visible damage appears. Trees that look stable may still contain internal decay or storm stress that increases the risk of sudden branch failure.</p>
                    <div class="trust-buttons">
                        <a href="#contact-section" class="btn-estimate">Request Free Estimate</a>
                        <a href="tel:+17164543636" class="btn-call">Call (716) 454-3636</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- SLIDE 05 -->
        <div class="hero-slide"
            style="background-image:url('https://cdn.eversite.com/media/tangitree.com/39268/storm+damage+tree+cleanup.png');">
            <div class="hero-overlay"></div>
            <div class="container">
                <div class="hero-content">
                    <h1 class="hero-title">Tree Service in Buffalo, NY - Get a free quote</h1>
                    <p>Many homeowners wait until a tree becomes an emergency before scheduling service. Preventive trimming and inspections can often help identify hazardous limbs and structural concerns before severe weather causes expensive property damage.
                        At Homeland Tree Care, our goal is simple: provide safe, responsive, and professional tree care solutions that help property owners feel confident throughout the entire process.</p>
                    <div class="trust-buttons">
                        <a href="#contact-section" class="btn-estimate">Request Free Estimate</a>
                        <a href="tel:+17164543636" class="btn-call">Call (716) 454-3636</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- SLIDER DOTS — inside .hero-slider so position:absolute works correctly -->
        <div class="slider-dots">
            <button class="dot active" data-slide="0"></button>
            <button class="dot" data-slide="1"></button>
            <button class="dot" data-slide="2"></button>
            <button class="dot" data-slide="3"></button>
            <button class="dot" data-slide="4"></button>
        </div>

        <!-- RIGHT CARD — moved inside slider for grid alignment -->
        <div class="hero-card-wrapper">
            <div class="hero-card">
                <h3 class="hero-card-title">Why Buffalo Property Owners Call Homeland Tree Care</h3>
                <div class="hero-services-list">
                    <div class="service-item"><span>Fully insured tree service professionals.</span></div>
                    <div class="service-item"><span>Locally owned and operated.</span></div>
                    <div class="service-item"><span>Emergency response availability.</span></div>
                    <div class="service-item"><span>Residential and commercial tree services.</span></div>
                    <div class="service-item"><span>Professional-grade equipment and safety systems.</span></div>
                    <div class="service-item"><span>Free estimates and honest recommendations.</span></div>
                    <div class="service-item"><span>Complete cleanup after every project.</span></div>
                </div>
            </div>
        </div>

    </div><!-- /.hero-slider -->

    <!-- SLIDER BUTTONS — outside slider, positioned relative to .hero-section -->
    <button class="slider-btn prev" aria-label="Previous Slide">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
            <path d="M15 18L9 12L15 6" stroke="black" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
    </button>

    <button class="slider-btn next" aria-label="Next Slide">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
            <path d="M9 6L15 12L9 18" stroke="black" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
    </button>

</section>