<section id="legal-terms-section" style="background-color: #f8f9fa; border-top: 1px solid #e9ecef; padding: 60px 0;">
    <div class="container" style="max-width: 900px; margin: 0 auto; padding: 0 20px;">
        
        <!-- PRIVACY POLICY CARD -->
        <div id="privacy-policy" style="margin-bottom: 40px; background: #ffffff; padding: 40px; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.04); border: 1px solid rgba(0,0,0,0.05);">
            <h3 style="font-size: 22px; color: var(--footer-bg, #1A2CA3); margin-top: 0; margin-bottom: 25px; border-bottom: 2px solid #FFB300; padding-bottom: 12px; display: inline-block; font-weight: 700;">
                SMS Privacy Notice
            </h3>
            
            <div style="font-size: 15px; color: #4a5568; line-height: 1.8;">
                <p style="margin-bottom: 16px;">
                    <strong style="color: #2d3748;">Collection of Information:</strong> We collect your mobile phone number when you opt-in to receive SMS communications from us.
                </p>
                <p style="margin-bottom: 16px;">
                    <strong style="color: #2d3748;">Use of Information:</strong> We use your phone number to send you service updates, appointment reminders, and marketing offers related to our landscaping services.
                </p>
                <p style="margin-bottom: 16px;">
                    <strong style="color: #2d3748;">Data Sharing:</strong> We do not share, sell, or rent your mobile phone information or SMS consent data with any third parties or affiliates for their own marketing purposes.
                </p>
                <p style="margin-bottom: 0;">
                    <strong style="color: #2d3748;">Your Rights:</strong> You have the right to request access to or deletion of your personal data. To exercise these rights, please contact us at 
                    <a href="mailto:info@homelandtree.com" style="color: var(--footer-bg, #1A2CA3); font-weight: 600; text-decoration: none; border-bottom: 1px solid currentColor;">info@homelandtree.com</a>.
                </p>
            </div>
        </div>

        <!-- TERMS & CONDITIONS CARD -->
        <div id="terms-conditions" style="background: #ffffff; padding: 40px; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.04); border: 1px solid rgba(0,0,0,0.05);">
            <h3 style="font-size: 22px; color: var(--footer-bg, #1A2CA3); margin-top: 0; margin-bottom: 25px; border-bottom: 2px solid #FFB300; padding-bottom: 12px; display: inline-block; font-weight: 700;">
                SMS Messaging Terms of Service
            </h3>
            
            <div style="font-size: 15px; color: #4a5568; line-height: 1.8;">
                <p style="margin-bottom: 16px;">
                    <strong style="color: #2d3748;">Program Description:</strong> By providing your phone number, you agree to receive recurring messages from Redefine Landscaping Buffalo regarding service updates, project status, and promotional offers.
                </p>
                <p style="margin-bottom: 16px;">
                    <strong style="color: #2d3748;">Opt-Out:</strong> You can opt-out of receiving SMS messages at any time by replying "STOP" to any message we send.
                </p>
                <p style="margin-bottom: 16px;">
                    <strong style="color: #2d3748;">Support:</strong> For help, reply "HELP" to any message or contact us at 
                    <a href="mailto:info@homelandtree.com" style="color: var(--footer-bg, #1A2CA3); font-weight: 600; text-decoration: none; border-bottom: 1px solid currentColor;">info@homelandtree.com</a>.
                </p>
                <p style="margin-bottom: 16px;">
                    <strong style="color: #2d3748;">Message & Data Rates:</strong> Message and data rates may apply for any messages sent to you from us and to us from you.
                </p>
                <p style="margin-bottom: 16px;">
                    <strong style="color: #2d3748;">Carrier Liability:</strong> Redefine Landscaping Buffalo is not liable for delayed or undelivered messages. Delivery of information and content through SMS may be subject to your mobile carrier’s capability and is not guaranteed.
                </p>
                <p style="margin-bottom: 0;">
                    <strong style="color: #2d3748;">Age Restriction:</strong> You must be 18 years of age or older to participate in our SMS program.
                </p>
            </div>
        </div>

    </div>
</section>
