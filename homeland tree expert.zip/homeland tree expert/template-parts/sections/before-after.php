<section id="gallery-section" class="before-after-section">
<div class="section-tag"><span>BEFORE & AFTER RESULTS</span></div>
    <div class="section-title">
        
        <h2 id="dynamic-heading">Real Tree Care Results</h2>
         <p>
            Our team focuses on delivering noticeable improvements while maintaining safe work practices and complete cleanup throughout every project.

        </p>
         <!-- CTA BUTTONS -->
      <div class="trust-buttons">

        <a href="#contact-section" class="btn-estimate">
          Request Free Estimate
        </a>

        <a href="tel:+17164543636" class="btn-call">
          Call (716) 454-3636
        </a>

      </div>

    </div>
    <div class="container">

        <div class="ba-grid">

            <!-- =================================
                 CARD 1
            ================================== -->

            <div class="ba-card">

                <div class="ba-image-wrap">

                    <!-- BEFORE -->
                    <div class="ba-image">

                        <img src="https://images.unsplash.com/photo-1506744038136-46273834b3fb?q=80&w=1200&auto=format&fit=crop" alt="Before Tree Removal">

                        <span class="ba-tag before-tag">

                            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="none" viewBox="0 0 24 24">
                                <path d="M12 2L2 7L12 12L22 7L12 2Z" fill="currentColor"/>
                                <path d="M2 17L12 22L22 17" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                                <path d="M2 12L12 17L22 12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                            </svg>

                            Before
                        </span>

                        <div class="service-badge">
                            Visible Tree Care
                        </div>

                    </div>

                    <!-- AFTER -->
                    <div class="ba-image">

                        <img src="https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?q=80&w=1200&auto=format&fit=crop" alt="After Tree Removal">

                        <span class="ba-tag after-tag">

                            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="none" viewBox="0 0 24 24">
                                <path d="M20 6L9 17L4 12" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>

                            After
                        </span>

                        <div class="service-badge">
                            Completed Result
                        </div>

                    </div>
<div class="ba-arrow">
    <svg class="icon">
    <use xlink:href="<?php echo get_template_directory_uri(); ?>/assets/icons/icons.svg#icon-arrow-right"></use>
</svg>
</div>

                </div>

                <div class="ba-content">

                    <h3>Visible Tree Care Results</h3>

                    <p>
                        Professional tree work can dramatically improve property safety, appearance, and usability. Homeland Tree Care helps homeowners transform overgrown, hazardous, and storm-damaged landscapes into cleaner and safer outdoor spaces.

                    </p>

                    <div class="ba-stats">
                        <span>Healthy Tree Growth</span>
                        <span>Safer Property</span>
                    </div>
                </div>

            </div>


            <!-- =================================
                 CARD 2
            ================================== -->

            <div class="ba-card">

                <div class="ba-image-wrap">

                    <!-- BEFORE -->
                    <div class="ba-image">

                        <img src="https://images.unsplash.com/photo-1511497584788-876760111969?q=80&w=1200&auto=format&fit=crop" alt="Storm Damage Before">

                        <span class="ba-tag before-tag">

                            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="none" viewBox="0 0 24 24">
                                <path d="M12 2L2 7L12 12L22 7L12 2Z" fill="currentColor"/>
                                <path d="M2 17L12 22L22 17" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                                <path d="M2 12L12 17L22 12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                            </svg>

                            Before
                        </span>

                        <div class="service-badge">
                           Tree Removal
                        </div>

                    </div>

                    <!-- AFTER -->
                    <div class="ba-image">

                        <img src="https://images.unsplash.com/photo-1441974231531-c6227db76b6e?q=80&w=1200&auto=format&fit=crop" alt="Storm Cleanup After">

                        <span class="ba-tag after-tag">

                            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="none" viewBox="0 0 24 24">
                                <path d="M20 6L9 17L4 12" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>

                            After
                        </span>

                        <div class="service-badge">
                            Completed Result
                        </div>

                    </div>

                    <div class="ba-arrow">
    <svg class="icon">
    <use xlink:href="<?php echo get_template_directory_uri(); ?>/assets/icons/icons.svg#icon-arrow-right"></use>
</svg>
</div>

                </div>

                <div class="ba-content">

                    <h3>Tree Removal Transformations</h3>

                    <p>
                        Removing dead or dangerous trees opens up yard space, improves visibility, and reduces safety concerns around homes and driveways.
                    </p>

                    <div class="ba-stats">
                        <span>Safe Removal</span>
                        <span>Full Cleanup</span>
</div>

                </div>

            </div>


            <!-- =================================
                 CARD 3
            ================================== -->

            <div class="ba-card">

                <div class="ba-image-wrap">

                    <!-- BEFORE -->
                    <div class="ba-image">

                        <img src="https://images.unsplash.com/photo-1465146344425-f00d5f5c8f07?q=80&w=1200&auto=format&fit=crop" alt="Before Trimming">

                        <span class="ba-tag before-tag">

                            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="none" viewBox="0 0 24 24">
                                <path d="M12 2L2 7L12 12L22 7L12 2Z" fill="currentColor"/>
                                <path d="M2 17L12 22L22 17" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                                <path d="M2 12L12 17L22 12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                            </svg>

                            Before
                        </span>

                        <div class="service-badge">
                           Storm Cleanup
                        </div>

                    </div>

                    <!-- AFTER -->
                    <div class="ba-image">

                        <img src="https://images.unsplash.com/photo-1473773508845-188df298d2d1?q=80&w=1200&auto=format&fit=crop" alt="After Trimming">

                        <span class="ba-tag after-tag">

                            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="none" viewBox="0 0 24 24">
                                <path d="M20 6L9 17L4 12" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>

                            After
                        </span>

                        <div class="service-badge">
                            Clean Finish
                        </div>

                    </div>

                    <div class="ba-arrow">
    <svg class="icon">
    <use xlink:href="<?php echo get_template_directory_uri(); ?>/assets/icons/icons.svg#icon-arrow-right"></use>
</svg>
</div>

                </div>

                <div class="ba-content">

                    <h3>Storm Cleanup Improvements</h3>

                    <p>
                       After severe weather, quick debris removal and damaged tree cleanup help restore safe access and improve property appearance.

                    <div class="ba-stats">
                        <span>Better Appearance</span>
                        <span>Healthier Growth</span>
                    </div>


                </div>

            </div>
          <!-- =================================
                 CARD 4
            ================================== -->

            <div class="ba-card">

                <div class="ba-image-wrap">

                    <!-- BEFORE -->
                    <div class="ba-image">

                        <img src="https://images.unsplash.com/photo-1511497584788-876760111969?q=80&w=1200&auto=format&fit=crop" alt="Storm Damage Before">

                        <span class="ba-tag before-tag">

                            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="none" viewBox="0 0 24 24">
                                <path d="M12 2L2 7L12 12L22 7L12 2Z" fill="currentColor"/>
                                <path d="M2 17L12 22L22 17" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                                <path d="M2 12L12 17L22 12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                            </svg>

                            Before
                        </span>

                        <div class="service-badge">
                           Trimming & Pruning
                        </div>

                    </div>

                    <!-- AFTER -->
                    <div class="ba-image">

                        <img src="https://images.unsplash.com/photo-1441974231531-c6227db76b6e?q=80&w=1200&auto=format&fit=crop" alt="Storm Cleanup After">

                        <span class="ba-tag after-tag">

                            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="none" viewBox="0 0 24 24">
                                <path d="M20 6L9 17L4 12" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>

                            After
                        </span>

                        <div class="service-badge">
                            Completed Result
                        </div>

                    </div>

                    <div class="ba-arrow">
    <svg class="icon">
    <use xlink:href="<?php echo get_template_directory_uri(); ?>/assets/icons/icons.svg#icon-arrow-right"></use>
</svg>
</div>

                </div>

                <div class="ba-content">

                    <h3>Trimming & Pruning Results</h3>

                    <p>
                    Proper pruning enhances tree shape, reduces overgrowth, improves sunlight exposure, and creates healthier canopy structures.

                    </p>

                    <div class="ba-stats">
                        <span>Better Appearance</span>
                        <span>Healthier Growth</span>
                    </div>
                </div>

            </div>

        </div>

    </div>

</section>