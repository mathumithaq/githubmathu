<?php
/**
 * Homeland Tree Care — Reviews Section
 * File: reviews.php
 * 
 * Usage: <?php include 'reviews.php'; ?>
 * Make sure to link reviews.css in your <head>
 */

// ── Review Data ───────────────────────────────────────────
$reviews = [
    [
        'name'   => 'Michael R. - Buffalo, NY',
        'stars'  => 5,
        'text'   => 'Homeland Tree Care removed a large damaged maple tree from our backyard after a windstorm. The crew was professional, careful around our fence, and cleaned everything up before leaving.',
        'avatar' => 'https://randomuser.me/api/portraits/women/65.jpg',
    ],
    [
        'name'   => 'Jennifer T. - Amherst, NY',
        'stars'  => 5,
        'text'   => 'Great service from start to finish! They helped with both tree removal and trimming. The crew paid attention to detail and left everything clean. Highly recommend for full tree care services.',
        'avatar' => 'https://randomuser.me/api/portraits/men/45.jpg',
    ],
    [
        'name'   =>  'David L. - Cheektowaga, NY',
        'stars'  => 5,
        'text'   => 'Fast response after a storm knocked down branches across our driveway. The team handled the cleanup quickly and safely.',
        'avatar' => 'https://randomuser.me/api/portraits/men/32.jpg ',
    ],
    [
        'name'   => 'Tracy S. - Hamburg, NY',
        'stars'  => 5,
        'text'   => 'Their attention to property protection really stood out. They used mats to protect the lawn and completed the tree removal without damaging our landscaping.',
        'avatar' => 'https://img.freepik.com/free-photo/pleased-handsome-male-customer-show-thumb-up-approval_176420-17945.jpg?semt=ais_hybrid&w=740&q=80 ',
    ],
    [
        'name'   => 'Brian M. - Tonawanda, NY',
        'stars'  => 5,
        'text'   => 'Very professional crew with fair pricing and excellent communication from start to finish.',
        'avatar' => 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ3tw8OVtceOIUHe-N9CQspV1HNTM2y0qEdVg&s ',
    ],
];

// ── Helper: render star icons (SVG) ──────────────────────────────
function renderStars(int $count): string {

    $count = max(0, min(5, $count)); // safe limit (0–5)
    $output = '';

    for ($i = 1; $i <= 5; $i++) {

        if ($i <= $count) {
            // Filled star
            $output .= '
            <svg width="16" height="16" viewBox="0 0 24 24" fill="#f5b301" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/>
            </svg>';
        } else {
            // Empty star
            $output .= '
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#f5b301" stroke-width="2" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/>
            </svg>';
        }
    }

    return $output;
}
?>

<!-- ======================================================
     Reviews Section
     Link in <head>: <link rel="stylesheet" href="reviews.css">
======================================================= -->
<section id="reviews-section" class="reviews-section">
      <div class="section-tag"><span>REVIEWS</span></div>
<div class="section-title">
      <h2 id="dynamic-heading">What Local Customers Say<br></h2>
      
    </div>
  <div class="reviews-inner">

    <!-- Left: Heading + CTA -->
    <div class="reviews-left">
    <div class="customer-review-card">
        <h3 class="review-title">Customer Review:</h3>
       
        
        <div class="review-quote">
            <h3 class="review-quote-text">
              Home Land Tree Care is Rated Great
</h3>
        </div>
        
        <!-- Stats Section Added -->
        <div class="review-stats">
            <div class="stat-item">
                <span class="stat-number">20+</span>
                <span class="stat-label">Years Experience</span>
            </div>
            <div class="stat-item">
                <span class="stat-number">5000+</span>
                <span class="stat-label">Trees Removed</span>
            </div>
            <div class="stat-item">
                <span class="stat-number">100%</span>
                <span class="stat-label">Satisfaction</span>
            </div>
        </div>
        <!-- CTA BUTTONS -->
      <div class="trust-buttons">

        <a href="#contact-section" class="btn-estimate">
          Request Free Estimate
        </a>

        <a href="tel:+17164543636" class="btn-call">
          Call (716) 454-3636
        </a>

      </div>
    </div>
</div>

    <!-- Right: Review Cards -->
    <div class="reviews-right">
      <?php foreach ($reviews as $review): ?>
        <div class="review-card">


          <!-- Avatar -->
          <img
            class="review-avatar"
            src="<?php echo htmlspecialchars($review['avatar']); ?>"
            alt="<?php echo htmlspecialchars($review['name']); ?>"
          />

          <!-- Body -->
          <div class="review-body">

            <!-- Stars -->
            <div class="review-stars" aria-label="<?php echo $review['stars']; ?> out of 5 stars">
              <?php echo renderStars($review['stars']); ?>
            </div>

            <!-- Quote -->
            <div class="review-quote-wrap">
              <span class="review-quote-mark" aria-hidden="true">"</span>
              <p class="review-text">
                <?php echo htmlspecialchars($review['text']); ?>
              </p>
            </div>

            <!-- Name -->
            <p class="review-author">— <?php echo htmlspecialchars($review['name']); ?></p>

          </div>
        </div>
      <?php endforeach; ?>
    </div>

  </div>
  

</section>