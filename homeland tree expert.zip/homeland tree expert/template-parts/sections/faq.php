<section id="faq-section" class="faq-section">
    <div class="section-tag"><span>FAQ</span></div>
    
        <div class="section-title">
            <h2 id="dynamic-heading">Frequently Asked Questions</h2>
            <!-- CTA BUTTONS -->
      <div class="trust-buttons">

        <a href="#contact-section" class="btn-estimate">
          Request Free Estimate
        </a>

        <a href="tel:+17164543636" class="btn-call">
          Call (716) 454-3636
        </a>

      </div>

        </div>
    <div class="container">


        <div class="faq-wrapper">

            <div class="faq-item active">
                <button class="faq-question">
                    <span>1. How much does tree removal cost in Buffalo?</span>
                   <i class="icon">
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M12 5V19" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/>
        <path d="M5 12H19" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/>
    </svg>
</i>
                </button>
                <div class="faq-answer" style="max-height: 500px;">
                    <p>
                        Tree removal costs vary depending on tree size, location, condition, accessibility, and complexity. Large hazardous trees or crane-assisted removals may require additional equipment and labor. Homeland Tree Care provides free estimates for all services.

                    </p>
                </div>
            </div>

            <div class="faq-item">
                <button class="faq-question">
                    <span>2. Do I need a permit for tree removal?</span>
                    <i class="icon">
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M12 5V19" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/>
        <path d="M5 12H19" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/>
    </svg>
</i>
                </button>
                <div class="faq-answer">
                    <p>
                        Permit requirements depend on your municipality and property regulations. Some Buffalo-area communities may require permits for specific tree removals. Our team can help guide you through the process when needed.

                    </p>
                </div>
            </div>
<div class="faq-item">
                <button class="faq-question">
                    <span>3. When should trees be trimmed?</span>
                    <i class="icon">
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M12 5V19" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/>
        <path d="M5 12H19" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/>
    </svg>
</i>
                </button>
                <div class="faq-answer">
                    <p>
                        Many trees benefit from trimming during dormant seasons, though timing varies by species and condition. Preventive trimming before storm season can also help reduce branch failure risks.

                    </p>
                </div>
            </div>
            <div class="faq-item">
                <button class="faq-question">
                    <span>4. Can you remove trees near power lines?</span>
                    <i class="icon">
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M12 5V19" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/>
        <path d="M5 12H19" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/>
    </svg>
</i>
                </button>
                <div class="faq-answer">
                    <p>
                        Trees near utility lines require careful planning and specialized safety procedures. Our crew evaluates these situations carefully and follows safe removal practices.

                    </p>
                </div>
            </div>
            <div class="faq-item">
                <button class="faq-question">
                    <span>5. Do you offer emergency tree services?</span>
                    <i class="icon">
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M12 5V19" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/>
        <path d="M5 12H19" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/>
    </svg>
</i>
                </button>
                <div class="faq-answer">
                    <p>
                        Yes. Homeland Tree Care provides emergency tree services for storm damage, fallen trees, hanging limbs, and other hazardous situations.

                    </p>
                </div>
            </div>
            <div class="faq-item">
                <button class="faq-question">
                    <span>6. Is stump grinding included with tree removal?</span>
                   <i class="icon">
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M12 5V19" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/>
        <path d="M5 12H19" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/>
    </svg>
</i>
                </button>
                <div class="faq-answer">
                    <p>
                        Stump grinding can be added to most tree removal projects. We offer both tree removal and stump grinding services depending on your needs.
                    </p>
                </div>
            </div>
            
        </div>

    </div>
</section>