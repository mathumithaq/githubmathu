<!-- =========================================
PROPERTY PROTECTION SECTION
FILE: property-protection.php
========================================= -->
<section class="property-protection-section">
    <div class="section-tag"><span>PROPERTY PROTECTION</span></div>
 <!-- HEADER -->
        <div class="section-title">

            <h2 id="dynamic-heading">
                 Property Protection Comes First
            </h2>

            <p>
                Protecting your home, lawn, landscaping, and surrounding structures is an important part of professional tree care. Homeland Tree Care uses careful planning, controlled removal methods, and specialized equipment designed to reduce unnecessary property impact during every project.
Many Buffalo neighborhoods contain mature trees growing close to homes, garages, patios, fences, sidewalks, and decorative landscaping. Working safely in these tight residential spaces requires precision, organization, and experience.
Our crew takes extra precautions throughout every phase of the project to help protect your property while completing removals, trimming, pruning, and storm cleanup services.

            </p>

        </div>

    <div class="container">

       
        <!-- MAIN GRID -->
        <div class="property-grid">

            <!-- LEFT CONTENT -->
            <div class="property-content animate-on-scroll fade-in-left">

                <!-- CARD -->
                <div class="property-card">

                    <div class="property-icon">
                        01
                    </div>

                    <div class="property-text">

                        <h3>Ground Protection Mats</h3>

                        <p>
                            Heavy equipment can damage lawns, landscaping, and soft ground conditions without proper protection. We use ground mats when necessary to help reduce soil disturbance, turf damage, and rutting during equipment movement.

                        </p>

                    </div>

                </div>

                <!-- CARD -->
                <div class="property-card">

                    <div class="property-icon">
                        02
                    </div>

                    <div class="property-text">

                        <h3>Fence & Structure Protection</h3>

                        <p>
                            Tree removals near fences, sheds, garages, patios, decks, and homes require controlled cutting and lowering techniques. Our crew carefully manages branch movement throughout the process to reduce unnecessary risks.

                        </p>

                    </div>

                </div>

                <!-- CARD -->
                <div class="property-card">

                    <div class="property-icon">
                        03
                    </div>

                    <div class="property-text">

                        <h3>Precision Lowering Systems</h3>

                        <p>
                            Professional rigging equipment allows branches and trunk sections to be lowered safely rather than dropped freely onto your property.
Controlled lowering improves safety while helping protect landscaping and nearby structures.

                        </p>

                    </div>

                </div>

                <!-- CARD -->
                <div class="property-card">

                    <div class="property-icon">
                        04
                    </div>

                    <div class="property-text">

                        <h3>Turf Care Awareness</h3>

                        <p>
                            We work carefully around gardens, flower beds, lawns, sidewalks, decorative features, and outdoor living spaces while planning equipment access routes and removal zones.
                        </p>

                    </div>

                </div>

                <!-- CARD -->
                <div class="property-card">

                    <div class="property-icon">
                        05
                    </div>

                    <div class="property-text">

                        <h3>Controlled Rigging Methods</h3>

                        <p>
                            Controlled rigging techniques improve safety and support safer removals in tight residential areas common throughout Buffalo neighborhoods.
                        </p>

                    </div>

                </div>

            </div>

            <!-- RIGHT IMAGE -->
            <div class="property-image animate-on-scroll fade-in-right">

                <img src="https://www.tmhindustries.com/cdn/shop/files/Composite-Access-Mats-TMH-Industries-1.jpg?v=1716410741&width=720" alt="Property Protection">

                <div class="property-floating-box">

                    <h4>Property Protection Tip</h4>

                    <p>
                         Large branches and trunk sections can cause significant damage if dropped without controlled rigging systems. Precision lowering methods help minimize impact during difficult removals.
                    </p>
<button class="learn-more-btn" onclick="openPropertyPopup()">
  Learn More
</button>

      </div>


                </div>
<!-- CTA BUTTONS -->
      <div class="trust-buttons animate-on-scroll fade-in-up">

        <a href="#contact-section" class="btn-estimate">
          Request Free Estimate
        </a>

        <a href="tel:+17164543636" class="btn-call">
          Call (716) 454-3636
        </a>
            </div>

        </div>

    </div>
<div id="propertyPopup" class="popup-overlay">

  <div class="popup-box">
    <p>
        Homeowners appreciate working with a tree company that respects their property and takes extra precautions throughout every phase of the job.
Our property-first approach helps customers feel more confident while ensuring cleaner, safer, and more organized project completion.

    </p>
</hr>
    <h3>Our Property Protection Approach Includes</h3>

    <ul>
      <li>Controlled branch lowering systems</li>
      <li>Strategic equipment placement</li>
      <li>Lawn and turf protection measures</li>
      <li>Careful debris management</li>
      <li>Precision cutting methods</li>
      <li>Safe equipment access planning</li>
      <li>Fence and structure awareness</li>
      <li>Organized cleanup procedures</li>
      <li>Landscape-conscious work planning</li>
    </ul>

  </div>

</div>


</section>