<section class="map-section">
    <div class="section-tag"><span>GOOGLE MAP</span></div>
    <div class="section-title">
      <h2 id="dynamic-heading">Find Homeland Tree Care in Buffalo</h2>
      <p>
       Homeland Tree Care proudly serves homeowners throughout Buffalo and nearby Erie County communities. Our service coverage includes residential neighborhoods, commercial properties, and the surrounding Western New York areas.
Customers searching for dependable local tree service can easily find us through our Google Business Profile and map listing.
      </p>
       <!-- CTA BUTTONS -->
      <div class="trust-buttons">

        <a href="#contact-section" class="btn-estimate">
          Request Free Estimate
        </a>

        <a href="tel:+17164543636" class="btn-call">
          Call (716) 454-3636
        </a>

      </div>
    </div>

  <div class="container">

    <div class="map-grid">

      <!-- MAP -->
      <div class="map-box">
        <iframe
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2224.0108926146077!2d-78.9027394!3d42.962954599999996!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89d36dccc00c78dd%3A0xeae47361a15a276b!2sHomeland%20Tree%20Care!5e1!3m2!1sen!2slk!4v1779307732165!5m2!1sen!2slk"
          width="100%"
          height="380"
          style="border:0;"
          allowfullscreen=""
          loading="lazy"
          referrerpolicy="no-referrer-when-downgrade">
        </iframe>
      </div>

      <!-- INFO -->
      <div class="map-info">

        <h3>Nearby Areas & Landmarks</h3>
        <ul>
          <li>Downtown Buffalo</li>
          <li>Amherst</li>
          <li>Cheektowaga</li>
          <li>Tonawanda</li>
          <li>West Seneca</li>
          <li>Orchard Park</li>
        </ul>

      </div>

    </div>

  </div>
  

</section>