<section class="trust-closer-section">
  <div class="section-tag"><span>TRUST</span></div>
  <div class="container">
    <div class="trust-box animate-on-scroll zoom-in">

      <h2 id="dynamic-heading">Your Local Buffalo Tree Service Team</h2>

      <p>
        Homeland Tree Care is proud to provide reliable tree services for homeowners and businesses throughout Buffalo
        and Erie County.

        From dangerous tree removals and storm cleanup to trimming, pruning, and stump grinding, our team focuses on
        safe work practices, responsive service, and property-first solutions designed for Western New York conditions.

      </p>
      <h3>Customers trust Homeland Tree Care because we prioritize</h3>
      <div class="trust-points">
        <span> Honest recommendations</span>
        <span> Transparent estimates</span>
        <span> Safe tree care methods</span>
        <span>Professional cleanup</span>
        <span>Fast communication</span>
        <span>Local experience</span>
      </div>
      <p class="trust-cta-text">
        If you need dependable tree service in Buffalo, NY, contact Homeland Tree Care today for a free estimate.
      </p>

      <!-- CTA BUTTONS -->
      <div class="trust-buttons">

        <a href="#contact-section" class="btn-estimate">
          Request Free Estimate
        </a>

        <a href="tel:+17164543636" class="btn-call">
          Call (716) 454-3636
        </a>

      </div>

    </div>

  </div>
</section>