<section class="seasonal-section">
  <div class="section-tag"><span>TREE CARE</span></div>
  <div class="section-title">
    <h2 id="dynamic-heading">Seasonal Tree Care for Buffalo Properties</h2>
    <p>Year-round maintenance helps trees remain healthier, safer, and more structurally balanced throughout changing
      Western New York seasons.
    </p>
    <!-- CTA BUTTONS -->
    <div class="trust-buttons">

      <a href="#contact-section" class="btn-estimate">
        Request Free Estimate
      </a>

      <a href="tel:+17164543636" class="btn-call">
        Call (716) 454-3636
      </a>

    </div>
  </div>

  <div class="container">

    <div class="season-grid">

      <div class="season-card">
        <h3>Spring Tree Care</h3>
        <p>
          Spring is an ideal time to inspect trees for winter damage, remove broken limbs, and prepare healthy growth
          for the warmer season ahead.

        </p>
      </div>

      <div class="season-card">
        <h3>Summer Maintenance</h3>
        <p>
          Summer trimming helps manage overgrowth, improve canopy balance, and identify developing pest or disease
          concerns.

        </p>
      </div>

      <div class="season-card">
        <h3>Fall Hazard Checks</h3>
        <p>
          Fall inspections help identify weak limbs, structural concerns, and storm risks before Buffalo’s winter
          weather arrives.

        </p>
      </div>

      <div class="season-card">
        <h3>Winter Storm Preparation</h3>
        <p>
          Preventive pruning before the heavy snow and ice season can reduce branch failures and help improve tree
          stability during harsh weather conditions.

        </p>
      </div>

    </div>

  </div>
</section>