<!-- =========================================
TREE REMOVAL SERVICE SECTION
FILE: tree-removal.php
========================================= -->

<section id="treeremoval-section" class="tree-removal-section">
  <div class="section-tag"><span>TREE REMOVAL</span></div>
  <div class="section-title">

    <h2 id="dynamic-heading">
      Professional Tree Removal in Buffalo, NY
    </h2>

    <p>
      Tree removal becomes necessary when trees are hazardous, diseased, storm-damaged, structurally unstable, or
      growing too close to buildings and utility lines. Homeland Tree Care provides safe and controlled tree removal
      services throughout Buffalo and surrounding Erie County communities using professional equipment and carefully
      planned removal strategies.
    </p>

    <p>
      Removing large or dangerous trees requires much more than simply cutting branches. Our crew evaluates tree size,
      condition, lean direction, branch weight distribution, surrounding structures, access limitations, and ground
      conditions before beginning any removal process.
    </p>
    <p>Every removal project begins with a detailed inspection to determine the safest and most efficient removal
      approach for the property.
      Our crew takes pride in leaving properties in better condition while helping homeowners eliminate dangerous or
      unwanted trees safely and efficiently.
    </p>
  </div>
  <div class="container">

    <div class="tree-removal-grid">

      <!-- LEFT COLUMN: IMAGE + COMMON REASONS -->
      <div class="tree-removal-left">

        <!-- IMAGE -->
        <div class="tree-removal-image">
          <img
            src="https://le-cdn.hibuwebsites.com/69b3dc5f7a3b49adb4ec6444901322ec/dms3rep/multi/opt/RSshutterstock_653147083-640w.jpg"
            alt="Tree Removal Service">
          <div class="tree-removal-badge">
            24/7 Emergency Removal
          </div>
        </div>

        <!-- COMMON REASONS - BELOW THE IMAGE -->
        <div class="common-reasons-box">
           <p>Whether you need a single hazardous tree removed or multiple trees cleared during a landscaping project, our
          team focuses on safe work practices and complete cleanup from start to finish.
        </p>
          <h3>Common Reasons Homeowners Need Tree Removal</h3>
          <div class="tree-removal-keywords">
            <span>Trees leaning toward structures</span>
            <span>Dead or decaying trees</span>
            <span>Storm-damaged trunks or limbs</span>
            <span>Root damage affecting stability</span>
            <span>Severe insect or disease issues</span>
            <span>Unsafe branch overhang near roofs</span>
            <span>Construction or renovation projects</span>
            <span>Poor tree health or structural decline</span>
            <span>Overcrowded tree growth limiting sunlight</span>
          </div>
          <!-- BUTTONS -->
        <div class="trust-buttons">
          <a href="#contact-section" class="btn-estimate">
            Request Free Estimate
          </a>
          <a href="tel:+17164543636" class="btn-call">
            Call (716) 454-3636
          </a>
        </div>
        </div>

        <!-- ADDITIONAL FILLER IMAGE TO BALANCE COLUMN HEIGHT -->
        <div class="tree-removal-image-filler" style="margin-top: 30px; border-radius: 12px; overflow: hidden; width: 100%; flex-grow: 1; display: flex;">
            <img src="https://media.istockphoto.com/id/186690958/photo/tree-stump-grinding.jpg?s=612x612&w=0&k=20&c=X67KIKnarKFWI2MPRj4NVCDBVZdkJeUp-xJEaU9HWG8=" alt="Tree Maintenance" style="width: 100%; height: 100%; object-fit: cover; border-radius: 12px; display: block;">
        </div>

      </div>

      <!-- RIGHT COLUMN: CONTENT -->
      <div class="tree-removal-content">

        <!-- FEATURES -->
        <div class="tree-removal-features">
          <div class="removal-item">
            <h3>Hazardous Tree Removal</h3>
            <p>Dead or unstable trees can quickly become serious safety risks during Buffalo's heavy windstorms, ice
              accumulation, and winter weather conditions. We remove hazardous trees showing signs of severe decay,
              trunk splitting, root failure, leaning, storm damage, or structural weakness before they create dangerous
              situations for nearby homes and properties.
            </p>
          </div>
          <div class="removal-item">
            <h3>Large Tree Removal</h3>
            <p>Large mature trees often require sectional dismantling methods to safely remove limbs and trunk sections
              in controlled stages. This approach helps protect garages, fences, driveways, sidewalks, landscaping, and
              nearby structures throughout the removal process.
              Instead of dropping large sections freely, our team uses precision rigging systems to carefully lower
              heavy materials in manageable pieces.
            </p>
          </div>
          <div class="removal-item">
            <h3>Crane-Assisted Tree Removal</h3>
            <p>Some tree removals require crane support due to limited access, oversized canopies, unstable conditions,
              or surrounding obstacles. Crane-assisted removals allow large sections to be lifted safely and efficiently
              while reducing unnecessary property impact.
              This method is especially useful for large trees growing over homes, garages, or difficult backyard areas.
            </p>
          </div>
          <div class="removal-item">
            <h3>Backyard Tree Removal</h3>
            <p>Tight spaces and limited backyard access require strategic planning and specialized equipment. Our team
              uses controlled rigging systems and precision cutting techniques to safely remove trees from confined
              residential spaces without unnecessary damage to surrounding property.
            </p>
          </div>
          <div class="removal-item">
            <h3>Diseased Tree Removal</h3>
            <p>Trees affected by fungal growth, decay, insect infestations, or internal damage may eventually become
              unstable. Removing diseased trees early can help reduce property hazards and protect nearby healthy trees
              from further spread.
            </p>
          </div>
        </div>
      </div>

    </div>

  </div>

  <!-- WARNING SIGNS -->
  <div class="warning-section">
    <div class="container">
      <h3 class="warning-heading">Warning Signs to Watch For</h3>
      <p class="warning-sub">These warning signs can all indicate serious structural instability.</p>
      <div class="warning-cards">

        <div class="warning-card">
          <div class="warning-icon">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" fill="none">
              <circle cx="32" cy="32" r="30" stroke="#FFB300" stroke-width="3"/>
              <polyline points="28,10 36,28 24,32 34,54" stroke="#1A2CA3" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </div>
          <p>Cracks in the trunk</p>
        </div>

        <div class="warning-card">
          <div class="warning-icon">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" fill="none">
              <circle cx="32" cy="32" r="30" stroke="#FFB300" stroke-width="3"/>
              <line x1="32" y1="14" x2="32" y2="36" stroke="#1A2CA3" stroke-width="3.5" stroke-linecap="round"/>
              <path d="M32 36 Q22 44 14 50" stroke="#1A2CA3" stroke-width="3" stroke-linecap="round"/>
              <path d="M32 36 Q42 44 50 50" stroke="#1A2CA3" stroke-width="3" stroke-linecap="round"/>
              <path d="M32 40 Q26 46 20 52" stroke="#1A2CA3" stroke-width="2.5" stroke-linecap="round"/>
              <path d="M32 40 Q38 46 44 52" stroke="#1A2CA3" stroke-width="2.5" stroke-linecap="round"/>
            </svg>
          </div>
          <p>Exposed roots</p>
        </div>

        <div class="warning-card">
          <div class="warning-icon">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" fill="none">
              <circle cx="32" cy="32" r="30" stroke="#FFB300" stroke-width="3"/>
              <rect x="20" y="16" width="24" height="32" rx="4" stroke="#1A2CA3" stroke-width="3"/>
              <ellipse cx="32" cy="32" rx="8" ry="10" stroke="#1A2CA3" stroke-width="2.5" stroke-dasharray="4 3"/>
            </svg>
          </div>
          <p>Hollow sections</p>
        </div>

        <div class="warning-card">
          <div class="warning-icon">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" fill="none">
              <circle cx="32" cy="32" r="30" stroke="#FFB300" stroke-width="3"/>
              <rect x="22" y="14" width="20" height="36" rx="3" stroke="#1A2CA3" stroke-width="3"/>
              <path d="M22 24 Q14 26 16 34 Q14 38 22 38" stroke="#1A2CA3" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
              <path d="M22 28 Q18 30 19 34" stroke="#FFB300" stroke-width="2" stroke-linecap="round"/>
            </svg>
          </div>
          <p>Peeling bark</p>
        </div>

      </div>
    </div>
  </div>

</section>