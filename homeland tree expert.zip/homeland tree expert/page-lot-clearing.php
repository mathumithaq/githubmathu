<?php
/* Template Name: Lot Clearing */

get_header();
?>

<section class="service-hero" 
data-bg="https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=1400">

    <div class="container">

        <div class="service-content">

            <span class="service-tag">Land Preparation Experts</span>

            <h1>Lot Clearing Service</h1>

            <p>
                Duis aute irure dolor in reprehenderit in voluptate velit esse
                cillum dolore eu fugiat nulla pariatur.
            </p>

            <a href="/contact" class="service-btn">
                Get Quote
            </a>

        </div>

    </div>

</section>

<?php get_footer(); ?>